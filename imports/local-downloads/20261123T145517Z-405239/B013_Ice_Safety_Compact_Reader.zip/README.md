# B013 — Minnesota Ice Safety · Field Pilot 01

**Use B013_ICE_SAFETY_OFFLINE_READER.html**. Open it directly in Chrome or Firefox, even without internet. Use Previous/Next or the page dropdown.

Eight field draft pages P01–P08; 18-page chapter map and 108 visual requirements (six per planned page). No source/claim records in reader; those are separate. Authentic photo needs remain unfilled. No PDF viewer required.

**Warning:** The scenic illustrations are AI generated and not evidence of what safe or unsafe ice looks like. Do not use an illustration to decide whether to cross real ice. This is a draft, not a certified rescue manual.

Files: B013_PAGE_MAP.csv, B013_VISUAL_ASSET_REGISTER.csv, B013_EDITABLE_PAGE_CONTENT.json, B013_SOURCE_REGISTER.csv, B013_EVIDENCE_AND_REVIEW.md, illustration JPEGs and build source.
Gate A BLOCKED. Publication NOT AUTHORIZED. No Git repository changes.
