# B013 — Research, Image Rights & Review Ledger

**Scope:** Eight-page B013-1 illustrated draft. The original B012 28-page offline reader remains unchanged. No modification to /home/jd/Survival_Guide; Gate A BLOCKED; publication NOT AUTHORIZED.

## Source hierarchy
1. Minnesota DNR current ice-safety pages for local conditions, self-rescue, rescue bystanders, gear, and ice thickness.
2. 2024 AHA / Red Cross first-aid guidelines for cold exposure and treatment of an impaired person.
3. U.S. Coast Guard cold-water guidance for early cold-shock breathing and rapid loss of movement. These are risk models, not individual survival guarantees.

## Non-negotiable safety rules
- **Never rely on appearance, tracks, animal trails, one check, or a stick to certify ice.** New clear ice minimum of 4 inches for on-foot *consideration* under MN DNR guidance, not a promise.
- **No-measurement/no-rescue-equipment scenarios default to staying off the ice.** Ice fishing without an auger, chisel and measuring equipment must not encourage improvised breaking of unknown ice.
- **Self-rescue:** keep clothes on, turn toward route of approach, lay arms on edge, kick horizontally, pull out, roll away and seek warmth/medical evaluation.
- **Bystander:** call 911; encourage and reach/throw from safety. A layperson should not run onto weak ice.
- **Post immersion:** prevent further heat loss, protect the core and handle gently. Altered alertness, abnormal breathing or continued cold exposure require urgent professional assistance. Do not use hot showers or heat/rubbing on extremities for impaired hypothermia.
- **No numerical thickness applies to old, white, thawed, current-affected, flooded, or variable ice as a guarantee.**

## Editorial deviations avoided
- No generic "safe ice" or "look for blue ice" claims.
- No prescriptive spacing claimed to ensure safe travel.
- No manufactured emergency rescue gear depicted as universally available.
- No instructions to weaken ice, chop unknown holes, or approach thin ice to save a pet.
- No AI illustration treated as true ice-condition identification or evidence of a successful rescue.

## Visual provenance
- ICE-STAGED-01–06 are cropped from original AI-generated illustrative composite; deliberately labeled **STAGED** on each reader page.
- All 18 pages have individual requirements for authentic photographs and review in B013_VISUAL_ASSET_REGISTER.csv.
- No outside images downloaded or redistributed. Real photography, specific license, original hashes, and trained ice-rescue specialist signoff remain outstanding.

## Human review gates
- Registered ice safety/rescue instructor: P05–P08 action, diagrams, gear and drill realism.
- Emergency/wilderness medical reviewer: P06 and P08 medical and hypothermia language, P07 victim handling.
- Minnesota water-safety / field specialist: ice morphology and route-risk photos, seasonality and local exceptions.
- Owner and editorial: all layout claims, figure captions, accessibility, source attribution in separate companion resource guide.
- Release: Gate A approval plus later research/content/image/rights gates required.

## Content and visual QA evidence
The generation script produces source records, page map, provenance/status ledger and unique asset IDs. Browser viewport tests are required before accepting reader delivery.

## Regional publication caveat
Minnesota DNR references are guidance and may update; recheck current agency pages and emergency instructions before final publication. Research date: 2026-11-22.
