# B013-2 Evidence and review ledger

**Status:** Six reader-page drafts P09–P14. The combined reader also includes unchanged content P01–P08 as previously delivered. This is not a field-tested reference or approved survival instruction. Gate A remains BLOCKED; publication NOT AUTHORIZED. No local Git changes or upload-back.

## Basis and claim scope
- P09 deteriorating spring/shore ice: Minnesota DNR official ice safety, formations, and "Danger! Thin Ice" guidance. Older, partially thawed ice can be weaker than new ice even when thick. No thickness guarantee.
- P10 snow/overflow: Minnesota DNR ice formations and conditions plus DNR snow-insulation note. Snow cover can conceal surface conditions and slow freezing. No strength claim based on a hard crust.
- P11 variation: Minnesota DNR new clear ice guideline (4 inches on foot as a general guideline only); ice thickness can vary widely within one water body. No transfer of the 4-inch threshold to old, white, spring, or current-affected ice.
- P12 children and pets: NWS winter awareness recommends keeping children away from frozen ponds and streams; MN DNR specifically warns not to risk a life attempting to save a pet.
- P13 emergency calling: MN DNR calls for 911 first for fallen-in persons, and recommends cell phone in waterproof case / PLB if available; request for location, accessible road and landmarks is practical incident-reporting guidance, not a claim of guaranteed network coverage.
- P14 practice: dry-land, supervised throw/reach practice is a safety-oriented training proposal, not a documented certified drill protocol. Requires registered ice-rescue instructor review for mechanics, safety, and language before field publication. No dangerous on-ice exercise is prescribed.

## Image integrity
- Staged composite images are AI-generated scene illustrations. They are not genuine ice-identification or documented rescue-practice photographs.
- Six original SVG diagrams are explanatory. Structural geometry is not to scale, and no diagram certifies real ice strength.
- 24 authentic diagnostic/process photographs are specified as NOT_ACQUIRED in the visual manifest; licensing and expert checks pending.

## Review gates
1. Minnesota ice-rescue instructor: P11 and P14, diagrams, bystander reach/throw practices, caveats.
2. Water safety educator: P09/P10/P12 real ice morphology, child/pet safety.
3. Emergency-responder/public safety reviewer: P13 dispatch/communication guidance and local practice.
4. Licensed image rights and photo-identity reviewer: 24 required real photograph slots.
5. Owner: Gate A engineering decision and subsequent research/safety/layout approvals; no automatic publication.

## Explicit exclusions
- No specific household-child distance, ice thickness measurement on spring ice, or technique for walking out to test unsafe ice.
- No layperson instructions for approaching unknown ice to perform a rescue or for training on live ice.
- No claim that a visible image can certify ice or water safety.
