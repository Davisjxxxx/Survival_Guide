# Browser verification

- Tested Chromium headless on 2026-11-22.
- Standalone 6-page and combined 14-page readers were loaded as self-contained HTML in Chromium (no network), using `page.set_content` because direct `file://` URLs are blocked in this environment.
- Both desktop (1350 px) and mobile (390 px) were checked for every selectable page.
- Total 40 page-views: correct one-page selection, image loaded, SVG present, no horizontal overflow.
- Six desktop page captures and one mobile capture included for visual review.
- This is rendering QA, not procedural, image-identity, or field-performance certification.
