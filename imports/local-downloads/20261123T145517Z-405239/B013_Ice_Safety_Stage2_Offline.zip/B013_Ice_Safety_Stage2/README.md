# B013-2 Minnesota Ice Safety — six new pages, combined 14-page offline draft

## Open first
- `B013_14_PAGE_OFFLINE_READER.html` — **all pages P01–P14 in one file**, staged scenes included, no internet/PDF viewer needed.
- `B013_2_SIX_PAGE_READER.html` — **P09–P14 only**, also self-contained.

## Records (not included on book pages)
- `B013_2_SOURCE_REGISTER.csv` — original official source URLs, attribution, review date.
- `B013_2_VISUAL_ASSET_REGISTER.csv` — 36 asset rows: 6 staged images, 6 vector diagrams, 24 required real photographs.
- `B013_2_PAGE_MAP.csv` — page coverage.
- `B013_2_EVIDENCE_AND_REVIEW.md` — outstanding verifications and controls.
- `SHA256SUMS.txt` — file checksums.

No real photographs were acquired. No field trials or independent ice rescue approval. P15–P18 remain for B013-3. Gate A BLOCKED; no publication. Only the encyclopedia project was touched.
