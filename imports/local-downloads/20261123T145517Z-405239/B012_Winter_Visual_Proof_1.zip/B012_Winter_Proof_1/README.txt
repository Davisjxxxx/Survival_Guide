B012-1 · Winter Survival Visual Evidence Proof

1. Extract the ZIP to any folder OUTSIDE the Survival_Guide Git repository.
2. Open index.html in Chrome or another browser. All illustrations and diagrams work offline.
3. See EDITORIAL_EVIDENCE.md for source and approval restrictions.
4. PHOTO_ACQUISITION_BATCH.csv contains first real-photo candidates; NO actual real photographs are bundled.
5. The companion spreadsheet is an UPDATED COPY of the original B012 register with two additional tracking sheets; original pages and assets are preserved.

This is a six-page production proof, not the full 28-page chapter. Staged imagery is explicitly not field testing.
