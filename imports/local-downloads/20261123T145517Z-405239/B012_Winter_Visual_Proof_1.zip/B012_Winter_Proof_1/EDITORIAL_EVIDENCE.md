# B012-1 editorial and evidence record

Status: **research/proof only; not approved or ingested**. Local repository remains untouched.

## Source-backed claims

- NWS outdoor winter storm guidance: shelter, keep dry, cover exposed body parts, windbreak and snow-melt precautions. https://www.weather.gov/safety/winter-during
- CDC hypothermia recognition: shivering, confusion, fumbling hands, slurred speech, drowsiness; immediate care. https://www.cdc.gov/winter-weather/prevention/
- CDC frostbite guidance: protect exposed skin; avoid direct heat or rubbing. https://www.cdc.gov/winter-weather/prevention/preventing-frostbite.html
- Minnesota DNR winter ice: ice appearance alone cannot confirm safe conditions. https://www.dnr.state.mn.us/safety/ice/index.html
- Minnesota DNR winter ground exposure: sitting directly on frozen/snowy surfaces increases ground heat loss. https://www.dnr.state.mn.us/picnic/index.html
- MN DNR general state-forest risk controls: overhead hazards, weather, map, resources. https://www.dnr.state.mn.us/state-forests/safety.html

## Visual provenance

Staged concept sequence: AI-generated in this research session on 2026-11-21. Divided into six JPEG panels. It is not a real participant, a field test, or specimen evidence. It includes a sleeping bag in some frames: those frames demonstrate the *equipped upgrade*, not a no-equipment baseline. All SVG diagrams are newly authored editorial diagrams requiring review.

## Gate boundaries

P01 and P04: medical/winter SME. P09: regional/structural. P10-P12: structural and winter survival. No field measurement, thermal performance, roof strength, or winter field trial is represented. Winter snow shelters and enclosed combustion are excluded from this preview. Specialist approval, real photo acquisition and rights verification remain pending.

## First proofs vs full inventory

Original B012 workbook: 28 pages, 143 specified visual assets. This research proof directly drafts six reader-page concepts (P01, P04, P09, P10, P11, P12) with 6 staged photo illustrations and 5 original SVGs. **0 confirmed real-photo originals acquired**. The photographic source leads in PHOTO_ACQUISITION_BATCH.csv are publicly indexed candidate assets, not accepted production photography.
