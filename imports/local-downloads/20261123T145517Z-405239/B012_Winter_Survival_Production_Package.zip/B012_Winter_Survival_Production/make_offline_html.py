from pathlib import Path
import csv,html
r=Path('/mnt/data/B012_Winter_Survival_Production')
def rows(n):
 with (r/n).open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f))
ps,ss=rows('B012_PAGE_MAP.csv'),rows('B012_SOURCE_REGISTER.csv')
e=html.escape
parts=[]
for p in ps:
 n=int(p['page']); status='Advanced only' if n in (16,17) else ('Medical review' if n in (7,8,24,25) else 'Research draft')
 parts.append(f'''<details class="page" id="p{n:02d}"><summary><span class="num">P{n:02d}</span><span>{e(p['section_title'])}</span><span class="pill">{status}</span></summary>
 <div class="detail"><p class="goal">{e(p['reader_job'])}</p><div class="tiers"><div><b>01 · NOTHING</b><p>{e(p['no_equipment'])}</p></div><div><b>02 · IMPROVISED</b><p>{e(p['improvised'])}</p></div><div><b>03 · EQUIPPED</b><p>{e(p['equipped'])}</p></div></div>
 <div class="assetgrid"><p><b>REAL HERO PHOTO</b>{e(p['real_photo_required'])}</p><p><b>REAL PROCESS CLOSE-UP</b>{e(p['process_closeup_required'])}</p><p><b>DIAGRAM / CUTAWAY</b>{e(p['diagram_or_cutaway'])}</p><p class="bad"><b>FAILURE → CORRECTION</b>{e(p['failure_correction_plate'])}</p></div><p class="meta">Expert review: {e(p['review_specialists'].replace(';',', '))} · Evidence: {e(p['source_ids'].replace(';',', '))}</p></div></details>''')
source=''.join(f'<tr><td>{e(s["source_id"])}</td><td>{e(s["organization"])}</td><td><a href="{e(s["url"])}" target="_blank" rel="noopener">{e(s["title"])}</a></td><td>{e(s["category"])}</td></tr>' for s in ss)
css='''
*{box-sizing:border-box}body{margin:0;background:#f0ede4;color:#18291b;font:15px/1.55 system-ui,-apple-system,Segoe UI,sans-serif}
header{background:#143822;color:#fff;padding:26px max(20px,calc((100vw - 1080px)/2)) 30px}header h1{margin:0;font-size:clamp(24px,4vw,40px);letter-spacing:-.6px;line-height:1.12}header p{opacity:.88;margin:12px 0}
main{max-width:1100px;margin:0 auto;padding:24px 16px 65px}.meta-note{font-size:13px;border-left:4px solid #9b7334;background:#fff8e9;padding:13px;margin:0 0 20px}
.stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;margin:18px 0}.stats div{background:white;padding:12px;border-radius:9px;border:1px solid #e2ded2}.stats strong{display:block;font-size:24px;color:#17462d}.stats span{font-size:12px;color:#526355}
.page{border-radius:10px;overflow:hidden;margin:8px 0;background:white;border:1px solid #ccd6c8;break-inside:avoid}summary{display:flex;gap:12px;align-items:center;cursor:pointer;padding:13px 15px;font-weight:750;min-height:55px}summary:hover{background:#f1f7ef}.num{background:#1e5132;color:white;border-radius:5px;font-size:12px;padding:5px 7px;min-width:40px;text-align:center}.pill{margin-left:auto;font-size:11px;padding:3px 8px;border:1px solid #c0c9bc;border-radius:12px;white-space:nowrap;color:#6b6658}
.detail{border-top:1px solid #e5e8df;padding:13px 15px 18px}.goal{font-weight:600;margin:0 0 13px}.tiers{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}.tiers div{background:#f1f5ef;border-radius:7px;padding:11px}.tiers b{color:#315741;font-size:12px}.tiers p{margin:6px 0 0}.assetgrid{display:grid;grid-template-columns:repeat(2,1fr);gap:8px;margin:13px 0}.assetgrid p{padding:10px;background:#f6f3ea;border-radius:6px;margin:0}.assetgrid b{display:block;font-size:11px;letter-spacing:.6px;margin-bottom:4px;color:#345a42}.assetgrid .bad{border-left:3px solid #9d3c2e}.meta{font-size:12px;color:#5c675d;margin:14px 0 0}
section h2{font-size:21px;margin:25px 0 12px}.source-wrap{overflow-x:auto;background:white;padding:10px;border-radius:8px;border:1px solid #ccd6c8}table{border-collapse:collapse;width:100%;font-size:12px}td,th{padding:8px;text-align:left;border-bottom:1px solid #edf0ed}th{background:#edf2ee}a{color:#19613a}footer{font-size:12px;color:#627264;margin-top:24px}
@media(max-width:720px){.stats{grid-template-columns:repeat(2,1fr)}.tiers,.assetgrid{grid-template-columns:1fr}summary{flex-wrap:wrap}.pill{margin-left:0}}
@media print{header{-webkit-print-color-adjust:exact;print-color-adjust:exact}.page{break-inside:avoid}details:not([open]) .detail{display:block}summary{list-style:none}}
'''
page='''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>B012 | Minnesota Winter Survival Production Brief</title><style>'''+css+'''</style></head><body>
<header><h1>WINTER SURVIVAL<br>Minnesota / Upper Midwest</h1><p>Track B012 · Page-by-page production blueprint · Offline readable</p></header>
<main><div class="meta-note"><strong>RESEARCH / PRODUCTION ONLY.</strong> No photographs acquired, no human field validation or specialist approval, no publication authority. Gate A remains blocked. This file is a visual production specification, not an operational field manual.</div>
<div class="stats"><div><strong>28</strong><span>Planned reader pages</span></div><div><strong>143</strong><span>Planned asset slots</span></div><div><strong>80</strong><span>Real-photo slots</span></div><div><strong>0</strong><span>Images acquired / approved</span></div></div>
<section><h2>Page-by-page production map</h2>'''+ '\n'.join(parts) + '''</section><section><h2>Source register (repo companion)</h2><p>Evidence and approval records stay outside the eventual reader pages. These are preliminary sources, not proof of technical validation.</p><div class="source-wrap"><table><thead><tr><th>ID</th><th>Agency</th><th>Title</th><th>Class</th></tr></thead><tbody>'''+source+'''</tbody></table></div></section><footer>Survival Field Encyclopedia · B012 production package · S00–S15 master roadmap unchanged</footer></main></body></html>'''
(r/'B012_Production_Brief_Offline.html').write_text(page,encoding='utf-8')
print('HTML',len(page),'chars')
