import csv, collections, json, hashlib, pathlib, textwrap, datetime, zipfile
ROOT=pathlib.Path('/mnt/data/B012_Winter_Survival_Production')
PAGES=[
# num, title, purpose, no gear, improvised, equipped, hero photo, process photo, diagram, failure, review, sources
(1,'Winter emergency: first 10 decisions','Identify priorities before losing dexterity, daylight or mobility.','Stop; check for injury, wetness, wind, terrain and shelter options; signal if possible.','Use clothing or found materials to cover exposed skin and reduce wind.','Use emergency communication, weather data and insulation kit.','Winter forest survivor at exposed site, ground and canopy visible','Hands shielding exposed face and checking wet clothing','Exposure decision ladder: STOP > shelter/dryness > ground insulation > rescue','Continuing into whiteout or ice instead of stabilizing','WINTER_FIELD; MEDICAL','S01;S02;S03;S09'),
(2,'Scenario selection: lost, wet, stranded, separated','Distinguish different winter emergencies.','Choose shelter-in-place vs travel based on actual conditions, avoiding lakes and open water.','Use known tracks, existing vehicle/building, reflective salvage.','Activate beacon, phone, vehicle signals and mapped route if reliable.','Four real Minnesota scenarios showing different terrain','Actual snow obstruction and wind-driven drift','Decision tree: lost / wet / injured / stranded car','Leaving a protected vehicle without a justified reason','WINTER_FIELD; NAVIGATION','S03;S04;S09'),
(3,'Read Minnesota winter hazards','Recognize sudden temperature/wind and visibility changes.','Look for wind direction, drifting snow, icy crust and wet ground; do not trust ice surfaces.','Use a simple wind streamer or recovered weather radio.','Use NWS forecast, measured temp/wind, alerts.','Clear woods vs wind-scoured clearing under snowfall','Ground blizzard blowing snow near forest edge','Wind, cold, precipitation, visibility hazard map','Assuming no new snowfall means no blizzard risk','REGIONAL; WINTER_FIELD','S03;S04;S08'),
(4,'Cold mechanics and body heat','Recognize conduction, convection, evaporation and radiation without misleading percentages.','Seek dry insulating layers; lift body from frozen/wet ground; block wind.','Use layered clothes, paper, dry leaves in an isolated pocket (not wet material against skin).','Use purpose-designed insulation, vapor/wind shell and sleeping pad.','Real winter ground-contact site with visible wet patch','Close-up wet cotton vs dry layered fabric','Four paths of heat loss with correct labels','Lying directly on snow; enclosing moisture against skin','WINTER_FIELD; MEDICAL','S01;S02;S05'),
(5,'Clothing: keep dry, limit sweat','Prevent sweat-induced chilling.','Slow exertion; loosen openings during work; close and cover when stopped.','Use dry recovered textile as removable layer; improvise wind barrier without trapping sweat.','Adjust wicking base layers, insulation and breathable shell.','Wet vs dry clothing and winter woodland setting','Glove adjusting collar and venting layered clothing','Activity > ventilation > dry rest cycle','Overheating while digging; delayed layer adjustment','WINTER_FIELD; MEDICAL','S02;S05'),
(6,'Feet, hands, socks and overnight freezing','Preserve function and avoid sweat/wet boot problems.','Keep hands covered using available fabric; separate wet material from dry insulating bedding.','Use replacement socks/fabric wrapping, keep footwear sheltered from precipitation.','Dry spare socks, mitts, boot liners and insulated footwear.','Boots, mittens, wet socks and dry replacement at winter camp','Close-up wetted boot cuff and frost developing','Foot checks / cold injury / boot management sequence','Leaving wet socks or boots to freeze without a contingency','WINTER_FIELD; MEDICAL','S02;S06'),
(7,'Recognize hypothermia early','Identify behavior changes that demand rescue and warming.','Watch shivering, clumsiness, confusion and slurred speech; prioritize shelter and emergency help.','Buddy checks and dry available insulation.','Use emergency communication and medically appropriate rewarming support.','Non-graphic winter rescue-training scene showing assistance','Hands fumbling at closures in cold training scene','Recognition triage: alert > impaired > unconscious','Assuming absence of shivering means recovery','MEDICAL; RESCUE','S01;S06'),
(8,'Recognize frostbite and protect tissue','Recognize at-risk skin without relying on color alone.','Protect numb or firm skin from further freezing; do not rub or apply direct flame.','Use dry gentle insulation; avoid re-freezing if rewarming is considered.','Seek professional medical assessment; follow approved rescue protocol.','Real, permission-cleared non-graphic frostbite demonstration photo','Gloves protecting face, fingertips and ears in high wind','Frostbite signs + do-not-rub warning graphic','Rubbing, direct heat, or rewarming then refreezing','MEDICAL','S01;S06'),
(9,'Choose a winter shelter site','Select safe ground with drainage, timber and ice hazards addressed.','Inspect overhead dead limbs, spring seepage, frozen stream/lake, wind exposure.','Use fallen timber and existing windbreaks without damaging live trees.','Consult terrain data and shelter equipment placement.','Overhead widowmaker vs open safe winter woodland clearing','Snow crust and possible overflow in low area','Site rejection map: overhead / drainage / ice / wind','Building in drainage channel, below unsupported branches','WINTER_FIELD; STRUCTURAL; REGIONAL','S03;S08;S10'),
(10,'Immediate windbreak from nothing','Reduce wind exposure quickly without complex construction.','Use terrain, boulder or sound fallen log; arrange dead branches as windbreak without enclosing self unsafely.','Use salvaged cloth/panels against reliable support.','Use tarp or compact windbreak with correct tie-offs.','Real downed tree wind shadow vs exposed clearing','Hands positioning naturally fallen branches','Wind vector and occupant position behind barrier','Building brittle wall that falls onto occupant','WINTER_FIELD; STRUCTURAL','S03;S10'),
(11,'Natural insulated sleeping platform','Prevent direct ground/snow contact.','Use safe dry dead leaves/needles, boughs already fallen, bark or other sound debris, layered to keep loft.','Use dry fabrics, paper or salvage materials above ground.','Use sleeping pad / winter-rated bag.','Real ground mat of dry fallen material on dry winter substrate','Close-up compressed vs lofted dry leaf layer','Cross-section: person/insulation/ground and thermal bridge','Thin compressed bed and wet bedding','WINTER_FIELD; STRUCTURAL; REGIONAL','S02;S10'),
(12,'Winter debris hut: conditional build','Show a low-volume enclosed debris shelter without false guarantees.','Select sound deadfall; stable small frame; plentiful dry debris only if time/energy allow.','Add recovered cordage and waterproof sheet if present.','Use an insulated tent if available instead of long build.','Real completed leaf/snow debris hut (field-tested proof needed)','True construction sequence showing stable frame ribs','Frame/load/insulation cross-section; no fire inside','Unstable ridgepole; thin roof; damp floor; blocked exit','WINTER_FIELD; STRUCTURAL','S03;S10'),
(13,'Natural winter A-frame alternatives','Demonstrate branch ribs and layered weather barrier as conditional option.','Use fallen wood, overlapping dead brush/bark; assess snow load and stability.','Use salvage straps or cloth for connections.','Use tarp shelter with rated snow support only if designed for it.','Real completed woodland A-frame with snow exposure','Close-up branch rib spacing and anchor contact','Roof-shedding and snow-loading cutaway','Overloaded roof collapses; wet material touches sleeper','STRUCTURAL; WINTER_FIELD','S03;S10'),
(14,'Lean-to and sheltered fire separation','Compare windbreak/open shelter without heat claims.','Build stable windbreak from deadfall; position outdoor fire only if feasible and allowed.','Use cloth/tarp for wind-facing protection.','Use ventilated designed shelter and legal fire site.','Real lean-to in snow with fire physically outside','Actual shelter clearance from fire and wind direction','Clearance/combustion warning map; not inside enclosure','Melted snow roof, sparks, smoke through sleep zone','STRUCTURAL; FIRE_SAFETY; REGIONAL','S03;S10;S11'),
(15,'Snow trench: decide before digging','Explain conditions for a shallow conditional winter shelter.','Compare available snow depth, snow cohesion, effort, stability and dry bedding; avoid unsuitable snow.','Use found panel as roof only when support is sound and not overhead hazard.','Use shovel and structural check where trained.','Real snow-trench build in suitable snow on safe flat ground','Close-up snow-wall stability inspection','Entry/exit/ventilation and roof load schematic (no fixed unverified dimensions)','Roof failure, saturated bedding or excavation exhaustion','WINTER_FIELD; STRUCTURAL; SNOW_SPECIALIST','S03;S10'),
(16,'Snow cave / quinzhee: advanced only','Make expertise and environmental prerequisites explicit.','No untrained emergency dig recommendation; use lower-risk windbreak if conditions uncertain.','Show conditional snow mound and partner safety checklist conceptually.','Qualified instruction, proper tools, stabilization and surface monitoring.','Real trained snow-cave/quinzhee inspection and entrance','Actual roof inspection; snow grain/consolidation view','Hazard cutaway: collapse, vent, drift, egress; no combustion','Unsafe overhead load or entry blocked by new snow','SNOW_SPECIALIST; RESCUE; STRUCTURAL','S03;S10'),
(17,'Semi-subterranean winter shelters: not a default','Evaluate earth/stone ideas without publishing unsupported construction.','Do NOT instruct unsupported digging or stone roof; assess flood/frost/soil collapse risk.','Use existing safe structure or stabilized above-ground alternatives.','Engineered excavation/roof only for longer-term project with site assessment.','Real shallow winter excavation with cautionary framing','Actual water seepage and unstable ground close-up','Cross-section with collapse/flooding/CO risk flags, NOT instructions','Rock fireplace inside cavity; unsupported earth roof','ENGINEER; STRUCTURAL; FIRE_SAFETY','S03;S10;S11'),
(18,'Shelter moisture and ventilation','Avoid damp insulation, condensation and suffocation hazards.','Keep ventilation and exits clear; refresh wet insulating materials if possible.','Adjust coverings/openings; protect dry sleeping space.','Ventilate purpose-built shelter per manufacturer design.','Real frost/condensation and damp insulation examples','Close-up moisture bead and damp sleeping material','Air path / wet vs dry zones / exit visibility','Sealed shelter with combustion; moisture trapped at bedding','WINTER_FIELD; FIRE_SAFETY','S02;S10;S11'),
(19,'Fire on snow without an indoor hearth','Explain outdoor controlled fire feasibility, tinder and foundation.','Only if legal and safe: seek dry dead material, clear site and maintain distance from shelter.','Use found metal/cook vessel and tools if safe.','Use manufactured ignition and legal site, no enclosed burning.','Real outdoor winter fire in cleared controlled location','Close-up dry tinder stored off snow','Snow-melt/fuel platform schematic with safe support and no false load specs','Fire sinks into snow; exposed roots; sparks hit shelter','FIRE_SAFETY; REGIONAL','S03;S10;S11'),
(20,'Minnesota winter tinder and fuels','Identify dry standing/deadwood candidates without species misidentification.','Prioritize appropriate fallen dead wood where lawful; avoid wet rotten material.','Dry-shave sound wood using a recovered edge if safely available.','Use packed tinder and reliable lighter when present.','Real birch bark and dry standing twigs, diagnostic ID views','Deadwood cross-section showing wet exterior/dry interior','Tinder > kindling > fuel moisture workflow','Using saturated twigs, cutting live trees or collecting prohibited bark','BOTANIST; REGIONAL; FIRE_SAFETY','S10;S11'),
(21,'No fire: warming priorities and failover','Show what to do when ignition is impossible or too costly.','Stop futile effort; insulate body; reduce wind; conserve strength and signal for rescue.','Use dry fabrics, found shelter and safe body-to-body warmth with consent.','Use portable heat only as designed, no improvised indoor combustion.','Real non-fire winter windbreak and insulated person','Exhausted hands and damp tinder shown as stop cue','Decision tree: fire feasible? if not, stabilize and rescue','Persisting with bow drill while getting colder and wetter','WINTER_FIELD; MEDICAL; RESCUE','S01;S02;S03;S11'),
(22,'Snow-to-water: collection and melting','Prevent cooling from eating frozen snow; distinguish melt from disinfection.','Collect visibly clean snow away from tracks/contamination; no-fire option remains conditional.','Use found heat-safe vessel only if known safe and available.','Use stove and proper water-treatment technology.','Real clean vs dirty snow sampling sites','Actual snow melt in verified heat-safe vessel','Snow -> melt -> treatment -> protected storage sequence','Eating snow as hydration plan; runoff near roads','WATER_SAFETY; WINTER_FIELD','S03;S12'),
(23,'No vessel, no fire: hydration limits','State unsafe gaps honestly.','Recognize no natural filtration method guarantees safe winter drinking water.','Use found approved bottle and treatment options if available.','Use rated filter/chemical treatment following product instructions.','Real snow and unfrozen water near shoreline, hazard cues','Found bottle vs unverified bark cup and source rejection','Decision tree: source hazards > feasible treatment > no safe option','Assuming melted snow or sand filter is potable','WATER_SAFETY; REGIONAL','S12;S08'),
(24,'Emergency hypothermia response','Give a concise layperson response with expert review.','Call emergency services where possible; gentle handling; protect from exposure; use dry insulating layers.','Use warm protected shelter and dry blankets when available.','Follow current EMS guidance and transport to care.','Real rescue-team training, non-graphic subject','Wrapping torso and head with dry insulating material','Immediate response / medical aid / monitor graphic','Rough handling, direct flame or misleading reassurance','MEDICAL; RESCUE','S01;S06'),
(25,'Frostbite: prevent worsening','Present medically reviewed field limits.','Protect tissue; avoid rubbing or direct radiant heat; arrange evacuation.','Use dry loose protection; do not rewarm if likely to refreeze.','Medical evaluation and controlled warming by qualified care.','Clinically approved frostbite recognition photo, age appropriate','Safe protected gloved hand vs exposed fingertips','Frostbite decision with refreezing caution','Skin burns from stove/rock; forceful rubbing','MEDICAL','S01;S06'),
(26,'Signal and decide whether to stay or move','Give survivor an evidence-based rescue strategy.','Stay visible near last known safe point when weather/visibility make travel hazardous; signal.','Use reflective or contrasting found objects and track marking.','Beacon, phone, whistle, GPS and pre-shared route.','Real rescue-marker contrasting against snow, no false signals','Winter line-of-sight and forest clearing','Stay/move decision matrix with no blanket rules','Travelling into whiteout or unsafe lake to find fish','RESCUE; NAVIGATION; REGIONAL','S03;S09'),
(27,'Winter failure atlas: diagnose and correct','Create a compact two-page-like troubleshooting wall but readable on one spread page.','Recognize wet bed, heat loss, collapse risk, cold injury and water failure.','Switch to recoverable alternative using what exists.','Escalate to rated gear and rescue when available.','12 real controlled failure scenes, individually verified and consented','Close-ups of wet/failed materials and poor anchors','Cause > field symptom > stop/repair matrix','Misidentifying a high-risk emergency as minor discomfort','WINTER_FIELD; MEDICAL; STRUCTURAL','S01;S02;S03;S10'),
(28,'One-page winter decision reference','Provide a field-ready navigation index into other zones and emergency thresholds.','Assess: shelter/dryness/ground insulation, injury, water, visibility, rescue.','Check available materials before committing energy.','Use proper tools, communications and insulation upgrades.','Real field overview of winter woodland safe campsite','Real weather change comparison from local conditions','Full-flow survival priority map; links B013 ice, B014 navigation, Z10 medicine','Treating ice crossing or shelter excavation as routine options','WINTER_FIELD; RESCUE; NAVIGATION','S01;S03;S08;S09')]
assert len(PAGES)==28
SOURCES=[
('S01','CDC','Preventing Hypothermia','https://www.cdc.gov/winter-weather/prevention/index.html','Medical','Recognize confusion, shivering, impaired coordination; move to warm shelter and seek medical care'),
('S02','US Army','Cold Weather Injuries Peak in January, February','https://www.army.mil/article/282512/cold_weather_injuries_peak_in_january_february','Field/Medical','COLD layered/dry clothing principles and observable impaired behavior'),
('S03','National Weather Service','What To Do If You Are Caught in a Winter Storm','https://www.weather.gov/safety/winter-during','Winter field','Windbreak/shelter, snow melt, exposure; broad field guidance requiring specificity'),
('S04','National Weather Service','What Is a Ground Blizzard?','https://www.weather.gov/safety/winter-ground-blizzard','Regional','Severe visibility deterioration even without active snowfall'),
('S05','National Weather Service','Winter Weather Resources and FAQ','https://www.weather.gov/safety/cold-outreach','Medical / Prevention','Loose layers, vapor management, cold injuries'),
('S06','CDC','Preventing Frostbite','https://www.cdc.gov/winter-weather/prevention/preventing-frostbite.html','Medical','Protect affected areas, no rubbing or direct heat, medical care'),
('S07','Minnesota DNR','What if You Fall Through the Ice?','https://www.dnr.state.mn.us/safety/ice/survival.html','Ice safety','Reserve detailed self rescue for B013; B012 emergency routing'),
('S08','Minnesota DNR','Ice Safety','https://www.dnr.state.mn.us/safety/ice/index.html','Ice safety','No universally safe ice; context-dependent strength'),
('S09','National Weather Service','Winter Weather Warnings Watches and Advisories','https://www.weather.gov/safety/winter-ww','Regional / Rescue','Avoid travel in blizzard conditions; stranded vehicle priority'),
('S10','Minnesota DNR','State Forest Rules','https://www.dnr.state.mn.us/state-forests/rules.html','Regional law','Do not cut/remove living plants; permit rules for bark/boughs; downed campfire wood restrictions'),
('S11','CDC','Clinical Guidance: Carbon Monoxide Poisoning Following Disasters','https://www.cdc.gov/carbon-monoxide/hcp/clinical-guidance/index.html','Combustion','Burning fuel in enclosures is dangerous; no indoor improvised hearth'),
('S12','CDC','Making Water Safe in an Emergency','https://www.cdc.gov/water-emergency/about/index.html','Water','Treatment limits; source contamination; water clarification is not disinfection'),
('S13','U.S. National Park Service','North Cascades Winter Safety','https://www.nps.gov/noca/planyourvisit/winter-safety.htm','Terrain','Storm, avalanche and travel hazards vary by terrain'),
('S14','DVIDS / Minnesota Air National Guard','Air National Guard Security Forces Cold Weather Operations Course (Image 28)','https://www.dvidshub.net/image/8203189/air-national-guard-security-forces-hosts-cold-weather-operations-course','Photo lead','Equipped shelter training at Camp Ripley, identify specific image, verify restrictions'),
('S15','DVIDS / U.S. National Guard','720th Special Tactics Group Holds Cold-Weather Survival Training (Image 4)','https://www.dvidshub.net/image/7019307/720th-special-tactics-group-holds-cold-weather-survival-training','Photo lead','Actual snow shelter training photo, inspect for suitability and rights'),
('S16','National Guard','Minnesota Guard Trains Norwegian Youths','https://www.nationalguard.mil/News/Article/576662/minnesota-guard-trains-norwegian-youths/','Photo lead','Natural shelter training photo, verify depicted equipment and context'),
('S17','Minnesota DNR','Dispersed Camping in Minnesota State Forests','https://www.dnr.state.mn.us/state-forests/dispersed-camping.html','Regional law','No unauthorized trenching/digging, protect land'),
]
# CSV utility
def csv_write(name, fields, rows):
    with open(ROOT/name,'w',newline='',encoding='utf-8') as f:
        w=csv.writer(f); w.writerow(fields);w.writerows(rows)
pageheaders=['page','section_title','reader_job','no_equipment','improvised','equipped','real_photo_required','process_closeup_required','diagram_or_cutaway','failure_correction_plate','review_specialists','source_ids']
csv_write('B012_PAGE_MAP.csv',pageheaders,PAGES)
csv_write('B012_SOURCE_REGISTER.csv',['source_id','organization','title','url','category','relevance_or_caution'],SOURCES)
# All assets remain needed and have no invented photos.
assets=[]
source_by_page={p[0]:p[11] for p in PAGES}
for p in PAGES:
    n,title,job,zero,imp,equip,hero,process,diag,failure,review,source=p
    for suffix,kind,subject,caption,required,art_mode,verify in [
       ('R01','REAL_PHOTO',hero,'Recognition / conditions', 'YES', 'REAL_ONLY','Actual situation and region confirmed; visible hazard indicators valid'),
       ('R02','REAL_PROCESS_PHOTO',process,'Close-up / process','YES','REAL_PREFERRED','Mechanics match steps; no hidden support or unrealistic anatomy'),
       ('D01','VECTOR_DIAGRAM',diag,'Mechanism / decision', 'YES','VECTOR_PREFERRED','Mechanics and units independently checked'),
       ('F01','FAILURE_PLATE',failure,'Failure / correction', 'YES','HYBRID_REAL_OR_VECTOR','Physically credible failure with a specific safe correction')]:
        assets.append((f'B012-P{n:02d}-{suffix}',f'P{n:02d}',title,kind,art_mode,subject,caption,required,'NEEDED','NONE','NONE','NO','NO',review,source,verify,'NO_PUBLICATION'))
# Additional targeted material and diagnostic plate requirements
add_ons=[
(3,'REAL_PHOTO','Wind scour vs deep drift in adjacent forest','REAL_ONLY','REGIONAL; WINTER_FIELD'),
(4,'VECTOR_DIAGRAM','Compressed vs uncompressed insulation cross-section','VECTOR_PREFERRED','WINTER_FIELD'),
(5,'REAL_PHOTO','Fogged damp shell and synthetic dry layer side-by-side','REAL_ONLY','WINTER_FIELD'),
(6,'REAL_PHOTO','Wet sock ice buildup vs dry sock','REAL_ONLY','MEDICAL'),
(7,'REAL_PROCESS_PHOTO','Visible hand fumbling, safe staged medical training','REAL_PREFERRED','MEDICAL'),
(8,'REAL_PHOTO','Clinical frostbite on multiple skin tones with permission','REAL_ONLY','MEDICAL'),
(9,'REAL_PHOTO','Overhanging dead branch concealed under snow','REAL_ONLY','STRUCTURAL'),
(9,'REAL_PHOTO','Shoreline overflow/slush on apparently solid snow','REAL_ONLY','REGIONAL'),
(10,'VECTOR_DIAGRAM','Wind shadow behind boulder: flow field and body position','VECTOR_PREFERRED','STRUCTURAL'),
(11,'REAL_PROCESS_PHOTO','Actual dry fallen leaf/needle collection without live cutting','REAL_PREFERRED','REGIONAL'),
(11,'VECTOR_DIAGRAM','Thermal bridge from body to snow before/after bedding','VECTOR_PREFERRED','WINTER_FIELD'),
(12,'REAL_PROCESS_PHOTO','Ridgepole joint tested under load','REAL_PREFERRED','STRUCTURAL'),
(13,'REAL_PHOTO','Roof member failure from snow loading','REAL_ONLY','STRUCTURAL'),
(14,'REAL_PHOTO','Scorched tarp edge near fire: rejected condition','REAL_ONLY','FIRE_SAFETY'),
(15,'REAL_PHOTO','Actual roof test by trained instructor','REAL_ONLY','SNOW_SPECIALIST'),
(16,'REAL_PHOTO','Snow-cave collapse/unsafe entrance hazard (staged by professionals)','REAL_ONLY','SNOW_SPECIALIST'),
(17,'VECTOR_DIAGRAM','Unsupported earth roof collapse mechanism (not build plan)','VECTOR_PREFERRED','ENGINEER'),
(17,'REAL_PHOTO','Soil seepage/wet frozen excavation face','REAL_ONLY','ENGINEER'),
(18,'REAL_PHOTO','Condensation frost near improvised wall','REAL_ONLY','FIRE_SAFETY'),
(19,'REAL_PROCESS_PHOTO','Fire burning onto wet snow fuel platform','REAL_PREFERRED','FIRE_SAFETY'),
(20,'REAL_PHOTO','Paper birch bark diagnostic winter tree in Minnesota','REAL_ONLY','BOTANIST'),
(20,'REAL_PHOTO','Dry standing dead conifer twigs vs green live bough','REAL_ONLY','BOTANIST'),
(21,'VECTOR_DIAGRAM','Stop attempt decision when sweaty, wet, disoriented','VECTOR_PREFERRED','MEDICAL'),
(22,'REAL_PHOTO','Clean snow vs roadway snow contamination','REAL_ONLY','WATER_SAFETY'),
(23,'REAL_PHOTO','Unsafe open-water inlet under ice','REAL_ONLY','WATER_SAFETY'),
(24,'REAL_PROCESS_PHOTO','Dry layers wrapped around hypothermia training casualty','REAL_PREFERRED','MEDICAL'),
(25,'VECTOR_DIAGRAM','Refreezing decision and evacuation','VECTOR_PREFERRED','MEDICAL'),
(26,'REAL_PHOTO','High contrast snow rescue signal test from distance','REAL_ONLY','RESCUE'),
(27,'REAL_PHOTO','Documented compressed vs lofted sleeping pad/surface','REAL_ONLY','WINTER_FIELD'),
(27,'REAL_PHOTO','Documented roof sagging from moisture/snow load','REAL_ONLY','STRUCTURAL'),
(28,'VECTOR_DIAGRAM','Module links B013 ice B014 navigation Z10 medicine','VECTOR_PREFERRED','RESCUE'),
]
for n,kind,subject,mode,review in add_ons:
    number=sum(1 for a in assets if a[1]==f'P{n:02d}')+1
    suffix=f'X{number:02d}'
    assets.append((f'B012-P{n:02d}-{suffix}',f'P{n:02d}',PAGES[n-1][1],kind,mode,subject,'Additional visual', 'YES','NEEDED','NONE','NONE','NO','NO',review,source_by_page[n],'Visual and content review; no inferred performance','NO_PUBLICATION'))
asset_fields=['asset_id','page','section','asset_type','image_requirement','subject_and_capture','role','required','acquisition_status','file_path','source_url','rights_verified','subject_verified','specialist_review','source_ids','acceptance_criteria','publication_state']
csv_write('B012_ASSET_REGISTER.csv',asset_fields,assets)
# Photo leads are specific authoritative source pages; individual file ID and rights need checking.
leads=[
('B012-P12-R01','National Guard / military training','https://www.nationalguard.mil/News/Article/576662/minnesota-guard-trains-norwegian-youths/','Natural winter shelter example, confirm actual article/image selection','SOURCE_PAGE_ONLY','Individual image file, authorship, rights, subject verification required'),
('B012-P15-R01','DVIDS / U.S. Air Force','https://www.dvidshub.net/image/7019307/720th-special-tactics-group-holds-cold-weather-survival-training','Cold weather shelter training in Michigan','SOURCE_PAGE_ONLY','Confirm actual shelter details and DVIDS usage terms'),
('B012-P16-R01','DVIDS / U.S. military','https://www.dvidshub.net/image/7019307/720th-special-tactics-group-holds-cold-weather-survival-training','Alternative trained snow shelter photo, may be same reused lead','SOURCE_PAGE_ONLY','DO NOT use same photo as independent diagnostic views'),
('B012-P14-R01','DVIDS / 148th Fighter Wing','https://www.dvidshub.net/image/8203189/air-national-guard-security-forces-hosts-cold-weather-operations-course','Minnesota Camp Ripley equipped winter shelter','SOURCE_PAGE_ONLY','Publication rights and credited image metadata need inspection'),
('B012-P05-R02','NWS / winter weather education','https://www.weather.gov/safety/cold-outreach','Layering and winter clothes image leads','SOURCE_PAGE_ONLY','May contain externally credited figures; inspect each'),
('B012-P26-R01','Minnesota DNR','https://www.dnr.state.mn.us/safety/ice/survival.html','Cold water and emergency rescue image links for cross-reference B013','SOURCE_PAGE_ONLY','Rights and subjects not verified'),
]
csv_write('B012_REAL_PHOTO_LEADS.csv',['candidate_asset_id','source_owner','source_page_url','reason_to_inspect','current_status','next_validation'],leads)
# documentation
intro='''# B012 — Minnesota Winter Survival | Production Brief v1.0

**Status:** Track B preproduction research / visual authoring brief. **NOT** a finished reader chapter, field-tested manual, approved medical guidance, or publication authorization. **Master roadmap:** S00–S15 unchanged; this is Track B012, not an extra master sprint. **Gate A:** BLOCKED. **Local repository:** unchanged.

## Design contract

**Default assumption:** lost or stranded in Minnesota/Upper Midwest winter, minimal equipment, inadequate time, possible wet clothes, low dexterity. Start with safest feasible actions from what exists, improve with salvaged material, and show equipment-assisted upgrades separately. **No primitive replacement is promised where none is reliable.** Photos/diagrams serve the action, not atmosphere. Keep field-danger text visible on the reader page; put source/claim IDs and approval history in repo-side records.

Every reader page must have: **situation → goal → find/choose → 3–6 illustrated actions → verify → failure/correction → stop/escalate → optional upgrade**. Never show untested dimensions, fire clearances, snow-roof strength or presumed temperature gains as numerical facts. Use editable type, real diagnostic photographs, clear cutaways and human-reviewed mechanics.

### Sections and pagination

- **P01–P03:** immediate priorities, scenario selection, Minnesota winter hazards.
- **P04–P08:** heat loss, clothing, feet/hands, hypothermia, frostbite.
- **P09–P18:** shelter siting, windbreaks, natural bedding, debris huts, A-frames, lean-tos, snow shelters, excavation risks, moisture.
- **P19–P23:** outdoor fire, winter tinder, no-fire backup, snow water and no-container limits.
- **P24–P28:** medical response, frostbite, rescue decisions, failure atlas, field decision reference.

## 28-page production map

'''
rows=[]
for p in PAGES:
    n,title,job,zero,imp,equip,hero,process,diag,failure,review,src=p
    rows.append(f'''### P{n:02d} — {title}

- **Reader must be able to:** {job}
- **No equipment:** {zero}
- **Improvised:** {imp}
- **Equipped alternative:** {equip}
- **Primary REAL photograph:** {hero}
- **Second/sequence photograph:** {process}
- **Exact diagram/cutaway:** {diag}
- **Failure-and-fix panel:** {failure}
- **Review required:** {review.replace(';', ', ')}
- **Repo evidence pointers:** {src.replace(';', ', ')}
''')
footer='''
## Visual-production rules

1. **Real photo mandatory** for terrain/ice, snow structure conditions, natural bedding materials and cold-injury recognition; include acquisition context, location, date, authentic subject, permission and image-level credit.
2. AI images may **illustrate** controlled steps and cutaways, but cannot establish botanical species, roof stability, injury severity, thermal claims, or field-tested performance.
3. Every depicted sequence must survive a component/mechanics review. Human anatomy, snow depth, load path, wind direction and fire position may not change between steps without explanation.
4. Do not convert a conceptual drawing into an authoritative field build by adding dimensions it cannot substantiate.
5. All important on-page instructions use editable text; AI-rendered words, labels or numbers must not be trusted.
6. Each no-gear method has a **feasibility/energy and abort** gate. A cold survivor may be worse off after hours of unsuccessful construction.
7. Avoid the phrase 'safe ice' and reject lake/river travel as an automatic shortcut; cross-reference B013.
8. No stone fireplace, camp stove, charcoal, flammable fuel or open flame within an enclosed emergency snow/earth/debris shelter.
9. **Land status matters.** Minnesota DNR prohibits digging/trenching a state-forest dispersed campsite and requires permits for cutting/removing many trees/plants. No legal claims copied silently across land types.
10. Design for phone and print, with minimum readable caption sizes and accessible alt text; run page-image QA, version/errata identity and grayscale check before final release.

## Completion gates

- **B012-0 Brief:** 28 page requirements explicit; asset register and source links available. This is the milestone achieved here.
- **B012-1 Photo acquisition:** Required real photographs acquired with individual identity, rights, context and local checksum; no placeholder images passed as real.
- **B012-2 Illustrated authoring:** Editable reader text, correct cutaways and step sequences on every page; no fabricated performance claims.
- **B012-3 Independent review:** Winter survival instructor; rescue/medical; snow/structural SME for relevant pages; regional legal review; all material corrections tracked.
- **B012-4 Controlled ingestion:** Only after applicable Gate A and content policies accepted, with precise approval/evidence packet; no automatic publication.

## Known unsafe or unproven shortcuts to exclude

- Assuming underground/stone-lined shelters are warmer or safer without soil and roof engineering.
- Building an enclosed stone hearth to 'vent' smoke through a small opening; CO remains a fatal risk.
- Treating snow caves as a quick default with no assessment of snow stability or burial/collapse risk.
- Using moss/wet leaves as if dry loft; using live boughs without land-use permission.
- Teaching friction-fire success as guaranteed or allowing prolonged failed attempts while hypothermic.
- Using untreated snowmelt, clarity or improvised filters as proof of microbial safety.
- Giving DIY frostbite/hypothermia treatment instructions that override emergency assessment.

## Source basis and editorial limits

Evidence sources are in `B012_SOURCE_REGISTER.csv`. They support the broad hazard and field boundaries, **not** specific primitive-shelter dimensions, snow-load capacity, medical protocols or untested performance. Photo links in `B012_REAL_PHOTO_LEADS.csv` are leads, not photographs yet acquired or accepted. Each reader-facing claim must later have an exact source or field-test record in the controlled claim ledger.
'''
(ROOT/'B012_PRODUCTION_BRIEF.md').write_text(intro+'\n'.join(rows)+footer,encoding='utf-8')
gates='''# B012 Review and Field Validation Gates

| Gate | Required reviewer | Non-negotiable demonstration | Escalation |
|---|---|---|---|
| Winter techniques | Verified human winter field instructor | Complete photo sequence reproducible in controlled conditions; documented materials and conditions | Reject untested thermal/time guarantees |
| Medical pages 7–8,24–25 | Qualified human medical reviewer | Diagnosis and response aligned with current guidance; no contradictory rewarming or treatment steps | Hold medical pages for safety review |
| Snow/earth structures pages 15–17 | Experienced snow-shelter specialist and qualified structural reviewer as applicable | Snow condition, loading, egress, structural collapse/ventilation risks addressed | Keep as risk-comparison only pending approval |
| Fire pages 14,19–21 | Field instructor + fire safety reviewer | Outdoor clearance and ignition/handling reviewed; no indoor combustion | Block combustible-in-enclosure illustration |
| Water pages 22–23 | Water safety reviewer | Treating snow, microbial risk, and treatment limitations accurate | No safe water promise absent validated method |
| Rights/identification | Image-rights and subject reviewer | Actual photo files inspected; licensing, location and seasonal ID verified | Leave source leads in quarantine |
| Regional law | Minnesota public lands reviewer | Correct distinction among state parks, forests, private lands, emergencies | Do not assume permitted cutting or excavation |
| Mechanical visual QA | Technical editor | Every arrow, line, hand position, label, measurement and failure correction validated | Redraw rather than cover errors with caption |

**Status on creation:** ALL gates pending. No human expert sign-off was performed or implied.

## Field-test records to design before tests (not conducted)

For each physical shelter or fire/water process, capture: method ID, weather and actual temperature, precipitation, wind, substrate/snow condition, materials dry/wet condition, built dimensions, tools, duration, safety monitoring, controlled outcome, failure, evacuation/abort, videos, reviewer signature, and any restrictions. Never expose volunteers to avoidable cold-injury or enclosed combustion risk for a photo shoot.

## Reader page types

- Decision: two or three-tier solution matrix with safe refusal path.
- Build: hero photograph + staged step crops + connection diagram + failure pair.
- Recognition: real photos with diagnostic identifiers and uncertainty warnings.
- Medical: real medically reviewed recognition imagery + concise emergency triage; no AI lesion image as evidence.
- Failure: real failed scenario (controlled) paired with verified correction and abort trigger.
'''
(ROOT/'B012_REVIEW_GATES.md').write_text(gates,encoding='utf-8')
readme=f'''# B012 — Minnesota Winter Survival | Production Handoff

Produced: {datetime.date(2026,11,21).isoformat()}

- `B012_PRODUCTION_BRIEF.md`: 28 fully specified reader-page briefs, visuals, three build tiers, failure and review flags.
- `B012_PAGE_MAP.csv`: spreadsheet-ready page plan.
- `B012_ASSET_REGISTER.csv`: {len(assets)} planned photo / diagram / failure asset slots. **These are requirements, not acquired images.**
- `B012_SOURCE_REGISTER.csv`: {len(SOURCES)} reference/source leads used to frame safety and law.
- `B012_REAL_PHOTO_LEADS.csv`: {len(leads)} specific photographic source pages pending individual image acquisition and rights review.
- `B012_REVIEW_GATES.md`: human review and field-test gates.
- `B012_Winter_Survival_Asset_Register.xlsx`: formatted planning workbook for sorting/filtering (created separately).

**Master scope**: 16-zone encyclopedia unchanged. **Gate A**: BLOCKED. **Publication**: NOT AUTHORIZED. No local repository or user files were modified. All specialist reviews pending. No real photos downloaded. Artificial imagery is not a substitute for diagnostic photos or validated test evidence.
'''
(ROOT/'README.md').write_text(readme,encoding='utf-8')
print('PAGES',len(PAGES),'ASSETS',len(assets),'SOURCES',len(SOURCES),'PHOTO LEADS',len(leads))
