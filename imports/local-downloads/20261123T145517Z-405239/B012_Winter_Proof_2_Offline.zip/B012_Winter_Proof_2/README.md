# B012-2 Winter Shelter Decision Plates

Open `B012_2_SELF_CONTAINED_READER.html` in Chrome or Firefox. It is one file with inline CSS and vector diagrams; it requires no internet, PDF viewer or JavaScript.

`pages/P13.html` ... `pages/P18.html` are separately editable pages, using `assets/style.css`.

This package implements the **reader-page drafts only** for the existing P13–P18 entries in B012, not a fully photographed or tested chapter. The original 28-page plan and asset register are retained as copies for mapping and traceability. All natural-material photos are **missing** rather than fabricated.

No changes to `/home/jd/Survival_Guide` were made. Gate A remains blocked.
