# Track B 008 — Fire from the landscape: research and safety register

**Status:** EDITORIAL RESEARCH / STAGED ILLUSTRATIONS ONLY. No approvals; no content ingestion; no publication. Gate A remains blocked. This register is not a reader-facing book chapter.

## Evidence references and claims

| ID | Supported claim and boundaries | Source |
|---|---|---|
| FF-001 | Bow-and-handle friction fire offers a mechanical advantage over rotating a spindle between palms; it is not instant or guaranteed. | U.S. National Park Service, *Archaic Period*, https://www.nps.gov/articles/000/archaic-period-3-200-to-11-450-years-ago.htm |
| FF-002 | Bow-drill has hearth, spindle, bearing block, bow and tinder; the operator braces the bearing hand, uses bow strokes, watches for dark dust, transfers ember into tinder. | University of Colorado Museum of Natural History, *Fire Starting*, https://www.colorado.edu/cumuseum/programs/schools-and-groups/colorado-archaeology-classroom/fire-starting |
| FF-003 | A soft, dry hearth can be paired with a workable spindle; cottonwood hearth and use of shoelaces/cord as bowstring are described. Practitioner materials differ on preferred spindle hardness; do not prescribe one universal pair. | Scouting America, *Wilderness Survival* pamphlet, https://filestore.scouting.org/filestore/Merit_Badge_ReqandRes/Pamphlets/Wilderness%20Survival.pdf |
| FF-004 | Bow geometry, natural cord breakage risk, body positioning and ember-catching notch. Wood preparation and string tension must be adapted to materials. | Canadian Cadet Program, *Light Fires Using Improvised Ignition*, https://app.cadets.gc.ca/cadet-publications/A-CR-CCP-804-PF-001/section-20_5_en.html |
| FF-005 | Basswood/low-density aspen are native MN options. DNR tree ID describes aspen leaves, bark and wood as light/soft. Wood condition determines friction success. | Minnesota DNR, *Quaking aspen*, https://www.dnr.state.mn.us/trees/quaking-aspen.html; *Native trees*, https://www.dnr.state.mn.us/trees/native-trees.html |
| FF-006 | Basswood inner bark is a traditional cordage fiber; do not take bark from living trees without permission. | USDA NRCS, *Basswood Plant Guide*, https://plants.sc.egov.usda.gov/DocumentLibrary/plantguide/pdf/cs_tiamh.pdf; USFS, *A Lesson in Trees: American Basswood*, https://research.fs.usda.gov/download/treesearch/14126.pdf |
| FF-007 | Fire risk and restrictions vary by jurisdiction/date. County/regional hazard checks needed; a restriction on debris burning is not necessarily the same as recreational campfire ban. | Minnesota DNR, *Fire danger and burning restrictions*, https://www.dnr.state.mn.us/forestry/fire/firerating_restrictions.html; *Burning permit information*, https://www.dnr.state.mn.us/forestry/fire/questions.html |
| FF-008 | No open flames in tents or enclosed shelters; manufactured fuels or accelerants have separate safety requirements. | Scouting America, *Chemical Fuels and Equipment*, https://www.scouting.org/health-and-safety/gss/gss06/ |
| FF-009 | Hearth notch must collect fine hot wood dust; correctness and difficulty depend on materials and technique. | University of Colorado Museum, above; Canadian Cadet Program, above. |

**Unverified / not claim evidence:** Real-life success rate, guaranteed wood pair, any precise ember timing, species identity of AI-generated material images, adequacy of natural-fiber bowstrings under load, durability of knots, specific drying moisture percentages, and subjective estimates of calories or effort. No field tests have been supplied.

## Critical editorial corrections made

- Rejected earlier AI composite statements that treated iron-and-stone ignition as a universal *no-gear* method. Conventional flint-and-steel requires a suitable steel striker, not merely any stone.
- Did not repeat unsupported claims about solar still yield, water filtering, or termite mounds.
- Kept pine/spruce resin and fatwood as **flame extenders / fuel aids**, not equivalent to watery tree sap and not appropriate as guaranteed friction hearth stock.
- Did not present a hand drill as an easy fallback when a bowstring breaks. Hand drill requires suitable dry stalk, hearth, skill and endurance.
- Used **staged AI images for the mechanics only**, labeled as draft. No AI image is species-identification evidence.
- No photos of specific Minnesota trees are embedded yet. The reader page describing them must not be used for positive tree identification until the real photo plate is independently checked and installed.
- Condensed mechanics and failure checks into 14 printed pages, keeping this detailed evidence register outside the book.

## Required next verification

1. Have a qualified outdoor-skills practitioner build and operate a bow drill using selected Minnesota wood pairs; record date/location, moisture conditions, species, spindle/bearing/notch geometry, cord material, and measured outcomes (successful ember / break / polish / time / reliability).
2. Specifically test bark-bast and dry-stalk-fiber cords for repetitive motion; separate test results from traditional use claims.
3. Acquire file-licensed true specimen photography of basswood, aspen, cottonwood, willow, northern white cedar and mullein, including winter tree ID and usable deadwood condition. Review for subject accuracy and false look-alikes.
4. Verify local material collection permissions and wildfire restrictions for target land designation before publishing as a location-specific field rule.
5. Mechanically inspect every staged/AI illustration, especially cord wrap, hand position, drill-end shape and notch. Replace errors with witnessed photos or technical drawings.
6. Conduct phone/print and accessibility reviews, alt text review, copyright/license analysis, and book-level index validation under the later production gates.

## Ownership, deadlines and gate

This packet is Track B editorial research only and is not permission to publish. It does not change the Git branch `gate-a/review-fixes-1` or any other branch. No reviewer registry updates, approval ledger entries, or release-state changes occurred.
