from pathlib import Path
import math, html, json, textwrap, csv
from PIL import Image
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor, Color
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Paragraph
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT

BASE=Path(__file__).resolve().parent
A=BASE/'assets'
PDF=BASE/'Survival_Field_Encyclopedia_008_Friction_Fire_System.pdf'
PAGEW,PAGEH=612,792
G=HexColor('#183B2A'); G2=HexColor('#326248'); GREEN=HexColor('#53735A')
C=HexColor('#F7F3E7'); WHITE=HexColor('#FFFFFF'); INK=HexColor('#1E2921')
MUTED=HexColor('#596658'); LIGHT=HexColor('#E9E7D9'); YELLOW=HexColor('#DCA34C'); RED=HexColor('#9C4439')
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
BOLD='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
pdfmetrics.registerFont(TTFont('DV', FONT)); pdfmetrics.registerFont(TTFont('DVB',BOLD))
S={}
for key,size,bold in [('tiny',7.0,False),('small',8.4,False),('body',9.3,False),('mid',10.4,False),('card',11.2,True),('subtitle',12.1,True),('h2',15.2,True),('heading',23.0,True)]:
 S[key]=ParagraphStyle(key,fontName='DVB' if bold else 'DV',fontSize=size,leading=size*1.35,textColor=INK,spaceBefore=0,spaceAfter=0,allowWidows=0,allowOrphans=0)
cv=canvas.Canvas(str(PDF),pagesize=(PAGEW,PAGEH),pageCompression=1)
cv.setTitle('Survival Field Encyclopedia | Bow Drill & Minnesota Fire Materials | Track B 008')
cv.setAuthor('Survival Field Encyclopedia - research edition')
PAGE=0

def p(text,x,top,w,style='body',color=None,max_h=None):
    st=S[style]
    if color:
        st=ParagraphStyle(style+'_'+str(color),parent=st,textColor=color)
    q=Paragraph(html.escape(str(text)).replace('\n','<br/>'),st)
    _,h=q.wrap(w,1000)
    if max_h is not None and h>max_h+0.5:
        raise ValueError(f'Overflow {text[:58]!r}: {h:.1f}>{max_h:.1f} on page {PAGE}')
    q.drawOn(cv,x,top-h)
    return h

def rounded(x,y,w,h,fill=C,stroke=None,r=8):
    cv.setFillColor(fill); cv.setStrokeColor(stroke if stroke else fill)
    cv.roundRect(x,y,w,h,r,stroke=bool(stroke),fill=1)

def ln(x1,y1,x2,y2,color=GREEN,width=1):
    cv.setStrokeColor(color);cv.setLineWidth(width);cv.line(x1,y1,x2,y2)

def box(x,y,w,h,title=None,fill=WHITE,title_bg=G,title_h=28):
    rounded(x,y,w,h,fill)
    if title:
        cv.setFillColor(title_bg);cv.roundRect(x,y+h-title_h,w,title_h,7,stroke=0,fill=1)
        # square bottom corners to avoid title uneven
        cv.rect(x,y+h-title_h,w,title_h/2,stroke=0,fill=1)
        p(title,x+11,y+h-7,w-20,'card',WHITE,max_h=title_h-8)
    return y+h-(title_h if title else 0)

def label(text,x,y,w,h=26,bg=G,color=WHITE,size='small'):
    rounded(x,y,w,h,bg,r=5)
    p(text,x+7,y+h-5,w-14,size,color,max_h=h-6)

def photo(path,x,y,w,h,mode='cover'):
    path=Path(path)
    im=Image.open(path).convert('RGB')
    target_w=max(180,round(w/72*125)); target_h=max(180,round(h/72*125))
    iw,ih=im.size
    if mode=='cover':
        needed=target_w/target_h
        curr=iw/ih
        if curr>needed:
            nw=round(ih*needed); left=(iw-nw)//2;im=im.crop((left,0,left+nw,ih))
        else:
            nh=round(iw/needed);top=(ih-nh)//2;im=im.crop((0,top,iw,top+nh))
    im=im.resize((target_w,target_h),Image.Resampling.LANCZOS)
    out=A/'derived';out.mkdir(exist_ok=True)
    key=f'{path.stem}_{target_w}x{target_h}'
    tgt=out/f'{key}.jpg'
    if not tgt.exists(): im.save(tgt,'JPEG',quality=78,optimize=True,subsampling=0)
    cv.saveState(); pathclip=cv.beginPath();pathclip.roundRect(x,y,w,h,6);cv.clipPath(pathclip,stroke=0,fill=0)
    cv.drawImage(str(tgt),x,y,w,h,mask='auto')
    cv.restoreState()

def dot(n,x,y,r=11):
    cv.setFillColor(G); cv.circle(x,y,r,stroke=0,fill=1)
    cv.setFont('DVB',10);cv.setFillColor(WHITE);cv.drawCentredString(x,y-3.4,str(n))

def arrow(x1,y1,x2,y2,color=G2,width=2):
    ln(x1,y1,x2,y2,color,width)
    ang=math.atan2(y2-y1,x2-x1); rr=8
    for dd in (-0.52,0.52):
        ln(x2,y2,x2-rr*math.cos(ang+dd),y2-rr*math.sin(ang+dd),color,width)

def page(title,kicker,section):
    global PAGE
    PAGE+=1
    cv.setFillColor(C); cv.rect(0,0,PAGEW,PAGEH,fill=1,stroke=0)
    cv.setFillColor(G);cv.rect(0,708,PAGEW,84,fill=1,stroke=0)
    cv.setFillColor(YELLOW);cv.rect(0,704,PAGEW,4,fill=1,stroke=0)
    p('SURVIVAL FIELD ENCYCLOPEDIA  /  TRACK B 008',28,783,548,'small',HexColor('#DCE8D6'))
    p(title,28,759,556,'heading',WHITE,max_h=40)
    p(kicker,28,722,554,'small',HexColor('#E8F0DD'))
    ln(28,39,584,39,LIGHT,0.75)
    p('ILLUSTRATED RESEARCH DRAFT  |  MATERIALS AND TECHNIQUES REQUIRE FIELD VALIDATION',28,32,470,'tiny',MUTED,max_h=16)
    cv.setFillColor(G);cv.setFont('DVB',9);cv.drawRightString(584,19,f'{PAGE:02d}')

def finish():cv.showPage()

def step_panel(n,img,title,body,x,y,w=267,h=214):
    box(x,y,w,h)
    photo(A/img,x+6,y+h-111,w-12,105)
    dot(n,x+20,y+h-124,10)
    p(title,x+37,y+h-115,w-48,'card',G,max_h=20)
    p(body,x+12,y+h-149,w-23,'body',max_h=h-157)

def flash_title(s,x,top,w=544):
    p(s,x,top,w,'h2',G)

# 01 introduction / method selection
page('Fire from the landscape','No rope? Make it. No matches? Consider friction fire. A guaranteed ember? Never.','Introduction')
photo(A/'bow_stage_6.jpg',28,354,555,334)
box(28,247,555,94,'THE WORKING ORDER',fill=WHITE)
items=[('1','Stay dry and sheltered'),('2','Prepare tinder + fuel first'),('3','Choose ignition method')]
for i,(num,tx) in enumerate(items):
    x=42+i*180
    dot(num,x+13,288)
    p(tx,x+33,303,140,'small',G,max_h=42)
box(28,89,555,145,'THREE CAPABILITY LEVELS',fill=WHITE)
rows=[('NO GEAR','Local dead wood, handmade cord, dry tinder. Large labor cost.'),('IMPROVISED','Shoelace, cloth strips, salvaged cord, found container or tool.'),('EQUIPPED','Lighter, matches, ferro rod, prepared tinder, saw and knife.')]
for i,(a,b) in enumerate(rows):
    yy=191-i*37
    label(a,40,yy-5,104,25,G if i==0 else GREEN)
    p(b,158,yy+13,412,'small',max_h=31)
finish()

# 02 priority choice
page('Choose the ignition path','A fire-making method is only useful if time, materials, weather and energy permit.','Decision')
box(28,387,555,302,'CHECK CONDITIONS BEFORE GATHERING',fill=WHITE)
checks=[('SITE','Outdoor fire is lawful and controllable. No enclosed shelter, fuel spills, heavy wind or nearby dry duff.'),('TIME','A bow-drill kit can take substantial preparation; do not count on immediate ignition.'),('PERSON','Cold, wet hands, exhaustion, injury or deteriorating weather can make a long attempt unsafe.'),('MATERIAL','Dry, sound hearth and spindle; workable cord; tinder that accepts a coal; kindling ready.'),('ESCAPE','Keep water or soil available for extinguishment and know how to leave the site.')]
for i,(a,b) in enumerate(checks):
    yy=616-i*51
    label(a,42,yy-14,101,29,G2)
    p(b,156,yy+12,410,'body',max_h=47)
box(28,126,555,244,'SELECT METHOD',fill=WHITE)
for i,(a,b,col) in enumerate([
('HAS LIGHTER OR MATCHES?','Use them. Preserve dry tinder and spare fuel.',G2),
('HAS STRING AND DRY WOOD?','Try the bow drill before the hand drill.',G2),
('HAS NO STRING, BUT FIBERS?','Making cordage costs time; assess exposure first.',G2),
('HAS NO DRY WOOD?','Prioritize shelter, insulation and drying; do not force a friction set.',RED)]):
    y=323-i*48;label(a,42,y-16,235,27,col);p(b,289,y+8,274,'body',max_h=36)
box(28,64,555,47,fill=HexColor('#F3E3D8'))
p('STOP RULE: If exposure is worsening or materials are failing, stop drilling, conserve energy, and improve shelter.',40,99,530,'small',RED,max_h=37)
finish()

# 03 tree selection
page('Choose the right wood','Minnesota candidates: correct species helps, but dry and sound condition is decisive.','Wood atlas')
box(28,396,555,293,'FIRST CHOICES FOR PRACTICE',fill=WHITE)
trees=[
('AMERICAN BASSWOOD','Tilia americana','Soft, light wood. First candidate for hearth and spindle.','Heart-shaped leaves; dangling bracted fruit.'),
('QUAKING ASPEN','Populus tremuloides','Light, soft wood. Useful alternative for hearth/spindle.','Pale bark; trembling, rounded leaves.'),
('EASTERN COTTONWOOD','Populus deltoides','Soft wood; hearth/spindle candidate where available.','Triangular leaves; furrowed mature bark.'),
('NORTHERN WHITE CEDAR','Thuja occidentalis','Dry non-pitchy wood can work; use as tested.','Flat scale-leaf sprays; shreddy bark.'),
('WILLOW','Salix species','Suitable dry wood sometimes works; verify species and wood.','Narrow leaves vary among willow species.')]
for i,(name,lat,role,ident) in enumerate(trees):
    yy=625-i*49
    rounded(39,yy-30,535,43,C,r=4)
    p(name,49,yy+5,158,'small',G,max_h=17)
    p(lat,49,yy-9,157,'tiny',MUTED,max_h=15)
    p(role,211,yy+6,347,'small',max_h=28)
    p('FIELD CLUE: '+ident,211,yy-16,347,'tiny',MUTED,max_h=18)
box(28,236,555,143,'REJECT BEFORE YOU CUT',fill=WHITE)
for i,(a,b) in enumerate([
('WET OR GREEN','Steam, glossy surfaces and weak dark dust; prepare dry material.'),
('ROT-PUNKY','Crumbles instead of making a stable hot dust pile.'),
('HARD OR GLAZING','If the socket polishes and dust will not form, change wood.'),
('PITCH-SATURATED','May gum or glaze a friction pair; save resinous wood for flame support.')]):
    y=337-i*27
    p(a,41,y,135,'small',RED,max_h=18)
    p(b,180,y,386,'small',max_h=24)
box(28,75,555,144,'WINTER ID IS A DIFFERENT TASK',fill=HexColor('#EFF0E7'))
p('Do not identify an unfamiliar tree from wood color alone. Use bark, winter buds, branching, fallen leaves and locality together. Verified real tree photographs are mandatory in the production edition; links and rights notes are in the separate photo register.',42,198,525,'body',max_h=68)
p('Keep bark and tree-ID imagery separate from staged construction illustrations.',42,132,525,'small',G,max_h=29)
finish()

# 04 woodworking components
page('Make the four-part kit','The bearing block, spindle, hearth and bow have different wood requirements.','Components')
photo(A/'bow_stage_1.jpg',28,401,555,285)
box(28,190,555,193,'ROLE MATTERS MORE THAN A NAME',fill=WHITE)
roles=[
('HEARTH','Soft, dry, non-resinous wood; flat and stable.'),
('SPINDLE','Straight, dry and sound; blunt working end; minimal wobble.'),
('BOW','Strong, slightly curved branch; not a soft hearth wood requirement.'),
('BEARING','Hard, smooth, low-friction socket (dense wood, stone or bone).')]
for i,(a,b) in enumerate(roles):
    yy=338-i*41
    label(a,40,yy-12,116,28,G2)
    p(b,170,yy+11,388,'body',max_h=35)
box(28,76,555,97,'NO GEAR IS NOT NO WORK',fill=HexColor('#E9EEDF'))
p('Without a knife or saw, shaping a good hearth notch, spindle and bearing socket may be very difficult. A sharp, naturally fractured stone edge can help, but cutting hazards and material limits remain. Choose an easier method if available.',41,152,528,'body',max_h=71)
finish()

# 05 string choices
page('What can replace rope?','The bowstring must grip the spindle, tolerate repeated abrasion and resist excessive stretch.','Cordage')
photo(A/'repurposed_cord_staged.jpg',28,454,269,231)
photo(A/'cloth_paracord_staged.jpg',308,454,275,231)
box(28,207,555,230,'SUBSTITUTION LADDER',fill=WHITE)
cords=[
('BEST IF AVAILABLE','Bootlace, tough woven cord, suitably sized paracord.'),
('IMPROVISED','Strong cloth strip or leather lace; evaluate stretch and friction.'),
('NATURAL BAST','Basswood inner bark, properly processed and reverse-wrapped.'),
('STALK FIBERS','Stinging nettle, milkweed or dogbane: fiber preparation required.'),
('ROOTS / VINES','Mostly binding alternatives; test first, often poor for repeated bowing.')]
for i,(a,b) in enumerate(cords):
    yy=391-i*40
    label(a,42,yy-10,151,26,G2 if i<2 else GREEN)
    p(b,204,yy+10,363,'body',max_h=36)
box(28,75,555,115,'QUICK STRING CHECK',fill=HexColor('#F5EEDC'))
p('Wrap the string once around a dry spindle. It should turn the spindle through long, smooth strokes without slipping. Reject frayed, cracked or over-stretched cords. A solid shelter lashing may still fail as a bowstring.',42,172,526,'body',max_h=69)
p('A hand drill does not use a bow or string.',42,113,518,'small',G,max_h=23)
finish()

# 06 two-ply reverse wrap diagram
page('Make natural two-ply cord','A useful no-gear skill - but fiber preparation can take longer than expected.','Cordage')
box(28,487,555,203,'REVERSE WRAP: EACH STRAND TURNS ONE WAY, PAIR WRAPS THE OTHER',fill=WHITE)
# Diagram circles and strand colors; direction annotations
for i,(title,verb) in enumerate([('1. ALIGN','Two similar fiber bundles'),('2. TWIST A','Roll near strand away'),('3. CROSS','Bring far strand toward you'),('4. REPEAT','Continue with even tension')]):
    x=40+i*135
    rounded(x,515,126,148,HexColor('#F1F1E9'),r=5)
    p(title,x+8,652,110,'small',G,max_h=16)
    # paired zig-zag strokes
    for j,col in enumerate([YELLOW,G2]):
        cv.setStrokeColor(col);cv.setLineWidth(4)
        pp=cv.beginPath()
        for k in range(8):
            xx=x+19+k*12
            yy=574+12*math.sin((k+i)*1.45+j*math.pi)
            if k==0: pp.moveTo(xx,yy)
            else: pp.lineTo(xx,yy)
        cv.drawPath(pp)
    p(verb,x+8,556,112,'tiny',max_h=37)
box(28,287,555,183,'EXTEND SHORT FIBERS',fill=WHITE)
for i,(n,t) in enumerate([
('1','Split new fibers into fine strips.'),('2','Overlap new fibers along the thinning strand.'),
('3','Twist the overlap into the working strand.'),('4','Resume the reverse wrap, then tug-test.')]):
    yy=418-i*35
    dot(n,53,yy,10);p(t,78,yy+12,485,'body',max_h=31)
box(28,75,555,195,'DO NOT ASSUME A FIBER IS SAFE TO HANDLE',fill=HexColor('#F5EEDC'))
p('Stinging nettle has irritating hairs; dogbane and milkweed contain latex and require identification and handling care. Use dead, identifiable fibers where permitted. Do not strip live trees or damage protected plants.',42,224,523,'body',max_h=76)
p('Proof of function: completed cord survives a series of unloaded bow strokes before work begins.',42,153,521,'small',G,max_h=44)
finish()

# 07 bow drill geometry original diagram
page('Assemble the bow drill','Keep the spindle vertical and the working end on the hearth; brace the bearing block.','Mechanics')
box(28,258,555,431,'WORKING SYSTEM - SIDE VIEW',fill=WHITE)
# Diagram in white panel main x70-440 center
# hearth
cv.setFillColor(HexColor('#B88D59'));cv.roundRect(143,343,310,32,5,fill=1,stroke=0)
cv.setFillColor(HexColor('#725334'));cv.rect(312,343,19,12,fill=1,stroke=0)
# spindle vertical
cv.setFillColor(HexColor('#CDAA70'));cv.roundRect(310,374,22,231,5,fill=1,stroke=0)
# bearing cup
cv.setFillColor(HexColor('#7C6A52'));cv.roundRect(286,598,69,30,11,fill=1,stroke=0)
# bow arc at mid
cv.setStrokeColor(HexColor('#926D39'));cv.setLineWidth(9)
pth=cv.beginPath();pth.moveTo(122,484);pth.curveTo(172,462,377,462,491,492);cv.drawPath(pth)
# Bowstring in side-view: the visible run makes one loop around the spindle.
cv.setStrokeColor(INK);cv.setLineWidth(2.9)
cv.line(127,482,306,482)
cv.line(337,492,481,492)
cv.ellipse(304,473,339,501,stroke=1,fill=0)
p('ONE CORD WRAP',352,471,142,'tiny',G,max_h=16)
# hearth notch opening with dust
cv.setFillColor(INK)
for i in range(6):cv.circle(318+(i%3)*4,339-(i//3)*4,1.8,stroke=0,fill=1)
for i,(tx,xt,yt,x2,y2) in enumerate([
 ('BEARING BLOCK',66,612,286,612),('SPINDLE',56,561,306,553),('BOW + STRING',360,547,402,490),('HEARTH',58,405,145,356),('DUST NOTCH',368,390,327,341)]):
    p(tx,xt,yt,165,'small',G,max_h=23)
    if i==0:arrow(186,603,x2,y2,G2,1.5)
    if i==1:arrow(155,548,x2,y2,G2,1.5)
    if i==2:arrow(449,530,x2,y2,G2,1.5)
    if i==3:arrow(117,399,x2,y2,G2,1.5)
    if i==4:arrow(402,374,x2,y2,G2,1.5)
box(28,97,555,145,'SET THE BODY POSITION',fill=WHITE)
notes=['Hold hearth firm with a boot or weight, away from notch.',
       'Brace your bearing-block wrist against the shin for stability.',
       'Move the bow horizontally in smooth, nearly full-length strokes.',
       'Keep the top socket low-friction; do not oil the hearth end.']
for i,t in enumerate(notes):
    yy=198-i*29;dot(i+1,51,yy,9);p(t,74,yy+10,487,'small',max_h=29)
finish()

# 08 prep the notch
page('Shape a dust-producing notch','The notch must collect fine hot dust. A black socket alone is not yet an ember.','Hearth')
photo(A/'bow_stage_2.jpg',28,375,555,310)
box(28,130,555,230,'THE GEOMETRY TO INSPECT',fill=WHITE)
# ellipse + notch schematic top down on left
cx,cy=157,226
cv.setFillColor(HexColor('#B88D59'));cv.roundRect(56,159,223,145,8,fill=1,stroke=0)
cv.setFillColor(HexColor('#33251A'));cv.circle(cx,235,43,fill=1,stroke=0)
# cut notch triangular to edge
cv.setFillColor(C); pp=cv.beginPath();pp.moveTo(cx,235);pp.lineTo(cx+43,159);pp.lineTo(cx+3,159);pp.close();cv.drawPath(pp,fill=1,stroke=0)
p('TOP VIEW',83,286,139,'small',WHITE,max_h=21)
arrow(275,223,308,223,G2,2)
p('NOTCH REACHES THE SOCKET',322,271,238,'card',G,max_h=42)
p('Cut a clean V-shaped outlet from the hearth edge to the socket center. The dust should drop into a pile on dry bark or another ember catch.',322,238,231,'small',max_h=101)
box(28,72,555,42,fill=HexColor('#F1DFCF'))
p('WRONG: sealed socket, wet base, shallow slit, or an oversized gap that releases the spindle.',40,103,531,'small',RED,max_h=35)
finish()

# 09 work to coal photo steps
page('From motion to ember','Three visible signals matter: fine dust, steady smoke, and a persistent glowing coal.','Operation')
step_panel(1,'bow_stage_3.jpg','START SMOOTH','Secure the hearth, maintain downward pressure and use long bow strokes.',28,420,267,256)
step_panel(2,'bow_stage_4.jpg','READ THE DUST','Brown dust indicates early wear; dark fine dust and smoke show increasing heat.',307,420,276,256)
step_panel(3,'bow_stage_5.jpg','WAIT FOR A COAL','After stopping, let the small smoking pile remain intact. Check for continued glow.',28,155,267,256)
box(307,155,276,256,'IF THERE IS NO EMBER',fill=WHITE)
for i,(a,b) in enumerate([
 ('Dust is pale','Try drier, more suitable wood.'),
 ('No dust forms','Increase suitable pressure; replace polished pair.'),
 ('Dust scatters','Fix notch, hearth angle or ember catcher.'),
 ('Smoke stops at once','Coal has not consolidated; improve the set.')]):
    yy=368-i*43
    p(a,322,yy,235,'small',RED,max_h=18)
    p(b,322,yy-16,235,'small',max_h=34)
finish()

# 10 ember handling
page('Turn the coal into a flame','Prepare tinder and kindling before drilling; a coal dies quickly when handled poorly.','Ember')
photo(A/'bow_stage_5.jpg',28,374,266,309)
photo(A/'bow_stage_6.jpg',306,374,277,309)
box(28,156,555,200,'A TWO-STAGE TRANSFER',fill=WHITE)
for i,(a,b) in enumerate([
('MOVE THE COAL','Lift the bark or ember catcher, not loose ash. Keep the glowing dust intact.'),
('FEED THE COAL','Place into the finest part of a dry, loose tinder nest and close it gently.'),
('VENTILATE','Use controlled breaths outdoors. As flame starts, offer fine dry kindling.'),
('BUILD SLOWLY','Increase fuel size gradually; avoid smothering the small flame.')]):
    yy=309-i*39
    dot(i+1,51,yy,10)
    p(a,74,yy+11,149,'small',G,max_h=18)
    p(b,224,yy+12,340,'small',max_h=34)
box(28,70,555,69,fill=HexColor('#F5E6DD'))
p('Hot resin, coal and burning fibers can stick to skin. Keep the flame outside shelters, away from dry duff, and never leave it unattended.',40,124,526,'small',RED,max_h=52)
finish()

# 11 minnesota materials
page('Minnesota natural-fire materials','Separating ember receivers, easy ignition materials, flame extenders and fuel.','Materials')
box(28,393,555,295,'WHICH MATERIAL SERVES WHICH ROLE?',fill=WHITE)
materials=[
('COAL RECEIVER','Very fine, thoroughly dry inner-bark or grass fibers.','Must accept a glowing coal.'),
('EARLY FLAME','Thin paper-birch bark layers; finely shaved dry wood.','Prepare curls and small pieces.'),
('FLASH TINDER','Dry cattail seed down or similar fluff.','May ignite fast and disappear fast.'),
('KINDLING','Dry, pencil-thin twigs or thin split wood.','Move from thin to thicker.'),
('FLAME EXTENDER','Fatwood, pine or spruce resin/pitch from suitable dead material.','Supports a flame; does not replace ignition.'),
('FUEL','Dry larger sticks and small logs.','Feed after a stable flame is present.')]
for i,(role,mat,lim) in enumerate(materials):
    yy=648-i*43
    label(role,40,yy-17,164,30,G2 if i!=4 else HexColor('#9E7038'))
    p(mat,217,yy+14,350,'small',max_h=25)
    p(lim,217,yy-7,350,'tiny',MUTED,max_h=17)
box(28,227,555,149,'AVOID THE WRONG CLAIM',fill=HexColor('#E8EFE6'))
p('Fresh watery tree sap is not interchangeable with resin. A resin-rich knot or dead pine fatwood can help a flame persist, but may be sticky and unsuitable for a friction hearth. Never heat a sealed resin container or use volatile chemicals as an ignition shortcut.',42,331,526,'body',max_h=104)
box(28,76,555,134,'LOCATE DRY MATERIAL BEFORE IT GETS WET',fill=WHITE)
p('Inspect fallen, suspended or standing dead twigs when lawful to collect. Split or shave dry interior wood where possible. Keep tinder and prepared bow-drill parts protected from rain and snow; wet ground can cool the ember catcher.',42,165,524,'body',max_h=93)
finish()

# 12 troubleshooting
page('Find the fault - fix one cause','Do not repeat an unsuccessful attempt without changing the failed element.','Troubleshooting')
box(28,138,555,551,'SYMPTOM  /  LIKELY CAUSE  /  CORRECTION',fill=WHITE)
issues=[
('CORD SLIPS','Too loose, smooth cord or glazed spindle','Adjust tension; change wrap or cord; roughen only as needed.'),
('CORD BREAKS','Overtight natural cord, frayed contact','Make stronger, longer fiber overlaps; reduce excess tension.'),
('SPINDLE JUMPS','Poor stance, crooked spindle or socket','Brace bearing hand, straighten set, deepen top socket.'),
('TOP SOCKET SMOKES','High friction above, not at hearth','Smooth and lightly lubricate bearing ONLY.'),
('WOOD POLISHES','Wood too hard, resinous or pressure low','Try dry, softer non-pitchy wood; reshape contact.'),
('DUST STAYS PALE','Moisture, wrong wood pair or low heat','Dry materials; refine pressure/speed; change wood.'),
('DUST WILL NOT PILE','Bad notch, sloped hearth or no catcher','Level hearth; open notch carefully; add dry ember catcher.'),
('SMOKE, NO COAL','Short duration or dust not insulated','Use smoother long strokes; let a sufficient pile develop.'),
('COAL DIES','Moved too early, blown apart or damp tinder','Wait for persistent glow; transfer gently into fine dry nest.'),
('FLAME FADES','Too much fuel too soon, fine tinder depleted','Build from thin dry kindling upward; do not smother.')]
for i,(sym,cause,fix) in enumerate(issues):
    y=642-i*50
    rounded(39,y-35,535,45,HexColor('#F5F4EE') if i%2 else HexColor('#EDEFE7'),r=3)
    p(sym,49,y+3,137,'small',RED,max_h=20)
    p(cause,187,y+2,171,'tiny',MUTED,max_h=34)
    p(fix,365,y+2,194,'tiny',INK,max_h=37)
box(28,65,555,55,fill=HexColor('#F4E4DA'))
p('If cold, wet, injured or exhausted: stop, improve insulation and shelter, and switch to an available ignition method.',40,109,525,'small',RED,max_h=42)
finish()

# 13 winter variant / hand drill
page('Cold-weather decision path','Friction fire becomes less forgiving with damp tinder, numb hands and scarce dry wood.','Winter')
box(28,411,555,277,'BEFORE TRYING IN SNOW OR FREEZING RAIN',fill=WHITE)
for i,(a,b) in enumerate([
('SHELTER FIRST','Protect hands and clothing from getting wetter during a long attempt.'),
('DRY WORK SURFACE','Keep hearth board, coal catcher and tinder off snow or wet earth.'),
('FUEL READY','Gather enough fine dry kindling before using energy on the drill.'),
('SHORT TEST','Trial the string, spindle and notch before sustained bowing.'),
('STOP EARLY','If you lose warmth or dexterity, switch to insulation, signaling or movement to safety.')]):
    yy=644-i*49
    dot(i+1,53,yy,11);p(a,77,yy+12,140,'small',G,max_h=23);p(b,222,yy+11,345,'body',max_h=40)
box(28,170,555,224,'HAND DRILL IS A DIFFERENT SKILL',fill=WHITE)
p('The hand drill turns a straight, dry, light spindle using bare hands. It avoids cordage, but needs sustained control and skill. A mature dried mullein flower stalk is a candidate spindle; a suitable soft dry wood is still needed as the hearth. It is not a reliable emergency fallback simply because bow cordage is absent.',43,364,520,'body',max_h=113)
p('Bow drill: mechanical advantage + more components. Hand drill: fewer components + greater physical skill and fatigue.',43,257,520,'small',G,max_h=54)
box(28,74,555,81,fill=HexColor('#F4E4DA'))
p('No primitive fire method guarantees warmth. Fire restrictions, wildfire risk and personal exposure determine whether an attempt is appropriate.',42,136,526,'small',RED,max_h=57)
finish()

# 14 field quick check
page('Bow drill - one-page field check','A compact action sequence for a prepared, suitable and lawful outdoor site.','Quick reference')
box(28,294,555,394,'BEFORE THE FIRST STROKE',fill=WHITE)
quick=[
('FIND','Dry, sound hearth and spindle; strong bow; stable bearing; cord; tinder and fuel.'),
('TEST','String grips; spindle straight; hearth flat and held firm; bearing socket smooth.'),
('SHAPE','Burn in socket, then make a dust notch to the socket; catch dust on dry bark.'),
('DRIVE','Work bow smoothly; brace bearing wrist; monitor dark dust and persistent smoke.'),
('CONFIRM','After motion stops, dust smolders as an independent coal.'),
('TRANSFER','Move coal gently into a dry fine tinder nest; supply air; add very fine kindling.'),
('CONTROL','Keep flame small, outside any shelter, and completely extinguish it.')]
for i,(a,b) in enumerate(quick):
    yy=647-i*50
    dot(i+1,52,yy,12)
    p(a,78,yy+13,112,'card',G,max_h=24)
    p(b,190,yy+13,375,'body',max_h=42)
box(28,90,555,185,'FAIL SAFE / NO GO',fill=HexColor('#F3E9E0'))
for i,s in enumerate(['Wind, bans, fuels or dry vegetation create unacceptable fire risk.',
                     'Suitable dry components cannot be obtained.',
                     'Cord is fraying or spindle/stone tool is unstable.',
                     'Repeated failure is causing exposure or exhaustion.']):
    yy=236-i*33
    p('STOP',43,yy+9,60,'small',RED,max_h=24)
    p(s,104,yy+9,465,'small',max_h=31)
finish()

# 15 research photo inventory and release boundary; we want not in book but separate? make final page cover in reader is too audit-y; skip this page.
cv.save()
print(PDF)
print('PAGES',PAGE)
