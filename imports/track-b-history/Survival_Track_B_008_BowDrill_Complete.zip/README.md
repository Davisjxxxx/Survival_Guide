# Survival Field Encyclopedia | Track B 008

**Deliverable:** 14-page, compact, indexed-by-page editorial trial module, “Fire from the Landscape: Bow Drill and Minnesota Materials.”

Open `Survival_Field_Encyclopedia_008_Friction_Fire_System.pdf` first. `index.html` is an offline alternative if PDF viewing fails. All book text is independently selectable in the PDF. The reader pages contain concise action-oriented content; research sources, image rights and unresolved expert validation are in `source/`.

**Purpose:** combine earlier fire, wood and cordage fragments into one coherent zero-equipment-first procedure. It includes natural/repurposed cord, Minnesota candidate woods, component geometry, detailed staged illustrations, notch/ember guidance, tinder selection, winter stop conditions and 10 troubleshooting cases. **It does not establish that any method will work in the field** and is not a release candidate.

The only true species photos presently identified are linked **leads** in the private acquisition ledger; they have not been acquired into this package. The construction visuals are AI-staged concepts. Do not use them for botanical ID or assume mechanically flawless depiction.

No local repository was changed. Gate A remains blocked; publication is not authorized.
