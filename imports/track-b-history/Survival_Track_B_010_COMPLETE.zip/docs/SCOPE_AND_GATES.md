# Track B 010 — Editorial, visual and safety QA

Status: **UNAPPROVED RESEARCH PLATES; Gate A remains BLOCKED; no authorized publication or local repository ingestion.**

## What is new

- Ten landscape, image-led field plates as a supplement to prior Track B 008 and 009 manuscripts. This is **not** the completed full fire or water chapter.
- Bow-drill mechanism drawn as an original vector schematic, V-notch top view, six staged photographic steps, six failure corrections, and a bowstring-substitution comparison.
- Water-collection staged imagery, original sand/gravel clarification section, no-fire treatment decision paths, Minnesota-specific risk conditions, and quick operational checklists.
- Reader pages contain no source IDs; the traceability and photo manifests remain in this companion file set.

## Critical limits and reviewer obligations

1. **Staged images**: Photorealistic images were generated for demonstration. They are not documentary photographic evidence of a field trial, not species identification plates, and do not certify a particular mechanical arrangement. All material close-ups are generic visual concepts. All claims about actual plant identity, practical strength, heating, flame performance, and water treatment remain subject to technical review and, as appropriate, controlled field testing.
2. **Bow drill**: Wood selection is based on the *function* and specific dry sound material, not a guarantee that any named species will work. The 2002 military manual describes a hard spindle/soft hearth pairing; bushcraft sources use other combinations. This pilot does not resolve species pairing efficacy without comparable practical trials. Bowstrings must withstand abrasion and maintain appropriate tension; tree bark and root strips are not automatically suitable.
3. **Fire risk**: Operate only outdoors at a controlled, lawful fire location. In severe exposure, repeated unsuccessful friction ignition can worsen hypothermia. Fire restrictions in Minnesota change; check the live DNR conditions. Do not use a fire inside enclosed snow/debris structures.
4. **Improvised water filters**: These are **clarifiers**, not rated microbial filters. No combination of loose stones, sand, moss, leaves, and untested charcoal is asserted to remove pathogens, algal toxins, or industrial chemicals. **Moss and other living material can introduce contamination.**
5. **No-fire water**: Proper SODIS requires a suitable clean transparent bottle, sufficiently clear water, adequate sunlight and time; it does not work against chemical toxins. Chlorine/chlorine dioxide follow the actual label and CDC pathogen limitations. Rated manufactured filters follow their specified organism removal scope and may require additional disinfection.
6. **Source priority**: The Army survival manual is a historical tactical-method source, not authoritative modern drinking-water guidance. Use CDC/MDH for safety. The publicly posted Army PDF has a distribution-restriction notice. Do not copy its wording, diagrams or PDF into a commercial book; all diagrams here are originally drawn.
7. **No apparatus proof**: The filter cross-section is conceptual. No verified flow rate, media depth, removal percentage, or load rating is claimed. The water vessel illustration is not a tested heat-safe or sanitary design.
8. **Text integrity**: Small words and labels were manually authored in PDF; no AI-generated captions were used. Images were cropped without stretching. The archive includes the authoring script, full raster page fallbacks and HTML reader.

## Before publication

- Expert-reviewed species identification photographs (entire tree, twig/leaf/needle, bark, winter diagnostic, candidate material) and licensed high-resolution originals.
- Controlled field trials: bow/spindle/hearth pairs, cord friction and breakage, dust/coal generation, total energy/time under wet and cold conditions, aborted trials.
- Water experimental demonstrations must not be used to infer microbiological clearance: laboratory testing and validated treatment pathways are required for that claim.
- Independent hazards/safety validation, rights clearance, accessible print and phone formats, page and link QA, and formal release authorization.

## Engineering status

No tracked changes to `/home/jd/Survival_Guide` were made from this ChatGPT session. Latest reported local engineering branch `gate-a/review-fixes-1`, commit `342d4550f233e405d5a128e2ca7b656d25c9dc96`, with 2,168 tests passed (reported, not independently reverified here). This does **not** approve Gate A.
