#!/usr/bin/env python3
"""SFE Track B 010: two field mechanisms. Original, staged research draft. No approval."""
import os, csv, hashlib, json, math, zipfile
from pathlib import Path
from PIL import Image, ImageOps, ImageDraw
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.utils import ImageReader
from reportlab.platypus import Paragraph
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT

ROOT=Path(__file__).resolve().parent
AS=ROOT/'assets'; PAGES=ROOT/'pages'; OUT=ROOT/'Survival_Field_Encyclopedia_010_Mechanism_Plates.pdf'
W,H=792,612
for name,fn in [('Lato','Lato-Regular.ttf'),('LatoBold','Lato-Bold.ttf'),('LatoBlack','Lato-Black.ttf')]:
    pdfmetrics.registerFont(TTFont(name, '/usr/share/fonts/truetype/lato/'+fn))
GREEN=HexColor('#163F2A'); DEEP=HexColor('#0B2D20'); CREAM=HexColor('#F5F0E4'); PAPER=HexColor('#FFFCF5'); TAN=HexColor('#EDE4D0'); GOLD=HexColor('#D9A441'); RED=HexColor('#8E2E25'); SOFT=HexColor('#DFE8DC'); INK=HexColor('#18352B'); GREY=HexColor('#52665D')

def box(c,x,top,w,h,fill=PAPER,r=10,stroke=None):
    c.setFillColor(fill)
    if stroke:
        c.setStrokeColor(stroke); c.setLineWidth(.65)
    else: c.setStrokeColor(fill)
    c.roundRect(x,H-top-h,w,h,r,stroke=int(stroke is not None),fill=1)

def txt(c,x,top,s,size=10,bold=False,color=INK):
    c.setFont('LatoBold' if bold else 'Lato',size);c.setFillColor(color);c.drawString(x,H-top-size,s)

def paras(c,content,x,top,w,maxh=500,size=10,leading=None,color=INK,bold=False):
    sty=ParagraphStyle('x',fontName='LatoBold' if bold else 'Lato',fontSize=size,leading=leading or size*1.24,textColor=color,spaceAfter=0,allowWidows=0,allowOrphans=0)
    p=Paragraph(content,sty)
    ww,hh=p.wrap(w,maxh)
    if hh>maxh+.1: raise ValueError(f'Text overflow {hh} > {maxh}: {content[:45]}')
    p.drawOn(c,x,H-top-hh)
    return hh

def photo(c,key,x,top,w,h,roundit=True):
    path=AS/f'{key}.jpg'
    if not path.exists(): raise FileNotFoundError(path)
    im=Image.open(path).convert('RGB')
    # Fill the frame by cropping, NEVER stretching source anatomy/materials.
    exact=ImageOps.fit(im,(max(1,int(w*2)),max(1,int(h*2))),method=Image.Resampling.LANCZOS,centering=(.5,.5))
    cropped=AS/f'{key}_{int(w*2)}x{int(h*2)}_crop.jpg'
    if not cropped.exists(): exact.save(cropped,format='JPEG',quality=80,optimize=True,subsampling=0)
    c.drawImage(str(cropped),x,H-top-h,width=w,height=h,mask='auto',preserveAspectRatio=False)
    c.setStrokeColor(HexColor('#D4D0C1'));c.setLineWidth(.6);c.rect(x,H-top-h,w,h,stroke=1,fill=0)

def head(c,kicker,title,deck,p):
    c.setFillColor(CREAM);c.rect(0,0,W,H,fill=1,stroke=0)
    c.setFillColor(DEEP);c.rect(0,H-75,W,75,fill=1,stroke=0)
    c.setFillColor(HexColor('#F7EFE0'));c.setFont('LatoBold',9);c.drawString(26,H-18,'SURVIVAL FIELD ENCYCLOPEDIA   /   TRACK B 010')
    c.setFillColor(HexColor('#BFD1B8'));c.setFont('Lato',9);c.drawRightString(W-27,H-18,kicker.upper())
    c.setFillColor(HexColor('#FFF5E1'));c.setFont('LatoBlack',25);c.drawString(26,H-49,title)
    c.setFillColor(HexColor('#E3E5DA'));c.setFont('Lato',10);c.drawString(27,H-67,deck)
    c.setStrokeColor(HexColor('#B0C1B1'));c.setLineWidth(.7);c.line(25,26,W-25,26)
    c.setFillColor(GREY);c.setFont('Lato',7.6);c.drawString(26,13,'FIELD REVIEW DRAFT   •   STAGED PHOTOGRAPHY + ORIGINAL DIAGRAMS   •   NOT FIELD-TEST CERTIFIED')
    c.setFont('LatoBold',8.6);c.drawRightString(W-26,13,f'{p:02d} / 10')

def subhead(c,x,top,w,title,color=GREEN):
    box(c,x,top,w,27,color,5)
    txt(c,x+11,top+6,title,11,True,HexColor('#FFF7E8'))

def ctext(c,x,top,w,title,body,height=72,tone='neutral'):
    fill=PAPER if tone=='neutral' else (HexColor('#FCEDE3') if tone=='danger' else SOFT)
    box(c,x,top,w,height,fill,8)
    paras(c,title,x+12,top+10,w-24,18,size=10.2,bold=True,color=RED if tone=='danger' else GREEN)
    paras(c,body,x+12,top+27,w-24,height-34,size=9.4)

def arrow(c,x1,y1,x2,y2,color=GOLD,sw=3):
    c.setStrokeColor(color);c.setFillColor(color);c.setLineWidth(sw)
    c.line(x1,H-y1,x2,H-y2)
    a=math.atan2((y2-y1),(x2-x1));r=8
    pts=[(x2,y2),(x2-r*math.cos(a-.55),y2-r*math.sin(a-.55)),(x2-r*math.cos(a+.55),y2-r*math.sin(a+.55))]
    q=c.beginPath();q.moveTo(pts[0][0],H-pts[0][1]);q.lineTo(pts[1][0],H-pts[1][1]);q.lineTo(pts[2][0],H-pts[2][1]);q.close();c.drawPath(q,fill=1,stroke=0)

def label(c,x,top,num,title,body,w,h=92):
    box(c,x,top,w,h,PAPER,7)
    box(c,x+9,top+9,21,21,GREEN,10)
    txt(c,x+15,top+11,str(num),10,True,HexColor('#FFFFFF'))
    txt(c,x+38,top+9,title,10,True)
    paras(c,body,x+11,top+28,w-22,h-30,size=8.6,leading=10.5)

def circle(c,x,top,r,fill):
    c.setFillColor(fill);c.circle(x,H-top,r,stroke=0,fill=1)

def draw_bow_detail(c):
    # Original exploded side-view: intentionally schematic, no photographic claim.
    x,y=50,153
    box(c,x,128,448,324,PAPER,9)
    txt(c,x+14,140,'SIDE VIEW  /  PARTS THAT MOVE',11,True,GREEN)
    # hearth and notch floor
    c.setFillColor(HexColor('#B58A5D'));c.roundRect(177,H-384,252,30,5,stroke=0,fill=1)
    c.setStrokeColor(HexColor('#775334'));c.setLineWidth(1.1);c.line(180,H-376,426,H-376)
    # spindle vertical
    c.setFillColor(HexColor('#D0A477'));c.roundRect(297,H-335,18,136,7,stroke=1,fill=1)
    # curved bearing socket
    c.setFillColor(HexColor('#5B6654'));c.ellipse(288,H-207,327,H-193,stroke=0,fill=1)
    # bow curved thin line left-right, line routing to spindle
    c.setStrokeColor(HexColor('#855936'));c.setLineWidth(7)
    p=c.beginPath();p.moveTo(126,H-309);p.curveTo(181,H-294,320,H-294,435,H-311);c.drawPath(p)
    c.setStrokeColor(HexColor('#414E48'));c.setLineWidth(2.5)
    # Cord loop around spindle: left segment, obscured rear, front horizontal with bulge.
    c.line(126,H-312,294,H-316)
    p=c.beginPath();p.moveTo(294,H-316);p.curveTo(288,H-328,319,H-331,317,H-316);c.drawPath(p)
    c.line(317,H-316,435,H-314)
    # foot/hand hints
    txt(c,73,253,'BOW',10,True,GREEN);txt(c,73,268,'side-to-side strokes',8)
    txt(c,340,196,'HANDHOLD / SOCKET',10,True,GREEN)
    txt(c,345,212,'press down; stabilize top',8)
    arrow(c,358,224,323,231,HexColor('#5C9A77'),1.6)
    txt(c,355,344,'SPINDLE',10,True,GREEN)
    txt(c,355,360,'vertical rotation',8)
    arrow(c,353,359,318,335,HexColor('#5C9A77'),1.6)
    txt(c,63,396,'HEARTH: dry seasoned board',9,True,GREEN)
    txt(c,63,414,'V-notch directs hot dust out to an ember catcher.',8.2)
    arrow(c,293,415,294,377,GOLD,1.6)
    arrow(c,180,348,250,347,GOLD,1.8);arrow(c,432,350,367,348,GOLD,1.8)
    txt(c,236,443,'For exact notch geometry, see the top view.',8.1,color=GREY)

def draw_notch(c,x,top,w,h):
    box(c,x,top,w,h,PAPER,8)
    txt(c,x+12,top+9,'TOP VIEW / HEARTH NOTCH',10.5,True,GREEN)
    c.setFillColor(HexColor('#C8A278'));c.roundRect(x+22,H-(top+h-10),w-44,65,5,stroke=0,fill=1)
    cx=x+w/2;cy=top+80
    circle(c,cx,cy,29,HexColor('#66503B'));circle(c,cx,cy,17,HexColor('#DFD4BE'))
    # wedge opening towards lower board edge: make broad open mouth
    c.setFillColor(CREAM)
    p=c.beginPath();p.moveTo(cx-9,H-(cy+24));p.lineTo(cx+9,H-(cy+24));p.lineTo(cx+30,H-(top+h-8));p.lineTo(cx-30,H-(top+h-8));p.close();c.drawPath(p,stroke=0,fill=1)
    txt(c,x+14,top+h-21,'NOTCH -> EMBER DUST',9,True,RED)


def draw_filter(c,x,top,w,h):
    # Tested only as clarification schematic; no microbiological efficacy implied.
    box(c,x,top,w,h,PAPER,9)
    txt(c,x+13,top+10,'FIELD-EXPEDIENT CLARIFIER (SECTION)',11,True,GREEN)
    fx=x+60;fy=top+58; fw=170;fh=h-116
    # vessel walls
    c.setStrokeColor(HexColor('#465A4B'));c.setLineWidth(4)
    c.line(fx,H-fy,fx,H-(fy+fh));c.line(fx+fw,H-fy,fx+fw,H-(fy+fh));
    c.setLineWidth(1)
    # fill from top to bottom; proportions only, not design-rated
    layers=[('COARSE SCREEN',38,HexColor('#BCA58D')),('RINSED COARSE SAND',60,HexColor('#CFBA91')),('RINSED FINE SAND',66,HexColor('#D9CDAA')),('SUPPORT GRAVEL',66,HexColor('#B9B6A9'))]
    yy=fy+4
    for name,th,col in layers:
        if yy+th>fy+fh-8:break
        c.setFillColor(col);c.rect(fx+4,H-(yy+th),fw-8,th,fill=1,stroke=0)
        c.setStrokeColor(HexColor('#766F60'));c.setLineWidth(.5);c.line(fx+4,H-(yy+th),fx+fw-4,H-(yy+th))
        txt(c,fx+fw+18,yy+8,name,9,True)
        arrow(c,fx+fw+5,yy+23,fx+fw+14,yy+23,HexColor('#5E95A2'),1.4)
        yy+=th
    arrow(c,fx+fw/2,fy-16,fx+fw/2,fy+7,HexColor('#4393A9'),3.5)
    txt(c,fx+fw/2-37,fy-39,'RAW WATER',9,True,RED)
    arrow(c,fx+fw/2,fy+232,fx+fw/2,fy+263,HexColor('#4393A9'),3.2)
    txt(c,fx+fw/2-53,fy+268,'CLARIFIED RAW',9.0,True,RED)
    txt(c,fx+fw/2-41,fy+281,'NOT POTABLE',9.3,True,RED)
    box(c,x+10,top+h-57,w-20,49,HexColor('#FFE8E1'),6)
    paras(c,'<b>OUTLET STILL UNTREATED.</b> Sand and gravel can remove particles. This construction does not verify removal of viruses, bacteria, parasites, heavy metals, or toxins.',x+18,top+h-50,w-36,42,9.2,11.3,RED)


def page1(c):
    head(c,'Quick start / hazard first','Two tools. One survival decision.','Make fire when feasible; never confuse clearer water with safe water.',1)
    photo(c,'fire3',26,104,358,241);photo(c,'water3',399,104,367,241)
    box(c,26,356,358,180,PAPER)
    subhead(c,26,356,358,'FIRE  /  CONTROL ENERGY FIRST')
    paras(c,'<b>Before drilling:</b> dry fuel staged, outdoor fire site checked, ignition material prepared. A bow drill is more practical than a hand drill if a usable cord can be made or found.',39,393,333,78,11.5,15)
    paras(c,'<font color="#8E2E25"><b>STOP:</b></font> Chilled, wet or exhausted? Prioritize shelter, dry insulation and reliable ignition if available.',39,467,333,61,10.2,13.0)
    box(c,399,356,367,180,PAPER)
    subhead(c,399,356,367,'WATER  /  FOUR DISTINCT OPERATIONS')
    paras(c,'<b>1. Select source.</b> Reject known toxins and suspect chemical runoff.<br/><b>2. Collect.</b> Keep raw water separate.<br/><b>3. Clarify.</b> Settle, strain, or use sand/gravel.<br/><b>4. Disinfect.</b> Use a validated method when possible.',412,392,342,103,11.0,15)
    paras(c,'<font color="#8E2E25"><b>NO-FIRE LIMIT:</b></font> Stone, sand, moss and charcoal do not by themselves verify potable water.',412,495,337,35,9.3,11.8)
    c.showPage()


def page2(c):
    head(c,'Firecraft / mechanics','Bow drill: build the mechanism','The string loops around the spindle; a V-notch collects ember dust.',2)
    draw_bow_detail(c)
    subhead(c,514,128,252,'PARTS / SELECT BY FUNCTION')
    for i,(a,b) in enumerate([
      ('BOW','Sound, resilient branch; length must allow steady strokes.'),
      ('STRING','Strong low-stretch cord; twisted bark fibers, lace or found line.'),
      ('SPINDLE','Dry, straight, seasoned working wood. Test the pairing.'),
      ('HEARTH','Dry, relatively soft sound board that generates dust.'),
      ('SOCKET','Smooth hard bearing: dense wood, bone, or cupped stone.')]):
      label(c,514,161+i*58, i+1,a,b,252,53)
    box(c,26,466,740,65,HexColor('#E8EFDD'))
    paras(c,'<b>Assembly acceptance:</b> hearth stays still; spindle remains vertical; cord makes one controlled wrap and drives rotation; dust exits through the notch onto a protected catcher. Prepare a fine, dry tinder nest before any drilling.',40,477,710,49,size=10.0,leading=13)
    c.showPage()


def page3(c):
    head(c,'Firecraft / visual method','Bow drill: six sequential actions','Staged photographs show actions; the following checks are the authority.',3)
    arr=[('fire1','STAGE ALL PARTS','Dry cord, hearth, straight spindle, bearing and fine tinder.'),('fire2','WRAP THE SPINDLE','Loop cord once around shaft; test positive rotation.'),('fire3','BRACE AND ALIGN','Hold hearth with foot; keep spindle vertical and handhold steady.'),('fire4','MAKE DARK DUST','Use smooth strokes; dark dust gathers by the notch.'),('fire5','VERIFY THE COAL','Pause gently. Dust must continue to smolder without motion.'),('fire6','IGNITE, THEN FEED','Set the coal in tinder on cleared ground; as flame grows, add fine kindling.')]
    for i,(k,t,b) in enumerate(arr):
        col=i%3;row=i//3;x=26+col*251;y=104+row*221
        photo(c,k,x,y,235,140)
        box(c,x,y+145,235,69,PAPER,7)
        txt(c,x+9,y+150,f'{i+1:02d}  {t}',10.4,True,GREEN)
        paras(c,b,x+9,y+169,217,43,9.6,11.5)
    c.showPage()


def page4(c):
    head(c,'Firecraft / detail & correction','Notch, dust and failure recognition','The ember is an outcome to confirm, not an assumption from smoke.',4)
    draw_notch(c,26,103,260,218)
    box(c,300,103,466,218,PAPER)
    subhead(c,300,103,466,'HOW A COAL IS MADE')
    paras(c,'<b>1.</b> Burn a shallow working socket, then cut the notch from the board edge into the socket.<br/><b>2.</b> Place a stable nonflammable ember catcher below the notch.<br/><b>3.</b> Drill until fine dark dust accumulates and the dust continues to smoke after stopping.<br/><b>4.</b> Transfer the coal gently; a glowing ember may be hidden inside the dust.',315,141,434,155,size=11,leading=19)
    subhead(c,26,336,740,'SIX COMMON FAILURES  /  MAKE ONE CONTROLLED ADJUSTMENT')
    faults=[('NO DARK DUST','Wood wet, overhard, or insufficient contact. Change the pair or dry the set.'),('PALE POWDER','Weak charring: increase consistent contact before speed.'),('BLACK DUST / NO COAL','Dust may be scattered or too thin. Improve the notch and keep the pile still.'),('CORD SLIPS','Cord too slick or loose. Rewrap, retension, or replace.'),('SPINDLE BINDS','Top socket overheats or is rough. Smooth and reduce top friction.'),('COAL GOES OUT','Tinder too coarse, damp or disturbed. Prepare dry fine fibers first.')]
    for i,(t,b) in enumerate(faults):
        x=26+(i%3)*251;y=374+(i//3)*80;ctext(c,x,y,235,t,b,74,'danger' if i==2 else 'neutral')
    c.showPage()




def page5(c):
    head(c,'Firecraft / make the string','No rope? Find, prepare, test a bowstring','The moving cord is often the hardest no-equipment part. Do not confuse static lashings with a durable bowstring.',5)
    cards=[('cord1','INNER-BARK FIBER','Processed bast can be twisted into cord; source identity unverified.'),
           ('cord2','DRIED STALK FIBER','Some mature stalks yield fine strong fibers; verify plant identity.'),
           ('cord3','SPLIT ROOT STRANDS','Often useful for static lashings; moving use must be tested.'),
           ('cord4','RECOVERED LEATHER','Strong strip, though dampness and stretching may reduce grip.'),
           ('cord5','BOOTLACE / SALVAGE','Practical if available; inspect the weak sections and knots.'),
           ('cord6','FABRIC / CORD','Tightly braided cloth or cord may work when not frayed.') ]
    for i,(key,title,desc) in enumerate(cards):
        x=26+(i%3)*251;y=104+(i//3)*158
        photo(c,key,x,y,235,94)
        box(c,x,y+99,235,54,PAPER,6)
        txt(c,x+8,y+105,title,10,True,GREEN)
        paras(c,desc,x+8,y+122,217,27,size=8.8,leading=10.2)
    subhead(c,26,425,740,'BEFORE THE FIRST DRILL STROKE  /  TEST THE CORD')
    box(c,26,454,740,79,PAPER)
    paras(c,'<b>1.</b> Select a continuous length; twist fibers firmly or braid a salvaged strip. <b>2.</b> Fit one controlled wrap around the spindle. <b>3.</b> Test repeated slow strokes with the hearth stable. <b>4.</b> Inspect for slipping, fray, heat, and stretched sections. <b>5.</b> Replace or re-tension rather than forcing a failing cord. <font color="#8E2E25"><b>Do not harvest unidentified toxic plants or cut living trees without permission.</b></font>',39,463,714,60,10.4,13.3)
    c.showPage()

def page6(c):
    head(c,'Water / source and vessel','Collect without declaring it safe','Use natural materials for collection; no natural vessel is automatically sanitized.',6)
    cards=[('water1','RAINFALL','Prefer a clean catch surface; avoid dirty roofs and droppings.'),('water2','BARK VESSEL','A folded vessel may hold water, but leaks and bark residues matter.'),('water3','LEAF / BARK CHANNEL','Direct water with a clean surface; do not claim this disinfects.')]
    for i,(key,title,desc) in enumerate(cards):
        x=26+251*i;photo(c,key,x,105,235,231)
        box(c,x,342,235,87,PAPER)
        txt(c,x+10,353,title,11,True,GREEN)
        paras(c,desc,x+10,377,215,44,10.6,13.1)
    box(c,26,445,740,89,HexColor('#FCE6DC'))
    paras(c,'<b>REJECT THE SOURCE BEFORE FILTERING</b><br/>Avoid visible algal scum, suspected chemicals or fuel, mining or industrial runoff, and known contamination incidents. Clear water may contain germs. No amount of improvised sand, stone, or moss filtration makes chemical/toxin-affected water reliably safe.',40,458,712,69,11.2,15.3)
    c.showPage()


def page7(c):
    head(c,'Water / clarification','Natural filter: build and understand','A debris strainer is helpful; a layered clarifier is not a certified drinking-water filter.',7)
    draw_filter(c,26,106,455,422)
    subhead(c,495,106,271,'BUILD ORDER / FIELD EXPEDIENT')
    for i,(a,b) in enumerate([
      ('CATCH','Collect the outflow in a separate container labeled RAW.'),
      ('MEDIA','Use clean, rinsed sand and gravel; avoid polluted sites.'),
      ('SCREEN','Cloth or clean fibrous top layer catches large debris; moss can add contamination.'),
      ('FLOW','Pour slowly. If sand escapes, improve support and re-clarify.'),
      ('AFTER','Choose a validated disinfection method. Clarified is not potable.')]):
      label(c,495,141+i*78,i+1,a,b,271,72)
    c.showPage()


def page8(c):
    head(c,'Water / no fire scenario','No flame? Choose a verified pathway','Natural filtration can be a preparation step, not the final treatment.',8)
    colw=350
    subhead(c,27,104,740,'A DECISION TREE YOU CAN USE WITH LIMITED EQUIPMENT')
    rows=[
      ('SAFE SUPPLY','Known potable bottled/managed water?','Use clean supply; preserve container hygiene.','green'),
      ('SUN + CLEAR BOTTLE','Clear, suitable transparent plastic bottle and adequate strong sun?','CDC solar exposure: 6 h sunny; 2 days cloudy. Chemical toxins remain.','green'),
      ('DRINKING-WATER CHEMICAL','Approved tablets or correct unscented disinfectant with verified label?','Apply exact product/CDC directions and full contact time.','green'),
      ('RATED FILTER','Tested filter with stated organism removal capability?','Use within rating; viruses may require additional disinfection.','green'),
      ('NONE OF THE ABOVE','Only stone, sand, moss, bark or untested charcoal?','You may clarify, but cannot verify safe drinking water. Seek a safer source or assistance.','red')]
    for i,(tag,q,a,color) in enumerate(rows):
      y=143+i*79
      box(c,27,y,740,72,PAPER)
      box(c,39,y+10,174,52,GREEN if color=='green' else RED,6)
      paras(c,tag,52,y+20,153,40,10.4,12.6,HexColor('#FFFFFF'),True)
      paras(c,q,226,y+9,517,24,10.2,12,INK,True)
      paras(c,a,226,y+33,520,37,9.6,11.2,INK)
    c.showPage()


def page9(c):
    head(c,'Water / winter & failure','When the normal method breaks','Preserve body heat; reject hazards that improvised filtration cannot solve.',9)
    photo(c,'water4',26,104,231,173);photo(c,'water5',270,104,240,173);photo(c,'water6',522,104,244,173)
    subhead(c,26,287,740,'TRIAGE THE FAILURE INSTEAD OF INVENTING A PURIFICATION CLAIM')
    entries=[('WATER LOOKS CLEAR','Not proof of microbial safety. Treat as RAW until validated.'),('FILTER OUTLET CLOUDY','Allow settling; rinse suitable media; avoid assuming repeat passes kill germs.'),('NO CLEAN VESSEL','Prioritize safe-source search or recovery of a suitable container.'),('SNOW / ICE ONLY','Melting requires heat; eating bulk snow can worsen cold stress.'),('SUSPECT BLUE-GREEN ALGAE','Avoid source. Boiling or sand/charcoal does not reliably resolve cyanotoxins.'),('SHORT WINTER DAY','Do not substitute an unvalidated SODIS exposure for required conditions.')]
    for i,(title,desc) in enumerate(entries):
      x=26+(i%2)*375;y=324+(i//2)*70
      ctext(c,x,y,362,title,desc,64,'danger' if i in [3,4] else 'neutral')
    c.showPage()


def page10(c):
    head(c,'Operational checklist','The field sequence: decide, build, verify','One system depends on dry materials. The other depends on a real treatment method.',10)
    box(c,26,103,359,424,PAPER)
    subhead(c,26,103,359,'FIRE  /  60-SECOND CHECK')
    tasks=[('01  Exposure','Dry shelter and heat retention first if cold or wet.'),('02  Fuel staged','Tinder nest, kindling and fuel are ready before friction.'),('03  Materials','Sound dry spindle/hearth; durable cord and handhold.'),('04  Mechanism','Stable hearth, centered spindle, cord wrap, dust notch.'),('05  Outcome','Sustained coal smolders when bow stops.'),('06  Escalate','Coal to tinder, small flame to kindling, fully extinguish.'),('07  Stop','If depleted or freezing: conserve heat and change plan.')]
    for i,(title,desc) in enumerate(tasks):
        y=142+i*52
        txt(c,40,y,title,10.6,True,GREEN);paras(c,desc,41,y+18,328,31,9.4,11)
    box(c,399,103,367,424,PAPER)
    subhead(c,399,103,367,'WATER  /  60-SECOND CHECK')
    tasks=[('01  Reject hazards','Algal bloom or chemical source? Choose another source.'),('02  Collect','Keep RAW container separate from treated water.'),('03  Clarify','Settle/strain/sand-gravel: improves clarity, not safety.'),('04  Disinfect','Boil, SODIS, verified chemical or rated system - if suitable.'),('05  Confirm limits','Viruses, cysts and chemical toxins need correct method.'),('06  Store clean','Prevent recontamination after validated treatment.'),('07  No suitable method','Do not claim that clear raw water is drinkable.')]
    for i,(title,desc) in enumerate(tasks):
        y=142+i*52
        txt(c,412,y,title,10.6,True,GREEN);paras(c,desc,412,y+18,336,31,9.4,11)
    c.showPage()


def prepare():
    # Crop only generated staged art: none is botanical or microbiological evidence.
    sources={
        'fire':Path('/mnt/data/a_highly_detailed_realistic_outdoor_survival_bush.png'),
        'water':Path('/mnt/data/a_hyper_realistic_outdoor_survival_bushcraft_instr.png'),
        'cord':Path('/mnt/data/a_high_resolution_realistic_macro_close_up_collag.png'),
    }
    for prefix,path in sources.items():
        im=Image.open(path).convert('RGB');width,height=im.size
        for j in range(2):
            for i in range(3):
                n=j*3+i+1
                # Remove sheet dividers; crop centrally and preserve output colors
                crop=im.crop((i*width//3+5,j*height//2+4,(i+1)*width//3-5,(j+1)*height//2-6))
                crop.save(AS/f'{prefix}{n}.jpg',quality=84,optimize=True,subsampling=0)
    # Replace unsafe staged hand-held flame image with a small fire on prepared bare ground.
    safe=Image.open('/mnt/data/a_realistic_high_detail_documentary_style_collag.png').convert('RGB')
    sw,sh=safe.size
    safe.crop((2*sw//3+5,sh//2+5,sw-5,sh-5)).save(AS/'fire6.jpg',quality=83,optimize=True)

if __name__=='__main__':
    prepare()
    c=canvas.Canvas(str(OUT),pagesize=(W,H),pageCompression=1,pdfVersion=(1,4))
    c.setTitle('Survival Field Encyclopedia: Track B 010 Mechanism Plates')
    c.setAuthor('Survival Field Encyclopedia - Research Edition')
    c.setSubject('Bow drill and no-fire water decisions, unapproved instructional research pilot')
    for fn in (page1,page2,page3,page4,page5,page6,page7,page8,page9,page10): fn(c)
    c.save()
    print(OUT)
