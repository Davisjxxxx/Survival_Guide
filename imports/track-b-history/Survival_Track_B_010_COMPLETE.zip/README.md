# Survival Field Encyclopedia — Track B 010

**Two mechanisms: bow-drill ignition and no-fire water handling.** Ten landscape reader pages. Supplemental review edition; no publication authorization.

Open `Survival_Field_Encyclopedia_010_Mechanism_Plates.pdf` or **open `index.html` in any browser** to view page JPEGs offline if the PDF does not load. PDFs are 1.4 compatible, readable text; JPEGs are raster fallbacks. `build.py` is the editable source.

The reader deliberately does not contain citations. `docs/SOURCE_REGISTER.csv`, `docs/PHOTO_LEADS.csv`, and `docs/SCOPE_AND_GATES.md` contain the research and outstanding approvals.

**Image disclosure:** staged generated photographs depict concepts, not a real field test or botanical identity. The photo leads in the CSV have NOT been downloaded or embedded. The mechanics are original vector diagrams and need practical review. No real plant/fungal identification photos are claimed.

**Safety:** Natural filtering with sand/gravel/moss is clarification, not drinking-water disinfection. Do not consume visibly contaminated water or claim this process removes viruses, bacteria, parasites, chemicals or algal toxins. In hypothermia conditions, prioritize shelter and energy conservation over repeated friction-fire attempts.
