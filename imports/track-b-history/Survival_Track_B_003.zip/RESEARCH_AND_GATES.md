# Survival Field Encyclopedia — Track B packet 003

Status: **Unapproved research and vector-illustrated reader prototype**. The eight-page book PDF is not a publication release; it has not been field-tested or approved by a qualified human reviewer. The diagrams are original explanatory sketches; no real subject photographs are included. The image acquisition matrix is on page eight of the PDF.

## Verified sources behind the reader instructions

| ID | Primary source | Used for | Notes |
|---|---|---|---|
| W01 | CDC, [Collecting Rainwater and Your Health](https://www.cdc.gov/drinking-water/about/collecting-rainwater-and-your-health-an-overview.html) | All raw rainwater, contamination, first flush, screens, separation | The drawing is a schematic of catchment/collection, not an engineered roof design; CDC says first-flush volume depends on catchment size. |
| W02 | CDC, [Safe Water Storage](https://www.cdc.gov/global-water-sanitation-hygiene/about/about-safe-water-storage.html) | Container hygiene and chemical storage rejection | Recommends 5–9% unscented sodium hypochlorite, 1 teaspoon in 1 liter (~1 quart) water, >=30 s surface contact, drain/air dry or safe-water rinse. |
| W03 | CDC, [How to Make Water Safe in an Emergency](https://www.cdc.gov/water-emergency/about/) | Boiling and limits | 1 min rolling boil; 3 min above 6,500 feet; chemical contamination requires a different approach. |
| W04 | EPA, [Emergency Disinfection of Drinking Water](https://www.epa.gov/ground-water-and-drinking-water/emergency-disinfection-drinking-water) | Clarification, boiling, chemical limitations | EPA presents an inconsistent threshold conversion (5,000 ft / 1,000 m), recorded as a conflict. |
| S01 | NWS, [Lightning Tips](https://www.weather.gov/safety/lightning-tips) | Tarp not lightning-safe; building/vehicle refuge; 30-min rule | No outdoor shelter is safe during thunderstorms. |
| S02 | NWS, [Lightning Outdoors](https://www.weather.gov/safety/lightning-outdoors) | Camping-specific lightning advice | A tent or picnic shelter does not provide protection. |
| S03 | Leave No Trace, [Travel & Camp on Durable Surfaces](https://lnt.org/why/7-principles/travel-camp-on-durable-surfaces/) | Durable ground and 200-ft rule for ordinary campsites | Local rules override general guidance. |

## Deferred technical validation

- Actual dimensions, weather loading, anchors and knot diagrams for a specific tarp product and site are **not specified**. The shelter sketch is conceptual; real field trials and expert review of anchoring/overhead hazards are required before claiming a complete shelter-building procedure.
- A roof catchment's first-flush sizing, potable materials, outlet backflow, structural supports, chemical screening, cold-weather ice, and local rainwater rules must be addressed in later engineering pages. No roof size / collection yield is promised.
- A microbial treatment that cannot remove chemicals must not be presented as a general guarantee of potability.
- The CDC and EPA publish different elevation thresholds for 3-minute boiling; packet currently follows CDC guidance and holds the conflict for human technical review.
- Container disinfection is **not** water disinfection; deliberately avoid conflating the sanitizer recipe with a drinking-water bleach dose.
- Real photographic slots: 12 candidate views shown on PDF page 8. No rights assessment or visual identity verification has occurred. No generated images may be used as species ID evidence.
- Hazardous structures, primitive traps, edible species and medical guidance require their own independent verification. No new such claims are included here.

## Expected progression

Next Track B priorities: (1) obtain rights-cleared real process photographs of each shelter and catchment state, (2) build a close-up mechanical connection atlas with knot/anchor failures, (3) build winter adaptations and drainage constraints, (4) create separate illustrated foraging lookalike plates using confirmed specimen photos and specialist review. Maintain all original zone requirements; do not simplify them to meet a page target.

## Implementation independence

Nothing in this packet changes Git state or D1–D23 owner decisions. Gate A remains blocked; publishing remains unauthorized. Reader pages intentionally omit source and approval mechanics; this research file provides the traceability.
