from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor, Color
from reportlab.lib.utils import simpleSplit
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase import pdfmetrics
from pathlib import Path
P=Path('/mnt/data/Survival_Track_B_003')
pdfmetrics.registerFont(TTFont('DejaVu','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
pdfmetrics.registerFont(TTFont('DejaVu-Bold','/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'))
W,H=792,612
ink=HexColor('#18332E'); green=HexColor('#1E755C'); cream=HexColor('#F6F4EC'); orange=HexColor('#D77D34'); red=HexColor('#AE3D34'); blue=HexColor('#3288A5'); pale=HexColor('#E4EEE7'); gray=HexColor('#62716B')
c=canvas.Canvas(str(P/'Survival_Visual_Field_Cards_003.pdf'),pagesize=(W,H))
c.setTitle('Survival Field Encyclopedia — Illustrated Field Cards 003 (Research Draft)')

def box(x,y,w,h,fill=cream,stroke=None,r=12):
 c.setFillColor(fill); c.setStrokeColor(stroke or fill);c.roundRect(x,y,w,h,r,fill=1,stroke=int(stroke is not None))
def txt(x,y,t,size=11,bold=False,color=ink):
 c.setFillColor(color);c.setFont('DejaVu-Bold' if bold else 'DejaVu',size);c.drawString(x,y,t)
def wrap(x,y,s,width,size=10,leading=15,color=ink,bold=False):
 for line in simpleSplit(s,'DejaVu-Bold' if bold else 'DejaVu',size,width):
  txt(x,y,line,size,bold,color);y-=leading
 return y

def line(x1,y1,x2,y2,col=ink,lw=2):
 c.setLineWidth(lw);c.setStrokeColor(col);c.line(x1,y1,x2,y2)
def poly(pts,fill=None,stroke=ink,lw=2):
 p=c.beginPath();p.moveTo(*pts[0]);[p.lineTo(*pt) for pt in pts[1:]];p.close();c.setLineWidth(lw);c.setStrokeColor(stroke)
 if fill:c.setFillColor(fill)
 c.drawPath(p,fill=int(fill is not None),stroke=1)
def arrow(x1,y1,x2,y2,col=blue):
 import math
 line(x1,y1,x2,y2,col,3);a=math.atan2(y2-y1,x2-x1);q=10;poly([(x2,y2),(x2-q*math.cos(a-.5),y2-q*math.sin(a-.5)),(x2-q*math.cos(a+.5),y2-q*math.sin(a+.5))],col,col,1)
def drop(x,y,r=9,color=blue):
 poly([(x,y+r*1.9),(x-r,y),(x,y-r*.6),(x+r,y)],color,color,1)
def header(num,title,sub):
 c.setFillColor(cream);c.rect(0,0,W,H,fill=1,stroke=0)
 box(0,H-100,W,100,ink,r=0)
 txt(34,H-43,f'{num}  /  FIELD PROCEDURE',10,True,HexColor('#9DDECA'))
 txt(34,H-76,title,24,True,HexColor('#FFFFFF'))
 txt(34,H-122,sub,11,False,ink)
 line(34,42,W-34,42,HexColor('#B9CBC1'),.8)
 txt(34,24,'SURVIVAL FIELD ENCYCLOPEDIA  /  ILLUSTRATED RESEARCH DRAFT',7,True,gray)
 txt(W-72,24,num,9,True,green)
def panel(x,y,w,h,title,accent=green):
 box(x,y,w,h,HexColor('#FFFFFF'),HexColor('#D5E2D9'),10)
 box(x+12,y+h-41,w-24,28,accent,r=5)
 txt(x+22,y+h-33,title,11,True,HexColor('#FFFFFF'))
def callout(x,y,w,h,title,body,bad=False):
 box(x,y,w,h,HexColor('#FCEBE9') if bad else HexColor('#E5F2EC'))
 txt(x+12,y+h-24,title,11,True,red if bad else green)
 wrap(x+12,y+h-45,body,w-24,9,14)
def end():c.showPage()

# page 1
header('01','RAIN CATCHMENT','Treat all captured rain as raw water, not drinking water.')
panel(34,160,453,316,'SET UP A CLEAN, SLOPED CATCHMENT')
# tarp slope
poly([(94,375),(347,340),(382,280),(128,308)],HexColor('#69AD94'),green)
line(94,375,74,219,gray,3);line(347,340,365,218,gray,3);line(128,308,124,218,gray,3);line(382,280,400,218,gray,3)
for x,y in [(155,297),(202,291),(251,286),(301,281)]:drop(x,y,5)
arrow(285,287,401,230)
box(389,190,57,52,HexColor('#ACD5E5'),blue,4)
poly([(389,231),(417,230),(444,230),(444,210),(389,210)],HexColor('#79B9CF'),blue)
txt(62,407,'Suspension and slope',10,True)
txt(261,215,'Lowest corner',9,True)
txt(390,176,'RAW',10,True,red)
txt(56,150,'1  Clean surface    2  Establish a low corner    3  Collect in a covered vessel',8,True)
panel(504,160,254,316,'CHECK BEFORE USE',orange)
wrap(523,413,'Inspect for:',210,11,18,bold=True)
for i,t in enumerate(['Bird droppings or dirt','Smoke / chemical residue','Damaged coatings','Unknown prior container use','Insect entry or open lid']):
 txt(523,378-i*34,'X',12,True,red);wrap(542,378-i*34,t,186,9,13)
callout(34,65,724,78,'STOP: CHEMICAL RISK','Boiling and ordinary microbial disinfection do not remove many chemicals or metals. If the catchment or water may be chemically contaminated, choose another source.',True)
end()
#page2
header('02','FIRST FLUSH + STORAGE','Keep the first dirty runoff away from the collected batch.')
panel(34,145,451,328,'ROOF RUNOFF — CONCEPT ONLY')
poly([(70,369),(258,429),(431,367),(241,307)],HexColor('#A2B9B1'),ink)
line(241,307,241,277,ink,4)
arrow(241,277,162,232,orange)
arrow(241,277,364,232,blue)
box(95,188,100,54,HexColor('#F7D8BD'),orange,5);box(325,188,100,54,HexColor('#BBDCE9'),blue,5)
txt(102,207,'FIRST RUNOFF',9,True,red);txt(341,207,'RAW WATER',9,True,blue)
txt(69,455,'Dirty catchment surface',10,True)
wrap(55,159,'Concept: divert initial contaminated runoff; use a screened, covered storage inlet. First-flush sizing is site-specific and is NOT established by this diagram.',410,9,14)
panel(502,145,256,328,'PROTECT THE COLLECTION')
for i,s in enumerate(['Screen the inlet against debris and insects.','Cover and label the raw-water container.','Keep the raw container separate from treated water.','Empty / clean the system as needed.','Use appropriate treatment for the intended use.']):
 box(520,398-i*55,23,23,pale);txt(527,404-i*55,str(i+1),10,True,green);wrap(552,400-i*55,s,188,9,14)
callout(34,57,724,77,'IF COLLECTING FROM FOLIAGE','Leaf, branch, or improvised runoff does not make water sterile. Debris, animal waste, surface treatments, and airborne pollution remain possible. Keep it classified as untreated water.',True)
end()
#p3
header('03','SANITIZE THE CONTAINER','A clean container is not necessarily sanitized.')
panel(34,146,724,329,'SEQUENCE — FOOD-GRADE WATER CONTAINER')
labels=[('1','WASH','Soap + water'),('2','RINSE','Remove soap'),('3','SANITIZE','Correct bleach mix'),('4','SHAKE','Wet all surfaces'),('5','WAIT','At least 30 sec'),('6','DRAIN / DRY','Air-dry or safe rinse')]
for i,(n,t,b) in enumerate(labels):
 col=i%3;row=i//3;x=55+col*232;y=312-row*135
 box(x,y,210,108,HexColor('#E6F1ED'),HexColor('#B7D9CD'),9)
 txt(x+12,y+75,n,29,True,green);txt(x+54,y+77,t,12,True)
 wrap(x+15,y+43,b,180,10,14)
 if i<5 and col<2:arrow(x+213,y+54,x+228,y+54)
callout(34,54,724,79,'MEASURED SANITIZER — NOT A DRINKING-WATER DOSE','For container sanitation: mix 1 teaspoon (5 mL) of regular unscented 5–9% chlorine bleach with 1 quart (~1 L) of water. Contact all inside surfaces, wait at least 30 seconds, drain, then air-dry. Never use a chemical storage container.',False)
end()
#p4
header('04','TREAT THE WATER, THEN STORE','Clear water can still contain pathogens. Treatment must match the risk.')
panel(34,146,724,325,'FIELD WORKFLOW')
steps=[('01','SOURCE','Reject suspected chemical contamination.'),('02','SETTLE','Allow sediment to fall out.'),('03','CLARIFY','Pass through clean cloth/filter.'),('04','DISINFECT','Boil or use a verified treatment method.'),('05','PROTECT','Cool, cap, label, store separately.')]
for i,(n,t,b) in enumerate(steps):
 x=48+i*141
 box(x,274,133,150,HexColor('#E4EEE7'),HexColor('#C4DDD1'),9)
 txt(x+9,403,n,16,True,green);txt(x+9,375,t,11,True)
 wrap(x+9,348,b,113,9,14)
 if i<4:arrow(x+133,353,x+141,353)
callout(50,171,335,95,'KEEP RAW AND TREATED SEPARATE','Never pour raw catchment water into the clean finished-water container, or return a raw scoop to treated water.')
callout(403,171,335,95,'DON’T TRUST APPEARANCE','Boiling targets germs, not chemicals. A cloth removes particles, not reliably bacteria, viruses, or parasites.',True)
callout(34,56,724,75,'WHEN BOILING IS APPROPRIATE','CDC guidance: bring clarified water to a rolling boil for 1 minute, or 3 minutes above 6,500 ft (1,981 m). Cool naturally and store covered. Local chemical contamination requires a different source.',False)
end()
#p5
header('05','A-FRAME TARP SHELTER','Roof shape, runoff and dry insulation matter more than appearance.')
panel(34,147,461,327,'FRONT + SIDE BUILD VIEWS')
# front
poly([(77,256),(187,408),(301,256)],HexColor('#94CDB7'),green)
poly([(115,256),(187,361),(262,256)],HexColor('#FFFFFF'),ink)
line(187,408,187,256,gray,1)
txt(92,418,'FRONT: equal roof slopes',10,True)
# side
poly([(344,387),(458,367),(458,279),(344,293)],HexColor('#73B39D'),green)
line(338,388,462,368,gray,3)
line(340,285,454,272,gray,2)
txt(324,420,'SIDE: taut ridgeline',10,True)
arrow(434,328,465,281)
wrap(54,219,'1  Select durable, draining ground outside runoff channels.  2  Tension a ridgeline between sound anchors.  3  Drape the tarp evenly.  4  Secure corners and check runoff.  5  Keep bedding off wet soil.',407,10,16)
panel(512,147,246,327,'WHAT TO INSPECT',orange)
for i,t in enumerate(['Dead limbs above','Low drainage channel','Roof sag / water pool','Loose or sharp anchors','Groundsheet edges outside roof','Insufficient sleeping insulation']):
 txt(530,420-i*39,'•',12,True,orange);wrap(547,420-i*39,t,193,9,14)
callout(34,56,724,78,'THUNDERSTORM = LEAVE THE TARP','A tarp or tent is NOT lightning protection. Use a substantial enclosed building or a hard-topped enclosed vehicle. Wait at least 30 minutes after the last thunder before returning.',True)
end()
#p6
header('06','SHELTER TROUBLESHOOTING','See the failure. Make the correction. Check again.')
problems=[('POOL ON ROOF','Sagging center','Retension; steepen roof pitch.'),('RAIN INSIDE','Groundsheet projects past roof','Fold edges inside drip line.'),('WET SLEEPER','No ground insulation','Add a dry insulating sleeping pad.'),('ANCHOR RELEASE','Slack or insecure tie-out','Inspect anchor; retension or relocate.')]
for i,(t,why,fix) in enumerate(problems):
 x=34+(i%2)*368;y=293-(i//2)*152
 panel(x,y,354,139,t,red)
 if i==0:
  line(x+24,y+62,x+110,y+62,ink,2);line(x+24,y+96,x+66,y+70,green,4);line(x+66,y+70,x+110,y+96,green,4);drop(x+68,y+55,4)
 elif i==1:
  poly([(x+24,y+65),(x+67,y+103),(x+110,y+65)],HexColor('#9ACAB7'),green);line(x+22,y+50,x+115,y+50,blue,4);arrow(x+110,y+79,x+124,y+55)
 elif i==2:
  line(x+19,y+55,x+123,y+55,ink,2);box(x+39,y+59,75,11,HexColor('#EBC78D'))
 else:
  line(x+28,y+97,x+112,y+57,ink,2);line(x+112,y+57,x+123,y+50,red,2)
 wrap(x+145,y+84,'FAULT: '+why,191,9,15)
 wrap(x+145,y+52,'FIX: '+fix,191,9,15,bold=True)
callout(34,58,724,75,'WIND OR UNSTABLE TREES','If anchors or overhead limbs cannot be made safe, change location. Do not stay under a dead branch or a shelter that is collapsing.',True)
end()
#p7
header('07','OFFLINE DECISION CARD','When time is limited, follow the dependency order.')
panel(34,120,724,352,'WATER + SHELTER: ACTION ORDER')
for i,(a,b) in enumerate([('A','Pick safer site and water source'),('B','Keep chemicals and runoff out'),('C','Set up catchment and weather protection'),('D','Clean / sanitize receiving container'),('E','Clarify and treat water as required'),('F','Verify, label, and keep supplies separated')]):
 y=390-i*48;box(59,y-12,46,38,green,green,6);txt(76,y+1,a,14,True,HexColor('#FFFFFF'))
 txt(122,y+1,b,12,True)
 if i<5:arrow(84,y-14,84,y-33,blue)
callout(34,52,724,60,'REJECT A BAD START','If the source, collection surface, container history, shelter tree, or storm exposure is unsafe, changing methods or location is better than trying to “fix” the result.',True)
end()
#p8 visual planning
header('08','NEXT PHOTO PLATES','Planned real-world images — not substitutes for verified reference photos.')
panel(34,136,724,336,'PHOTO SHOT LIST FOR THE FIELD BOOK')
entries=[('RAIN','Clean tarp + slope','Low corner close-up','Dirty runoff vs clear runoff'),('CONTAINERS','Food-grade marking','Cap and gasket','Sanitizing equipment'),('SHELTER','Correct A-frame','Roof pooling failure','Groundsheet overlap failure'),('WOOD','Sound anchor','Rotten limb hazard','Finished dry sleeping system')]
for j,(topic,a,b,d) in enumerate(entries):
 y=407-j*75;box(53,y-37,100,54,pale);txt(65,y-7,topic,12,True,green)
 for k,lab in enumerate([a,b,d]):
  x=169+k*182;box(x,y-37,168,54,HexColor('#F4F6F4'),HexColor('#B5C7BD'),6)
  wrap(x+9,y-5,lab,150,9,13)
callout(34,50,724,74,'PHOTOGRAPHIC EVIDENCE','Photo slots intentionally remain empty: real subject identity, copyright permission, captions, and image provenance must be checked before adding specimen or mechanism photos. No synthetic image is used as evidence.')
end();c.save()
print(P/'Survival_Visual_Field_Cards_003.pdf')
