#!/usr/bin/env python3
"""Track B 009 - reader-first water module. Research draft, not publication.
Only editable text and vector annotations. Staged AI images are illustrative only.
"""
from pathlib import Path
from PIL import Image
import math,html,hashlib,zipfile,csv
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
from reportlab.lib.utils import ImageReader
from reportlab.platypus import Paragraph
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.pagesizes import letter

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'Survival_Field_Encyclopedia_009_Water_Zero_Gear.pdf'
A=ROOT/'assets'
W,H=letter
G=HexColor('#163C2B');G2=HexColor('#2A5D48'); OLIVE=HexColor('#6C795E'); C=HexColor('#F6F3E9'); LIGHT=HexColor('#E6E8DC'); WHITE=HexColor('#FFFFFF'); INK=HexColor('#1A2923'); MUTED=HexColor('#53645A'); RED=HexColor('#9E4237'); PINK=HexColor('#F7E6DC'); BLUE=HexColor('#2E6F88'); SKY=HexColor('#E6F1F3'); GOLD=HexColor('#E1B56E')
c=canvas.Canvas(str(OUT),pagesize=letter,pageCompression=1)
c.setTitle('Survival Field Encyclopedia | 009 Water: From No Equipment to Treated Water')
c.setAuthor('Survival Field Encyclopedia - editorial research draft')
PAGE=0

def rounded(x,y,w,h,fill=WHITE,border=None,r=7):
 c.setFillColor(fill); c.setStrokeColor(border or fill)
 c.roundRect(x,y,w,h,r,fill=1,stroke=bool(border))

def box(x,y,w,h,title=None,fill=WHITE,head=G):
 rounded(x,y,w,h,fill)
 if title:
  c.setFillColor(head); c.roundRect(x,y+h-27,w,27,6,stroke=0,fill=1);c.rect(x,y+h-27,w,11,fill=1,stroke=0)
  txt(title,x+11,y+h-7,w-22,10.2,WHITE,True,max_h=20)
 return y+h-(27 if title else 0)

def txt(text,x,top,w,size=10,color=INK,bold=False,max_h=None,leading=None):
 if text is None:return 0
 st=ParagraphStyle('p',fontName='Helvetica-Bold' if bold else 'Helvetica',fontSize=size,leading=leading or size*1.34,textColor=color,spaceAfter=0,spaceBefore=0)
 pp=Paragraph(html.escape(str(text)).replace('\n','<br/>'),st)
 _,hh=pp.wrap(w,1000)
 if max_h is not None and hh>max_h+0.4:
  raise ValueError(f'page {PAGE}: text overflow {hh:.1f}>{max_h:.1f}: {str(text)[:65]}')
 pp.drawOn(c,x,top-hh)
 return hh

def tag(s,x,y,w,bg=G,color=WHITE,size=9):
 rounded(x,y,w,23,bg,r=5);txt(s,x+6,y+18,w-12,size,color,True,max_h=18)

def photo(filename,x,y,w,h):
 im=Image.open(A/filename).convert('RGB')
 ratio=w/h; ir=im.width/im.height
 if ir>ratio:
  nw=round(im.height*ratio);left=(im.width-nw)//2;im=im.crop((left,0,left+nw,im.height))
 else:
  nh=round(im.width/ratio);up=(im.height-nh)//2;im=im.crop((0,up,im.width,up+nh))
 dpi=125; nw=max(130,round(w/72*dpi));nh=max(130,round(h/72*dpi))
 im=im.resize((nw,nh),Image.Resampling.LANCZOS)
 d=A/'derived';d.mkdir(exist_ok=True)
 fp=d/f'{Path(filename).stem}_{nw}_{nh}.jpg'
 if not fp.exists(): im.save(fp,'JPEG',quality=72,optimize=True,subsampling=0)
 c.saveState();clip=c.beginPath();clip.roundRect(x,y,w,h,6);c.clipPath(clip,fill=0,stroke=0)
 c.drawImage(str(fp),x,y,w,h)
 c.restoreState()

def rule(x1,y1,x2,y2,col=LIGHT,thick=1):
 c.setStrokeColor(col);c.setLineWidth(thick);c.line(x1,y1,x2,y2)

def circ(n,x,y,bg=G,r=11):
 c.setFillColor(bg);c.circle(x,y,r,fill=1,stroke=0)
 c.setFillColor(WHITE);c.setFont('Helvetica-Bold',9.5);c.drawCentredString(x,y-3,str(n))

def arr(x1,y1,x2,y2,col=G2):
 rule(x1,y1,x2,y2,col,1.8)
 ang=math.atan2(y2-y1,x2-x1)
 for a in [ang+0.48,ang-0.48]:rule(x2,y2,x2-7*math.cos(a),y2-7*math.sin(a),col,1.8)

def start(title,kicker='Minnesota / Upper Midwest | No gear  >  Improvised  >  Equipped'):
 global PAGE
 PAGE+=1
 c.setFillColor(C);c.rect(0,0,W,H,fill=1,stroke=0)
 c.setFillColor(G);c.rect(0,707,W,85,fill=1,stroke=0)
 c.setFillColor(GOLD);c.rect(0,705,W,3,fill=1,stroke=0)
 txt('SURVIVAL FIELD ENCYCLOPEDIA  /  TRACK B 009',27,780,550,9.5,HexColor('#DCE9DB'),True,max_h=15)
 txt(title,27,758,558,21.4,WHITE,True,max_h=36)
 txt(kicker,27,724,556,9.0,HexColor('#DFEADD'),False,max_h=18)
 rule(26,36,585,36,LIGHT,0.8)
 txt('ILLUSTRATED RESEARCH DRAFT  /  ALL WATER IS RAW UNTIL ADEQUATELY TREATED',28,30,488,7.0,MUTED,True,max_h=11)
 c.setFillColor(G);c.setFont('Helvetica-Bold',9);c.drawRightString(585,17,f'{PAGE:02d}')

def finish():c.showPage()

def note(y,s,bg=PINK,col=RED,high=55):
 rounded(27,y,558,high,bg);txt(s,40,y+high-9,531,9.3,col,True,max_h=high-16)

def triptych(items,y=382,h=268):
 colw=176; xs=[27,218,409]
 for idx,(im,title,desc) in enumerate(items):
  x=xs[idx];box(x,y,colw,h)
  photo(im,x+6,y+h-128,colw-12,122)
  circ(idx+1,x+18,y+h-145,r=10)
  txt(title,x+33,y+h-135,colw-42,10,G,True,max_h=35)
  txt(desc,x+10,y+h-170,colw-19,9.2,INK,max_h=h-178)

def steps(rows,x=39,top=640,width=520,gap=58):
 for i,(head,body) in enumerate(rows):
  yy=top-i*gap
  circ(i+1,x+10,yy-12,r=12)
  txt(head,x+32,yy,width-40,10.4,G,True,max_h=18)
  txt(body,x+32,yy-19,width-40,9.2,INK,max_h=gap-22)

# 1: cover
start('WATER: FROM NOTHING TO SAFE STORAGE','Field skills | Collect | Contain | Clarify | Treat | Protect')
photo('bark_runoff.jpg',27,360,360,324)
photo('boiling.jpg',397,523,189,161)
photo('bark_cup.jpg',397,360,189,154)
box(27,206,558,141,'THE HARD TRUTH',fill=WHITE)
txt('Finding water is NOT the same as making it drinkable.',43,306,523,15.4,G,True,max_h=28)
txt('No gear may let you collect rain or carry untreated water, but it may leave you without a dependable way to kill microbes or remove chemicals. Never label a natural filter as a purifier.',43,273,523,10.2,INK,max_h=64)
box(27,64,558,128,'THE METHOD LADDER')
for i,(a,b) in enumerate([('NO GEAR','Find a lower-risk source; collect and assess. Treatment may be impossible.'),('IMPROVISE','Find a suitable vessel, heat source, and separate clean storage.'),('EQUIPPED','Use tested filtration and disinfection, or an appropriate boiling method.')]):
 y=160-i*31
 tag(a,40,y-9,111,G2 if i else G,size=8)
 txt(b,166,y+7,404,8.5,max_h=27)
finish()

# 2 selection overview
start('ONE DECISION CHANGES EVERYTHING','Start with exposure and source hazards, not with an improvised filter.')
box(27,327,558,360,'DECISION PATH',fill=WHITE)
questions=[('1. SUSPECT CHEMICALS OR BLOOM?','Oil sheen, mine or factory discharge, farm runoff, algal scum or spill?','Reject source. Seek another source; boiling will not fix it.',RED),
('2. CAN YOU COLLECT WITHOUT HARM?','Rain or other available water; clean vessel or catchment?','Collect and label RAW. Never call it treated.',G2),
('3. DO YOU HAVE A HEAT-SAFE VESSEL?','An intact suitable pot plus safe outdoor fuel?','Settle cloudy water, then boil using validated timing.',G2),
('4. NO RELIABLE TREATMENT?','No suitable pot, treatment product, or filter + disinfectant?','Do not invent a guaranteed zero-gear purifier.',RED),
('5. SAFE STORAGE?','Clean covered container, clean hands or scoop?','Protect treated water from contact with raw water.',G2)]
for i,(head,q,answer,col) in enumerate(questions):
 yy=623-i*63
 tag(str(i+1),42,yy-1,28,col,size=10)
 txt(head,82,yy+16,478,10.2,G,True,max_h=18)
 txt(q,82,yy-1,476,9.0,INK,max_h=20)
 txt(answer,82,yy-20,476,9.0,col,True,max_h=24)
note(207,'Never risk worsening exposure, hypothermia, or collapse to build a water gadget with uncertain output.',high=100)
box(27,60,558,130,'THREE DISTINCT STATES',fill=WHITE)
for i,(a,b,col) in enumerate([('RAW','Collected water. May contain microbes or chemicals.',RED),('CLARIFIED','Visible dirt reduced. Still NOT potable.',BLUE),('TREATED','Appropriate validated process completed; contamination risk addressed.',G2)]):
 y=152-32*i
 tag(a,40,y-10,108,col);txt(b,157,y+8,413,9.0,max_h=29)
finish()

# 3 source decisions
start('FIND THE LOWER-RISK SOURCE','Looks clear  !=  verified safe  |  Minnesota lakes, wetlands, streams and rain')
photo('forest_rain.jpg',27,382,270,302)
box(307,382,278,302,'CHOOSE WITH CAUTION')
texts=[('RAIN','A clean, direct catch may avoid surface runoff, but rain can still contain contaminants.'),('SPRINGS / FLOWING WATER','A clear appearance does not rule out pathogens. Treatment is still required.'),('LAKE / RIVER','Avoid shore scum, sewage exposure, or runoff. Do not assume flowing equals safe.'),('WINTER SNOW','Untracked snow away from roads is a collection candidate; melting is not disinfection.')]
for i,(a,b) in enumerate(texts):
 yy=637-i*64
 txt(a,321,yy,241,9.5,G,True,max_h=16)
 txt(b,321,yy-15,242,8.4,INK,max_h=46)
box(27,117,558,244,'REJECT OR RELOCATE',fill=WHITE,head=RED)
for i,(head,b) in enumerate([('ALGAE / SCUM','Suspected harmful bloom: avoid. Boiling can concentrate toxins.'),('CHEMICALS','Fuel, pesticide, solvent, heavy metal or unknown industrial exposure: new source required.'),('SEWAGE / ANIMAL WASTE','Avoid obvious fecal contamination and heavily impacted areas; choose a less affected source.'),('UNSAFE ACCESS','Fast current, unstable bank, thin ice or high fall risk: do not approach.')]):
 yy=323-i*49
 tag('NO',39,yy-15,43,RED,size=9)
 txt(head,91,yy+7,464,9.2,RED,True,max_h=17)
 txt(b,91,yy-11,464,8.7,INK,max_h=31)
finish()

# 4 rain
start('NO-GEAR METHOD: CATCH RAIN','Natural surfaces can catch small amounts; none makes water clean by itself.')
triptych([('forest_rain.jpg','WAIT FOR DIRECT RAIN','Use precipitation, not water draining from soil, animal nests, painted roofs or unknown materials.'),('bark_runoff.jpg','COLLECT RUNOFF','A clean, known, non-toxic surface can guide rain into a vessel. Avoid debris and droppings.'),('bark_cup.jpg','PROTECT THE SAMPLE','Keep a suitable container covered as much as possible. Record it as RAW water.')],y=375,h=309)
box(27,186,558,175,'IF NOTHING CLEAN WILL HOLD WATER',fill=WHITE)
steps([('Do not spend all your energy on dew.','Tiny yields and doubtful cleanliness make dew or leaf drip unreliable as the primary plan.'),('Seek a viable vessel.','A sound found container may be a better investment than hours of complex natural craft.'),('Prioritize exposure management.','Shelter and body temperature come first when water collection threatens immediate safety.')],x=39,top=329,gap=48)
note(64,'Natural collection does not remove microbes or dissolved chemicals. Do not claim that rainwater is automatically drinkable.',high=104)
finish()

# 5 folded bark container
start('FOLDED BARK: A CARRIER, NOT A PURIFIER','A real traditional vessel concept; use suitable fallen bark and prove the seams.')
photo('bark_cup.jpg',27,357,300,326)
box(337,357,248,326,'WHAT A VESSEL REQUIRES')
for i,(a,b) in enumerate([('MATERIAL','Sound, appropriately identified, clean bark from fallen material.'),('FORM','A broad intact sheet; corners fold without cracking.'),('JOIN','Secure folds mechanically with suitable twigs or natural cord; no unknown glues.'),('TEST','Hold a small volume, watch every seam, then test for leaks.'),('LIMIT','Not heat-safe, not sterile, and not proof against chemicals.')]):
 yy=644-i*60
 txt(a,349,yy,225,9.7,G,True,max_h=17)
 txt(b,349,yy-19,222,9.0,max_h=40)
box(27,145,558,198,'FOLD / SEAL / CHECK - CONCEPT DIAGRAM')
# vector shallow folded sheet to cup
for i,lab in enumerate(['1. Intact sheet','2. Fold corners','3. Secure joins','4. Leak test']):
 x=42+i*137
 c.setStrokeColor(G2);c.setLineWidth(1.4)
 if i==0:
  c.setFillColor(LIGHT);c.roundRect(x+19,225,93,68,4,fill=1,stroke=1)
 elif i==1:
  c.setFillColor(LIGHT);c.roundRect(x+24,230,79,54,4,fill=1,stroke=1)
  rule(x+24,230,x+44,249,G2);rule(x+103,230,x+83,249,G2)
 elif i==2:
  c.setFillColor(LIGHT);c.roundRect(x+26,232,74,52,5,fill=1,stroke=1)
  for k in range(3):rule(x+26,236+15*k,x+18,236+15*k,G)
 else:
  c.setFillColor(LIGHT);c.roundRect(x+27,232,72,52,5,fill=1,stroke=1)
  c.setFillColor(SKY);c.rect(x+29,234,68,29,fill=1,stroke=0)
 txt(lab,x+4,214,128,8.4,G,True,max_h=20)
note(65,'Do not strip living trees. These staged visuals do not demonstrate a tested watertight design or validate every bark species.',high=65)
finish()

# 6 gear options
start('IF YOU FIND MATERIALS: UPGRADE THE VESSEL','The ability to hold and safely heat water changes the entire strategy.')
box(27,422,558,262,'WHAT COUNTS AS USEFUL?')
rows=[('HEAT-SAFE METAL POT','Best practical improvised route to controlled boiling; clean first and inspect for damage.'),('KNOWN FOOD-SAFE BOTTLE','Useful for carrying treated water. Do not heat ordinary plastic or reuse chemical containers.'),('SOUND BARK OR WOODEN VESSEL','Can carry raw water if tested for leaks; not automatically heat-safe or sanitary.'),('CLEAN CLOTH','Useful to reduce large sediment; it does not disinfect water.'),('PROPER TREATMENT PRODUCT','Follow the exact device/tablet directions and organism coverage; do not invent doses.')]
for i,(a,b) in enumerate(rows):
 yy=649-47*i
 tag(str(i+1),43,yy-10,24,G2)
 txt(a,76,yy+12,484,9.5,G,True,max_h=18)
 txt(b,76,yy-6,486,8.8,max_h=34)
photo('boiling.jpg',27,215,275,192)
photo('two_samples.jpg',313,215,272,192)
box(27,63,558,139,'WHAT TO AVOID',head=RED)
txt('Chemical drums, fuel bottles, unknown coatings, painted cans, cracked containers and improvised plastic cookware can create risks beyond microbes.',41,161,520,10.5,RED,True,max_h=60)
txt('A vessel is not safe simply because it holds water.',41,108,520,9.7,INK,max_h=26)
finish()

# 7 clarity
start('CLARIFY MUDDY WATER','Settling and cloth straining remove visible sediment - NOT pathogens.')
photo('settling.jpg',27,304,274,378)
photo('two_samples.jpg',312,495,273,187)
box(312,304,273,177,'WORKING ORDER')
steps([('WAIT','Let silt collect at the bottom.'),('DECANT','Carefully separate the clearer upper water.'),('STRAIN','If possible, pass through a clean cloth.')],x=323,top=447,width=254,gap=41)
box(27,134,558,157,'RESULT: CLEARER DOES NOT MEAN SAFE',head=BLUE)
txt('Invisible bacteria, viruses, parasites and dissolved chemicals can remain in crystal-clear water. The clarified sample still requires the appropriate treatment method.',42,249,520,11.1,INK,max_h=80)
# state labels
for i,(a,col) in enumerate([('MUDDY',RED),('SETTLED',BLUE),('STILL RAW',RED)]):tag(a,43+i*172,146,145,col)
note(63,'Never put clarified water into a container reserved for treated water unless that container is clean and sanitary.',high=58)
finish()

# 8 boiling
start('BOIL WHEN YOU HAVE A SUITABLE POT','A controlled boil addresses disease-causing microbes, not harmful chemicals.')
photo('boiling.jpg',27,331,277,353)
box(315,331,270,353,'BOIL / COOL / STORE')
rows=[('FIRST','Reject sources suspected of fuel, chemicals, heavy metals or harmful algal toxins.'),('IF CLOUDY','Allow sediment to settle and filter through clean cloth first.'),('BOIL','Bring clear water to a rolling boil for at least 1 full minute.'),('HIGH ALTITUDE','Use 3 minutes above 5,000 ft (conservative threshold; see research notes).'),('COOL / COVER','Allow to cool naturally; transfer to clean, covered storage.')]
for i,(a,b) in enumerate(rows):
 yy=640-i*60
 txt(a,329,yy,232,9.4,G,True,max_h=18)
 txt(b,329,yy-19,231,8.9,max_h=42)
box(27,135,558,180,'WHY THE POT MATTERS')
for i,(head,desc,col) in enumerate([('GOOD: intact metal pot','A compatible heat-safe vessel lets you observe a rolling boil.',G2),('BAD: plastic or bark in open fire','May melt, ignite or contaminate water; do not substitute.',RED),('BAD: hot-rock guesswork','Unknown rock spalling, burns and incomplete heating; not a validated default.',RED)]):
 yy=278-i*47
 tag(head,40,yy-12,225,col,size=8.4)
 txt(desc,274,yy+10,293,8.9,max_h=36)
note(60,'The absence of a pot is a real capability limit. The book must not conceal it behind an untested stone-boiling trick.',high=59)
finish()

# 9 alternative systems
start('FILTERS, TABLETS AND UV','Equipped alternatives require matching the device to bacteria, viruses and parasites.')
box(27,423,558,260,'TREATMENT IS NOT ONE UNIVERSAL PRODUCT')
for i,(a,b) in enumerate([('CERTIFIED / TESTED FILTER','Follow pore specifications and instructions. Many backcountry filters do not reliably address viruses.'),('FILTER + DISINFECT','CDC recommends adding appropriate disinfection after filtration when needed for coverage.'),('CHEMICAL TABLETS','Follow product directions for source clarity, time and temperature. Not all chemicals kill Cryptosporidium.'),('UV UNITS','Work only within specified water clarity, volume, power and operating conditions.'),('SOLAR DISINFECTION','Requires a suitable clear bottle and specific sun exposure; not a no-gear or all-weather guarantee.')]):
 yy=642-48*i
 txt(a,41,yy,523,9.6,G,True,max_h=18)
 txt(b,41,yy-17,520,9.1,max_h=34)
box(27,191,558,220,'WHEN A NATURAL FILTER FAILS')
# simple filter cross section schematic
x=47;y=225;c.setStrokeColor(G2);c.setLineWidth(1.5)
c.line(x+25,y+151,x+128,y+151);c.line(x+25,y+151,x+47,y+15);c.line(x+128,y+151,x+106,y+15);c.line(x+47,y+15,x+106,y+15)
for color,bt,ht in [(LIGHT,40,32),(HexColor('#B5A48B'),70,30),(HexColor('#6F7771'),100,30)]:
 c.setFillColor(color);c.rect(x+49,y+bt,55,ht,fill=1,stroke=0)
txt('SAND / GRAVEL / CHARCOAL',215,366,351,10,G,True,max_h=18)
txt('A household-looking filter can reduce visible debris, but variable DIY layers do not establish pathogen removal or safe chemical treatment.',215,341,350,9.5,max_h=78)
arrow_x=150; arr(160,292,204,292,RED)
tag('NOT A PURIFIER',218,224,191,RED)
note(66,'Do not assume that clear water, home-charcoal, repeated straining, UV sunshine, or tree sap makes water potable.',high=104)
finish()

# 10 snow/winter
start('MINNESOTA WINTER: SNOW AND ICE','Water is present, but collecting and heating it can increase cold exposure.')
box(27,367,558,317,'WINTER DECISION PATH')
steps([('KEEP WARM FIRST','Severe cold and wind make exposure more urgent. Do not remove gloves or sweat heavily gathering snow.'),
('CHOOSE A LOWER-RISK SAMPLE','Avoid roadbanks, plowed snow, unusual colors, animal waste, industrial areas or salted snow.'),
('MELT IF EQUIPPED','Use a suitable vessel and safe outdoor heat source. Avoid eating solid snow to hydrate.'),
('TREAT IF NEEDED','Melted snow and ice can still carry pathogens or chemicals; freezing does not certify potability.'),
('PROTECT STORED WATER','Keep the clean vessel closed and minimize freezing and recontamination.')],x=43,top=640,width=520,gap=55)
# winter vector
box(27,162,558,194,'CROSS SECTION: CLEAN COLLECTION IS NOT A TREATMENT')
# ground and snow with stylized mounds
c.setFillColor(HexColor('#72867E'));c.rect(42,216,320,9,fill=1,stroke=0)
c.setFillColor(SKY);p=c.beginPath();p.moveTo(42,225)
for xx,yy in [(76,243),(110,230),(148,255),(185,243),(223,252),(265,233),(330,239),(362,225)]:p.lineTo(xx,yy)
p.lineTo(362,225);p.close();c.drawPath(p,fill=1,stroke=0)
for xx,yy in [(103,266),(179,263),(246,272)]:c.setFillColor(BLUE);c.circle(xx,yy,2.8,fill=1,stroke=0)
txt('FRESHER COLLECTION ZONE',57,311,290,10,G,True,max_h=20)
txt('Avoid road salt, ash, animals and traffic contamination.',57,294,295,8.8,max_h=40)
tag('MELT != DISINFECT',379,251,184,RED)
note(62,'Never make an enclosed fire in a snow shelter. Seek rescue rather than taking unsafe risks on ice or near open water.',high=82)
finish()

# 11 failure chart
start('WHEN WATER IS STILL UNSAFE','Six failure scenes that must stop a claimed treatment or trigger a new source.')
problems=[('GREEN SCUM','Possible algal toxins.','Switch source; boiling can worsen concentration.'),('STRONG CHEMICAL SMELL','Fuel, solvents or spill risk.','Switch source; no simple field cure.'),('CLOUDY AFTER STRAINING','Settling or filtering incomplete.','Clarify first; still requires treatment.'),('NICE AND CLEAR','Looks clean but may have germs.','Never use appearance as certification.'),('DIRTY SCOOP','Treated water touched by contaminated item.','Reassess storage sanitation and re-treatment.'),('NO RELIABLE TREATMENT','Natural material kit only.','Do not promise safe water; seek supplies or assistance.')]
for i,(a,b,d) in enumerate(problems):
 row=i//2; col=i%2
 x=27+col*284; yy=467-row*195
 box(x,yy,273,181,fill=WHITE,head=RED)
 tag('FAILURE',x+10,yy+140,79,RED)
 txt(a,x+98,yy+159,166,10,G,True,max_h=22)
 txt(b,x+11,yy+124,247,9.3,max_h=42)
 rounded(x+9,yy+15,255,83,HexColor('#ECF1E8'))
 txt('NEXT ACTION',x+20,yy+88,231,9,G2,True,max_h=14)
 txt(d,x+20,yy+70,230,9.2,max_h=58)
finish()

# 12 material reference
start('MATERIALS: WHAT NATURE CAN PROVIDE','Collection material is not evidence of species identity or drinking safety.')
triptych([('bark_cup.jpg','FOLDED BARK','If suitable fallen bark is available, test an improvised carrier for leak-tightness. Never place it over flame.'),('bark_runoff.jpg','LARGE LEAVES','Known non-toxic, clean leaves may help redirect small amounts of rain; fragile, low-yield and contamination-prone.'),('forest_rain.jpg','DIRECT RAIN','Small direct catches avoid some soil contact. Collection still does not guarantee safe drinking.')],y=364,h=322)
box(27,155,558,194,'THE REGIONAL PHOTO ATLAS MUST ADD')
for i,(a,b) in enumerate([('BIRCH / BARK','Whole tree, bark detail, fallen material, foldability, negative examples, rights.'),('COMMON LEAVES','Known safe vs unidentified leaf; effects of rain contact, surface contamination and yield.'),('TOOLS / VESSELS','Only tested, rights-cleared photographs and mechanically verified constructions.')]):
 yy=310-i*51
 txt(a,41,yy,520,9.5,G,True,max_h=19)
 txt(b,41,yy-20,519,9.0,max_h=38)
note(61,'The real species images must be verified separately. These staged photos demonstrate a concept, not botanical identification.',high=78)
finish()

# 13 explicit limits
start('NO CONTAINER? NO HEAT? NO GUARANTEE.','Confront the hardest scenario instead of inventing a natural purifier.')
box(27,400,558,283,'WHAT ZERO-GEAR MEANS')
for i,(a,b,col) in enumerate([('WHAT YOU MAY DO','Look for lower-risk source and collect small amounts using a viable natural carrier.',G2),('WHAT YOU MAY NOT CLAIM','Bark, leaves, sand, charcoal, dew, snow and a folded vessel do NOT reliably eliminate pathogens.',RED),('WHAT MUST CHANGE','Locate an appropriate vessel, validated treatment method, additional supplies or rescue.',G2),('WHEN TO STOP','If water access requires falling, entering icy water, or becoming dangerously cold, withdraw.',RED)]):
 yy=646-i*63
 tag(str(i+1),40,yy-5,30,col)
 txt(a,80,yy+13,484,9.8,G,True,max_h=18)
 txt(b,80,yy-7,482,9.0,max_h=44)
box(27,143,558,242,'WHAT NOT TO TRUST AS A COMPLETE TREATMENT',head=RED)
for i,a in enumerate(['A plastic-sheet solar still that produces only drops, or needs supplies you do not have.',
'Sand-and-charcoal bottle construction without demonstrated microbial performance.',
'Hot stones dropped into a fragile container without verified safe rock, vessel and temperature.',
'Sunlight exposure without the appropriate clear bottle, clear water and time controls.',
'Untreated stream, spring or ice water merely because it looks and tastes fine.']):
 txt(f'{i+1}. {a}',42,339-i*39,529,8.9,max_h=35)
note(59,'Field judgment cannot turn an unvalidated treatment into a safe instruction. This limitation is part of an honest worst-case guide.',high=70)
finish()

# 14 takeaway
start('FIELD CARD: DECIDE, ACT, VERIFY, ABORT','A short sequence for fast reference. Source dossiers stay outside reader pages.')
box(27,369,558,315,'SIX-STEP WATER SYSTEM')
steps([('1 - REJECT TOXINS','Suspected fuel, chemicals, fertilizer or algal bloom? Switch sources.'),
('2 - COLLECT','Use the cleanest viable catchment and container available; label raw.'),
('3 - CLARIFY','If cloudy, settle and strain without claiming disinfection.'),
('4 - TREAT','Boil in a suitable vessel or use validated treatment equipment and instructions.'),
('5 - STORE','Use a clean, covered container with clean handling; keep raw separate.'),
('6 - RECHECK','If handling, storage, method or contamination is uncertain, do not mark as safe.')],x=42,top=646,width=518,gap=47)
box(27,168,558,186,'UPGRADE LADDER')
for i,(a,b) in enumerate([('NATURAL','Gather cautiously. Treat still unresolved without suitable means.'),('IMPROVISED','Obtain tested heat-safe vessel and suitable outdoor heat; boil.'),('EQUIPPED','Bring a verified filter/disinfectant combination and water-safe storage.')]):
 y=320-i*48
 tag(a,42,y-8,112,G if i==0 else G2)
 txt(b,167,y+9,392,9.4,max_h=38)
note(63,'This is a research draft. Illustrated concepts require physical verification and specialist review before publication.',high=84)
finish()

c.save()
print('PDF',OUT,'pages',PAGE,'bytes',OUT.stat().st_size)
