# Survival Field Encyclopedia | Track B 009

## Files
- `Survival_Field_Encyclopedia_009_Water_Zero_Gear.pdf`: 14-page compact book draft, built with compatible PDF 1.4/Helvetica text.
- `build.py`: editable layout, all captions, headings, sequences, warning copy, and vector diagrams.
- `assets/`: six staged AI collage crops (not specimen-identity evidence) and embedded optimized JPEG derivatives.
- `previews/`: independent reader page JPEGs and contact sheet.
- `index.html`: offline alternative for browsers with PDF issues.
- `RESEARCH_AND_GATES.md`: separate evidence, decision log, unresolved review and copyright restrictions.
- `PHOTO_BRIEFS.csv`: requirements for real, rights-cleared diagnostic and field-test photography.

## Scope
This packet explores **No Equipment -> Improvised -> Equipped** water sourcing, collection, storage, treatment and limitations for the Upper Midwest. It does not provide false assurance that untreated rain, dew, snow, or DIY filters are drinkable. Field use requires qualified review and testing.

## Status
- Track B illustration/research only.
- **Gate A blocked**. Content publication **NOT AUTHORIZED**.
- No contents added to `/home/jd/Survival_Guide`; no Git changes.
- Do not treat the packet index `009` as sprint `S09`. Master plan has **16 sprints S00-S15**: S01 unresolved Gate A, and S02-S15 remain open.

## Build
`python build.py` (Pillow and ReportLab required). Avoid changing the ready PDF without re-rendering and visually reviewing every page.
