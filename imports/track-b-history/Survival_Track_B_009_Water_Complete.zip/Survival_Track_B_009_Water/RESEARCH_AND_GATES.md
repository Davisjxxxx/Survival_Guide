# Track B 009 - Water survival from no equipment

**Artifact state:** Visual research draft; not approved, field-tested, ingested, or publishable. Gate A remains blocked. This is one Track B packet, not one completed master-plan sprint.

## Reader design

- Reader pages omit citation clutter and engineering gate records. The following material remains in this private companion dossier.
- Every water sample is RAW until suitable treatment addresses the credible hazards. A clear sample can remain unsafe.
- Use progression: NO GEAR (gather, carry, assess) -> IMPROVISE (obtain heat-safe vessel and safe outdoor heat) -> EQUIPPED (appropriate certified filter / disinfection system).
- Do not promise that natural sand, charcoal, leaves, a bark cup, dew, condensation, solar still, snow, or hot stones guarantee drinkable water.
- The six images in the PDF are **AI-created staged instruction concepts**, not documentary photos and not species-identity or procedural-validation evidence. In particular, the generated bark cup should not be treated as an independently tested design.

## Source register (accessed November 21, 2026)

| ID | Organization and document | Locator | Supports |
|---|---|---|---|
| W-CDC-001 | CDC, How to Make Water Safe in an Emergency | https://www.cdc.gov/water-emergency/about/index.html | Sediment clarification, boiling, germs vs chemicals, covered storage, devices/UV limitations |
| W-CDC-002 | CDC, Collecting Rainwater and Your Health | https://www.cdc.gov/drinking-water/about/collecting-rainwater-and-your-health-an-overview.html | Rainwater may contain germs/chemicals, collection contamination, first-flush principles |
| W-CDC-003 | CDC, Water Treatment Options When Hiking, Camping, or Traveling | https://www.cdc.gov/drinking-water/prevention/water-treatment-hiking-camping-traveling.html | Boil best for germs; filtration plus disinfection; chemical contamination exclusions |
| W-EPA-001 | EPA, Emergency Disinfection of Drinking Water | https://www.epa.gov/ground-water-and-drinking-water/emergency-disinfection-drinking-water | Emergency boil/bleach, disinfection limits, chemicals and altitude |
| W-MDH-001 | Minnesota Department of Health, Preventing Illness while Camping, Hiking, and Traveling | https://www.health.state.mn.us/diseases/waterborne/prevention/backcountry.html | Clear source still contaminated; backcountry boil/filtration guidance |
| W-MDH-002 | Minnesota Department of Health, Harmful Algal Blooms | https://www.health.state.mn.us/diseases/hab/hab.html | Avoid blooms, boiling may increase toxin concentrations |
| W-NOAA-001 | NOAA, The Great Outdoors: Weather Safety | https://www.noaa.gov/explainers/great-outdoors-weather-safety | Melt snow rather than eat un-melted snow; exposure priorities |
| W-UMI-001 | U. Michigan MuseumAnthro, Birch Bark Container | https://museumcollab.anthro.lsa.umich.edu/s/Anishinaabe/item/105 | Historical example of one folded/stitched bark vessel; not validation of our staged build |
| W-SMI-001 | Smithsonian, Algonquin birch-bark sap buckets | https://www.si.edu/object/sap-bucket%3ANMAI_165299 | Provenance evidence for historical birch-bark containers; separate image rights |

## Decisions and unresolved quality checks

1. **Boiling elevation threshold:** CDC generally specifies 1 minute at a rolling boil and 3 minutes above 6,500 ft. EPA's current page says 3 minutes above 5,000 ft but pairs it with an erroneous 1,000 m metric equivalent. The pilot conservatively uses 3 minutes above **5,000 ft**, which is stricter than the CDC guidance. This editorial choice requires independent technical review before publication. In Minnesota's normal elevations, the CDC one-minute rule applies to clear water.
2. **No-gear water treatment:** Neither a natural folded vessel nor generic field media establishes reliable disinfection. There is no guaranteed potable treatment in a genuinely zero-equipment scenario, and the guide must make that limitation visible.
3. **First flush:** CDC confirms a first-flush diverter can reduce contamination, but required flush volume is catchment-specific. Do not prescribe a universal 5-10 minutes for a small leaf/bark catchment.
4. **Chemicals and algal toxins:** Boiling, general disinfection, and most camp filters cannot reliably remove these. Avoid the source, rather than presenting an improvized purification step.
5. **Container safety:** Not all bark, leaves, salvaged bottles, or metal pots are appropriate. No live-tree bark stripping; no fuel/chemical bottle reuse; heat only in an appropriate heat-safe vessel. Natural container construction requires physical testing, botanical material identification, and local collecting-law review.
6. **SODIS and solar still:** Solar disinfection can work under documented conditions with a suitable clear bottle, but is not a no-gear method. A solar still has low and variable yield and needs materials; do not imply dependable water supply or chemical safety.
7. **Snow:** Snow-melting limits are source- and exposure-dependent; melting does not disinfect. No enclosed combustion.
8. **Future editorial:** Add quantitative capacity/time/yield field experiments; dry vs wet material tests; winter freezing; riverbank access; raw/treated storage protocols; sanitation methods by actual container; technical diagrams from tested vessels.

## Required human verification

- Water-treatment specialist or public-health reviewer: source exclusion, time, device coverage, microbial vs chemical hazards.
- Field-skills practitioner: actual bark-cup sealing, collection yield, mechanical stability, field use in wind/rain.
- Image specialist: replace AI illustration with rights-cleared documentary step photos, label synthetic reconstructions accurately, verify relevant tree and plant specimens.

## Media provenance

- `assets/forest_rain.jpg`, `bark_cup.jpg`, `bark_runoff.jpg`, `settling.jpg`, `boiling.jpg`, `two_samples.jpg`: crops of one synthetic generated collage (not real-world documentary photographs).
- All captions and quantities in the PDF are editable ReportLab text, not rasterized AI-generated captions.
- 14 pages, built-in PDF fonts (Helvetica), portable PDF 1.4. No scripts or embedded external links required to render.

## Release status

**NOT AUTHORIZED FOR PUBLICATION.** No local Git changes or project ingestion. Freeze only as a draft review packet; do not count as a completed master-plan sprint.
