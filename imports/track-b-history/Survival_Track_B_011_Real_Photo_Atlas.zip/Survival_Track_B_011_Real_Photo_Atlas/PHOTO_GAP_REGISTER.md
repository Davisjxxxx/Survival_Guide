# Photographic acceptance gaps — Track B 011

## Not yet sourced or independently verified
- American basswood: whole-tree, winter buds, specimen-linked inner bark and actual hearth board.
- Quaking aspen: trunk context with flattened petiole in same observation, paired wood sample.
- Northern white cedar: winter habit, wood test sample; do not rely on a single cultivated branch.
- Paper birch: full tree, fallen outer bark tinder preparation, winter twigs.
- Eastern cottonwood: mature bark and whole-tree view; current leaf view alone is insufficient.
- Mullein: dried mature flower stalk, cut end, tested hand-drill spindle (the photos currently show plant identity only).
- Hemp dogbane and stinging nettle: whole live plant, dried fiber stalks, cord under cyclic bow-drill test; qualified botany review and handling warnings.
- Actual bow-drill: six verified consecutive frame photographs, cord wrap/bearing/notch and dust/coal evidence. Current photographic sequences are staged AI *not field trial evidence*.
- Actual water clarification: sediment source, filter cross section and outlet sample; define flow, turbidity measurements, and no potability implication. Moss should not be a default microbial treatment.

## Acceptance before production
- For each asset: exact original bytes and SHA-256, license page checked, compatible reuse terms, derivative stripped of EXIF, visible subject evaluated by a qualified human, at least two independent diagnostic views per species plate and look-alike comparisons.
- Keep documentary photographs and AI mechanism art in distinct manifests.
- Any species identification/edibility guidance remains blocked until specialist review. No species photo alone establishes edibility.
