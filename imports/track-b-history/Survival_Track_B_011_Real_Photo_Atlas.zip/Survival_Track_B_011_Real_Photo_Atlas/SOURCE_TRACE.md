# Editorial source trace — Track B 011

**Reader pages deliberately do not carry citations.** This technical register records where regional identification descriptions came from. Species-photo source licenses are separately tracked in PHOTO_MANIFEST.csv and PHOTO_CREDITS.md.

## Authoritative identification sources

1. Minnesota DNR, American basswood (*Tilia americana*): https://www.dnr.state.mn.us/trees/american-basswood.html — leaf shape, bark, hanging bracts, regional occurrence.
2. Minnesota DNR, Quaking aspen (*Populus tremuloides*): https://www.dnr.state.mn.us/trees/quaking-aspen.html — flattened petiole, leaf, bark and habitat.
3. Minnesota DNR, Paper birch (*Betula papyrifera*): https://www.dnr.state.mn.us/trees/paper-birch.html — peeling bark, leaf, twigs and range.
4. Minnesota DNR, Native Trees: https://www.dnr.state.mn.us/trees/native-trees.html — Minnesota taxa list and multiple-character identification practice.
5. Minnesota Conservation Volunteer, Aspen: https://www.dnr.state.mn.us/sites/default/files/assets/mcv/2022/mar-apr/yn/yn_aspen.pdf — quaking aspen compared with paper birch, leaf stalk.

## Safety and survival method limitations

6. CDC, How to Make Water Safe in an Emergency: https://www.cdc.gov/water-emergency/about/index.html — settling/clarification, disinfection, chemical contamination boundaries; sand/stone/moss filtration is not validated potable-water treatment.
7. Friction fire: the preceding Track B 008-010 research records remain the method evidence sources. This packet adds botanical identification and rights acquisition; it does not independently validate all bow-drill woods/techniques.

## Photo status and engineering boundary

- External source pages and **reported licenses** were reviewed as of 2026-11-21, but actual photo bytes and immutable SHA-256s were **not** obtained in the authoring container.
- The local photo downloader is fail-closed on license mismatch and Commons SHA-1 mismatch, and emits a separate checksum receipt. It does **not** establish whether a pictured specimen was correctly identified by its uploader.
- No species, edibility, medicine, fire performance, structural design or water-treatment claim has received human specialist approval here.
- Reader material remains a draft. Engineering branch, production database, reviewer registry, and active release are not modified.
