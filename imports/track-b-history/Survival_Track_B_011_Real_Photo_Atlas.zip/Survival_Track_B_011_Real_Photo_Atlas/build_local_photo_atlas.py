#!/usr/bin/env python3
"""After approved candidate photos are downloaded, build an image-led compatibility PDF.
All species/photo IDs remain research leads, not independently confirmed identifications.
"""
from pathlib import Path
from textwrap import wrap
import csv, io, sys, tempfile
R=Path(__file__).resolve().parent
G=[
('BASSWOOD','American basswood','Tilia americana','BAS-LEAF','BAS-BARK','Heart-shaped, saw-toothed leaves; old gray bark has shallow vertical ridges.','Bow-drill hearth and spindle candidate; bast cordage after correct preparation.','Do not strip living trees; reject moist or rotten wood.'),
('ASPEN','Quaking aspen','Populus tremuloides','ASP-LEAF','ASP-BARK','Almost circular leaves with flattened stalk; pale bark with dark scars.','Dry hearth / spindle candidate.','Check against paper birch; test actual dry wood rather than assuming success.'),
('CEDAR','Northern white cedar','Thuja occidentalis','CED-LEAF','CED-BARK','Flat scale-leaf sprays and thin shreddy bark.','Dry material can serve firecraft or tinder functions.','Do not confuse with resin-rich pine; no live-tree damage.'),
('PAPER BIRCH','Paper birch','Betula papyrifera','BIR-BARK','BIR-LEAF','Thin white peeling bark with horizontal marks; toothed leaves.','Outer bark: natural tinder/ignition extender.','Tinder role differs from hearth/spindle selection; gather fallen or loose material.'),
('COTTONWOOD','Eastern cottonwood','Populus deltoides','COT-LEAF',None,'Triangular pointed leaves; longer flattened stalk.','Dry hearth / spindle candidate.','Bark and whole-tree images still needed. Wood from wet sites may be too damp.'),
('MULLEIN','Common mullein','Verbascum thapsus','MUL-PLANT','MUL-STALK','Woolly leaves and a tall flowering spike; dry stem differs from green stalk.','Dried, straight stalk can be a hand-drill spindle candidate.','This photo shows plant not tested spindle; confirm material when harvested.'),
('DOGBANE','Hemp dogbane','Apocynum cannabinum','DOG-PLANT','DOG-DETAIL','Opposite leaves, branching stalk, milky sap.','Mature bast fibers may make cord for a bow drill.','Toxic if ingested. Need botanical verification and safe processing.'),
('NETTLE','Stinging nettle','Urtica dioica','NET-LEAF',None,'Serrated leaf with stinging hairs.','Mature fiber stalks may supply cordage after processing.','Contact stings; not an edibility or positive-ID guide.'),
]

def make_pdf(output, photos):
    from reportlab.pdfgen import canvas
    from reportlab.lib.colors import HexColor
    from reportlab.lib.utils import ImageReader
    from PIL import Image, ImageOps
    W,H=612,792
    c=canvas.Canvas(str(output),pagesize=(W,H),pageCompression=1,pdfVersion=(1,4))
    c.setTitle('Track B 011 - Minnesota Material Photo Atlas (Research Draft)')
    forest=HexColor('#163721');pale=HexColor('#f5f2e7');ink=HexColor('#213425');haz=HexColor('#904a29')
    def head(num,name,sci):
        c.setFillColor(pale);c.rect(0,0,W,H,stroke=0,fill=1)
        c.setFillColor(forest);c.rect(0,H-83,W,83,stroke=0,fill=1)
        c.setFillColor(HexColor('#e9f0dd'));c.setFont('Helvetica-Bold',10);c.drawString(24,H-24,'SURVIVAL FIELD ENCYCLOPEDIA / MINNESOTA MATERIALS')
        c.setFont('Helvetica-Bold',22);c.drawString(24,H-54,name)
        c.setFont('Helvetica-Oblique',11);c.drawRightString(W-24,H-53,sci)
        c.setFillColor(ink);c.setFont('Helvetica',8)
        c.drawString(24,19,'REAL-SOURCE PHOTO LEADS - RESEARCH ONLY - SPECIES ID NOT INDEPENDENTLY CERTIFIED')
        c.drawRightString(W-24,19,f'{num:02d} / {len(G):02d}')
    def txt(x,y,title,value,width=172):
        c.setFillColor(forest);c.setFont('Helvetica-Bold',10);c.drawString(x,y,title)
        c.setFillColor(ink);c.setFont('Helvetica',9.2)
        # rough char width to fit small blocks, from 6.7 px average
        for line in wrap(value,width=max(18,int(width/5.1))):
            y-=13.8;c.drawString(x,y,line)
    def photo(asset,x,y,w,h):
        if asset:
            f=photos/(asset+'.jpg')
            if f.exists():
                with Image.open(f) as orig:
                    im=ImageOps.exif_transpose(orig).convert('RGB')
                    iw,ih=im.size;scale=max(w/iw,h/ih)
                    new=(max(1,int(iw*scale)),max(1,int(ih*scale)))
                    im=im.resize(new,Image.Resampling.LANCZOS)
                    dx=(im.width-int(w))/2;dy=(im.height-int(h))/2
                    im=im.crop((dx,dy,dx+int(w),dy+int(h)))
                    c.drawImage(ImageReader(im),x,y,width=w,height=h)
                    return
        c.setFillColor(HexColor('#d3d8c9'));c.rect(x,y,w,h,stroke=0,fill=1)
        c.setFillColor(ink);c.setFont('Helvetica-Bold',10);c.drawCentredString(x+w/2,y+h/2,'SECOND VIEW STILL NEEDED')
    for i,(code,name,sci,a,b,features,role,reject) in enumerate(G,1):
        head(i,name,sci)
        photo(a,24,300,273,380);photo(b,311,300,277,380)
        c.setFillColor(forest);c.setFont('Helvetica-Bold',10)
        c.drawString(26,282,'PRIMARY SOURCE PHOTO');c.drawString(312,282,'COMPLEMENTARY SOURCE PHOTO' if b else 'SECOND VIEW NOT YET SOURCED')
        # wide, three text boxes under the photographs
        for bx in (24,213,403):
            c.setFillColor(HexColor('#e5e9da'));c.roundRect(bx,78,184,179,7,fill=1,stroke=0)
        txt(35,239,'IDENTIFY',features,160)
        txt(224,239,'ROLE / USE',role,160)
        c.setFillColor(haz);c.setFont('Helvetica-Bold',10);c.drawString(414,239,'REJECT / VERIFY')
        c.setFillColor(ink);c.setFont('Helvetica',9.2)
        for j,line in enumerate(wrap(reject,width=29)):c.drawString(414,225-j*13.8,line)
        c.showPage()
    c.save()

if __name__=='__main__':
    base=R/'photos';out=R/'Survival_Track_B_011_Offline_Photo_Atlas_RESEARCH.pdf'
    if '--self-test' in sys.argv:
        from PIL import Image
        import fitz
        with tempfile.TemporaryDirectory() as d:
            d=Path(d);p=d/'photos';p.mkdir()
            for key in set((r[3] for r in G if r[3])) | set((r[4] for r in G if r[4])):
                Image.new('RGB',(100,110),'navy').save(p/(key+'.jpg'))
            pdf=d/'test.pdf';make_pdf(pdf,p)
            doc=fitz.open(pdf);assert len(doc)==len(G)
            assert all(pg.get_text().strip() for pg in doc)
            print('SELF TEST PASS:',len(doc),'pages; PDF opens with PyMuPDF')
        sys.exit(0)
    required=[key for r in G for key in (r[3],r[4]) if key]
    missing=[k for k in required if not (base/(k+'.jpg')).exists()]
    if missing:
        print('Refusing to make an incomplete photo PDF. Missing:',', '.join(missing),file=sys.stderr)
        print('Run python3 fetch_commons_photos.py first. No images have been silently substituted.',file=sys.stderr)
        sys.exit(2)
    make_pdf(out,base);print('Built:',out)
