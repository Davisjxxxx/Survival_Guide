#!/usr/bin/env python3
"""Acquire explicitly listed Commons photographs with checksum, license, and EXIF controls.

No repository access, no content approvals, no image-derived species certification.
"""
from __future__ import annotations
import argparse, csv, hashlib, io, json, re, sys, tempfile, urllib.parse, urllib.request
from pathlib import Path

ROOT=Path(__file__).resolve().parent
API='https://commons.wikimedia.org/w/api.php'
UA='SurvivalFieldEncyclopedia/0.1 photo rights research (user-directed)' 
MAX_BYTES=20*1024*1024

def norm_license(t:str)->str:
    return re.sub(r'[^a-z0-9]','',t.lower().replace('unported','').replace('international',''))

def license_matches(expected:str, actual:str, license_url:str)->bool:
    e=norm_license(expected); a=norm_license(actual); u=norm_license(license_url)
    if e=='publicdomain':return 'publicdomain' in a or 'publicdomain' in u or a in ('cc0','cczero')
    if e in ('cc01','cc010','cczero10'):return 'cc0' in a or 'cc0' in u
    if 'by' not in e:return False
    # explicit version, BY vs BY-SA. Do not accept NC / ND.
    if not (a.startswith(e) or e in a or e in u):return False
    if 'nonderivative' in a or 'noncommercial' in a or 'bynd' in a or 'bync' in a:return False
    if 'bysa' in e and 'bysa' not in a and 'bysa' not in u:return False
    if 'bysa' not in e and 'bysa' in a:return False
    return True

def page_api(name):
    args=urllib.parse.urlencode({'action':'query','format':'json','formatversion':'2', 'prop':'imageinfo',
                              'iiprop':'url|size|sha1|extmetadata','titles':'File:'+name})
    req=urllib.request.Request(API+'?'+args,headers={'User-Agent':UA,'Accept':'application/json'})
    with urllib.request.urlopen(req,timeout=30) as r:
        if int(r.status)!=200:raise ValueError('API HTTP '+str(r.status))
        return json.load(r)

def license_info(info):
    m=info.get('extmetadata') or {}
    get=lambda x:re.sub('<[^>]*>','',str(m.get(x,{}).get('value','')))
    return get('LicenseShortName'),get('LicenseUrl'),get('Artist')

def secure_wikimedia_url(url):
    p=urllib.parse.urlsplit(url)
    if p.scheme!='https' or p.hostname not in ('upload.wikimedia.org','commons.wikimedia.org','thumb.wikimedia.org'):
        raise ValueError('Unexpected image host: '+str(p.hostname))
    return url

def download_limited(url):
    secure_wikimedia_url(url)
    req=urllib.request.Request(url,headers={'User-Agent':UA})
    with urllib.request.urlopen(req,timeout=45) as r:
        typ=r.headers.get('Content-Type','').lower()
        if not (typ.startswith('image/jpeg') or typ.startswith('image/png') or typ.startswith('image/webp')):
            raise ValueError('Unexpected image content type: '+typ)
        data=r.read(MAX_BYTES+1)
        if len(data)>MAX_BYTES:raise ValueError('Photo larger than maximum permitted input')
        return data

def make_derivative(original:bytes, output:Path):
    from PIL import Image, ImageOps
    with Image.open(io.BytesIO(original)) as source:
        source.verify()
    with Image.open(io.BytesIO(original)) as im:
        img=ImageOps.exif_transpose(im).convert('RGB')
        img.thumbnail((1350,1350),Image.Resampling.LANCZOS)
        # New image payload deliberately has no source EXIF, GPS, or ICC.
        output.parent.mkdir(parents=True,exist_ok=True)
        img.save(output,format='JPEG',quality=83,optimize=True,exif=b'')
        return img.size

def self_test():
    from PIL import Image
    assert license_matches('CC BY-SA 4.0','CC BY-SA 4.0','https://creativecommons.org/licenses/by-sa/4.0/')
    assert license_matches('CC BY 3.0 US','CC BY 3.0 US','https://creativecommons.org/licenses/by/3.0/us/')
    assert license_matches('CC0 1.0','CC0 1.0','https://creativecommons.org/publicdomain/zero/1.0/')
    assert license_matches('Public domain','Public domain','')
    assert not license_matches('CC BY 4.0','CC BY-SA 4.0','')
    assert not license_matches('CC BY-SA 4.0','CC BY-NC-SA 4.0','')
    try:secure_wikimedia_url('http://other.example.com/x.jpg');assert False
    except ValueError:pass
    im=Image.new('RGB',(40,50),'navy'); e=io.BytesIO(); im.save(e,format='JPEG',exif=b'Exif\x00\x00test-privacy-field')
    with tempfile.TemporaryDirectory() as d:
        p=Path(d)/'preview.jpg'; dims=make_derivative(e.getvalue(),p)
        assert dims==(40,50)
        assert b'Exif' not in p.read_bytes()
    print('SELF-TEST PASS: license, bad-host, image decode, EXIF-free derivative')

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--self-test',action='store_true')
    p.add_argument('--limit',type=int,default=0,help='Optional number of images for first download batch')
    args=p.parse_args()
    if args.self_test:self_test();return 0
    try:from PIL import Image
    except ImportError:
        print('Pillow required: install in a dedicated environment (python3 -m pip install pillow).',file=sys.stderr);return 2
    rows=list(csv.DictReader((ROOT/'PHOTO_MANIFEST.csv').open(encoding='utf-8')))
    if args.limit:rows=rows[:args.limit]
    originals=ROOT/'originals';local=ROOT/'photos';receipts=ROOT/'download_receipts.csv'
    originals.mkdir(exist_ok=True);local.mkdir(exist_ok=True)
    result=[];errors=0
    for r in rows:
        id=r['asset_id'];name=r['commons_filename']
        try:
            j=page_api(name)
            pages=j.get('query',{}).get('pages',[])
            if len(pages)!=1 or not pages[0].get('imageinfo'):raise ValueError('Commons asset not found')
            inf=pages[0]['imageinfo'][0];lic,licurl,artist=license_info(inf)
            if not license_matches(r['declared_license'],lic,licurl):
                raise ValueError('License mismatch: expected '+r['declared_license']+', Commons reports '+lic+' / '+licurl)
            raw=originals/(id+'.jpg')
            if raw.exists(): b=raw.read_bytes()
            else:b=download_limited(inf['url'])
            if hashlib.sha1(b).hexdigest()!=inf['sha1']:
                raise ValueError('Wikimedia original SHA-1 differs; do not use image')
            if not raw.exists():raw.write_bytes(b)
            out=local/(id+'.jpg');dimensions=make_derivative(b,out)
            result.append({'asset_id':id,'state':'DOWNLOADED_NOT_TAXON_VERIFIED','original_sha1':inf['sha1'],
                           'original_sha256':hashlib.sha256(b).hexdigest(),
                           'derivative_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),
                           'rights_checked_at_download':lic,'source_page':r['source_page'],
                           'reviewer':'','species_identity_review':'PENDING','pixel_dimensions':str(dimensions)})
            print(id,'OK:',dimensions)
        except Exception as exc:
            errors+=1;result.append({'asset_id':id,'state':'FAILED','error':str(exc)})
            print(id,'FAILED:',str(exc),file=sys.stderr)
    columns=['asset_id','state','original_sha1','original_sha256','derivative_sha256','rights_checked_at_download','source_page','reviewer','species_identity_review','pixel_dimensions','error']
    with receipts.open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=columns);writer.writeheader();writer.writerows(result)
    print('Completed:',len(result)-errors,'/',len(result),'photos. Receipts:',receipts)
    return 1 if errors else 0
if __name__=='__main__':sys.exit(main())
