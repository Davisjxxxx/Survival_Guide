# Track B 011 — Real-source Minnesota field material atlas

**Purpose:** An image-led, authoritative-source-linked research reader and a local acquisition workflow. This is not an approved identification atlas or completed book. The online reader uses real Commons photographs; the package does **not yet contain their bytes** because network download from the authoring runtime failed. It is inaccurate to call this a complete offline photo atlas until acquisition succeeds.

## Open now (internet connection required)
Open `index.html` in Chrome. The 14 photographs load directly from their Wikimedia Commons file paths when internet is available. Click each image's "Open original photo" link to inspect the exact source. The page text is readable offline even before the photographs are downloaded.

## Make the photographs work offline, WITHOUT an AI/CLI token session
With Python 3 and Pillow installed, in this package directory:

```bash
python3 fetch_commons_photos.py --self-test
python3 fetch_commons_photos.py
```

This fetches only the 14 source-labelled photographs listed in `PHOTO_MANIFEST.csv` from Wikimedia Commons, checks the source license label against the manifest, verifies Commons SHA-1 against downloaded bytes, stores originals separately, produces resized EXIF-stripped `photos/*.jpg`, creates SHA-256 receipts, and refuses missing/mismatched permissions. Reopen `index.html`: it automatically prefers local photos and is now portable offline. No Git changes or encyclopedia approval occur. If the network or API refuses a file, a failure is recorded and the asset remains pending.

Pillow is required only for derivatives; if absent, install it in a dedicated environment (`python3 -m pip install pillow`) without modifying the Survival_Guide repository. Do not treat a downloaded image as taxonomically verified or publication approved.

The script was tested here in self-test mode against synthetic local image fixtures but **was not able to fetch public image bytes in this environment**. Real download/response status is unknown until you run it on a computer with internet access.

## Book assembly later
After actual photos have been acquired and qualified: integrate the confirmed assets with the editable paragraphs of Tracks 008-010. Do not ingest until Gate A and the relevant species/rights controls permit it. The reader-facing book should not display claim IDs or citations; `PHOTO_CREDITS.md` and `PHOTO_GAP_REGISTER.md` are separate editorial/rights records.
