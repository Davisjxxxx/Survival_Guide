# TRACK B / 007 — FRICTION FIRE WOOD SOURCES AND LIMITATIONS

Status: draft; source and photo identity subject to human verification. Do not ingest into approved or published content.

Friction mechanics/roles:
- https://scoutingmagazine.org/2019/10/create-fire-by-friction/ — Les Stroud; four components, bow-drill semisoft woods (cedar, poplar, aspen, basswood).
- https://www.outsideonline.com/uncategorized/whats-best-wood-bow-drill/ — Tony Nester; soft, low-resin woods and caution about pine sap; hard bearing socket.
- https://willowhavenoutdoor.com/best-wood-for-bow-drill-how-to-choose-the-perfect-wood-for-your-friction-fire-bow-drill-kit/ — Creek Stewart; basswood, same species pairing, mullein bow spindle.
- https://www.sacredhearthfrictionfire.com/hand-drill.html — practitioner account; pithy dry stems (mullein) with soft hearths (lime/poplar), difficulty/variability.
- https://phys.org/news/2023-12-friction-requires-physics-principlesthere-ways.pdf — research discussion; friction performance also depends on spindle diameter, pressure/speed, moisture, with caveat against categorical wood-hardness claims. Publication and link validity must be verified.

Minnesota tree/plant identification:
- https://www.dnr.state.mn.us/trees/american-basswood.html
- https://www.dnr.state.mn.us/trees/quaking-aspen.html
- https://www.dnr.state.mn.us/forestry/nursery/northern-white-cedar-seed-collection-guide.html
- https://www.dnr.state.mn.us/trees/cottonwood.html
- https://www.dnr.state.mn.us/trees/black-willow.html
- https://hort.extension.wisc.edu/articles/common-mullein-verbascum-thapsus/

Legal/field context:
- https://www.dnr.state.mn.us/firewood/index.html — Minnesota state parks prohibit firewood collection; state forests permit dead wood for campfires subject to rules.
- https://www.dnr.state.mn.us/forestry/harvest-permits-state-lands.html — harvesting/cutting trees or plants in state forests generally needs authorization; rules differ from dead fuelwood collection.
- https://www.dnr.state.mn.us/wildfire/prevention/campfiresafety.html — fire restrictions and safety.

REVIEW LIMITATIONS:
1) Tree identity descriptions are corroborated by MN DNR, but web photo subjects have not received specimen-level independent expert attestation.
2) A useful species is not a promise: moisture, decay, diameter, contact geometry, pressure, and experience can reverse field performance.
3) Identified sample photos from online image results have NOT been acquired as redistributable offline assets; licensing, attribution, and technical inspection are still pending.
4) No claim of measured success rate, minimum ember time, or universal species suitability.
5) No live vegetation harvest is authorized merely because this record names a useful material.
