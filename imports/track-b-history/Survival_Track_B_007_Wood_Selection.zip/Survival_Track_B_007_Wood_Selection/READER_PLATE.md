# FRICTION FIRE: CHOOSE THE RIGHT WOOD

Status: EDITORIAL DRAFT / RESEARCH ONLY — not reviewed, not approved, not field tested.
Region: Minnesota / Upper Midwest. No-gear first, equipped upgrades second.

## 1 — Parts have different requirements

| Part | Look for | Reject / change |
|---|---|---|
| Bow-drill hearth board | Dead, thoroughly dry, sound, relatively soft, low-resin wood that makes fine dark dust. | Damp, rotten/punky, sticky resin, glazed surface, extreme hardness. |
| Bow-drill spindle | Straight, thoroughly dry, sound wood of compatible hardness with hearth; same species is a practical starting pairing. | Bent, cracked, wet, rotten, resin-glazed; loose cord. |
| Bow | Flexible but strong stick that tolerates repeated strokes; its species need not match the drill. | Brittle, split, severely twisted wood. |
| Cord | Tough, abrasion-resistant natural fibers if no manufactured cord exists; must grip spindle and withstand heat/abrasion. | Weak, slick, fraying cord. |
| Bearing socket | Hard wood, smooth stone, or bone; top should turn freely while bottom generates friction. | Soft/hot/fraying top socket that wastes pressure and energy. |
| Hand-drill spindle | Long, straight, light, dry pithy plant stalk (e.g. dead mullein flowering stem) rather than a short dense branch. | Heavy, crooked, wet, cracked or short stalk; excessive hand friction. |
| Hand-drill hearth | Thoroughly dry, nonresinous wood such as basswood, cottonwood, aspen or suitable willow. | Wet, gummy, rotten, glazed board. |

## 2 — Minnesota reference species / visual plate subjects

1. AMERICAN BASSWOOD (Tilia americana): Preferred beginner bow-drill hearth/spindle candidate; hand-drill hearth candidate. Large, alternate heart-shaped, toothed leaves with asymmetric base; leaf-like bract supporting round fruits; light gray to shallow-ridged bark.
2. QUAKING ASPEN (Populus tremuloides): Good dry bow-drill hearth/spindle candidate and secondary hand-drill hearth. White to greenish-white bark with dark scars; rounded finely toothed leaves on flattened leafstalks.
3. NORTHERN WHITE CEDAR (Thuja occidentalis): Good dry bow-drill hearth/spindle candidate; verify material is dry and not resin-glazed. Flat, fan-shaped, overlapping scale-leaf sprays; shredding gray to reddish bark.
4. EASTERN COTTONWOOD (Populus deltoides): Good dry hearth/spindle material and hand-drill hearth candidate. Triangular leaves with pointed tips and flattened stalks; deep mature bark furrows; often by rivers and floodplains.
5. BLACK WILLOW (Salix nigra): Usable dry hearth/spindle candidate; species varies. Long, narrowly lance-shaped leaves with finely toothed edges; deeply furrowed mature bark; southern/central Minnesota waterways.
6. COMMON MULLEIN (Verbascum thapsus), NOT A TREE: Dry, straight, light second-year flowering stem for hand-drill spindle; also documented for bow drill. Woolly basal leaves, tall yellow-flowered spike in second year, persistent dry brown stalk later. It is non-native.

These descriptions are quick recognition aids, not complete diagnostic identification. Each final photo plate needs whole tree/plant, leaf/needle, bark, winter twigs/buds or persistent stalk, and labeled wood sample. Never diagnose a tree from a single AI-generated image.

## 3 — Two material starting sets (conditional, not guaranteed)

BOW DRILL: Dry basswood hearth + dry basswood spindle as the first local trial. If unavailable, assess sound dry aspen, cottonwood, northern white cedar or willow. Use a sturdy flexible bow, durable cord and harder bearing socket. Recheck both wood moisture and cord behavior before changing technique.

HAND DRILL: Long, straight, fully dried mullein flowering stem + thoroughly dry basswood hearth as a candidate trial. Aspen, cottonwood, or suitable willow hearths are secondary candidates. More practice and effort are normally needed than with the bow drill. A standing dried stalk may be damaged by rain, insects or rot; test rather than assume.

## 4 — Test the wood before investing energy

- Inspect: use dead sound wood; do not cut live trees or collect wood where prohibited. Prefer dry material sheltered from ground moisture. A standing dead branch may be drier, but never assume that it is.
- Shave: freshly exposed wood should feel dry; reject wet fibers and wood that crushes into rotten powder.
- Press: a fingernail should leave a shallow mark without wood crumbling. This is a field screen, not a definitive hardness or species test.
- Observe: fine, dark wood dust collecting steadily is favorable. Smoke by itself does not prove a self-sustaining ember.
- Correct: if wood glazes or produces scant dust, change species/part or reprepare dry faces. If wood disintegrates quickly, change to sounder wood. If hands or cord fail, stop and repair before repeating.
- Abort: if cold, wet, injured or exhausted, prioritize shelter and body-temperature protection. Do not depend on friction fire as guaranteed emergency ignition.

## 5 — Common mix-ups

PINE RESIN AND FATWOOD: Useful as an ignition aid/tinder extender; often poor for the hearth/spindle where sticky resin can interfere with friction dust.
OAK, HICKORY, HARD MAPLE: Usually inefficient novice hearth/spindle choices because they demand more work; not categorically impossible. Hard, dense woods can be useful for the bearing socket or other components.
WET PUNKY WOOD: Softness alone does not make a wood useful. Rotten or damp wood frequently fails to hold an ember.

## Reader-facing photography required before publication

Each species: (a) verified whole tree/plant in habitat; (b) leaf or needle spray in identifiable close-up; (c) bark, bud, bract or dry stalk in season; (d) close-up of DEAD DRY usable wood/sample; (e) specimen photo provenance and rights. Separately provide actual hearth and spindle photos, side-by-side failures (wet, resinous, punky), and hand-vs-bow drill assembly photographs.

NO external citations belong on the field card. Source locator, rights, claim evidence and reviewer conclusions stay in the separate evidence/register file.
