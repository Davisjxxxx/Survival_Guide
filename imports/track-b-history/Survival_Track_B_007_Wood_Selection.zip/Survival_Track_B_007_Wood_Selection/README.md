# Survival Guide / Track B 007 — Friction Fire Wood Identification

Editable reader page draft, separate research notes, and six real-photograph leads for Minnesota friction-fire plants and trees. Photo leads are *not* downloaded or licensed assets, and must not be treated as approved species images. This package is outside the user's local Git repository. Gate A remains blocked, no ingestion or publication authorized.
