SURVIVAL GUIDE — RUN-004 CHAT REVIEW PACKAGE

START HERE
Read RUN004_Chat_Review_20261120.txt for the outcome and limitations.
The patch contains only two source fixes and two regression files. It is based
on bd409f87b51efcfd1492125999beae790b3ce66f. Do not apply it to another baseline
without checking differences. Gate A is still blocked; publication is not authorized.

APPLICATION
Give APPLY_WITH_NEON.txt to the current Gemini Neon CLI session after downloading
this ZIP. Extract this package outside the repository. A ZIP is an archive to open
or extract, not an executable command. No permission change or sudo is required.
The prompt performs a checksum check, git apply --check, application, one full
make check in the existing toolchain and a focused handback.

EVIDENCE
The original submitted archive was reviewed unchanged. All execution copies are
isolated. Most evidence paths are original scratch execution paths, retained for
traceability; their corresponding logs are bundled here by filename.
release_pin_fault_probe.py is frozen BASELINE-ONLY evidence that deliberately
asserts the old bypass exists. It is not the corrected-code acceptance test.
Use the two regression files inside the patch for corrected-code acceptance.

The corrected candidate passes 787 selected tests. Eight existing TeX-dependent
cases were excluded locally; full PDF/reproducibility must be checked in the
working local toolchain. Logs from the initial environment-blocked selection are
also included. Historical whole-suite counts are not relabelled as new evidence.

No research ingestion, photo approvals, gate decisions, external account actions,
main branch creation, remote changes, tags or pushes were performed here.
