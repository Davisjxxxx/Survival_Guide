"""Independent state-machine-only probe. Synthetic artifacts; no PDF/TeX claim."""
import json
from pathlib import Path
from sfe import release as rel
from sfe.common import sha256_file

BASE = Path('/workspace/scratch/34ced55b54bb/run004_review/release_pin_fault_probe')
BASE.mkdir(exist_ok=True)
A = 'ED-' + 'a' * 16
B = 'ED-' + 'b' * 16

def stage(dist, eid):
    target = dist / rel.STAGING / (eid + '-stage')
    (target / 'zones').mkdir(parents=True)
    pdf = target / 'zones/Z09.pdf'
    manifest = target / 'zones/Z09.build.json'
    pdf.write_bytes(('synthetic ' + eid).encode())
    manifest.write_text(json.dumps({'edition_id':eid}) + '\n')
    doc = {'schema':1,'edition_id':eid,'entries':[], 'ledger_state':{},'policy_sha256':{},
           'artifacts':[{'zone':'Z09','pdf':'zones/Z09.pdf','pdf_sha256':sha256_file(pdf),
                         'manifest':'zones/Z09.build.json','manifest_sha256':sha256_file(manifest)}]}
    (target / rel.EDITION_FILE).write_bytes(rel.edition_bytes(doc))
    return target

class InjectedCrash(RuntimeError): pass

def crash_at(point):
    def fault(step):
        if step == point:
            raise InjectedCrash(point)
    return fault

def attempt(mode):
    dist = BASE / mode
    if dist.exists(): raise RuntimeError('not overwriting prior probe output')
    result = {'scenario':mode,'artifacts':'synthetic state-machine fixtures; not release-ready PDFs'}
    rel._FAULT = crash_at('after_pointer')
    try:
        rel.promote(dist, stage(dist,A),A)
    except InjectedCrash:
        result['first_promotion_interrupted_after_pointer'] = True
    finally:
        rel._FAULT = None
    result['pointer_after_first_crash'] = rel.read_pointer(dist)[0].state
    result['log_after_first_crash'] = rel.read_log(dist)[0]
    if mode == 'consecutive_crashes': rel._FAULT = crash_at('after_withdraw_pointer')
    try:
        rel.withdraw(dist,'Safety review requires immediate edition withdrawal.')
        result['withdraw_returned'] = True
    except InjectedCrash:
        result['withdraw_interrupted_after_pointer'] = True
    finally:
        rel._FAULT = None
    result['pointer_after_withdraw'] = rel.read_pointer(dist)[0].state
    result['recovery_actions'] = rel.recover(dist)
    rows, problems = rel.read_log(dist)
    result['log_problems_after_recovery'] = [f.code for f in problems]
    result['log_after_recovery'] = [[r['event'],r['edition_id']] for r in rows]
    result['withdrawal_of_A_logged'] = any(r['edition_id']==A and r['event'] in ('withdraw','auto_withdraw') for r in rows)
    rel.promote(dist,stage(dist,B),B)
    try:
        rel.promote(dist,stage(dist,A),A)
        result['repromote_A'] = 'ACCEPTED'
    except rel.ReleaseStateError as exc:
        result['repromote_A'] = 'REFUSED'
        result['repromote_error'] = str(exc)
    pointer, pointer_problems = rel.read_pointer(dist)
    result['final_pointer'] = {'state':pointer.state,'edition_id':pointer.edition_id}
    result['final_pointer_problems'] = [f.code for f in pointer_problems]
    return result

out = [attempt('control_withdraw_completes'),attempt('consecutive_crashes')]
print(json.dumps(out,indent=2))
assert out[0]['repromote_A']=='REFUSED'
assert out[1]['repromote_A']=='ACCEPTED'
