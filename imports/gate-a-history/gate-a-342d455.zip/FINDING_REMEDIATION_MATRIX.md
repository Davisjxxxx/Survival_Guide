# Finding remediation matrix (RUN-003)

| | |
|---|---|
| Run | RUN-003: critical trust-model remediation |
| Base | `a08104a540f8017ac8f60c3405e1585e542806e6` (tag `gate-a-remediation-1`, RUN-002). Submitted baseline `dc678192da569638946ae9c8e4671cff2f7e8b0f` and both tags are untouched. |
| Branch | `gate-a/remediation-2` (no `main`, no remote) |
| Source of findings | `FABLE-REVIEW-001` in `/home/jd/Survival_Guide_Fable_Review/` (29 findings, 59 probes). Its central claim was reproduced before any change: the three probe batches run on a fresh export of `a08104a` give output identical to the report's (48 counterexamples still eligible; only P01, P02, P08a blocked). |
| Gate A | **BLOCKED. This document does not approve it.** |
| Status of this file | Sections 1 to 7 are the **contract**, written before any code change and left as written. Section 8 is the **outcome**, filled in at the end of the run with the evidence for each status. |

Status values: `Planned` · `Closed` (only with passing evidence named in the run record) · `Partial` (a named part is closed, the rest stays open) · `Open` (not in RUN-003 scope).

## 1. The change in one paragraph

Today the gate trusts what the author types: the hazard class, the entry type, the reviewer's role, the dates that order decisions, and the content the approval hash covers. RUN-003 replaces each with something the author cannot choose. Required reviews are **derived** from zone, entry type, cited claims, plan and text (declared tags only add). Reviewers are **registered identities** in an append-only registry; a ledger row names an id and the capacity it acts in, and the registry decides what that is worth. Ledgers are **append-only, sequence-ordered and hash-chained**; an adverse decision blocks until an explicit, evidence-linked **resolution** row clears it. An approval binds to a **package digest** that covers the entry and everything it rests on (claims, sources, images, specimen and taxon records, the checklist); the reviewer's packet is stored so what they saw is on record. The renderer must **print every approved field** or the build fails. Image evidence binds to **taxon and specimen records** and to distinct file bytes.

Nothing here rebuilds the architecture. CSV registers, the status ladder, the pdfLaTeX pipeline and the fail-closed release stay as they are.

## 2. Findings in scope

Test names refer to files planned in section 6. "Probe" ids are the Fable probes.

### FR-001 (Critical): self-declared hazard-gate bypass

| | |
|---|---|
| **Root cause** | `_is_hazardous` reads only author-typed `hazard_tags` and `entry_type` (`validate.py:328`). Nothing derives risk from zone, claims, plan or text. |
| **Planned change** | New `schemas/classification_policy.yaml` and `scripts/sfe/classify.py`. Required review subjects are the union of: the zone's row; the zone-priority floor (Critical zones need at least `CLS-HIGH-RISK`); the entry-type row; every cited claim's type and risk level; hazard topics and entry type in the coverage plan; structural content (species or medical fields, cited diagnostic photos, pressure or temperature units); keyword triggers over all entry text; plus declared tags, which only add. An empty result requires an independent **screening** review (`CLS-SCREENING`). An unknown zone, type or claim classification, or an invalid policy, requires every subject and raises an error (fail closed). Zone `allowed_types` (Z10 allows only `medical_guidance`). Identification content in an identification zone must be a `species_profile`. Species and medical fields are rejected on other types. |
| **Acceptance** | P18, P18b, P46, P47, P20 return errors naming the derived subject. A 16-zone × 4-type matrix: no combination needs fewer subjects than its zone alone. Removing a tag never lowers the requirement. Unknown classification requires all subjects and errors. An invalid policy approves nothing. |
| **Regression tests** | `test_classification.py` (zone, type, claim, plan, structure, keyword, unknown, matrix, tag-additivity); `test_fable_probes.py` P18, P18b, P46, P47, P20 |
| **Migration** | New policy file. `hazard_tags` changes from the gate's trigger to additive information. Verified-rung rules that keyed on tags (danger boundaries, legal date) now key on the derived subjects. No entries exist. |

### FR-002 (Critical): a recorded failure blocks only a tagged topic

| | |
|---|---|
| **Root cause** | The barrier is built only from rows that list a tagged topic, for this revision, ordered by typed date (`validate.py:431-477`). A failure with an empty topic list, an untagged topic, another revision or a mistyped entry id is ignored. |
| **Planned change** | An adverse decision (`fail`, `conditional`; approvals `rejected`, `withdrawn`; image audits `fail`, `conditional`) blocks the whole entry (or asset) whatever its subjects, revision, hash or tags. Every ledger row must resolve: known entry or asset, known reviewer, existing `resolves_id`. An orphan is an error. A failure naming a subject outside the entry's required set raises `SAFETY_FAILURE_REPORTS_UNCLASSIFIED_HAZARD`. |
| **Acceptance** | P04, P05, P06, P52, P53 blocked. Metamorphic: appending any adverse row never leaves an entry eligible. |
| **Regression tests** | `test_adverse_decisions.py` (each form, three ledgers, orphan and reference cases, metamorphic and permutation properties); probes P04, P05, P06, P52, P53 |
| **Migration** | `topics_reviewed` becomes `subjects`; the `decision` enum gains `resolution`. Registers are header-only. |

### FR-003 (High): typed date and file position decide precedence

| | |
|---|---|
| **Root cause** | Order is `(reviewed_on, row position)`; dates are pattern-checked only (`validate.py:431`); a spreadsheet sort changes the verdict. |
| **Planned change** | `scripts/sfe/ledger.py`. Every ledger has a `sequence` (1..n, in file order) and a `chain_sha256` over each row and its predecessor. Sequence alone orders events. Dates must be real calendar dates (every register) and must not decrease along the sequence. An append-only check against Git history (each commit's rows must be a prefix of the next's). `python -m sfe ledger seal` fills the tail of a ledger and refuses to touch sealed rows. |
| **Acceptance** | P03a, P03b, P08b, P08c, P11a, P11b, P24 blocked. Editing, deleting, inserting or reordering any sealed row breaks the chain. A Git history that rewrites a row is reported. A row-permutation property test. |
| **Regression tests** | `test_ledger_integrity.py`; probes P03a, P03b, P08a, P08b, P08c, P11a, P11b, P24 |
| **Migration** | Every ledger gets `sequence` (first) and `chain_sha256` (last). No rows exist to seal. |

### FR-004 (High): conflicts settled by recency

| | |
|---|---|
| **Root cause** | Later passes clear failures; approvals use "latest row of any role" (`validate.py:396-406`). |
| **Planned change** | A failure stays in force until a `resolution` row in the same ledger cites its id, gives a reason, links an evidence file (existence and SHA-256 checked) and comes from the reviewer who recorded the failure or a registered adjudicator, never from the entry's author. `resolution_kind: void` retracts a row entered in error (adjudicator or registrar only). A pass counts only if its sequence is after the entry's latest adverse or resolution row. Approvals are evaluated per capacity. |
| **Acceptance** | P07, P10a, P10b blocked. Only fail, valid resolution, new current passes restores eligibility. A resolution with a missing target, a later target, a duplicate, bad evidence, the wrong authority or an author as resolver is rejected. |
| **Regression tests** | `test_adverse_decisions.py` (resolution matrix); `test_review_independence.py` (RUN-002's remediation tests, ported); probes P07, P10a, P10b |
| **Migration** | Ledgers get `resolves_id`, `resolution_kind`, `evidence_path`, `evidence_sha256`. |

### FR-005 (High): reviewer identity and independence

| | |
|---|---|
| **Root cause** | `reviewer_role` is a typed enum; there is no registry, no author record, no notion of human or AI, no qualification, no domain. |
| **Planned change** | `reviews/reviewers.csv`: append-only, chained, rooted in an owner bootstrap row; each later registration is attested by an active registrar. Rows carry `kind` (human, ai_model, owner), `capacity`, `domains`, evidence, validity, and `revoke` events. Ledger rows carry `reviewer_id` and `capacity` instead of free-text name and role. Class eligibility comes from the registry: `domain_expert` is a registered human `external_sme` whose domains cover the subject (and the organism group for identification); `chatgpt_validation` is a registered AI `chatgpt_editorial`; `independent_screen` is a registered reviewer other than the author. The owner satisfies no class. No self-review; one identity cannot fill two classes of a subject. Entry fields `authored_by`, `technical_reviewer`, `editorial_reviewer` become registry ids. |
| **Acceptance** | P09, P09b, P93 blocked. Unregistered, wrong-capacity, out-of-domain, revoked, expired, wrong-kind and author reviewers do not count. `chatgpt_editorial` can never satisfy `domain_expert`. Conflicting registry identities are errors. |
| **Regression tests** | `test_reviewer_registry.py`; `test_review_independence.py`; `test_review_policy.py` (ported to the new policy shape); probes P01, P09, P09b, P36, P93 |
| **Migration** | `approver`, `approver_role`, `reviewer`, `reviewer_role` are replaced by `reviewer_id`, `capacity`. Entries need `authored_by`. `review_policy.class_roles` becomes `review_policy.classes`. **Decision for the owner (D13):** `domain_expert` now means a registered human `external_sme`; RUN-002 also accepted `technical_reviewer`. |

### FR-009 (High): claims and sources not bound to the approval

| | |
|---|---|
| **Root cause** | The entry hash covers claim and source *ids* only. `verified` is a cell in the row it describes. A verified source needs no edition, retrieval date or hash. Background and rights-rejected sources may back claims (probes P21, P22a, P22b, P49). |
| **Planned change** | The package digest (FR-010) covers the full row of every cited claim and source. A verified source needs a known edition and revision date, `retrieved_on`, `local_sha256`, and known provenance. `background` sources and rights-`rejected` sources cannot back a claim. |
| **Acceptance** | P21 goes stale. P22a, P22b, P49 return errors. Mutating any cell of a cited claim or source invalidates the approvals and reviews that depend on it; mutating an uncited row does not. |
| **Regression tests** | `test_package_binding.py`; `test_registers.py` additions; probes P21, P22a, P22b, P49 |
| **Migration** | Conditional schema requirements on verified sources. Claim verification stays a register cell (still open, see FR-009 residual in section 4). |

### FR-010 (High): approval does not cover what the page prints

| | |
|---|---|
| **Root cause** | The entry hash holds asset ids; an image audit stores a decision and a file hash; its four check flags are never read; any role may pass it (probes P12, P16, P17). |
| **Planned change** | The package digest covers each cited asset's manifest row, the **actual** file hash, and its taxon and specimen rows. An image-audit pass needs all four checks true and is bound to the file hash and to a record digest; the reviewer comes from the registry. An unresolved image failure blocks every entry citing the asset. |
| **Acceptance** | P12, P16, P17 blocked. Changing one printed character of a caption makes the entry's approval and reviews stale. |
| **Regression tests** | `test_package_binding.py` (one test per asset field); `test_identification_evidence.py`; `test_adverse_decisions.py`; probes P12, P16, P17 |
| **Migration** | Image-audit columns change (`record_sha256`, `reviewer_id`, `capacity`, resolution and evidence columns). |

### FR-011 (High): approved text missing from the PDF

| | |
|---|---|
| **Root cause** | `render_entry` prints a fixed subset; the schema allows species and medical fields on any type; release QA checks entry ids only; body text is never rendered (probe P20). |
| **Planned change** | Renderer totality: every non-empty field is printed or sits on an explicit metadata list, otherwise `RenderError`. Species and medical fields are rejected on other types. After the build, every printed string is looked up in the PDF text layer (`pdftotext -raw`, alphanumeric-normalised, running footer removed); a miss is `RENDER_FIELD_MISSING` and the release is refused. A non-empty body is refused for published entries until a body renderer exists. The release manifest records package digests and lists the approved fields that are known not to be printed (asset alt text, FR-023). |
| **Acceptance** | P20 refused at validation and at render. A unique token in every printed field is found in the PDF. A sabotaged renderer that drops a field is caught. |
| **Regression tests** | `test_render_totality.py`; `test_texgen.py`, `test_pdf_pipeline.py` updates; probe P20 |
| **Migration** | Published entries must have an empty body for now. The release manifest gains `package_sha256` per entry and `known_unrendered`. |

### FR-012 (Critical): species plate passes without real, matching views

| | |
|---|---|
| **Root cause** | The plate rule counts `verified_diagnostic` rows and view labels (`validate.py:381-384`). No file-identity, subject or specimen check exists (probes P13, P13b, P14, P15, P32, P92). |
| **Planned change** | SHA-256 uniqueness across the manifest, taken from the files; duplicate paths rejected. New registers `research/taxa.csv` and `assets/specimens.csv`; entries carry `taxon_id`; diagnostic assets carry `taxon_id` and `specimen_id`. For a target view the asset's taxon must equal the entry's. Look-alike views must name a different taxon and never count toward the minimum. The minimum is two distinct target views, at least one `whole` or `key_feature`, from distinct files. A specimen record needs observer, date, locality, habitat and a determination basis; the determiner is a registered human specialist who is neither the author nor the photographer; a Tier A taxon needs a physical-examination or voucher basis. Scientific-name conflicts are errors. One species entry per taxon. Identification reviews need the organism-group domain. AI-generated images stay excluded. Documented: hashing detects identical bytes only, and nothing here claims automated recognition establishes biological identity. |
| **Acceptance** | P13, P13b, P14, P15, P32, P92 blocked. Incomplete or conflicting identification evidence is an error in each of its forms. |
| **Regression tests** | `test_identification_evidence.py`; `test_species_gates.py`, `test_assets.py` updates; probes P13, P13b, P14, P15, P32, P92, P34 |
| **Migration** | `assets/manifest.csv` gains `taxon_id`, `specimen_id`; two new header-only registers; entry `taxon_id` (required for `species_profile`). Still open: near-duplicate (re-encoded or cropped) detection, organism-group perspective sets, look-alike pair records, edibility records (section 4). |

## 3. Supporting changes, and the findings they partly close

| ID | What RUN-003 does for it | What stays open |
|---|---|---|
| FR-029 | `scripts/sfe/package.py` builds the package, its digest and a stored **review packet** (`reviews/packets/`) that every approval and safety pass cites by path and SHA-256; the gate re-derives the digest and compares. | The reviewer's verbatim reply is stored as optional evidence for passes, required for resolutions. Nothing proves the reviewer read the packet. |
| FR-022 | Sequence, chain, calendar dates, append-only Git history check. `package_version` is part of the digest. | A written migration procedure for a future hash-version change. Tail truncation is detectable only in a Git checkout. |
| FR-007 | The definition digest of every required subject is part of the package, so a changed checklist stales earlier reviews (probe P60). | `authority_requirement` (CDC/EPA, USDA/NCHFP) is still not enforced against sources. |
| FR-006 | `technical_reviewer` and `editorial_reviewer` must be active registry identities, and the editorial reviewer must match the editorial approval row (probe P93). | Technical review is not a ledger row; no owner release authorization row. |

## 4. Not in RUN-003 scope (stay open)

FR-008 (claims for species and medical entries), FR-013 (self-declared image method; only partly mitigated by the required determination), FR-014 (EXIF and GPS), FR-015 (licence vocabulary), FR-016 (nothing expires), FR-017 (withdrawing built output, edition identity), FR-018 (duplicate link targets), FR-019 (unit tolerance), FR-020 (breakable safety panels, species and medical layouts), FR-021 (null-like safety text), FR-023 (alt text), FR-024 (invariant tests: new tests assert invariants for the areas above only), FR-025 (look-alike pair and edibility records), FR-026 (originals and derivatives), FR-027 (controlled vocabularies), FR-028 (decorative fields), and the residual of FR-009 (claim verification as a ledger attestation). Each remains in `ARCHITECTURE_FINDINGS.md` with its own target sprint; none is marked closed here.

## 5. Rules for changing the existing tests

1. No test is deleted without a replacement that asserts the same scenario under the new model. Every failure-case test that exists today keeps its assertion.
2. Fixtures and factories change so that a "complete world" supplies the new evidence (registry, author, packets, sealed ledger rows). This is required by the new gates and is not a loosening.
3. Tests that encode a defect are replaced, not adjusted, and each is listed in `RUN-003.md`. Today these pass while asserting the wrong behaviour: `test_safety_review_independence.py` lines 199-205, 207-213, 309-325 and 427-437 (typed date or record position decides; a failure on one topic blocks only that topic; new passes alone restore eligibility); the medical tests that accept two rows listing no topic; `test_two_complementary_diagnostic_views_pass` and the `add_asset` default (a diagnostic photo with no subject or specimen); `test_release_builds_a_published_entry_with_real_images` (cannot fail on an omitted field); `test_hash_entry_prints_the_approval_hash` (approvals no longer bind to that hash).
4. Counts, before and after, are reported in `RUN-003.md`.

## 6. Planned tests

| File | Covers |
|---|---|
| `tests/test_ledger_integrity.py` | sealing, sequence, chain, calendar and monotonic dates, tamper cases, Git history, permutation property |
| `tests/test_reviewer_registry.py` | bootstrap, registrar attestation, kind and capacity rules, revoke, validity window, conflicts, eligibility checks |
| `tests/test_classification.py` | derivation by zone, type, claim, plan, structure, keyword; fail-closed; zone × type matrix; additivity of tags; policy validation |
| `tests/test_adverse_decisions.py` | absorbing failures on all ledgers, orphans, reference errors, resolution and void matrix, metamorphic properties |
| `tests/test_review_independence.py` | RUN-002's 92 independence tests, ported to the registry model, plus new cases |
| `tests/test_review_policy.py` | RUN-002's 37 policy tests, ported |
| `tests/test_package_binding.py` | digest content, one test per bound field, packets, stale cases, non-material changes |
| `tests/test_render_totality.py` | unique tokens, omission detection, body refusal, type-exclusive fields |
| `tests/test_identification_evidence.py` | taxa, specimens, byte identity, subject binding, determination authority, plate rules |
| `tests/fable_probes.py`, `tests/test_fable_probes.py` | the Fable probes re-expressed on the new model, one expectation each, runnable as a table |

## 7. Verification plan

1. The full suite, before (611 on the live tree at `a08104a`) and after.
2. The unmodified Fable probe scripts on an export of `a08104a` (baseline column); the ported probes on the new tree (outcome column); both tables in `RUN-003.md`.
3. `make check` (integrity, validate, specimen, tests, proof, reproducibility); the committed proof rebuilt in the same commit as any schema change that feeds it.
4. Release determinism: two release builds of one tree are byte-identical.
5. Fail-closed checks: invalid policy, invalid registry, broken chain, missing packet, missing evidence each refuse approval and release.
6. Preserved-file hashes (`make verify-preserved`), tags unchanged, no `main`, no remote, `.serena/` untouched, working tree clean after the last commit (tracked files; `.serena/` remains untracked).

## 8. Outcome

Written at the end of the run. A finding is marked **Closed** only where the evidence named here passed on the final tree; **Partial** names what is closed and what is not. Test files are in
`tests/`; probe ids are the independent review's; `RUN-003.md` has the full before/after probe table, the test counts and the validation record.

| Finding | Status | Evidence | What stays open |
|---|---|---|---|
| FR-001 derived classification | **Closed** (mechanism) | `test_classification` (156): zone, type, claim, plan, structure, keyword, tag additivity, 16 zones x 4 types, fail-closed, policy validation; probes P18, P18b, P46, P47, P20, P36 refused, naming the derived subjects | The table in `schemas/classification_policy.yaml` is an engineering initial version pending ChatGPT's and the owner's confirmation (D14). Keyword triggers are a safety net a paraphrase evades; the zone, type and claim rules do not depend on them. |
| FR-002 failure blocks only a tagged topic | **Closed** | `test_adverse_decisions` (72), `test_review_independence` (109); probes P02 P04 P05 P06 P07 P52 P53 refused | none known |
| FR-003 date and position decide precedence | **Partial** | `test_ledger_integrity` (76); probes P03a P03b P08a P08b P11a P11b P24 refused; P08c refused in a Git checkout | Removing the **last** rows of a ledger leaves a valid chain: invisible outside a Git checkout (P08c stays eligible in a bare export). Written migration procedure for a future hash-version change. |
| FR-004 conflicts settled by recency | **Closed** | `test_adverse_decisions` resolution and void matrix; probes P07 P10a P10b refused | none known |
| FR-005 reviewer identity and independence | **Closed** (mechanism) | `test_reviewer_registry` (87), `test_review_independence`, `test_review_policy` (66); probes P01 P09 P09b refused | The registry is the owner's attestation: it cannot prove a registered person is who it says or is qualified (D16). `domain_expert` is human `external_sme` only (D13). |
| FR-009 claims and sources not bound | **Partial** | full claim and source rows are in the package (`test_package_binding` 47); verified sources are identifiable, background and rights-rejected sources cannot back a claim (`test_registers` 74); probes P21 P22a P22b P49 refused | Claim verification is still a register cell, not a ledger attestation. |
| FR-010 approval does not cover what the page prints | **Closed** | image rows, actual file hashes, taxon and specimen rows and checklist digests are in the package; image audits need all four checks and a registered reviewer; probes P12 P16 P17 refused | none known |
| FR-011 approved text missing from the PDF | **Closed** (against its acceptance) | `test_render_totality` (47): unprinted fields refused, published bodies refused, a unique token in every printed field found in a real release PDF, a sabotaged layout caught in release and proof; probe P20 refused | Approved material known not to be printed is named in every manifest: image alt text (FR-023), the claim id of a unit-table row, body text (refused for published entries). Species and medical layouts do not exist (FR-020). |
| FR-012 species plate without real, matching views | **Partial** | `test_identification_evidence` (114): taxa and specimens, determiner authority, plate rules, duplicate bytes, review domains, binding; probes P13 P13b P14 P15 P32 P34 P92 refused | Near-duplicate (re-encoded or cropped) detection; organism-group perspective sets; look-alike pair records; edibility records; the taxon tier is a register cell no specialist has attested (D15). P34 is closed only for the missing label; the self-declared image method (FR-013) stays open. |
| FR-029 (supporting) review packet | **Partial** | `reviews/packets/` stored, cited by path and SHA-256, re-derived by the gate | Nothing proves the reviewer read the packet. |
| FR-022 (supporting) ledger integrity | **Partial** | sequence, chain, calendar dates, Git history check; `package_version` is in the digest | tail truncation outside Git; migration procedure. |
| FR-007 (supporting) checklist changes | **Partial** | definition digests of required subjects are in the package (probe P60) | `authority_requirement` (CDC/EPA, USDA/NCHFP) is not enforced against sources. |
| FR-006 (supporting) reviewer fields | **Partial** | `technical_reviewer`, `editorial_reviewer` and `authored_by` must be active registry identities; probe P93 | Technical review is not a ledger row; there is no owner release-authorization row. |
| FR-008, 013, 014, 015, 016, 017, 018, 019, 020, 021, 023, 024, 025, 026, 027, 028 | **Open** | not in RUN-003 scope (section 4); probes P19a P19b P27 P28 P29 P25 P26 P94 P70 P71 P72 P90 P91 measured, unchanged | each keeps its target sprint in `ARCHITECTURE_FINDINGS.md` of the review. |

### Differences from the contract as written

1. **Taxon domains.** The contract said "organism-group domain". Implemented as the taxon's `kind` (plant, fungus, lichen, mineral, rock, material), giving the registry domain `ID-<KIND>`; a registered `ID-` domain must be one of these.
2. **P34** is listed under FR-012's tests in the contract; the review files it under FR-013. Only its label hole is closed here (every AI-generated image needs its label, whatever its subject fields say).
3. **P93.** A literal `technical_reviewer: x` is now refused by the schema (an id must look like `REV-0001`) before the registry is consulted; a well-formed unregistered id is refused by the registry. The probe asserts the registry case and records the schema case.
4. **P18 and P18b** are asserted with the screening review RUN-002's rules would have asked for, so what is left uncovered is exactly what the zone and the type derive; the original no-review scenario is also recorded and refused.
5. **Found while porting the probes:** a repository with no commits yet was reported as an unreadable ledger history. Fixed, with a test that fails without the fix.
6. **Decisions added:** D13 to D16 in `BUILD_PLAN.md` section 9; D10, D11 and D12 are superseded or done.
7. **Not created:** no tag for this run (RUN-002 tagged its tip); the branch tip is the continuation point.

---

# RUN-004: safety and release-integrity remediation (contract)

| | |
|---|---|
| Run | RUN-004: claim completeness, placeholder safety text, measurement accuracy, release state, image publication, ledger continuity |
| Base | `3ef62a7ca042521ddad6a6d6ad4a18448fcc7a96` (branch `gate-a/remediation-2`, RUN-003). Both tags, branches `gate-a/scaffold`, `gate-a/remediation-1` and `gate-a/remediation-2` are untouched. |
| Branch | `gate-a/remediation-3` (no `main`, no remote, no push) |
| Source of findings | `FABLE-REVIEW-001` (`/home/jd/Survival_Guide_Fable_Review/`): FR-008, FR-021, FR-019, FR-017, FR-014, FR-015 and the residual of FR-003 (also FR-022 in part). RUN-003 closed the trust model; nothing it validated is repeated here. |
| Gate A | **BLOCKED. This document does not approve it.** No content publication is authorised. |
| Status of this part | Sections 9 to 14 are the **contract**, written before any code change in this run and left as written. Section 15 is the **outcome**, added at the end with the evidence for each status. |

Reproduced before any change (ported probes run unmodified on the untouched tree, `3ef62a7`, baseline `make check` green with 1353 tests): **P19a, P19b, P27, P28 ELIGIBLE** · **P23** accepts `1 mi / 2 km`, `1 in / 3 cm`, `2 lb / 1 kg`, `3 ft / 1 m`, `1 gal / 4 L`, `1 qt / 1 L`, `1 yd / 1 m` and rejects `18 °F / 10 °C`, `1/4 in / 6.35 mm`, `4-6 in / 102-152 mm`, `1 tsp / 5 ml` ·
**P25** the second release is refused (`APPROVAL_NOT_CURRENT`) and `Z09_tools_construction.pdf` and its manifest stay in `dist/zones` · **P72** the EXIF artist is recovered from the released PDF bytes · **P90** `All rights reserved`, `CC BY-NC-ND 4.0` with derivatives `none`, `Fair use` and an unnamed licence are accepted ·
**P08c** is blocked in a Git checkout and invisible in a bare export (the stated RUN-003 residual).

## 9. The change in one paragraph

RUN-003 made approval depend on records the author cannot choose. Six holes remain around it. (1) An entry can be approved while it cites **no claim**, and safety-bearing fields are untraced prose. (2) A safety field can hold **filler** ("N/A", "-"). (3) A **conversion** only has to round-trip at its own printed precision, so `1 mi / 2 km` passes, and a conversion in prose is never read. (4) A release **overwrites** a flat `dist/zones` and a later refusal leaves the old PDF looking current. (5) A published photograph's **EXIF and GPS** travel into the PDF, and a licence is free text. (6) A **truncated ledger tail** is invisible outside Git. RUN-004 answers each with a rule a human can state in one sentence, a policy table the owner can amend as a reviewed diff, and tests that fail without it.

## 10. Findings in scope

### FR-008 (High): species and medical entries can be approved with no claim at all

| | |
|---|---|
| **Root cause (reproduced)** | Claims are required only for procedure steps and unit-table rows (`_gate_researched`). An empty `procedure` and empty `claim_ids` therefore exempt a medical or species entry from every claim rule (P19a, P19b). Identification, medical, legal and safety text is untraced prose. |
| **Planned change** | New `schemas/claim_policy.yaml` and `scripts/sfe/evidence.py`. From `researched` up: (a) every entry cites at least `min_claims` registered claims (any status at `researched`, all verified from `verified`), and a `technical_procedure` has at least one step; (b) a `species_profile` cites at least one `identification` claim and a `medical_guidance` entry at least one `medical` claim; (c) every non-empty **bound field** must be bound, in a new optional front-matter mapping `field_claims`, to at least one registered claim whose type the policy accepts for that field (species: diagnostic features, look-alikes, uncertainty, positive-identification warning, expert criteria, processing restrictions, regulated status, dangers; medical: audience, evacuation threshold, contraindications, local emergency guidance, dangers); (d) every step of a `medical_guidance` entry cites a `medical` claim (no unsupported medical procedure); (e) text that makes an edibility or identification statement (trigger `TRG-FORAGING`) needs an `identification` or `safety_boundary` claim, and text that gives medical instruction (`TRG-MEDICAL`) needs a `medical` claim, **whatever the entry type**. `field_claims` ids count as cited claims (classification, package digest, source checks). An unusable policy is an error and applies the strictest reading. |
| **Acceptance** | P19a and P19b are refused for the stated reason (`ENTRY_CLAIMS_INSUFFICIENT`, `FIELD_CLAIM_MISSING`, `ENTRY_CLAIM_TYPE_MISSING`) from a clean control. Each rule has a failing and a passing case; an empty `procedure` or `claim_ids` never exempts anything; a binding to a claim of the wrong type, to an unregistered claim or to an empty field is an error; an invalid policy is an error. |
| **Regression tests** | `tests/test_claim_completeness.py`; probes P19a, P19b |
| **Stated limits** | Binding is per **field**, not per list item: one claim of the right type can back every item of a field (item-level `{text, claim_ids}` stays open). A claim of the right type proves a source was cited, not that it supports the sentence: that stays the domain expert's review. The trigger words are a safety net a paraphrase evades; the type rules do not depend on them. |
| **Migration** | Optional `field_claims` in the entry schema (a metadata key: unprinted, listed in `known_unrendered`); new `schemas/claim_policy.yaml`; fixtures supply claims of the required types. No entries exist. |

### FR-021 (Medium): required safety fields accept "N/A"

| | |
|---|---|
| **Root cause (reproduced)** | The verified rung tests only that a safety field is non-blank, so `abort_if: "N/A"`, `verify: "-"` and `dangers: ["n/a"]` pass (P27). |
| **Planned change** | New `scripts/sfe/textcheck.py`: `assess(text)` returns why a text carries no usable information, or nothing. Layers, none of which is a length test alone: no letter or digit; a null phrase after normalising case, punctuation, quotes and dashes (n/a, none, nil, tbd, "not applicable", "no abort condition", ...); an unfilled placeholder (`[insert ...]`, `<...>`, "fill in", "to be added", "xxx"); one character or one word repeated; no content word once stop words and generic filler (ok, fine, check, verify, safe, stop, careful, ...) are removed, with a two-word floor. Applied at `verified` and above to every mandatory text field: step `action`, `verify`, `abort_if`; `dangers` (hazardous entries); the type-required fields of technical, species and medical entries; **every item** of a list. The one **exception**: step `verify` or `abort_if` may read `Not applicable [CLM-0007]: <justification>` where the justification is itself usable (at least five words and three content words), the claim is cited by that same step, and the field is not `action`. The declaration is printed, is part of the reviewed package, and is the only way a field may say it does not apply. |
| **Acceptance** | P27 refused (each of the three values, with its reason). A table of null-like variants (case, spacing, punctuation, quotes, Unicode dashes, `N/A.`, `(none)`) is refused. A real sentence is accepted. A justified exception is accepted; an unjustified, null-like-justified, claimless or wrong-field one is refused. Property test: no mutation of a usable sentence by case or surrounding punctuation changes the verdict. |
| **Regression tests** | `tests/test_usable_text.py`; probe P27 |
| **Stated limits** | The check removes null, placeholder, repeated and content-free text. It cannot tell an adequate sentence from a poor one: that remains the reviewer's judgement. The word lists are finite. |
| **Migration** | None for data. The check starts at `verified`. |

### FR-019 (Medium): the unit check accepts large errors and cannot express common quantities

| | |
|---|---|
| **Root cause (reproduced)** | A pair must round-trip at each side's own printed decimals, so low-precision pairs pass whatever their size (P23). Fractions, ranges and temperature intervals are unparseable. Only `dimension_unit_table` is read; a conversion written in step text is never checked (P28). |
| **Planned change** | New `schemas/unit_policy.yaml` (engineering initial values, validated on every run; an unusable policy is an error and applies the strictest class) and a rewritten `scripts/sfe/units.py`. **Policy.** A pair is consistent only if it satisfies both the existing two-way round-trip rule **and** a relative-error bound from the exact conversion, `|conversion - stated| / max(|conversion|, |stated|)`: **precise 1 %** (the default for an unmarked pair), **approximate 5 %** (only a pair that carries an explicit marker, `~`, `≈`, about, approx., approximately, roughly, circa; the round-trip rule is then waived and nothing looser is allowed), **safety 0.5 %** (markers never loosen it). A quantity is safety-critical if its dimension is pressure or temperature, or its entry requires any review subject beyond screening, or its claim is high or critical risk or of type medical or safety_boundary. Absolute temperatures are held to correct rounding at the printed precision in both directions (a relative bound is meaningless on a scale with an arbitrary zero); a temperature **interval** is written `Δ18 °F / Δ10 °C` and converts without the offset. Fractions (`1/4`, `1 1/2`), ranges (`4-6`, `4 to 6`; endpoint against endpoint, ascending) and thousands separators parse. Zero compares only with zero. **Prose.** Every conversion written in entry text as `A (B)`, `A / B` or `A or B` with the two quantities in different systems and the same dimension is checked by the same policy, at every status; a quantity in prose with no counterpart is a **warning** (the handoff asks for dual units "when useful", not always). **No medical dose tolerance is invented**: dose units (mg, mcg, IU) and household measures (tsp, tbsp, cup) are not units of this table and stay refused as unknown. |
| **Acceptance** | The loose P23 pairs (`1 mi / 2 km`, `1 in / 3 cm`, `2 lb / 1 kg`, `3 ft / 1 m`, `1 gal / 4 L`, `1 qt / 1 L`, `1 yd / 1 m`) are refused; the corrected pairs (`1 mi / 1.6 km`, `1 in / 2.54 cm`, `2 lb / 0.9 kg`, `3 ft / 0.91 m`, `1 gal / 3.8 L`, `1 qt / 0.95 L`, `1 yd / 0.91 m`) pass; `1/4 in / 6.35 mm`, `4-6 in / 102-152 mm`, `Δ18 °F / Δ10 °C`, `8 fl oz / 237 ml`, `15 psi / 103 kPa` pass; `32 °F / 0 °C`, `-40 °F / -40 °C`, `0 °F / -18 °C` pass; every pair the old rule refused is still refused. P28 refused. Property tests (round trip of every exact conversion, symmetry, monotonicity in the error, a refused pair never becomes accepted by marking it safety) and boundary tests (exactly at, just inside and just outside each bound; zero; negatives; ranges). |
| **Regression tests** | `tests/test_unit_equivalence.py` (new); `tests/test_units.py` (kept: every old refusal still holds); probes P23, P28 |
| **Stated limits** | The three bounds are an engineering initial table (D19): tolerance by quantity kind is a policy decision. Only recognised units participate. A conversion in an unrecognised construction is not found. A minimum or maximum limit's rounding direction is not modelled. |
| **Migration** | New `schemas/unit_policy.yaml`. Some pairs that passed now fail (they were loose); no data exists. |

### FR-017 (High): a correction does not withdraw what was already built

| | |
|---|---|
| **Root cause (reproduced)** | `release` writes the flat `dist/zones/<ZONE>.pdf` and `.build.json`, overwriting. A refusal leaves the earlier PDF and manifest where releases are collected (P25). Nothing says which output is current, nothing archives a superseded one, and the manifest cannot be matched to the approvals in force. |
| **Planned change** | New `scripts/sfe/release.py`; `pdfbuild.build_release` becomes the builder and `release` the state machine. Layout under `dist/`: `editions/<ED-id>/` (an **immutable archive**, one directory per edition, the PDFs, their manifests and `EDITION.json`; written once, never overwritten, files made read-only); `ACTIVE_RELEASE.json` (the **explicit active-release manifest**: state `active` or `withdrawn`, edition id, hash of its `EDITION.json`, generation, reason); `RELEASE_LOG.csv` (**append-only, chained audit log**: promote, supersede, withdraw, auto-withdraw, quarantine, recover; never deleted by the tool); `.staging/` (transient). The edition id is derived from the build's inputs (entries and their package digests, ledger heads and row counts, policy digests, layout, toolchain, pipeline version). **Promotion is atomic:** build and verify in staging, rename the staging directory into `editions/` (same file system), write the pointer to a temporary file and `os.replace` it, then append the log. An interrupted promotion is detected and repaired by `release recover` (and by the next `release`), never by deleting evidence. **Validation of the active release** (`release verify`, read-only): the pointer is well formed; the edition exists and its `EDITION.json` and every artifact match their recorded hashes; every entry is still published, with the same revision and the **same package digest** as at build; each ledger still extends the head recorded at build; the policy digests are unchanged; the current tree has no error that concerns the edition (an error in an unrelated entry does not revoke it; a ledger, register or policy error does). **Invalidation** (`release reconcile`, run first by every `release`): an invalid active edition becomes `withdrawn` with the reason recorded; a legacy flat `dist/zones` or `dist/complete` file is **moved** to `dist/quarantine/`, never deleted. `release withdraw --reason` withdraws on purpose. No PDF is labelled current except through the pointer, and no flat copy exists. |
| **Acceptance** | P25: after an approval is withdrawn and a release refused, `ACTIVE_RELEASE.json` says `withdrawn` with the reason, no PDF sits outside `editions/`, the archived edition is intact, `release verify` fails. A failed build writes nothing. Promotion interrupted at each step (after archive, after pointer, mid log) leaves a state `recover` repairs and the next release completes. Restart recovery is tested. Two builds of one tree give one edition (byte-identical, idempotent), a different edition a different id; an existing edition is never overwritten (a conflicting one is an error). A superseded edition is logged as superseded. |
| **Regression tests** | `tests/test_release_state.py` (new); `tests/test_pdf_pipeline.py`, `tests/test_cli.py` and the probes updated for the new layout; probe P25 |
| **Stated limits** | State is local files under git-ignored `dist/`: nothing is signed, so someone with write access can edit the pointer; `verify` re-validates against the tree and catches a stale or forged pointer, not a forged edition together with a forged tree. The log's tail can be truncated unnoticed (as FR-003 before its pin). The edition id is not yet printed in the PDF and there is no errata ledger (the review's remaining FR-017 items). A copied PDF carries no label. |
| **Migration** | `dist/zones/<ZONE>.pdf` is replaced by `dist/editions/<ED-id>/zones/<ZONE>.pdf`; `ReleaseResult` gains `edition_id`; `make release` prints the edition and state; `.gitignore` covers the new paths; the release manifest gains the ledger row counts and the `edition_id`. |

### FR-014 (Medium) and FR-015 (Medium): image metadata and licences

| | |
|---|---|
| **Root cause (reproduced)** | The release copies the original file into the LaTeX run, so pdfTeX embeds a JPEG's EXIF and GPS segments unchanged (P72, `pdfimages -all` recovers them). `license` is free text, `allowed_derivatives` is free text although the layout re-encodes and overlays every image, and only a short list of bare words is rejected (P90). |
| **Planned change** | **FR-014.** New `scripts/sfe/derive.py`: a publication **derivative** is a deterministic re-encode of the original (orientation applied, then every EXIF, XMP, IPTC, comment and text chunk dropped; the ICC profile, which colour needs, is kept; format kept). The release embeds only derivatives; the original is opened read-only and never copied into the build or the archive. The manifest records each lineage (asset, original hash, derivative hash, recipe). After every build the PDF is checked: no EXIF or Photoshop signature in its bytes, none of the original's metadata strings in its bytes, and every extracted image free of APPn and comment markers (`IMAGE_METADATA_IN_PDF`); no original's hash appears among the archived files (`ORIGINAL_PUBLISHED`). **FR-015.** New `schemas/licenses.yaml`: a controlled vocabulary, each licence with its permissions (reuse, modify, crop, redistribute, commercial) and obligations (attribution, share-alike). An approved asset's `license` must be in it; the pipeline's operations (reuse, modify, crop, redistribute, and commercial use while the owner has not said distribution is non-commercial) must all be permitted, so `All rights reserved`, `Fair use`, `CC BY-NC-*` (until D22) and `CC BY-ND-*` are refused; a permission-based asset (`LicenseRef-Permission`) must state the operations it grants. **Every approved asset needs rights evidence**: a stored file under `assets/rights/` whose SHA-256 matches. Files outside the approved directories, and uncatalogued files in the quarantine directory, are reported; the build reads nothing outside the approved directories. Nothing here infers that a real-looking photograph is authentic: `generation_method` stays an attested field (FR-013). |
| **Acceptance** | P72: no EXIF, GPS, artist or description string in the PDF bytes; extracted images carry no metadata; pixels and orientation are preserved; the derivative is deterministic and the original byte-identical and untouched. P90: every restrictive case is refused with its reason; permitted licences pass; a licence outside the vocabulary, missing evidence, a changed evidence file, or an ND or NC licence is refused. A corrupt image refuses the release. |
| **Regression tests** | `tests/test_image_publication.py`, `tests/test_licences.py` (new); `tests/test_assets.py` updated; probes P72, P90 |
| **Stated limits** | PDF graphics are embedded as they are (they must be the project's own diagrams). The derivative is not resized, so file size is FR-026's. Reviewers audit the original, not the re-encoded pixels. Evidence proves what was stored, not that a rights statement is true. The printed credit line is unchanged (the work's title and the licence link are still absent) and no attribution ledger is generated. Storing originals outside Git, and who may read them, is an owner decision (D21). |
| **Migration** | Asset manifest gains `rights_evidence_path`, `rights_evidence_sha256`, `rights_granted`; `allowed_derivatives` stays but the vocabulary decides; new `schemas/licenses.yaml` and `assets/rights/`; the release manifest gains `derivatives`. |

### FR-003 (High, residual): a truncated ledger tail is invisible outside Git

| | |
|---|---|
| **Root cause (reproduced)** | The chain of a prefix is a valid chain, so removing the last rows leaves a ledger that verifies. Only Git history catches it, and an exported tree has none. A chain alone cannot detect truncation, and this run does not claim it can. |
| **Planned change** | A **pin**: `python -m sfe ledger pin` verifies every ledger's sequence and chain and prints a short line holding, for each ledger, its row count and chain head. The owner keeps it **outside the repository**. `validate --pin`, `release --pin` and `release verify --pin` (or the environment variable `SFE_LEDGER_PIN`; a pin file inside the repository is refused) check that every ledger still has at least the pinned rows and that the chain value at the pinned row is the pinned head: fewer rows is `LEDGER_PIN_TRUNCATED`, a different value `LEDGER_PIN_REWRITTEN`, a malformed pin `LEDGER_PIN_INVALID`. **Fail closed:** when any ledger has rows and no pin is supplied, `release` and `release verify` refuse (`LEDGER_PIN_REQUIRED`); `validate` reports `LEDGER_CONTINUITY_UNANCHORED` as a warning (an error under `--strict`). When every ledger is empty no anchor is needed. |
| **Acceptance** | P08c in a bare export, with a pin: refused (`LEDGER_PIN_TRUNCATED`); without one: `release` refused (`LEDGER_PIN_REQUIRED`) and `validate` warns. Truncating any ledger by one row, rewriting the prefix, a pin for another ledger set, a malformed pin and an empty pin are all refused; appending rows after the pin is accepted; a pin taken from broken ledgers is not issued. |
| **Regression tests** | `tests/test_ledger_pin.py` (new); probe P08c (bare export and with a pin) |
| **Stated limits** | A pin protects the rows that existed when it was taken: rows appended later, and their truncation, are unprotected until the owner pins again. The pin is only as independent as where the owner keeps it. Nothing is cryptographically signed. |
| **Migration** | New CLI `ledger pin` and `--pin`; `release` and `release verify` need a pin once any ledger has rows. |

## 11. Not in RUN-004 scope (stay open)

FR-013 (self-declared image method), FR-016 (nothing expires), FR-018 (duplicate link targets), FR-020 (breakable safety panels, species and medical layouts), FR-023 (alt text), FR-024 (invariant tests beyond these areas), FR-025 (look-alike pair and edibility records), FR-026 (derivative size and the storage plan; only the derivative recipe and lineage start here), FR-027 (controlled vocabularies), FR-028 (decorative fields), the residual of FR-009 (claim verification as a ledger attestation) and the item-level form of FR-008. Each keeps its target sprint in `ARCHITECTURE_FINDINGS.md`; none is marked closed here.

## 12. Rules for changing the existing tests

As section 5, and in addition: a fixture that now needs a claim of the right type, a usable sentence, a pin or the new release layout is **adapted** (these are the new gates' required evidence, never a loosening); a test that passed while asserting a loose or wrong behaviour (a loose conversion accepted, a flat `dist/zones`, a restrictive licence accepted, an unpinned ledger accepted) is **replaced**, not adjusted, and listed in `RUN-004.md`. Before and after counts, with every exclusion, are reported there.

## 13. Verification plan

The full suite before (1353) and after; the nine probes before (above) and after, each asserted only if refused for the stated reason from a world proved clean; `make check`; the committed proof rebuilt in the same commit as any schema change that feeds it; two release builds byte-identical; fail-closed command-level checks; sabotage experiments for every new safeguard (a scratch copy with one safeguard removed must fail the tests, after a clean control); preserved-file hashes, tags unchanged, no `main`, no remote, `.serena/` untouched; `make release` still refuses; no content published; tracked tree clean after the last commit.

## 14. Decisions requested (new)

**D17** claim policy (`schemas/claim_policy.yaml`): minimum claims, required claim types and which fields need which claim types · **D18** the usable-text rule and the `Not applicable [CLM-id]: ...` exception · **D19** unit tolerances (`schemas/unit_policy.yaml`: 1 %, 5 %, 0.5 %) and what is safety-critical · **D20** release custody: who may withdraw, edition retention, and where the release log is kept (it lives under git-ignored `dist/`) · **D21** where original photographs are stored and who may read them, and the derivative recipe · **D22** the licence vocabulary and whether distribution is commercial (the table assumes it is, which refuses NC licences) · **D23** ledger pin custody and cadence (who takes it, where it is kept, when it is renewed).

## 15. Outcome (RUN-004)

Written at the end of RUN-004. A finding is marked **Closed** only where every acceptance criterion passed on the final tree; **Partial** names what is closed and what stays open (unresolved items are never marked closed). Full probe table, test counts, sabotage results and migration notes: `RUN-004.md`.

| Finding | Status | Evidence | What stays open |
|---|---|---|---|
| FR-008 claim completeness | **Partial** | `schemas/claim_policy.yaml`, `scripts/sfe/evidence.py`; `test_claim_completeness` (82); sabotages S81–S92 (12/12 detected); probes P19a, P19b refused (`ENTRY_CLAIMS_INSUFFICIENT`, `ENTRY_CLAIM_TYPE_MISSING`, `FIELD_CLAIM_MISSING`) from clean controls; medical steps require medical claims; trigger rules enforce claims across entry types | Binding is per **field** (`field_claims`), not per list item (item-level `{text, claim_ids}` stays open). Policy table awaits confirmation (D17). A claim of the right type shows a source was cited, not that the source supports the sentence (stays domain-expert review). |
| FR-021 placeholder safety text | **Closed** (mechanism) | `scripts/sfe/textcheck.py`; `test_usable_text` (246), including seeded property tests; sabotages S93–S109 (17/17 detected); probe P27 refused (`FIELD_NOT_USABLE`, naming `step 1 abort_if`, `step 1 verify`, `dangers[0]`) from a clean control; justified `Not applicable [CLM-id]: <justification>` exception enforced and printed | Cannot tell an adequate sentence from a poor one (stays reviewer judgement); word lists are finite; exception policy awaits confirmation (D18). |
| FR-019 measurement accuracy | **Closed** (mechanism) | `schemas/unit_policy.yaml`, rewritten `scripts/sfe/units.py`; `test_unit_equivalence` (369) and `test_units` (30), including property and boundary tests; sabotages S110–S137 (28/28 detected); probes P23 and P28 refused (`UNIT_INCONSISTENT`) from clean controls; prose conversions checked across all text fields; no medical dosage tolerances invented | Policy bounds (1 % / 5 % / 0.5 %) are an engineering initial table (D19). Minimum/maximum rounding direction (RT-103) is not modelled. |
| FR-017 release state | **Partial** | `scripts/sfe/release.py`, `pdfbuild.py`, `cli.py`; `test_release_state` (18): active-release manifest, immutable read-only edition archive, atomic promotion, withdrawal/auto-withdrawal, `verify_active`, zone removal (RT-115), legacy quarantine, all crash/fault points and restart recovery; sabotages S138–S151 (14/14 detected); probe P25 closed | Edition id is not yet printed on every PDF page (RT-107) and there is no errata/recall ledger; state lives under git-ignored `dist/` without cryptographic signing; release custody awaits D20. |
| FR-014 EXIF/GPS & image derivatives | **Closed** (against RUN-004 acceptance) | `scripts/sfe/derive.py`, `pdfbuild.py`, `assets.py`; `test_image_publication` (9): deterministic EXIF/GPS/XMP/IPTC/COM/PNG-text stripping, orientation transpose, ICC preservation, read-only originals with access-control check (`ASSET_PERMISSIONS_TOO_OPEN`), post-build PDF byte + `pdfimages -all` check (`IMAGE_METADATA_IN_PDF`), no originals archived (`ORIGINAL_PUBLISHED`), lineage in manifests; sabotages S152–S157 (6/6 detected); probe P72 closed | Derivative sizing/resolution budgets and external original storage plan remain in FR-026 and D21. Nothing infers photograph authenticity (FR-013 stays open). |
| FR-015 controlled licences & rights evidence | **Partial** | `schemas/licenses.yaml`, `schemas/asset.schema.json`, `scripts/sfe/assets.py`, `package.py`; `test_licences` (39), `test_assets` (45); sabotages S158–S167 (10/10 detected); probe P90 closed; rights evidence files under `assets/rights/` verified by SHA-256 and bound to package digest; quarantine/directory hygiene enforced | Printed credit line still omits work title and licence URL, and no generated attribution ledger exists yet. Distribution model (commercial vs non-commercial) awaits D22. |
| FR-003 (residual) ledger continuity outside Git | **Closed** (with stated operational limit) | `scripts/sfe/ledger.py`, `validate.py`, `release.py`, `pdfbuild.py`, `cli.py`; `test_ledger_pin` (20); sabotages S168–S177 (10/10 detected); probe P08c closed in Git checkout (`LEDGER_HISTORY_REWRITTEN`) and in bare export with external pin (`LEDGER_PIN_TRUNCATED`), and fails closed without an anchor (`LEDGER_PIN_REQUIRED` on release/verify; `LEDGER_CONTINUITY_UNANCHORED` warning / `--strict` error on validate); pins inside repo refused (`LEDGER_PIN_INSIDE_REPO`) | A hash chain alone never detects truncation; the external pin protects rows up to the checkpoint only (rows appended afterwards need a renewed pin), is unsigned, and is only as independent as where the owner keeps it (D23). |
| FR-022 (supporting) ledger integrity | **Partial** | External continuity pin closes bare-export tail truncation alongside sequence, chain, calendar dates and Git history check | Written migration procedure for a future hash-version change remains open. |
| FR-013, 016, 018, 020, 023, 024, 025, 026, 027, 028; residuals of FR-009, FR-012 | **Open** / **Partial** | Not in RUN-004 scope (section 11); open probes P26, P29, P70, P71, P91, P94 measured and unchanged | Each keeps its target sprint in `ARCHITECTURE_FINDINGS.md`; none is marked closed here. |

### Differences from the RUN-004 contract as written

1. **Temperature intervals (FR-019).** Because pdfLaTeX (T1 encoding) cannot print `Δ` or `≈` without a fatal missing-character error, temperature intervals use ASCII `"18 °F difference / 10 °C difference"` and approximation markers are ASCII (`~`, `about`, `approx.`, `approx`, `approximately`, `roughly`, `circa`).
2. **Release superseding vs auto-withdrawal (FR-017).** On a valid new build (e.g. revision 1 → revision 2, or a zone losing its last published entry), `build_release` runs `recover` and `quarantine_legacy` and then promotes atomically, recording `supersede` + `promote` in `RELEASE_LOG.csv`. Full `reconcile` (which auto-withdraws an invalidated active edition) runs whenever a build is refused or when invoked explicitly (`release reconcile`), so clean upgrades record `supersede` while invalidations record `auto_withdraw`.
3. **Original access control (FR-014).** `assets.py` checks that approved original files are not world-writable (`ASSET_PERMISSIONS_TOO_OPEN`) in addition to keeping them separate from `dist/` and never copying them into build directories or release archives.
4. **Pin integrity digest (FR-003).** `sfe-pin-v1` carries a 16-hex digest over its body so transcription typos are caught immediately as `LEDGER_PIN_INVALID`.
5. **No new Git tag.** As in RUN-003, no new tag was created; branch `gate-a/remediation-3` tip is the continuation point. Earlier tags `gate-a-submission` and `gate-a-remediation-1` are untouched.
