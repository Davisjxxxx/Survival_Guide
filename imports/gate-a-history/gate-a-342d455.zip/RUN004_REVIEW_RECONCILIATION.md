# RUN-004 Contract & Evidence Reconciliation

| | |
|---|---|
| Project | Survival Field Encyclopedia (`/home/jd/Survival_Guide`) — no other project touched or included |
| Branch | `gate-a/remediation-3` (no `main`, no remote, no push, no new tag) |
| RUN-003 base | `3ef62a7ca042521ddad6a6d6ad4a18448fcc7a96` (`gate-a/remediation-2`, untouched) |
| RUN-004 contract commit | `e0ab463d729e4b84aac3e2acd3e5c62452aa47a6` (`FINDING_REMEDIATION_MATRIX.md` §§9–14, verified byte-for-byte unchanged) |
| Submitted RUN-004 tip | `12e068452921f0a68a2ebd9c51875d477ba694d5` |
| Reconciliation code/test commit | `ca8172778499cc7e748b383ceb83665f2a8464cc` (verified by full `make check`: 2140 passed) |
| Final reconciliation commit | Commit adding this file (`git log -1 --format=%H -- RUN004_REVIEW_RECONCILIATION.md`; exact SHA stated in the handoff message and review archive filename) |
| Gate A status | **BLOCKED** (not self-approved) |
| Content publication | **NOT AUTHORIZED** (Track B content not started or ingested here) |

## 1. Repository State and Preservation Verification

Verified before any reconciliation edit and re-verified after committing:

- **Workspace & branch:** `/home/jd/Survival_Guide`, on `gate-a/remediation-3`, starting cleanly at `12e068452921f0a68a2ebd9c51875d477ba694d5` with only `.serena/` untracked (preserved untouched).
- **Remotes & refs:** no remote configured (`git remote -v` empty); no `main` or `master` branch; prior branches `gate-a/scaffold` (`dc67819`), `gate-a/remediation-1` (`a08104a`), and `gate-a/remediation-2` (`3ef62a7`) untouched; prior tags `gate-a-submission` (`dda968fbaf8c677c578b7f2b492e46d3bbfccd18` → `dc67819`) and `gate-a-remediation-1` (`c641235a44146ebbab17336c7b09ea92d0dcf263` → `a08104a`) untouched; no new tag created.
- **Preserved files & prior records:** `make verify-preserved` passes 6/6 (`PRESERVED_FILES.sha256`) and 3/3 (`handoff/SHA256SUMS.txt`). `git diff 3ef62a7 HEAD` is empty for `handoff/`, `BASELINE_AUDIT_20261116.md`, `PROJECT_AUDIT.md`, `RUN-001.md`, `RUN-002.md`, `RUN-003.md`, and `PRESERVED_FILES.sha256`.
- **Contract immutability:** `git diff e0ab463 HEAD -- FINDING_REMEDIATION_MATRIX.md` shows zero edits to sections 9–14 (only section 15 Outcome was appended).
- **Superseded patch:** `Survival_Guide_RUN004_ChatGPT_Prework.patch` is superseded and was not applied.
- **No content published / no fabricated approvals:** all real registers (`research/*.csv`, `assets/*.csv`, `reviews/*.csv`) remain header-only; `make release` refuses (`NO_PUBLISHED_ENTRIES`).

## 2. Contract-to-Evidence Reconciliation Table

Judged strictly against `FINDING_REMEDIATION_MATRIX.md` §§9–14 as written in `e0ab463` before any RUN-004 code changed. Later-sprint requirements (atlas layouts, accessibility/tagging, errata, external original storage) are not converted into RUN-004 work and remain explicitly `deferred` or `partial`.

| Criterion (from `e0ab463` contract) | Finding | Status | Evidence | Tested Tree | Limitation / Residual |
|---|---|---|---|---|---|
| Minimum claims (`min_claims`, hard floor ≥ 1 in code) and `min_steps` (`technical_procedure` ≥ 1); empty `procedure`/`claim_ids` exempt nothing | FR-008 | **met** | `schemas/claim_policy.yaml`, `scripts/sfe/evidence.py`, `tests/test_claim_completeness.py` (82), `tests/sabotage.py` S81–S84 (detected), P19a & P19b BLOCKED | `2981870`, `12e0684`, `ca81727` | Policy table is engineering initial version pending D17. |
| Required claim types by entry type (`species_profile` → `identification`, `medical_guidance` → `medical`); every medical procedure step cites a `medical` claim | FR-008 | **met** | `scripts/sfe/evidence.py`, `tests/test_claim_completeness.py`, S85–S86 (detected), P19a & P19b BLOCKED | `2981870`, `12e0684`, `ca81727` | Proves a claim of the required type is cited, not that the source supports the wording (stays domain-expert review). |
| Non-empty safety-bearing fields bound in `field_claims` to accepted claim types; `field_claims` counted in cited claims, classification, package digest, source checks | FR-008 | **partial** | `schemas/entry.schema.json`, `scripts/sfe/entries.py` (`claim_ids_of`), `evidence.py`, `tests/test_claim_completeness.py`, S87–S90 (detected) | `2981870`, `12e0684`, `ca81727` | Binding is per **field**, not per list item; item-level `{text, claim_ids}` was explicitly deferred in `e0ab463` §§10–11. |
| Text triggers (`TRG-FORAGING` → `identification`/`safety_boundary`, `TRG-MEDICAL` → `medical`) enforced across entry types; unusable policy fails closed | FR-008 | **met** | `scripts/sfe/evidence.py`, `tests/test_claim_completeness.py`, S91–S92 (detected) | `2981870`, `12e0684`, `ca81727` | Trigger regexes can be evaded by paraphrase; primary type/zone/claim rules do not depend on them. |
| Layered usable-text check (not length alone: no letters/digits, null phrases/leads, placeholders, repetition, word floor, no content words) on mandatory safety/verification fields and every list item from `verified` | FR-021 | **met** | `scripts/sfe/textcheck.py`, `tests/test_usable_text.py` (246, incl. seeded property tests), S93–S105 (detected), P27 BLOCKED (`step 1 abort_if`, `step 1 verify`, `dangers[0]`) | `1987142`, `12e0684`, `ca81727` | Cannot distinguish an adequate sentence from a weak one (stays reviewer judgement); finite word lists. |
| Sole explicit exception `Not applicable [CLM-id]: <justification>` (≥ 5 words, ≥ 3 content words, claim cited by that step, allowed ONLY in step `verify`/`abort_if`, printed & package-bound) | FR-021 | **met** | `scripts/sfe/textcheck.py`, `tests/test_usable_text.py`, S106–S109 (detected) | `1987142`, `12e0684`, `ca81727` | Exception wording/policy pending owner confirmation (D18). |
| Documented numeric equivalence policy (`schemas/unit_policy.yaml`: precise 1 %, explicit approximate 5 %, safety 0.5 % with code ceilings; unusable policy fails closed to strictest) + two-way round trip retained | FR-019 | **met** | `schemas/unit_policy.yaml`, `scripts/sfe/units.py`, `tests/test_unit_equivalence.py` (369), `tests/test_units.py` (30), S110–S123 & S130–S135 (detected), P23 BLOCKED | `3ae6277`, `12e0684`, `ca81727` | Policy numbers are engineering initial values pending D19. |
| Fractions, ranges (endpoint-to-endpoint, ascending), temperature offsets/zero, and temperature intervals (`18 °F difference / 10 °C difference`) | FR-019 | **met** | `scripts/sfe/units.py`, `tests/test_unit_equivalence.py`, P23 table verified | `3ae6277`, `12e0684`, `ca81727` | ASCII-only (`difference`, `~`, `about`, etc.) because pdfLaTeX T1 cannot print `Δ`/`≈`. |
| Prose conversion scanning (`A (B)`, `A / B`, `A or B`, `A = B`) across all entry text; lone prose quantity warns only | FR-019 | **met** | `scripts/sfe/units.py` (`scan_text`), `scripts/sfe/validate.py` (`_check_units`), `tests/test_unit_equivalence.py`, S124–S129 & S136–S137 (detected), P28 BLOCKED | `3ae6277`, `12e0684`, `ca81727` | Only recognised units and listed prose constructions are matched. |
| No medical dosage tolerances invented (dose units `mg`/`mcg`/`IU` and household measures `tsp`/`tbsp`/`cup` refused as unknown) | FR-019 | **met** | `scripts/sfe/units.py`, `tests/test_unit_equivalence.py`, S121 (detected), P23 (`1 tsp / 5 ml: REJECTED`) | `3ae6277`, `12e0684`, `ca81727` | Intentional safety boundary; never loosened without specialist policy. |
| RT-103 minimum/maximum limit rounding direction | FR-019 | **deferred** | Explicitly excluded in `e0ab463` contract (`FINDING_REMEDIATION_MATRIX.md` line 243: *"A minimum or maximum limit's rounding direction is not modelled."*) | `e0ab463`, `ca81727` | Retained as residual; see §4.3 for content restrictions until modelled. |
| Explicit active-release manifest (`ACTIVE_RELEASE.json`), immutable read-only edition archive (`dist/editions/<ED-id>/`), atomic promotion, append-only hash-chained `RELEASE_LOG.csv`, no flat `dist/zones/` copy | FR-017 | **met** | `scripts/sfe/release.py`, `scripts/sfe/pdfbuild.py`, `scripts/sfe/cli.py`, `tests/test_release_state.py` (19), S138–S151 & S178 (detected), P25 BLOCKED | `8f6a297`, `12e0684`, `ca81727` | State lives under git-ignored `dist/`, unsigned; custody/backup pending D20. |
| Active-release validation (`release verify`) against approvals, package digests, ledger extension, policy digests, archived hashes, legacy files; invalidation/auto-withdrawal on refusal (`reconcile`); manual withdrawal (`withdraw --reason`); crash/restart recovery without deleting evidence or reactivating withdrawn editions | FR-017 | **met** | `scripts/sfe/release.py`, `tests/test_release_state.py` (all 6 fault points, partial log row, legacy quarantine, RT-115 zone loss, `EDITION_WITHDRAWN` reactivation guard), S138–S151 & S178 (detected), P25 BLOCKED | `8f6a297`, `ca81727` | Reconciliation commit `ca81727` closed the gap where `promote()` could reactivate a manually withdrawn `edition_id` on an unchanged tree. |
| Printed edition ID on every PDF page (RT-107) and errata/recall ledger | FR-017 | **deferred** | Explicitly stated as out of RUN-004 scope in `e0ab463` contract (`FINDING_REMEDIATION_MATRIX.md` line 254: *"The edition id is not yet printed in the PDF and there is no errata ledger"*) | `e0ab463`, `ca81727` | FR-017 therefore remains **Partial** until RT-107 and errata ledger are implemented. |
| Deterministic EXIF/GPS/XMP/IPTC/comment/PNG-text stripping in publication derivatives, orientation transpose, ICC preservation, read-only originals never copied into build/archive, post-build PDF byte + `pdfimages -all` check, derivative lineage in manifests | FR-014 | **met** | `scripts/sfe/derive.py`, `scripts/sfe/pdfbuild.py`, `tests/test_image_publication.py` (9), S152–S157 (detected), P72 BLOCKED (`errors: IMAGE_METADATA_IN_PDF`, clean on `ca81727`) | `c43edf4`, `12e0684`, `ca81727` | Derivative resizing/size budgets (FR-026) and external original storage/ACL custody (D21) are deferred; see §4.5. Never infers photograph authenticity (FR-013 stays open). |
| Controlled licence vocabulary (`schemas/licenses.yaml`), required operations (`reuse`, `modify`, `crop`, `redistribute`, `commercial`) with floor in code, `LicenseRef-Permission` + `rights_granted`, rights-evidence files under `assets/rights/` hash-checked and package-bound, quarantine/directory hygiene | FR-015 | **partial** | `schemas/licenses.yaml`, `schemas/asset.schema.json`, `scripts/sfe/assets.py`, `scripts/sfe/package.py`, `tests/test_licences.py` (39), `tests/test_assets.py` (45), S158–S167 (detected), P90 BLOCKED | `c43edf4`, `12e0684`, `ca81727` | Printed credit-line work title/URL and generated attribution ledger explicitly deferred in `e0ab463` §10; commercial distribution model pending D22. |
| External ledger continuity pin (`ledger pin`, `sfe-pin-v1`, `--pin` / `SFE_LEDGER_PIN`), in-repo pin refused, truncation (`LEDGER_PIN_TRUNCATED`) and rewrite (`LEDGER_PIN_REWRITTEN`) caught in bare export, fail-closed without anchor (`LEDGER_PIN_REQUIRED` on release/verify; `LEDGER_CONTINUITY_UNANCHORED` warning / `--strict` error on validate), broken ledgers never pinned, validate/release/verify never self-generate a pin | FR-003 (residual) | **met** | `scripts/sfe/ledger.py`, `validate.py`, `release.py`, `pdfbuild.py`, `cli.py`, `tests/test_ledger_pin.py` (21), S168–S177 (detected), P08c bare-export BLOCKED | `b394b63`, `12e0684`, `ca81727` | Unsigned checkpoint; protects rows up to pin only; no separate project-id field beyond `reviewers` bootstrap chain head; custody/cadence pending D23. See §4.2. |

## 3. Reconciled Probe Accounting (All 59 IDs)

### 3.1 Resolution of the `42/59 → 50/59` vs Nine Named Cases Discrepancy

In RUN-003 (`3ef62a7`), `tests/test_fable_probes.py` pinned `len(IN_SCOPE) == 42` and `len(OUT_OF_SCOPE) == 17` (`42 + 17 = 59` total probe IDs). **Probe `P08c` was already one of those 42 `BLOCKED` probe IDs** in RUN-003 because its primary scenario ran inside a Git checkout and blocked with `LEDGER_HISTORY_REWRITTEN`, while recording its bare-export residual in `info["outside_git"]`.

In RUN-004, **8 new probe IDs** moved from `OUT_OF_SCOPE` (non-blocked) to `IN_SCOPE` (`BLOCKED`):
`P19a`, `P19b`, `P27`, `P23`, `P28`, `P25`, `P72`, `P90` (`42 + 8 = 50 BLOCKED`, `17 - 8 = 9` remaining non-blocked).

The 9th named item — **`P08c` bare-export** — is a **scenario variant** of an already-counted probe ID (`P08c`), NOT a 51st probe ID. Thus:
- **By unique probe ID (59 total):** `42 BLOCKED, 11 ELIGIBLE, 6 INFO` (RUN-003) → **`50 BLOCKED, 6 ELIGIBLE, 3 INFO`** (RUN-004).
- **By scenario variant:** `P08c [bare export]` transitioned from `ELIGIBLE` (RUN-003 residual) to `BLOCKED` with external pin (`LEDGER_PIN_TRUNCATED`) and fail-closed unpinned (`LEDGER_PIN_REQUIRED` at release).

### 3.2 Complete 59-Probe Before/After Table

| Probe | Finding | RUN-003 (`3ef62a7`) | RUN-004 (`b394b63` / `ca81727`) | Change |
|---|---|---|---|---|
| P01 | FR-005 | BLOCKED | BLOCKED (`SAFETY_REVIEW_ROLE_MISSING`) | Retained |
| P02 | FR-002 | BLOCKED | BLOCKED (`SAFETY_AUDIT_SUPERSEDED`, `SAFETY_FAILURE_UNRESOLVED`) | Retained |
| P03a | FR-002, FR-003 | BLOCKED | BLOCKED (`LEDGER_DATE_REGRESSION`, `SAFETY_AUDIT_SUPERSEDED`, `SAFETY_FAILURE_UNRESOLVED`) | Retained |
| P03b | FR-002, FR-003 | BLOCKED | BLOCKED (`LEDGER_DATE_REGRESSION`, `SAFETY_AUDIT_SUPERSEDED`, `SAFETY_FAILURE_UNRESOLVED`) | Retained |
| P04 | FR-002 | BLOCKED | BLOCKED (`SAFETY_AUDIT_SUPERSEDED`, `SAFETY_FAILURE_UNRESOLVED`) | Retained |
| P05 | FR-002 | BLOCKED | BLOCKED (`SAFETY_AUDIT_SUPERSEDED`, `SAFETY_FAILURE_REPORTS_UNCLASSIFIED_HAZARD`, `SAFETY_FAILURE_UNRESOLVED`) | Retained |
| P06 | FR-002 | BLOCKED | BLOCKED (`SAFETY_AUDIT_SUPERSEDED`, `SAFETY_FAILURE_REPORTS_UNCLASSIFIED_HAZARD`, `SAFETY_FAILURE_UNRESOLVED`) | Retained |
| P07 | FR-002 | BLOCKED | BLOCKED (`SAFETY_FAILURE_UNRESOLVED`) | Retained |
| P08a | FR-002 | BLOCKED | BLOCKED (`SAFETY_AUDIT_SUPERSEDED`, `SAFETY_FAILURE_UNRESOLVED`) | Retained |
| P08b | FR-003 | BLOCKED | BLOCKED (`LEDGER_SEQUENCE_BROKEN`, `SAFETY_FAILURE_UNRESOLVED`) | Retained |
| P08c | FR-003 | BLOCKED *(Git only; bare ELIGIBLE)* | BLOCKED (`LEDGER_HISTORY_REWRITTEN`; bare-export variant now also closed — see §3.3) | Variant closed (already in 42) |
| P09 | FR-005 | BLOCKED | BLOCKED (`SAFETY_REVIEW_ROLE_MISSING`) | Retained |
| P09b | FR-005 | BLOCKED | BLOCKED (`REGISTRY_KIND_CAPACITY`, `SAFETY_REVIEW_ROLE_MISSING`) | Retained |
| P10a | FR-002 | BLOCKED | BLOCKED (`APPROVAL_NOT_CHATGPT_EDITORIAL`, `APPROVAL_NOT_CURRENT`) | Retained |
| P10b | FR-002 | BLOCKED | BLOCKED (`APPROVAL_NOT_CHATGPT_EDITORIAL`, `APPROVAL_NOT_CURRENT`) | Retained |
| P11a | FR-002, FR-003 | BLOCKED | BLOCKED (`APPROVAL_NOT_CURRENT`, `LEDGER_DATE_REGRESSION`) | Retained |
| P11b | FR-002, FR-003 | BLOCKED | BLOCKED (`APPROVAL_NOT_CURRENT`, `LEDGER_DATE_REGRESSION`) | Retained |
| P12 | FR-010 | BLOCKED | BLOCKED (`IMAGE_AUDIT_CHECKS_INCOMPLETE`) | Retained |
| P13 | FR-012 | BLOCKED | BLOCKED (`ASSET_DUPLICATE_BYTES`, `ASSET_DUPLICATE_PATH`, `SPECIES_PLATE_VIEWS`) | Retained |
| P13b | FR-012 | BLOCKED | BLOCKED (`ASSET_DUPLICATE_BYTES`, `ASSET_DUPLICATE_PATH`) | Retained |
| P14 | FR-012 | BLOCKED | BLOCKED (`SPECIES_PLATE_TAXON_MISMATCH`, `SPECIES_PLATE_VIEWS`, `SPECIES_SCIENTIFIC_NAME_CONFLICT`) | Retained |
| P15 | FR-012 | BLOCKED | BLOCKED (`SPECIES_PLATE_NO_WHOLE_OR_KEY`, `SPECIES_PLATE_VIEWS`) | Retained |
| P16 | FR-009, FR-010 | BLOCKED | BLOCKED (`APPROVAL_STALE`, `IMAGE_AUDIT_STALE`, `LICENSE_UNKNOWN`, `SAFETY_AUDIT_NOT_PASSING_OR_STALE`) | Retained (+`LICENSE_UNKNOWN`) |
| P17 | FR-010 | BLOCKED | BLOCKED (`APPROVAL_STALE`, `IMAGE_AUDIT_CHECKS_INCOMPLETE`, `SAFETY_AUDIT_NOT_PASSING_OR_STALE`) | Retained |
| P18 | FR-001 | BLOCKED | BLOCKED (`ENTRY_TYPE_NOT_ALLOWED_IN_ZONE`, `IDENTIFICATION_CONTENT_REQUIRES_PROFILE_TYPE`, `SAFETY_TOPIC_UNCOVERED`) | Retained |
| P18b | FR-001 | BLOCKED | BLOCKED (`ENTRY_TYPE_NOT_ALLOWED_IN_ZONE`, `SAFETY_TOPIC_UNCOVERED`) | Retained |
| **P19a** | **FR-008** | **ELIGIBLE** | **BLOCKED** (`ENTRY_CLAIMS_INSUFFICIENT`, `ENTRY_CLAIM_TYPE_MISSING`, `FIELD_CLAIM_MISSING`) | **Newly closed (#1)** |
| **P19b** | **FR-008** | **ELIGIBLE** | **BLOCKED** (`ENTRY_CLAIMS_INSUFFICIENT`, `ENTRY_CLAIM_TYPE_MISSING`, `FIELD_CLAIM_MISSING`) | **Newly closed (#2)** |
| P20 | FR-011 | BLOCKED | BLOCKED (`ENTRY_FIELD_NOT_FOR_TYPE`, `dist_written: false`) | Retained |
| P21 | FR-009 | BLOCKED | BLOCKED (`APPROVAL_STALE`, `SAFETY_AUDIT_NOT_PASSING_OR_STALE`) | Retained |
| P22a | FR-009 | BLOCKED | BLOCKED (`APPROVAL_STALE`, `REJECTED_SOURCE_BACKS_CLAIM`, `SAFETY_AUDIT_NOT_PASSING_OR_STALE`) | Retained |
| P22b | FR-009 | BLOCKED | BLOCKED (`APPROVAL_STALE`, `BACKGROUND_SOURCE_BACKS_CLAIM`, `SAFETY_AUDIT_NOT_PASSING_OR_STALE`) | Retained |
| **P23** | **FR-019** | **INFO** | **BLOCKED** (`UNIT_INCONSISTENT`; all 7 loose pairs & `1 tsp / 5 ml` rejected) | **Newly closed (#3)** |
| P24 | FR-003 | BLOCKED | BLOCKED (`APPROVAL_STALE`, `DATE_INVALID`, `SAFETY_AUDIT_NOT_PASSING_OR_STALE`) | Retained |
| **P25** | **FR-017** | **INFO** | **BLOCKED** (`APPROVAL_NOT_CURRENT`; pointer → `withdrawn`, archive intact, 0 stray PDFs) | **Newly closed (#4)** |
| P26 | FR-018 (open) | ELIGIBLE | ELIGIBLE (`release_ok: true`, `duplicate_destination_lines: 3`) | Unchanged (open) |
| **P27** | **FR-021** | **ELIGIBLE** | **BLOCKED** (`FIELD_NOT_USABLE`: `step 1 abort_if`, `step 1 verify`, `dangers[0]`) | **Newly closed (#5)** |
| **P28** | **FR-019** | **ELIGIBLE** | **BLOCKED** (`UNIT_INCONSISTENT` on inline `'4 in (100 mm)'`) | **Newly closed (#6)** |
| P29 | FR-016 (open) | ELIGIBLE | ELIGIBLE | Unchanged (open) |
| P32 | FR-012 | BLOCKED | BLOCKED (`SPECIES_TAXON_DUPLICATE`) | Retained |
| P34 | FR-012 | BLOCKED | BLOCKED (`ILLUSTRATION_LABEL_MISSING`) | Retained |
| P36 | FR-001 | BLOCKED | BLOCKED (`SAFETY_TOPIC_UNCOVERED`) | Retained |
| P46 | FR-001 | BLOCKED | BLOCKED (`APPROVAL_STALE`, `COVERAGE_ENTRY_TYPE_MISMATCH`, `SAFETY_TOPIC_UNCOVERED`) | Retained |
| P47 | FR-001 | BLOCKED | BLOCKED (`APPROVAL_STALE`, `SAFETY_TOPIC_UNCOVERED`) | Retained |
| P49 | FR-009 | BLOCKED | BLOCKED (`APPROVAL_STALE`, `ROW_SCHEMA`, `SAFETY_AUDIT_NOT_PASSING_OR_STALE`, `SOURCE_EDITION_UNKNOWN`) | Retained |
| P52 | FR-002 | BLOCKED | BLOCKED (`SAFETY_AUDIT_SUPERSEDED`, `SAFETY_FAILURE_UNRESOLVED`) | Retained |
| P53 | FR-004 | BLOCKED | BLOCKED (`LEDGER_ROW_ORPHAN`) | Retained |
| P60 | FR-007 | BLOCKED | BLOCKED (`APPROVAL_STALE`, `SAFETY_AUDIT_NOT_PASSING_OR_STALE`) | Retained |
| P70 | FR-020 (open) | ELIGIBLE | ELIGIBLE at validate (`release_ok: false`: `LAYOUT_OVERFLOW`, `PDF_OUTSIDE_MARGIN`, `RENDER_FIELD_MISSING`) | Unchanged (open) |
| P71 | FR-020 (open) | ELIGIBLE | ELIGIBLE (`release_ok: true`, 40/40 steps present) | Unchanged (control) |
| **P72** | **FR-014** | **ELIGIBLE** | **BLOCKED** (`exif_artist_in_pdf_bytes: false`, `extracted_images_clean: true`, `original_untouched: true`, leak check: `IMAGE_METADATA_IN_PDF`) | **Newly closed (#7)** |
| P73 | (property kept) | INFO | INFO (`both_ok: true`, `byte_identical: true`) | Unchanged (property) |
| P80 | (measured) | ELIGIBLE | ELIGIBLE (`1000` entries validated in `4.5 s`) | Unchanged (benchmark) |
| P81 | (measured) | ELIGIBLE | ELIGIBLE (`release_ok: true`, `40.6 s`, `120` pages, `4080` promised / `0` missing; fixed on `12e0684`) | Unchanged (benchmark) |
| **P90** | **FR-015** | **INFO** | **BLOCKED** (`LICENSE_AMBIGUOUS`, `LICENSE_DERIVATIVES_FORBIDDEN`, `LICENSE_INCOMPATIBLE`, `LICENSE_UNKNOWN`; 5/5 rejected) | **Newly closed (#8)** |
| P91 | FR-013 (open) | INFO | INFO (`camera_photo: ACCEPTED`, `scan: ACCEPTED`) | Unchanged (open) |
| P92 | FR-012 | BLOCKED | BLOCKED (`DIAGNOSTIC_SPECIMEN_MISSING`, `DIAGNOSTIC_TAXON_MISSING`) | Retained |
| P93 | FR-006 | BLOCKED | BLOCKED (`TECHNICAL_REVIEWER_NOT_REGISTERED`) | Retained |
| P94 | FR-018 (open) | INFO | INFO (`destinations` show shared `sfe:src:SRC-0001` on page 1) | Unchanged (open) |

**Totals (unique probe IDs):** `42 + 11 + 6 = 59` (RUN-003) → **`50 + 6 + 3 = 59`** (RUN-004).

### 3.3 Scenario Variants Counted Separately

| Base Probe | Scenario Variant | RUN-003 (`3ef62a7`) | RUN-004 (`ca81727`) |
|---|---|---|---|
| P08c | Git checkout, tail fail row deleted & re-sealed | BLOCKED (`LEDGER_HISTORY_REWRITTEN`) | BLOCKED (`LEDGER_HISTORY_REWRITTEN`) |
| P08c | Bare export (no `.git`), with external pin | *(not implemented)* | BLOCKED (`LEDGER_PIN_TRUNCATED`) |
| P08c | Bare export (no `.git`), without pin — `release` | ELIGIBLE *(residual)* | BLOCKED (`LEDGER_PIN_REQUIRED`) |
| P08c | Bare export (no `.git`), without pin — `validate` | ELIGIBLE *(residual)* | WARNING (`LEDGER_CONTINUITY_UNANCHORED`; error under `--strict`) |
| P18 | Z05 `general` with screening review / without any review | BLOCKED / BLOCKED | BLOCKED / BLOCKED |
| P18b | Z10 `technical_procedure` with screening review / without any review | BLOCKED / BLOCKED | BLOCKED / BLOCKED |
| P72 | EXIF/GPS JPEG release build / injected-EXIF PDF leak check | ELIGIBLE (leaked) / N/A | Stripped cleanly (`exif_artist_in_pdf_bytes: false`) / BLOCKED (`IMAGE_METADATA_IN_PDF`) |
| P93 | Unregistered well-formed id (`REV-0099`) / literal `'x'` | BLOCKED / BLOCKED | BLOCKED (`TECHNICAL_REVIEWER_NOT_REGISTERED`) / BLOCKED (`ENTRY_SCHEMA`) |

### 3.4 Classification of the 9 Non-Blocked Probe IDs

| Probe | Verdict | Classification | Finding / Scope | Evidence |
|---|---|---|---|---|
| **P29** | `ELIGIBLE` | **Remaining bypass** | FR-016 (out of RUN-004 scope) | `as_of_date=1990-01-01`, `region=['anywhere']` passes; freshness/expiry and controlled region codes are planned for a later sprint. |
| **P26** | `ELIGIBLE` | **Remaining bypass** | FR-018 (out of RUN-004 scope) | Multi-entry zone PDF builds (`release_ok: true`) with `duplicate_destination_lines: 3` in LaTeX log; `_GENERIC_WARNING` does not catch `pdfTeX warning (ext4):`. |
| **P91** | `INFO` | **Remaining bypass** | FR-013 (out of RUN-004 scope) | `generation_method` (`camera_photo`, `scan`) is self-declared; no automated authenticity inference is claimed or implemented. |
| **P70** | `ELIGIBLE` (validate) / refused (release) | **Partial result** | FR-020 (out of RUN-004 scope) | Release fails closed (`LAYOUT_OVERFLOW`, `PDF_OUTSIDE_MARGIN`, `RENDER_FIELD_MISSING`) so clipped text cannot ship, but 60-line safety panel minipage still cannot break across pages. |
| **P94** | `INFO` | **Informational result** (paired with P26) | FR-018 (out of RUN-004 scope) | Diagnostic readout confirming shared `sfe:src:SRC-0001` lands on page 1 in a 2-entry PDF; illustrates the effect of P26. |
| **P71** | `ELIGIBLE` | **Informational result** (passing control, NOT a vulnerability) | FR-020 (control) | `release_ok: true`, `1.4 s`, `40/40` procedure steps rendered across pages; confirms breakable procedure boxes work. |
| **P73** | `INFO` | **Informational result** (property kept, NOT a vulnerability) | Determinism property | `both_ok: true`, `byte_identical: true` across two independent builds of the same published tree. |
| **P80** | `ELIGIBLE` | **Informational result** (scale benchmark, NOT a vulnerability) | Performance measurement | `1000` published entries + claims + approvals + screening reviews validated in `4.5 s` (fixture build `4.2 s`). |
| **P81** | `ELIGIBLE` | **Informational result** (scale benchmark, NOT a vulnerability) | Performance measurement | `120`-entry zone PDF built in `40.6 s`, `120` pages, `4080` promised strings, `0` missing (`release_ok: true`). |

## 4. Resolution of Specific Evidence Gaps

### 4.1 Exact Commit / Tree Attribution of All Evidence

| Check / Artifact | Exact Commit / Tree Tested | Passing Control | Result |
|---|---|---|---|
| Baseline `make check` before RUN-004 code | `3ef62a7` | Clean RUN-003 checkout | `1353 passed`, proof OK, `REPRODUCIBLE` |
| Baseline `make check` at Claude handoff (P1–P3) | `3ae6277` | Clean checkout + untracked `release.py` | `2050 passed`, proof `d2608a84…`, `REPRODUCIBLE` |
| Sabotage S81–S92 (FR-008, 12 cases) | `2981870` | Unmodified scratch copy passed `test_claim_completeness.py` | 12/12 detected |
| Sabotage S93–S109 (FR-021, 17 cases) | `1987142` | Unmodified scratch copy passed `test_usable_text.py` | 17/17 detected |
| Sabotage S110–S137 (FR-019, 28 cases) | `3ae6277` | Unmodified scratch copy passed `test_unit_equivalence.py`, `test_units.py` | 28/28 detected |
| Sabotage S138–S151 (FR-017, 14 cases) | `8f6a297` | Unmodified scratch copy passed `test_release_state.py` (17 passed) | 14/14 detected |
| Sabotage S152–S167 (FR-014/015, 16 cases) | `c43edf4` | Unmodified scratch copy passed `test_image_publication.py` (9) / `test_licences.py` (39) | 16/16 detected |
| Sabotage S168–S177 (FR-003 pin, 10 cases) | `b394b63` | Unmodified scratch copy passed `test_ledger_pin.py` (20 passed) | 10/10 detected |
| Full `make check` + clean `git archive` export + release determinism + 59-probe run | `b394b63` | Working checkout & clean export (no `.git`) | Checkout: `2138 passed`; export: `2136 passed, 2 skipped`; determinism: `ED-0a9c3fb16ada9db0` byte-identical PDF (`8d51ab42…`) & `EDITION.json`; 58/59 probes clean, **P81 raised `FileNotFoundError`** on legacy `out/zones/*.build.json` path |
| P81 scale probe after manifest-path fix | `12e0684` (uncommitted `fable_probes.py` line 946, committed identically in `12e0684`) | Clean 120-entry fixture | `P81 ELIGIBLE`, `release_ok: true`, `40.6 s`, `120` pages, `4080` promised / `0` missing |
| Full `make check` on submitted RUN-004 tip | `12e0684` | Clean checkout (`git status` clean except `.serena/`) | `2138 passed`, proof `e8ee7b16…`, `REPRODUCIBLE` |
| Affected tests (`test_release_state`, `test_ledger_pin`, `test_fable_probes`), P08c & P72 probes, and sabotage S178 | `ca81727` | Unmodified scratch copy passed `test_release_state.py` (19 passed) | `96 passed`; `P08c` BLOCKED; `P72` BLOCKED (`errors: IMAGE_METADATA_IN_PDF` only); `S178 DETECTED` |
| Full `make check` on reconciliation code/test commit | `ca81727` | Clean checkout | **`2140 passed` in 104.32 s**, `validate` 0/0, `validate --specimen` 0/0, proof `e8ee7b16…`, `REPRODUCIBLE` |

**Note on evidence before the P81 fix (`b394b63` → `12e0684`):** `12e0684` changed zero production scripts and zero unit tests — it updated only documentation files plus one line in `tests/fable_probes.py` (line 946: `built.pdfs[0].with_suffix(".build.json")`). Therefore the clean-export check, determinism check, and sabotage runs S81–S177 on `b394b63` remained valid for `12e0684`. In `ca81727`, only `scripts/sfe/release.py` (+5 lines in `promote()`) and test/probe files changed; affected tests, P08c/P72 probes, targeted sabotage `S178`, and the full `make check` (`2140 passed`) were all executed on `ca81727`.

### 4.2 FR-003 External Ledger Continuity Pin Audit

- **Custody:** Pins must be stored **outside** the repository. Both `write_pin_file()` (`ledger pin --write`) and `resolve_pin()` (`--pin` / `SFE_LEDGER_PIN`) resolve candidate paths and refuse any path inside `repo.root` (`LEDGER_PIN_INSIDE_REPO`). **A pin bundled inside an exported archive or repository checkout is NOT an independent trust anchor** — whoever controls that archive can rewrite both the ledgers and the bundled pin.
- **Project and ledger binding:** `sfe-pin-v1` binds all four registered ledger names (`approvals`, `image_audit`, `reviewers`, `safety_audit`), each ledger's exact row count, each ledger's chain head (`SHA-256` over sequence + all cells + predecessor), and a 16-hex integrity digest over the payload. **Explicit limitation:** the format carries no separate repository/project identifier field; for populated repositories, uniqueness rests on the `reviewers` bootstrap chain head (row 1), while empty repositories all share `0:0000…0000`.
- **Update authority & non-self-generation:** Only the operator explicitly invoking `python -m sfe ledger pin` calls `create_pin()` / `write_pin_file()`. Verified by `grep -rn "create_pin\|write_pin_file" scripts/` (only `cli.py` `ledger pin` subcommand and `ledger.py`) AND pinned by `test_validate_release_and_verify_never_self_generate_a_replacement_pin` (`ca81727`), which monkeypatches both functions to fail immediately and verifies `validate_repo`, `build_release`, `verify_active`, and `reconcile` never invoke them.
- **Failure modes verified (`tests/test_ledger_pin.py`, 21 tests):**
  - *Missing pin:* empty ledgers need no anchor; non-empty ledgers fail closed on `release` and `release verify` (`LEDGER_PIN_REQUIRED`) and emit `LEDGER_CONTINUITY_UNANCHORED` warning on `validate` (exit 1 under `--strict`).
  - *Malformed / wrong ledger set / corrupted digest / empty string / missing file:* `LEDGER_PIN_INVALID`.
  - *In-repo pin file:* `LEDGER_PIN_INSIDE_REPO`.
  - *Tail truncation (even 1 row or all rows to empty, even re-sealed):* `LEDGER_PIN_TRUNCATED`.
  - *Prefix rewrite (same row count, re-sealed):* `LEDGER_PIN_REWRITTEN`.
  - *Broken or unsealed ledger during `ledger pin`:* raises `LedgerError`, refuses to issue a pin.
- **Unsigned checkpoint limits:** `sfe-pin-v1` is not cryptographically signed. It protects every row up to the pinned row count only; rows appended after the pin can be truncated undetected until the owner takes a fresh pin. D23 (custody and renewal cadence) remains **PENDING OWNER DECISION (NOT APPROVED)**.

### 4.3 FR-019 RT-103 Minimum/Maximum Rounding Direction Determination

- **Contract determination:** **Explicitly deferred** in the `e0ab463` contract (`FINDING_REMEDIATION_MATRIX.md` §10, FR-019 Stated limits, line 243): *"A minimum or maximum limit's rounding direction is not modelled."* It was therefore NOT a RUN-004 omission.
- **Safety-critical coverage verified:** `entries.py` `claim_ids_of()` collects `dimension_unit_table[].claim_id`; `classification_policy.yaml` maps `high`/`critical` risk claims and `medical`/`safety_boundary` claim types to `CLS-HIGH-RISK` / `CLS-MEDICAL`, which makes `_is_hazardous()` true and enforces the 0.5 % `safety` bound on every pair in that entry (in addition to the code floor requiring `safety` for all `pressure` and `temperature` quantities).
- **Retained residual & content restriction:** Until RT-103 directional rounding is modelled, authors and domain experts must manually verify that minimum thresholds (e.g. boiling/pressure-canning temperatures, minimum clearances) never round downward and maximum limits never round upward when converting between US customary and metric units. No medical dosage tolerances were invented (`mg`, `mcg`, `IU`, `tsp`, `tbsp`, `cup` remain refused as unknown). D19 remains **PENDING OWNER DECISION (NOT APPROVED)**.

### 4.4 FR-017 Crash/Withdrawal Non-Reactivation Proof

- `recover(dist)` never writes `ACTIVE_RELEASE.json` (`_write_pointer` is never called in `recover()`); if a withdrawal crashed after replacing `ACTIVE_RELEASE.json` (`after_withdraw_pointer`) and before appending to `RELEASE_LOG.csv`, `recover()` appends the missed `withdraw`/`auto_withdraw` log row and leaves the pointer `withdrawn`.
- `reconcile(repo, dist)` calls `recover()`, `quarantine_legacy()`, and `verify_active()`; when `pointer.state == "withdrawn"`, `reconcile()` performs no pointer write.
- **Demonstrated gap closed in `ca81727`:** Previously, `promote()` did not refuse re-promoting an `edition_id` that had been manually withdrawn if `build_release` were re-run on the exact same unchanged tree. `promote()` now checks both `previous` and `RELEASE_LOG.csv` and refuses with `ReleaseStateError(... EDITION_WITHDRAWN)` whenever `edition_id` was previously withdrawn (`withdraw` or `auto_withdraw`). A genuinely new edition (different `edition_id` from a new revision/approval) still promotes cleanly.
- Verified by `test_interrupted_withdrawal_and_partial_log_row_recover`, `test_recovery_reconcile_and_repromote_cannot_reactivate_a_withdrawn_edition`, and sabotage `S178` (detected).
- Printed edition IDs on PDF pages (RT-107) and an errata/recall ledger were explicitly listed as stated limits in `e0ab463` §10 and remain **Partial / deferred**.

### 4.5 FR-014 Tested Controls vs Future Custody / Storage Controls

- **Implemented and tested now (`derive.py`, `assets.py`, `pdfbuild.py`, `test_image_publication.py`):**
  1. Deterministic re-encoding (`strip-metadata-reencode-v1`) stripping EXIF, GPS, XMP, IPTC/Photoshop, JPEG COM, and PNG `eXIf`/`tEXt`/`zTXt`/`iTXt`/`tIME` chunks while baking EXIF orientation into pixels and preserving ICC colour profiles.
  2. Originals opened read-only, never modified, never copied into LaTeX work dirs or release archives (`ORIGINAL_PUBLISHED`), and rejected if outside approved directories or corrupt (`IMAGE_DERIVE_FAILED`).
  3. Post-build verification scanning raw PDF bytes and every `pdfimages -all` extracted image (`IMAGE_METADATA_IN_PDF`).
  4. Local POSIX permission guard rejecting world-writable approved originals (`mode & 0o002` → `ASSET_PERMISSIONS_TOO_OPEN`) plus quarantine directory hygiene (`ORPHAN_ASSET_FILE`, `QUARANTINE_UNCATALOGUED_FILE`, `ASSET_DIRECTORY_UNEXPECTED`).
- **Not built here (future FR-026 / D21 scope):**
  - Moving originals outside the Git repository to dedicated archival storage, OS/cloud ACLs and multi-user role-based read controls, derivative resolution/file-size budgets per print/phone profile, and photograph authenticity verification (FR-013).

## 5. Pending Owner Decisions (D17–D23 — NOT APPROVED)

Exact decision text from `BUILD_PLAN.md` §9 and `FINDING_REMEDIATION_MATRIX.md` §14. **None of these is approved here:**

| # | Decision (verbatim summary from `BUILD_PLAN.md` §9) | Consequence while undecided |
|---|---|---|
| **D17** | Claim policy (`schemas/claim_policy.yaml`): minimum claims, required claim types per entry type, and which safety-bearing fields require which claim types in `field_claims` (FR-008). | Engineering initial defaults remain in force (hard floor of 1 claim in code); S02 ingestion remains blocked until confirmed. |
| **D18** | Usable-text rule and the sole `Not applicable [CLM-id]: <justification>` exception for step `verify` / `abort_if` (FR-021). | Only step `verify`/`abort_if` may declare non-applicability with a step-cited claim and ≥ 5 words / ≥ 3 content words. |
| **D19** | Unit equivalence policy (`schemas/unit_policy.yaml`: precise 1 %, approximate 5 %, safety 0.5 %) and what counts as safety-critical (FR-019). No medical dosage tolerances are defined. | Engineering initial bounds remain in force; dose/household units remain refused; directional rounding (RT-103) requires manual review. |
| **D20** | Release custody: who may withdraw an active release, edition retention policy, and where `RELEASE_LOG.csv` is backed up (it lives under git-ignored `dist/`, FR-017). | `dist/` state is local and unsigned; no release is authorized until custody and backup procedures are set. |
| **D21** | Original photograph storage, read permissions, and the publication derivative recipe (`strip-metadata-reencode-v1`, FR-014 / FR-026). | Originals remain local under `assets/original_photos/` (currently empty); large photo library storage/ACL design blocks S06. |
| **D22** | Controlled licence vocabulary (`schemas/licenses.yaml`) and distribution model: currently requires `commercial` use (refusing CC BY-NC licences, FR-015). | All `CC BY-NC-*` licences are refused by default until the owner declares commercial vs non-commercial distribution. |
| **D23** | External ledger pin custody and cadence (`python -m sfe ledger pin`, kept outside the repo, FR-003). | Once real ledgers gain rows, `release` and `release verify` will fail closed (`LEDGER_PIN_REQUIRED`) until an external pin process is established. |

Prior Gate A decisions **D1–D9** and **D13–D16** also remain open.

## 6. Reconciliation Changes and Final Verification

Bounded corrections committed in `ca8172778499cc7e748b383ceb83665f2a8464cc` (without amending any submitted history):
- `scripts/sfe/release.py`: added `EDITION_WITHDRAWN` guard in `promote()` preventing reactivation of any previously withdrawn `edition_id`.
- `tests/test_release_state.py`: added `test_recovery_reconcile_and_repromote_cannot_reactivate_a_withdrawn_edition`.
- `tests/sabotage.py`: added `S178` targeting the `EDITION_WITHDRAWN` guard (`S178 DETECTED`, 178 total sabotages).
- `tests/test_ledger_pin.py`: added `test_validate_release_and_verify_never_self_generate_a_replacement_pin`.
- `tests/fable_probes.py`: updated `P72` leak-check input to a valid PDF with injected EXIF bytes so `P72` reports `IMAGE_METADATA_IN_PDF` cleanly without `IMAGE_METADATA_CHECK_UNAVAILABLE`.
- `RUN-004.md`: fixed the probe summary wording typo (`50 BLOCKED, 6 ELIGIBLE, 3 INFO`; clarified `P08c` was already counted among RUN-003's 42 BLOCKED probes in Git).

Verification on `ca8172778499cc7e748b383ceb83665f2a8464cc`:
- `make check`: exit 0 (`2140 passed` in 104.32 s, 0 failed, 0 skipped; `validate` 0/0; `validate --specimen` 0/0; proof `e8ee7b1641baa8e9148de5a531dc36315a65446b0acaccc54c6d1c69100c330a`; `repro: REPRODUCIBLE`).
- `tests/fable_probes.py` on `P08c` and `P72`: both `BLOCKED` with clean controls and expected codes.
- `tests/sabotage.py` `S178`: `DETECTED` (1 failed, control 19 passed).
- Final commit adds this document only (no code or test edits).
