# Survival Field Encyclopedia

An original, source-traceable, region-aware, offline-first field encyclopedia (Minnesota / Upper Midwest first), produced as
16 zone PDFs plus one combined indexed master. **This repository is at Gate A: production scaffolding only.**

| | |
|---|---|
| Content written | **None.** No zone has an entry; no zone is complete. |
| Research, photos, approvals recorded | **None.** All registers are header-only, including the reviewer registry. |
| What exists | Zone structure, schemas, validation and approval gates, a reviewer registry and append-only ledgers, derived review requirements, package-bound reviews, identification-evidence records, image-provenance checks, a reproducible PDF pipeline that verifies every printed field, one labelled dummy specimen PDF, tests |
| Where the facts come from | `handoff/` (supplied by the owner, preserved byte-for-byte) |
| Status of Gate A | **Not approved.** An independent review found two high-severity safety-validation defects (RUN-002), and a second, adversarial review (`FABLE-REVIEW-001`, 29 findings) found trust-model, safety-field, unit, release-state, image-handling and ledger-continuity defects. Branch `gate-a/remediation-2` rebuilt the trust model (`RUN-003.md`), and branch `gate-a/remediation-3` (`RUN-004.md`) closes claim completeness (field-level), placeholder safety text, measurement accuracy, immutable release state, EXIF/GPS-stripped derivatives, controlled licences/rights evidence, and external ledger continuity pinning (`FINDING_REMEDIATION_MATRIX.md`); 50 of the 59 probes are now closed and 9 remain open or measured. Nothing here claims Gate A has passed or that any content may be published. |

ChatGPT owns research, claims, wording and approval. The build tooling owns structure, validation, asset cataloguing and PDF
production. It never writes, edits or invents survival content (`GOVERNANCE.md`).

## Run it

```bash
make check      # integrity + all gates + tests + specimen proof + reproducibility proof
make test       # 2138 tests (about 1.7 minutes)
make proof      # rebuild proofs/SPECIMEN_LAYOUT_PROOF.pdf
make release    # must REFUSE at Gate A: nothing is published
```

Prerequisites: Python 3.13 with `requirements.txt`; `pdflatex` (TeX Live 2023: latex-base, -recommended, -extra,
fonts-recommended, pictures, tex-gyre); poppler-utils; make. Details and decisions: `BUILD_PLAN.md`.

## Layout

```
handoff/                 supplied documents (never edited; hashes in PRESERVED_FILES.sha256)
content/                 zones.yaml + Z01_fundamentals/ ... Z16_field_atlas/ (README only, no entries)
templates/               entry, species profile, technical procedure, medical guidance (field names only)
schemas/                 JSON Schemas for entries, registers and ledgers; hazard_topics.yaml, classification_policy.yaml, claim_policy.yaml, unit_policy.yaml, licenses.yaml
research/                sources.csv, claims.csv, taxa.csv, coverage-matrix.csv (header-only), unresolved-research.md
assets/                  manifest.csv, specimens.csv (header-only), original_photos/, diagrams/, rejected_unverified/, rights/
reviews/                 reviewers.csv (the registry), approvals.csv, image-audit.csv, safety-audit.csv (header-only, hash-chained); packets/ and evidence/ (empty)
layouts/                 sfe.sty (the card layout), build.yaml, specimen/ (labelled dummy inputs)
scripts/sfe/             validation, gates, evidence, textcheck, units, derive, release state, ledger pinning, PDF pipeline, CLI
tests/                   2138 tests on throwaway fixture repositories; fable_probes.py (the 59 ported review probes); sabotage.py (177 sensitivity experiments)
proofs/                  SPECIMEN_LAYOUT_PROOF.pdf, its build manifest, colour and grayscale previews
dist/                    immutable release editions and state (empty at Gate A; fail-closed)
```

## Documents

`PROJECT_AUDIT.md` (what was found, reconciliation, no-overwrite plan) · `BUILD_PLAN.md` (toolchain, commands, decisions for review)
· `RUN-001.md` (Gate A run record) · `RUN-002.md` (remediation of GA-001/GA-002) · `RUN-003.md` (trust-model remediation) · `RUN-004.md` (safety and release-integrity remediation)
· `FINDING_REMEDIATION_MATRIX.md` (each finding: cause, change, criteria, tests, outcome) · `GOVERNANCE.md` (rules and gates) · `RUN-LOG.md` · `CHANGELOG.md`
· `BASELINE_AUDIT_20261116.md` (earlier audit, preserved unchanged). The independent review itself lives outside this repository, in `/home/jd/Survival_Guide_Fable_Review/`.
