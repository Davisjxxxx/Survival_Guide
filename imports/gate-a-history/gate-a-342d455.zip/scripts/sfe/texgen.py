"""Entry -> LaTeX. Layout lives in layouts/sfe.sty; this module only fills it.

Safety properties:
  * every value passes through tex_escape(), so entry text can never inject TeX commands;
  * unsupported entry types raise RenderError (fail closed): a layout that silently drops a
    mandatory field (for example a species profile's positive-identification warning) is worse
    than no page at all;
  * a release build never renders a placeholder where an approved image should be.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from .assets import APPROVED_DIR, REQUIRED_LABEL
from .common import nonempty, walk_strings

SUPPORTED_TYPES = ("general", "technical_procedure")
# Renderer totality (FABLE-REVIEW-001 FR-011, probe P20). Every front-matter key of an entry is either PRINTED by this layout or METADATA that is
# never printed. A non-empty key that is neither is approved text the page would silently drop, so the renderer refuses the entry instead.
# After the build, qa.missing_text checks every string printed_strings() promises against the PDF's own text layer.
PRINTED_KEYS = frozenset({
    "id", "zone", "title", "status", "revision", "region", "season", "what_it_is", "find_where", "find_when", "diagnostic_features",
    "lookalikes_or_confusions", "materials", "procedure", "conditions_and_limits", "dangers", "source_ids", "claim_ids", "photo_ids",
    "illustration_ids", "as_of_date", "materials_tools", "dimension_unit_table", "environmental_constraints", "inspection_acceptance_criteria",
    "failure_modes", "hazard_boundaries",
})
METADATA_KEYS = frozenset({"entry_type", "hazard_tags", "authored_by", "technical_reviewer", "editorial_reviewer", "approved_by_chatgpt", "specimen",
                           "field_claims"})
# Sub-fields of a printed key that are links to evidence, not text on the page. The claim ids of the steps and of the entry are printed together
# in the "Claim ids" line; the claim id of a unit-table row is not printed anywhere.
UNPRINTED_SUBFIELDS = {"procedure": frozenset({"claim_ids"}), "dimension_unit_table": frozenset({"claim_id"})}
# Approved material that is deliberately NOT printed in a release, named so the omission is visible rather than silent (recorded in every manifest).
KNOWN_UNRENDERED = (
    "asset alt_text is printed in proofs only; it needs the tagged-PDF decision D1 (FABLE-REVIEW-001 FR-023)",
    "dimension_unit_table[].claim_id is a provenance link that the layout does not print; the 'Claim ids' line lists the step, entry and field-bound claims only",
    "field_claims maps each safety-bearing field to the claims that back it; the 'Claim ids' line prints the ids, not the mapping (FABLE-REVIEW-001 FR-008)",
    "entry body text has no section in the layout; a published entry with a body is refused (PUBLISHED_BODY_NOT_RENDERED)",
)
# Only these image types are rendered. EPS and other types need an external conversion step, which needs shell escape,
# and shell escape stays off by design. This also makes the documented-benign epstopdf note (pdfbuild.py) demonstrably safe:
# no EPS graphic can ever be part of a build.
RENDERABLE_IMAGE_TYPES = (".png", ".jpg", ".jpeg", ".pdf")
# \item followed by text starting with "[" would read it as an optional label; \relax prevents that.
ITEM = r"\item\relax "
_ESCAPES = {
    "\\": r"\textbackslash{}", "{": r"\{", "}": r"\}", "$": r"\$", "&": r"\&", "#": r"\#",
    "^": r"\textasciicircum{}", "_": r"\_", "~": r"\textasciitilde{}", "%": r"\%", "`": r"\textasciigrave{}",
}


class RenderError(ValueError):
    """Raised when an entry cannot be rendered safely."""


def tex_escape(text: str) -> str:
    """Escape arbitrary text for LaTeX. Control characters are rejected, never passed through."""
    collapsed = re.sub(r"[ \t\r\n]+", " ", text.strip())
    if any(ord(ch) < 32 for ch in collapsed):
        raise RenderError("control character in text")
    return "".join(_ESCAPES.get(ch, ch) for ch in collapsed)


def plain(text: str) -> str:
    """ASCII-safe text for PDF metadata and bookmark titles (no TeX tokens survive)."""
    return re.sub(r"\s+", " ", re.sub(r"[^A-Za-z0-9 .,:;()/\-\[\]]", "", text)).strip()


def cmd(name: str, *args: str, opt: str | None = None) -> str:
    head = "\\" + name + (f"[{opt}]" if opt is not None else "")
    return head + "".join("{" + arg + "}" for arg in args)


def env(name: str, body: str, *args: str) -> str:
    return "\\begin{" + name + "}" + "".join("{" + a + "}" for a in args) + body + "\\end{" + name + "}"


def _bullets(values: list[str]) -> str:
    kept = [v for v in values if v.strip()]
    if not kept:
        return r"\textendash{}"
    return env("itemize", "".join(ITEM + tex_escape(v) for v in kept))


def _label_list(pairs: list[tuple[str, str]]) -> str:
    kept = [(label, text) for label, text in pairs if text.strip()]
    if not kept:
        return r"\textendash{}"
    return env("sfeitems", "".join(r"\item[\textbf{" + tex_escape(label) + "}] " + tex_escape(text) for label, text in kept))


def _table_body(header: list[str], rows: list[str]) -> str:
    """booktabs table body. `header` cells and `rows` (each a full row of already-escaped cells joined by &) are
    LaTeX-safe. \\relax separates data rows so a cell that starts with '[' or '*' is never read as an optional
    argument of the row terminator; it is deliberately absent before \\midrule and \\bottomrule, which must follow a
    row end directly."""
    head = " & ".join(r"\textbf{" + cell + "}" for cell in header)
    return (r"\toprule " + head + r"\tabularnewline\midrule\relax "
            + (r"\tabularnewline\relax ").join(rows) + r"\tabularnewline\bottomrule")


@dataclass
class Rendered:
    tex: str
    files: dict[str, Path] = field(default_factory=dict)  # build-dir relative name -> source file
    stats: dict[str, int] = field(default_factory=dict)


def _asset_line(asset: dict[str, Any], proof: bool) -> str:
    parts = [asset["asset_id"], asset["role"].replace("_", " ")]
    if asset.get("view"):
        parts.append(f"view {asset['view']}")
    parts.append(f"license {asset.get('license') or asset['license_status']}")
    credit = asset.get("credited_photographer") or asset.get("organization")
    if credit:
        parts.append(f"credit {credit}")
    if asset.get("provenance_url"):
        parts.append(urlparse(asset["provenance_url"]).hostname or "")
    text = tex_escape(" · ".join(p for p in parts if p))
    caption = tex_escape(asset.get("caption") or "")
    block = r"\textbf{" + text + "}"
    detail = [caption] if caption else []
    if proof and asset.get("alt_text"):
        detail.append(r"\textit{ALT: " + tex_escape(asset["alt_text"]) + "}")
    if detail:
        block += r"\par " + " · ".join(detail)
    return block


def _image_blocks(fm: dict[str, Any], assets: dict[str, dict[str, Any]], *, kind: str, proof: bool,
                  repo_root: Path, files: dict[str, Path]) -> str:
    ids = fm["photo_ids"] if kind == "photo" else fm["illustration_ids"]
    height = ("3.0cm" if len(ids) <= 1 else "2.2cm") if kind == "photo" else "2.4cm"
    blocks: list[str] = []
    for aid in ids:
        asset = assets.get(aid)
        if asset is None:
            raise RenderError(f"{aid} is not in the asset manifest")
        has_file = bool(asset.get("local_path")) and asset["license_status"] == "approved" and (repo_root / asset["local_path"]).is_file()
        label = tex_escape(asset.get("overlay_label") or ("ILLUSTRATION" if kind != "photo" else ""))
        if has_file:
            if not proof and not str(asset["local_path"]).startswith(APPROVED_DIR[asset["asset_kind"]]):
                raise RenderError(f"{aid}: image file {asset['local_path']!r} is outside approved directory {APPROVED_DIR[asset['asset_kind']]}")
            suffix = Path(asset["local_path"]).suffix.lower()
            if suffix not in RENDERABLE_IMAGE_TYPES:
                raise RenderError(f"{aid}: image type {suffix!r} cannot be rendered (accepted: {', '.join(RENDERABLE_IMAGE_TYPES)}); "
                                  "other types, including EPS, need a conversion step that needs shell escape, and shell escape stays off")
            name = f"img/{aid}{suffix}"
            files[name] = repo_root / asset["local_path"]
            blocks.append(cmd("sfeSlotImage", name, height) if kind == "photo" else cmd("sfeSlotIllusImage", name, height, label))
        elif proof:
            blocks.append(cmd("sfeSlotPhoto", height) if kind == "photo" else cmd("sfeSlotIllus", height, label))
        else:
            raise RenderError(f"{aid}: no approved image file; a release build never renders a placeholder")
        blocks.append(cmd("sfeAssetLine", _asset_line(asset, proof)))
    return "".join(blocks)


def _zone_label(fm: dict[str, Any], zone_title: str) -> str:
    return "ZXX · SPECIMEN (not a real zone)" if fm.get("specimen") else f"{fm['zone']} · {zone_title}"


def render_entry(fm: dict[str, Any], *, assets: dict[str, dict[str, Any]], sources: dict[str, dict[str, Any]],
                 zone_title: str, proof: bool, repo_root: Path, proof_note: str = "", body: str = "") -> Rendered:
    if fm["entry_type"] not in SUPPORTED_TYPES:
        raise RenderError(f"layout for entry_type {fm['entry_type']!r} is not implemented yet (planned for a later sprint); refusing to render it incompletely")
    unprinted = sorted(key for key, value in fm.items() if key not in PRINTED_KEYS | METADATA_KEYS and nonempty(value))
    if unprinted:
        raise RenderError(f"the layout prints no field {', '.join(unprinted)}: refusing to render an entry whose approved text the page would drop")
    if body.strip() and not proof:
        raise RenderError("the entry has body text but the layout has no body section yet: refusing to print a page without text that was approved")
    eid, steps = fm["id"], fm["procedure"]
    files: dict[str, Path] = {}
    zone_label = _zone_label(fm, zone_title)
    out: list[str] = [
        cmd("sfeAnchor", eid, "top", "Entry: " + plain(fm["title"]), opt="0"),
        cmd("sfeEntryHeader", tex_escape(eid), tex_escape(zone_label), tex_escape(fm["status"].upper()), str(fm["revision"]), tex_escape(fm["title"])),
    ]

    left = (
        cmd("sfeAnchor", eid, "what", "WHAT") + env("sfepanel", r"\textbf{WHAT}\quad " + tex_escape(fm["what_it_is"]))
        + cmd("sfeAnchor", eid, "where", "WHERE") + env("sfesec", tex_escape(fm["find_where"]), "find", "WHERE")
        + cmd("sfeAnchor", eid, "when", "WHEN") + env("sfesec", tex_escape(fm["find_when"]), "find", "WHEN")
    )
    out.append(cmd("sfecols", left, _image_blocks(fm, assets, kind="photo", proof=proof, repo_root=repo_root, files=files)))

    identify = (
        cmd("sfeAnchor", eid, "identify", "IDENTIFY")
        + env("sfesec", _bullets(fm["diagnostic_features"]) + r"\par\textbf{Look-alikes and confusions:}" + _bullets(fm["lookalikes_or_confusions"]), "identify", "IDENTIFY")
    )
    out.append(cmd("sfecols", identify, _image_blocks(fm, assets, kind="illustration", proof=proof, repo_root=repo_root, files=files)))

    tools = fm.get("materials_tools", [])
    materials = cmd("sfeAnchor", eid, "materials", "MATERIALS") + env(
        "sfesec", _bullets(fm["materials"]) + (r"\par\textbf{Tools:}" + _bullets(tools) if tools else ""), "none", "MATERIALS")
    rows = fm.get("dimension_unit_table", [])
    if rows:
        body = [" & ".join((tex_escape(r["quantity"]), tex_escape(r["us_customary"]), tex_escape(r["metric"]))) for r in rows]
        table = env("tabularx", _table_body(["Quantity", "US customary", "Metric"], body), r"\linewidth", "Yll")
        units = cmd("sfeAnchor", eid, "units", "DIMENSIONS") + env("sfesec", r"{\footnotesize " + table + "}", "none", "DIMENSIONS — US CUSTOMARY | METRIC")
    else:
        units = ""
    out.append(cmd("sfecols", materials, units))

    step_items = "".join(ITEM + tex_escape(s["action"]) for s in steps)
    out.append(cmd("sfeAnchor", eid, "steps", "STEPS") + env("sfesec", env("sfeenum", step_items) if steps else r"\textendash{}", "use", "STEPS"))

    check = _label_list([(f"Step {s['step']}", s["verify"]) for s in steps])
    criteria = fm.get("inspection_acceptance_criteria", [])
    if criteria:
        check += r"\par\textbf{Acceptance criteria:}" + _bullets(criteria)
    danger = (
        r"\textbf{\textcolor{sfeAccent}{\sfeicon[sfeAccent]{avoid}\ AVOID}} --- abort if:" + _label_list([(f"Step {s['step']}", s["abort_if"]) for s in steps])
        + r"\par\textbf{\textcolor{sfeAccent}{\sfeicon[sfeAccent]{caution}\ CAUTION}} --- danger boundaries:" + _bullets(fm["dangers"] + fm.get("hazard_boundaries", []))
    )
    modes = fm.get("failure_modes", [])
    if modes:
        danger += r"\par\textbf{Failure modes:}" + _bullets(modes)
    out.append(cmd("sfehalves", cmd("sfeAnchor", eid, "check", "CHECK") + env("sfesec", check, "check", "CHECK"),
                   cmd("sfeAnchor", eid, "danger", "FAILURE / DANGER") + env("sfewarn", danger, "caution", "FAILURE / DANGER")))

    stamp = f"as of {fm['as_of_date']}" if fm.get("as_of_date") else ""
    regional = (
        r"\textbf{Region:} " + tex_escape(", ".join(fm["region"]) or "—") + r"\quad\textbf{Season:} " + tex_escape(", ".join(fm["season"]) or "—")
        + (r"\quad\textbf{Legal/regional status:} " + tex_escape(stamp) if stamp else "")
        + r"\par" + _bullets(fm["conditions_and_limits"])
        + (r"\par\textbf{Environmental constraints:}" + _bullets(fm["environmental_constraints"]) if fm.get("environmental_constraints") else "")
    )
    regional_box = cmd("sfeAnchor", eid, "regional", "REGIONAL / LEGAL LIMITATIONS") + env("sfesec", regional, "none", "REGIONAL / LEGAL LIMITATIONS")

    cited = [sources[s] for s in fm["source_ids"] if s in sources]
    chips = r"\ ".join(cmd("sfeSrcLink", tex_escape(s["source_id"])) for s in cited) or r"\textendash{}"
    claim_ids = tex_escape(", ".join(sorted(printed_claim_ids(fm))) or "—")
    sources_body = r"\textbf{Sources:} " + chips + r"\quad\textbf{Claim ids:} {\ttfamily\footnotesize " + claim_ids + "}"
    sources_box = cmd("sfeAnchor", eid, "sources", "SOURCES") + env("sfesec", sources_body, "source", "SOURCES")
    out.append(cmd("sfehalves", regional_box, sources_box))

    if cited:
        legend = [cmd("sfeLegendRow", tex_escape(s["source_id"]), tex_escape(s["document_title"]), tex_escape(s["rights_status"]),
                      tex_escape(s["verification_status"]), tex_escape(s["intended_use"])) for s in cited]
        out.append(r"{\scriptsize\textbf{SOURCE LEGEND (condensed)}\par"
                   + env("tabularx", _table_body(["ID", "Title", "Rights", "Verification", "Use"], legend), r"\linewidth", "lYlll") + "}")
    if proof_note:
        out.append(env("sfepanel", r"\scriptsize\textbf{PROOF CHECKS (generated by the pipeline):} " + tex_escape(proof_note)))
    out.append(r"\vspace{2pt}\sfeIconKey")
    stats = {"sources": len(cited), "assets": len(fm["photo_ids"]) + len(fm["illustration_ids"]), "steps": len(steps), "unit_pairs": len(rows)}
    return Rendered("\n".join(out), files, stats)


def printed_claim_ids(fm: dict) -> set[str]:
    """The claim ids the 'Claim ids' line prints: the steps', the entry's and every field-bound claim (not a unit-table row's)."""
    ids = {c for step in fm["procedure"] for c in step["claim_ids"]} | set(fm["claim_ids"])
    for bound in (fm.get("field_claims") or {}).values():
        ids.update(bound)
    return ids


def printed_strings(fm: dict[str, Any], *, assets: dict[str, dict[str, Any]], sources: dict[str, dict[str, Any]], zone_title: str = "") -> list[tuple[str, str]]:
    """Every string render_entry prints for an entry, with the field it comes from: what the PDF's text layer must contain.

    A key the layout prints verbatim is expected in full, every string of it, so a sub-field added to the schema later is expected too and a
    layout that does not print it fails the check instead of dropping it silently. The few keys that appear in another form are listed first."""
    out: list[tuple[str, str]] = []

    def add(path: str, text: Any) -> None:
        if isinstance(text, str) and text.strip():
            out.append((path, text))

    # The header line, in the order the layout sets it: id, zone tag, status tag, revision tag.
    add("header", f"{fm['id']} ZONE {_zone_label(fm, zone_title)} STATUS: {fm['status'].upper()} REV {fm['revision']}")
    if fm.get("as_of_date"):
        add("as_of_date", f"as of {fm['as_of_date']}")
    for claim_id in sorted(printed_claim_ids(fm)):
        add("claim_ids", claim_id)
    for source_id in fm["source_ids"]:
        source = sources.get(source_id)
        if source:  # the layout prints a chip and a legend row for a source the register knows
            add("source_ids", source_id)
            for key in ("document_title", "rights_status", "verification_status", "intended_use"):
                add(f"sources.{source_id}.{key}", source[key])
    for asset_id in list(fm["photo_ids"]) + list(fm["illustration_ids"]):
        asset = assets.get(asset_id)
        if asset:
            add(f"assets.{asset_id}", asset_id)
            add(f"assets.{asset_id}.role", asset["role"].replace("_", " "))
            if asset.get("view"):
                add(f"assets.{asset_id}.view", f"view {asset['view']}")
            add(f"assets.{asset_id}.license", f"license {asset.get('license') or asset['license_status']}")
            credit = asset.get("credited_photographer") or asset.get("organization")
            if credit:
                add(f"assets.{asset_id}.credit", f"credit {credit}")
            if asset.get("provenance_url"):
                add(f"assets.{asset_id}.provenance", urlparse(asset["provenance_url"]).hostname or "")
            add(f"assets.{asset_id}.caption", asset.get("caption"))
    in_other_form = {"id", "zone", "status", "revision", "as_of_date", "claim_ids", "source_ids", "photo_ids", "illustration_ids"}
    for key in sorted(PRINTED_KEYS - in_other_form):
        skipped = UNPRINTED_SUBFIELDS.get(key, frozenset())
        for path, text in walk_strings(fm.get(key), key):
            if "." in path and path.split(".", 1)[1].split("[")[0] in skipped:
                continue
            add(path, text)
    return out


def render_document(body: str, *, paper: str, proof: bool, title: str, author: str, subject: str, keywords: str,
                    footer_left: str, footer_right: str, version: str, banner: str = "") -> str:
    head = [
        # Documented opt-out in pdftex.def ("before even the \documentclass line"): newer graphics drivers would otherwise load
        # epstopdf-base, which warns "Shell escape feature is not enabled" at load time. We never include EPS, and shell escape stays off.
        r"\newcommand{\DoNotLoadEpstopdf}{}",
        r"\documentclass[10pt]{article}",
        rf"\def\sfePaper{{{paper}}}",
        rf"\def\sfeProof{{{1 if proof else 0}}}",
        rf"\def\sfeVersion{{{version}}}",
        rf"\def\sfePdfTitle{{{plain(title)}}}",
        rf"\def\sfePdfAuthor{{{plain(author)}}}",
        rf"\def\sfePdfSubject{{{plain(subject)}}}",
        rf"\def\sfePdfKeywords{{{plain(keywords)}}}",
        rf"\def\sfeFooterLeft{{{tex_escape(footer_left)}}}",
        rf"\def\sfeFooterRight{{{footer_right}}}",
        r"\usepackage{sfe}",
        r"\begin{document}",
    ]
    if banner:
        head.append(cmd("sfeBanner", tex_escape(banner)))
    return "\n".join(head + [body, r"\end{document}", ""])
