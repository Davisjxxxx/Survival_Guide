"""US customary <-> metric equivalence (handoff section 7; finding FR-019).

THE POLICY (documented in GOVERNANCE.md; the numbers live in schemas/unit_policy.yaml, decision D19)

A pair is consistent only if BOTH hold:

  1. the two-way round trip, unchanged since RUN-001: converting the US value and rounding to the metric value's displayed decimals gives exactly the
     metric value shown, and converting the metric value and rounding to the US value's displayed decimals gives exactly the US value shown;
  2. a relative-error bound from the exact conversion, |conversion - stated| / max(|conversion|, |stated|), by class:

         precise      1 %    the default, for a pair that carries no marker
         approximate  5 %    only for a pair with an explicit marker (~, about, approx., approximately, roughly, circa); the round trip is then waived
         safety       0.5 %  for a safety-critical quantity; a marker never loosens it

Why a bound as well as the round trip. At RUN-003 the round trip alone accepted 1 mi / 2 km (24 % apart), 1 in / 3 cm (18 %), 2 lb / 1 kg (10 %), 3 ft / 1 m
(9 %), 1 gal / 4 L and 1 qt / 1 L (6 %), because each value is "correctly rounded" at a precision of one digit. Rounding to one digit is a fact about the
printed number, not about the quantity.

Safety-critical means: the dimension is pressure or temperature (a floor in code the policy cannot remove), or the entry requires any review subject beyond
screening, or the entry is medical guidance, or the quantity's claim is high or critical risk or of type medical or safety_boundary.

Absolute temperatures are held to correct rounding at the printed precision, in both directions; a relative bound means nothing on a scale whose zero is
arbitrary (0 deg C is not "nothing"). A temperature INTERVAL is written with the word difference ("18 °F difference / 10 °C difference") and converts without
the offset; it is held to the safety bound. Zero compares only with zero. Fractions ("1/4", "1 1/2", "1-1/2") convert exactly; a range ("4-6", "4 to 6")
is checked end against end and must ascend on both sides. The layout cannot print Δ, ≈ or the Unicode minus (a fatal LaTeX error), so only ASCII forms are read.

NOT INVENTED: no tolerance exists for a medical dose. Dose units (mg, mcg, IU) and household measures (tsp, tbsp, cup) are not units of this table; they stay
refused as unknown units. A limit's direction (a minimum or a maximum) is not modelled. Arithmetic is exact decimal arithmetic (all factors are exact by
definition), so there is no floating-point edge. This checks internal consistency only; it says nothing about whether the quantity itself is right.

PROSE. `scan_text` finds a conversion written in running text, as A (B), A / B or A or B / A = B with the two quantities in different systems and the same
dimension, and checks it by the same policy. A quantity in prose with no counterpart is only reported (the handoff asks for both systems "when useful").
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation, getcontext
from functools import lru_cache
from typing import TYPE_CHECKING, Any

from .common import Finding, err, load_yaml

if TYPE_CHECKING:  # pragma: no cover
    from .registry import Repo

getcontext().prec = 40

# unit -> (dimension, factor to the SI base unit as an exact decimal string, system)
_UNITS: dict[str, tuple[str, str, str]] = {
    "mm": ("length", "0.001", "metric"), "cm": ("length", "0.01", "metric"),
    "m": ("length", "1", "metric"), "km": ("length", "1000", "metric"),
    "in": ("length", "0.0254", "us"), "ft": ("length", "0.3048", "us"),
    "yd": ("length", "0.9144", "us"), "mi": ("length", "1609.344", "us"),
    "g": ("mass", "0.001", "metric"), "kg": ("mass", "1", "metric"),
    "oz": ("mass", "0.028349523125", "us"), "lb": ("mass", "0.45359237", "us"),
    "ml": ("volume", "0.000001", "metric"), "l": ("volume", "0.001", "metric"),
    "fl oz": ("volume", "0.0000295735295625", "us"), "qt": ("volume", "0.000946352946", "us"),
    "gal": ("volume", "0.003785411784", "us"),
    "kpa": ("pressure", "1000", "metric"), "psi": ("pressure", "6894.757293168", "us"),
}
_TEMPERATURE = {"°c": "metric", "°f": "us"}
_KELVIN_OFFSET = Decimal("273.15")
DIMENSIONS = frozenset({"length", "mass", "volume", "pressure", "temperature"})
# Spellings that mean one of the units above (lower case, single spaces). Only ASCII and the degree sign are read.
_ALIASES: dict[str, str] = {
    "inch": "in", "inches": "in", "foot": "ft", "feet": "ft", "yard": "yd", "yards": "yd", "mile": "mi", "miles": "mi",
    "millimeter": "mm", "millimeters": "mm", "millimetre": "mm", "millimetres": "mm", "centimeter": "cm", "centimeters": "cm",
    "centimetre": "cm", "centimetres": "cm", "meter": "m", "meters": "m", "metre": "m", "metres": "m", "kilometer": "km", "kilometers": "km",
    "kilometre": "km", "kilometres": "km", "gram": "g", "grams": "g", "kilogram": "kg", "kilograms": "kg", "ounce": "oz", "ounces": "oz",
    "pound": "lb", "pounds": "lb", "lbs": "lb", "milliliter": "ml", "milliliters": "ml", "millilitre": "ml", "millilitres": "ml",
    "liter": "l", "liters": "l", "litre": "l", "litres": "l", "fluid ounce": "fl oz", "fluid ounces": "fl oz", "quart": "qt", "quarts": "qt",
    "gallon": "gal", "gallons": "gal", "kilopascal": "kpa", "kilopascals": "kpa",
    "degrees fahrenheit": "°f", "degree fahrenheit": "°f", "degrees f": "°f", "degree f": "°f", "deg f": "°f", "deg. f": "°f", "fahrenheit": "°f",
    "degrees celsius": "°c", "degree celsius": "°c", "degrees c": "°c", "degree c": "°c", "deg c": "°c", "deg. c": "°c", "celsius": "°c",
}
_INTERVAL_WORDS = ("difference", "change", "rise", "drop", "span")
_NUM = r"(?:\d+(?:\s+|-)\d+/\d+|\d+/\d+|(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?)"
_OK_CHARS = re.compile(r"^[\x20-\x7e°–—]*$")


class UnitError(ValueError):
    """Raised when a quantity string cannot be parsed or its unit is unknown."""


# ---------------------------------------------------------------------------------------------- the policy
@dataclass(frozen=True)
class UnitPolicy:
    precise: Decimal
    approximate: Decimal
    safety: Decimal
    safety_dimensions: frozenset[str]
    markers: tuple[str, ...]

    def bound(self, kind: str) -> Decimal:
        return {"precise": self.precise, "approximate": self.approximate, "safety": self.safety}[kind]


DEFAULT_MARKERS = ("~", "about", "approx.", "approx", "approximately", "roughly", "circa")
# The engineering initial values (schemas/unit_policy.yaml holds the ones in force; this copy serves callers that pass no policy).
DEFAULT_POLICY = UnitPolicy(Decimal("0.01"), Decimal("0.05"), Decimal("0.005"), frozenset({"pressure", "temperature"}), DEFAULT_MARKERS)
# What applies when the policy file is missing or invalid: every quantity is safety-critical and every bound is the safety bound.
STRICT_POLICY = UnitPolicy(Decimal("0.005"), Decimal("0.005"), Decimal("0.005"), DIMENSIONS, DEFAULT_MARKERS)
POLICY_REL = "schemas/unit_policy.yaml"
FLOOR_SAFETY_DIMENSIONS = frozenset({"pressure", "temperature"})  # the policy may add dimensions, never remove these
CEILING = {"precise": Decimal("0.05"), "approximate": Decimal("0.10"), "safety": Decimal("0.02")}  # the policy may tighten a bound, never loosen it past these


def load_unit_policy(repo: "Repo") -> tuple[UnitPolicy | None, list[Finding]]:
    """Load and validate schemas/unit_policy.yaml. Returns (None, findings) when it cannot be trusted: STRICT_POLICY then applies and the run fails."""
    path = repo.path(POLICY_REL)
    if not path.is_file():
        return None, [err("UNIT_POLICY_MISSING", POLICY_REL, "the unit policy is missing: every quantity is held to the strictest bound and nothing passes")]
    try:
        data = load_yaml(path.read_text(encoding="utf-8"))
    except Exception as exc:
        return None, [err("UNIT_POLICY_INVALID", POLICY_REL, f"not valid strict YAML: {exc}")]
    if not isinstance(data, dict) or data.get("schema_version") != 1:
        return None, [err("UNIT_POLICY_INVALID", POLICY_REL, "expected a mapping with schema_version 1")]
    findings: list[Finding] = []

    def bad(message: str) -> None:
        findings.append(err("UNIT_POLICY_INVALID", POLICY_REL, message))

    table = data.get("tolerance")
    bounds: dict[str, Decimal] = {}
    if not isinstance(table, dict) or set(table) != set(CEILING):
        bad("tolerance: needs exactly precise, approximate and safety")
    else:
        for name, value in table.items():
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not 0 < value < 1:
                bad(f"tolerance.{name}: must be a number above 0 and below 1 (a relative error)")
            elif Decimal(str(value)) > CEILING[name]:
                bad(f"tolerance.{name}: {value} is looser than the ceiling {CEILING[name]} that only a code change may raise")
            else:
                bounds[name] = Decimal(str(value))
        if len(bounds) == 3 and not bounds["safety"] <= bounds["precise"] <= bounds["approximate"]:
            bad("tolerance: must satisfy safety <= precise <= approximate")
    dims = data.get("safety_dimensions")
    if not isinstance(dims, list) or not all(isinstance(d, str) for d in dims) or not FLOOR_SAFETY_DIMENSIONS <= set(dims) or not set(dims) <= DIMENSIONS:
        bad(f"safety_dimensions: must list at least {', '.join(sorted(FLOOR_SAFETY_DIMENSIONS))} and only dimensions of the unit table ({', '.join(sorted(DIMENSIONS))})")
    markers = data.get("approximate_markers")
    if not isinstance(markers, list) or not markers or not all(isinstance(m, str) and m.strip() and m == m.strip() for m in markers):
        bad("approximate_markers: must be a non-empty list of strings")
    elif any(re.search(r"[^\x20-\x7e]", m) for m in markers):
        bad("approximate_markers: only ASCII markers are allowed, because the layout cannot print anything else")
    if findings:
        return None, findings
    return UnitPolicy(bounds["precise"], bounds["approximate"], bounds["safety"], frozenset(dims), tuple(markers)), []


# ------------------------------------------------------------------------------------------- parsing
@dataclass(frozen=True)
class Endpoint:
    value: Decimal
    decimals: int | None  # displayed decimals; None for a fraction, which is an exact value with no displayed precision


@dataclass(frozen=True)
class Measure:
    text: str
    unit: str  # a symbol of the unit table, lower case
    ends: tuple[Endpoint, ...]  # one value, or low and high of a range
    approximate: bool
    interval: bool

    @property
    def dimension(self) -> str:
        return "temperature" if self.unit in _TEMPERATURE else _UNITS[self.unit][0]

    @property
    def system(self) -> str:
        return _TEMPERATURE[self.unit] if self.unit in _TEMPERATURE else _UNITS[self.unit][2]


def _marker_alt(markers: tuple[str, ...]) -> str:
    parts = []
    for marker in sorted(markers, key=len, reverse=True):
        part = re.escape(marker)
        part = (r"\b" + part if marker[0].isalpha() else part) + (r"\b" if marker[-1].isalpha() else "")
        parts.append(part)
    return "|".join(parts) or r"(?!)"


@lru_cache(maxsize=16)
def _measure_regex(markers: tuple[str, ...]) -> re.Pattern[str]:
    return re.compile(
        rf"^\s*(?P<approx>(?:{_marker_alt(markers)})\s*)?(?P<lo>-?{_NUM})(?:\s*(?:-|–|—|\bto\b)\s*(?P<hi>-?{_NUM}))?\s*(?P<unit>[^\d\s].*?)\s*$",
        re.IGNORECASE)


def _endpoint(raw: str, text: str) -> Endpoint:
    negative = raw.startswith("-")
    body = re.sub(r"\s+", " ", raw[1:] if negative else raw)
    if "/" in body:
        # A fraction is an EXACT value: it has no displayed decimals, so there is no backward round trip to make (3/16 in is 4.7625 mm, and nobody
        # states a drill size to that precision). It is held to correct rounding of the other side and to the relative-error bound.
        whole, _, fraction = body.rpartition(" ") if " " in body else body.rpartition("-")
        numerator, _, denominator = fraction.partition("/")
        num, den = int(numerator), int(denominator)
        if den == 0:
            raise UnitError(f"cannot parse number in {text!r}: a fraction cannot have a zero denominator")
        value = (Decimal(int(whole) * den + num) / Decimal(den)) if whole else Decimal(num) / Decimal(den)
        decimals = None
    else:
        try:
            value = Decimal(body.replace(",", ""))
        except InvalidOperation as exc:
            raise UnitError(f"cannot parse number in {text!r}") from exc
        decimals = max(0, -value.as_tuple().exponent)  # type: ignore[operator]
    return Endpoint(-value if negative else value, decimals)


def _resolve_unit(raw: str, text: str) -> tuple[str, bool]:
    unit = re.sub(r"\s+", " ", raw.strip().lower())
    unit = re.sub(r"°\s+", "°", unit)
    interval = False
    match = re.fullmatch(rf"(.*?)\s+(?:{'|'.join(_INTERVAL_WORDS)})", unit)
    if match:
        unit, interval = match.group(1), True
    unit = _ALIASES.get(unit, unit)
    if unit not in _UNITS and unit not in _TEMPERATURE:
        raise UnitError(f"unknown unit {unit!r} in {text!r}")
    if interval and unit not in _TEMPERATURE:
        raise UnitError(f"{text!r}: only a temperature can be an interval (a difference)")
    return unit, interval


def parse_measure(text: str, markers: tuple[str, ...] = DEFAULT_MARKERS) -> Measure:
    """A quantity as written: a number, a fraction, a mixed number or a range, an optional approximation marker, a unit, and for a temperature
    an optional word (difference, change, rise, drop, span) that makes it an interval."""
    if not isinstance(text, str) or not _OK_CHARS.match(text):
        bad = next((ch for ch in str(text) if not _OK_CHARS.match(ch)), "")
        hint = f": {bad!r} cannot be printed by the layout (write ~ or 'about' for an approximation and '°F difference' for a temperature interval)" if bad else ""
        raise UnitError(f"cannot parse quantity {text!r}{hint}")
    match = _measure_regex(markers).match(text)
    if not match:
        raise UnitError(f"cannot parse quantity {text!r}")
    unit, interval = _resolve_unit(match.group("unit"), text)
    ends = [_endpoint(match.group("lo"), text)]
    if match.group("hi") is not None:
        ends.append(_endpoint(match.group("hi"), text))
    return Measure(text, unit, tuple(ends), bool(match.group("approx")), interval)


def parse_quantity(text: str) -> tuple[Decimal, int, str]:
    """Return (value, displayed decimals, normalised unit) of a single quantity."""
    measure = parse_measure(text)
    if len(measure.ends) != 1:
        raise UnitError(f"cannot parse quantity {text!r}: a range is not a single quantity")
    end = measure.ends[0]
    return end.value, end.decimals or 0, measure.unit


def dimension_of(text: str) -> str | None:
    """The physical dimension of a quantity string (length, mass, volume, pressure, temperature), or None when it cannot be parsed."""
    try:
        return parse_measure(text).dimension
    except UnitError:
        return None


# --------------------------------------------------------------------------------------- conversion
def _to_si(value: Decimal, unit: str, interval: bool) -> Decimal:
    if unit == "°c":
        return value if interval else value + _KELVIN_OFFSET
    if unit == "°f":
        return value * 5 / 9 if interval else (value - 32) * 5 / 9 + _KELVIN_OFFSET
    return value * Decimal(_UNITS[unit][1])


def _from_si(si: Decimal, unit: str, interval: bool) -> Decimal:
    if unit == "°c":
        return si if interval else si - _KELVIN_OFFSET
    if unit == "°f":
        return si * 9 / 5 if interval else (si - _KELVIN_OFFSET) * 9 / 5 + 32
    return si / Decimal(_UNITS[unit][1])


def convert(value: Decimal, from_unit: str, to_unit: str, *, interval: bool = False) -> Decimal:
    """Exact conversion between two units of one dimension (an interval for a temperature difference)."""
    return _from_si(_to_si(value, from_unit, interval), to_unit, interval)


def _round(value: Decimal, decimals: int) -> Decimal:
    return value.quantize(Decimal(1).scaleb(-decimals), rounding=ROUND_HALF_UP)


def _shown(value: Decimal) -> str:
    """A conversion to six significant figures, for a message."""
    if value == 0:
        return "0"
    return f"{value.quantize(Decimal(1).scaleb(-max(0, 5 - value.adjusted()))):f}"


def relative_error(conversion: Decimal, stated: Decimal) -> Decimal:
    """|conversion - stated| / max(|conversion|, |stated|); zero only compares equal with zero."""
    if conversion == stated:
        return Decimal(0)
    return abs(conversion - stated) / max(abs(conversion), abs(stated))


def check_pair(us_text: str, metric_text: str, *, strictness: str = "precise", policy: UnitPolicy | None = None) -> list[str]:
    """Return a list of problems (empty when the pair is consistent under the policy).

    `strictness` is "precise" (the default) or "safety": the caller says the quantity is safety-critical because of where it sits (its entry or its claim).
    A pressure or a temperature is safety-critical whatever the caller says."""
    policy = policy or DEFAULT_POLICY
    try:
        us = parse_measure(us_text, policy.markers)
        me = parse_measure(metric_text, policy.markers)
    except UnitError as exc:
        return [str(exc)]
    problems: list[str] = []
    if us.system != "us":
        problems.append(f"{us_text!r} is not a US customary unit")
    if me.system != "metric":
        problems.append(f"{metric_text!r} is not a metric unit")
    if us.dimension != me.dimension:
        problems.append(f"dimension mismatch: {us_text!r} is {us.dimension}, {metric_text!r} is {me.dimension}")
    elif us.interval != me.interval:
        problems.append(f"{us_text!r} and {metric_text!r}: one is a temperature interval (difference) and the other an absolute temperature")
    if len(us.ends) != len(me.ends):
        problems.append(f"{us_text!r} and {metric_text!r}: one value is a range and the other is not")
    for measure in (us, me):
        if len(measure.ends) == 2 and measure.ends[0].value > measure.ends[1].value:
            problems.append(f"{measure.text!r}: a range must run from the lower value to the higher")
    if problems:
        return problems

    safety = strictness == "safety" or us.dimension in policy.safety_dimensions
    kind = "safety" if safety else ("approximate" if us.approximate or me.approximate else "precise")
    bound = policy.bound(kind)
    absolute_temperature = us.dimension == "temperature" and not us.interval
    labels = [""] if len(us.ends) == 1 else ["low end ", "high end "]
    for label, us_end, me_end in zip(labels, us.ends, me.ends):
        conversion = convert(us_end.value, us.unit, me.unit, interval=us.interval)
        if kind != "approximate":
            forward = _round(conversion, me_end.decimals) if me_end.decimals is not None else conversion
            if forward != me_end.value:
                problems.append(f"{label}{us_text!r} converts to {forward:f} {me.unit}, not {metric_text!r}")
            if us_end.decimals is not None:
                backward = _round(convert(me_end.value, me.unit, us.unit, interval=us.interval), us_end.decimals)
                if backward != us_end.value:
                    problems.append(f"{label}{metric_text!r} converts to {backward:f} {us.unit}, not {us_text!r}")
        if absolute_temperature:
            continue  # a relative bound means nothing where zero is arbitrary: correct rounding at the printed precision is the rule
        error = relative_error(conversion, me_end.value)
        if error > bound:
            advice = {"precise": "state more digits, or mark both values approximate (~ or 'about') if they are rounded",
                      "approximate": "even marked approximate, the two values may not differ by more than that",
                      "safety": "a safety-critical quantity must be stated exactly; an approximation marker does not loosen it"}[kind]
            problems.append(f"{label}{us_text!r} and {metric_text!r} differ by {error:.2%} (they should be about {_shown(conversion)} {me.unit}); "
                            f"{'an' if kind[0] in 'aeiou' else 'a'} {kind} pair may differ by at most {bound:.2%}: {advice}")
    return problems


# --------------------------------------------------------------------------------------------- prose
@dataclass
class ProseResult:
    problems: list[str]  # a conversion written in text that the policy refuses
    unpaired: list[str]  # quantities with no counterpart (reported, never an error)


_AMBIGUOUS_ALONE = frozenset({"in", "l"})  # "in" and "l" are also ordinary words and letters: alone they are not reported as quantities


def _spelling(word: str) -> str:
    return r"\s+".join(re.escape(part) for part in word.split(" "))


@lru_cache(maxsize=16)
def _prose_regexes(markers: tuple[str, ...]) -> tuple[re.Pattern[str], re.Pattern[str], re.Pattern[str], re.Pattern[str]]:
    temperature = sorted([k for k in _TEMPERATURE] + [k for k, v in _ALIASES.items() if v in _TEMPERATURE], key=len, reverse=True)
    others = sorted([k for k in _UNITS] + [k for k, v in _ALIASES.items() if v in _UNITS], key=len, reverse=True)
    temperature_alt = "|".join(_spelling(w) if not w.startswith("°") else r"°\s?" + re.escape(w[1:]) for w in temperature)
    other_alt = "|".join(_spelling(w) for w in others)
    unit = rf"(?:(?:{temperature_alt})(?:\s+(?:{'|'.join(_INTERVAL_WORDS)}))?|(?:{other_alt}))(?![A-Za-z0-9°])"
    marker = _marker_alt(markers)

    def qty(sfx: str) -> str:
        return (rf"(?P<q{sfx}>(?:(?:{marker})\s*)?-?{_NUM}(?:\s*(?:-|–|—|\bto\b)\s*-?{_NUM})?\s*{unit})")

    flags = re.IGNORECASE
    paren = re.compile(rf"(?<![\w]){qty('a')}\.?\s*\(\s*(?:or\s+)?{qty('b')}\s*\)", flags)
    slash = re.compile(rf"(?<![\w]){qty('a')}\.?\s*/\s*{qty('b')}", flags)
    word = re.compile(rf"(?<![\w]){qty('a')}\.?\s*,?\s*(?:or|=|equals|equal\s+to|which\s+is|that\s+is)\s+{qty('b')}", flags)
    single = re.compile(rf"(?<![\w]){qty('s')}", flags)
    return paren, slash, word, single


def scan_text(text: str, *, strictness: str = "precise", policy: UnitPolicy | None = None) -> ProseResult:
    """Find the conversions written in running text and check each by the policy; list the quantities that have no counterpart."""
    policy = policy or DEFAULT_POLICY
    paren, slash, word, single = _prose_regexes(policy.markers)
    found: list[tuple[int, int, str, str]] = []
    for pattern in (paren, slash, word):
        found.extend((m.start(), m.end(), m.group("qa"), m.group("qb")) for m in pattern.finditer(text))
    found.sort()
    result = ProseResult([], [])
    taken: list[tuple[int, int]] = []
    for start, end, a_text, b_text in found:
        if any(start < t_end and t_start < end for t_start, t_end in taken):
            continue
        try:
            a, b = parse_measure(a_text, policy.markers), parse_measure(b_text, policy.markers)
        except UnitError:
            continue  # something that looks like a quantity but is not one: not a conversion
        if a.system == b.system or a.dimension != b.dimension:
            continue  # two quantities side by side are not a conversion unless they are the same thing in two systems
        taken.append((start, end))
        us, metric = (a, b) if a.system == "us" else (b, a)
        result.problems += [f"{text[start:end]!r}: {problem}" for problem in check_pair(us.text, metric.text, strictness=strictness, policy=policy)]
    masked = list(text)
    for start, end in taken:
        masked[start:end] = " " * (end - start)
    for m in single.finditer("".join(masked)):
        try:
            measure = parse_measure(m.group("qs"), policy.markers)
        except UnitError:
            continue
        if measure.unit not in _AMBIGUOUS_ALONE:
            result.unpaired.append(m.group("qs").strip())
    return result
