"""The reviewer registry: who may author, review, adjudicate and register (finding FR-005).

A ledger row used to name its reviewer with a free-text name and a typed `reviewer_role`; the gate trusted both. Now a ledger row names
a registry id and the capacity it acts in, and only this registry says what that is worth:

* the registry is an append-only, chained event log (reviews/reviewers.csv), rooted in the owner's bootstrap row;
* every later registration is attested by an identity holding an active `registrar` capacity;
* an identity has one `kind` (human, ai_model, owner) for ever, and capacities such as external_sme, chatgpt_editorial, adjudicator;
* a capacity names the subjects (domains) the reviewer may speak for and the dates it counts;
* a revocation is retroactive for counting.

A row that breaks a rule is reported and granted nothing (fail closed). The registry cannot prove that a registered person is who the
row says; that is the owner's attestation, recorded and reviewable in Git, not a cryptographic fact (stated in the run record).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .common import Finding, err, valid_calendar_date

# capacity -> the kinds that may hold it
KIND_RULES: dict[str, tuple[str, ...]] = {
    "registrar": ("owner",),
    "adjudicator": ("human", "owner"),
    "external_sme": ("human",),
    "chatgpt_editorial": ("ai_model",),
    "technical_reviewer": ("human", "ai_model"),
    "author": ("human", "ai_model", "owner"),
}
NEEDS_EVIDENCE = frozenset({"technical_reviewer", "external_sme", "adjudicator"})  # a qualification must be on record
NEEDS_DOMAINS = frozenset({"technical_reviewer", "external_sme", "chatgpt_editorial"})  # subjects the reviewer may speak for
ALL_ALLOWED = frozenset({"chatgpt_editorial"})  # only the validation capacity spans every subject


def normalize_name(text: str) -> str:
    return " ".join(text.lower().split())


@dataclass(frozen=True)
class Registration:
    registration_id: str
    reviewer_id: str
    display_name: str
    kind: str
    capacity: str
    domains: frozenset[str]
    evidence: str | None
    registered_by: str
    valid_from: str
    valid_until: str | None
    sequence: int


class Registry:
    """The state obtained by replaying the registry ledger in sequence order."""

    def __init__(self) -> None:
        self.registrations: dict[str, Registration] = {}
        self.revoked_at: dict[str, int] = {}
        self.identities: dict[str, tuple[str, str]] = {}  # reviewer_id -> (kind, display_name)
        self.findings: list[Finding] = []

    def kind_of(self, reviewer_id: str | None) -> str | None:
        found = self.identities.get(reviewer_id or "")
        return found[0] if found else None

    def name_of(self, reviewer_id: str | None) -> str | None:
        found = self.identities.get(reviewer_id or "")
        return found[1] if found else None

    def live(self, reviewer_id: str, capacity: str) -> list[Registration]:
        return [r for r in self.registrations.values()
                if r.reviewer_id == reviewer_id and r.capacity == capacity and r.registration_id not in self.revoked_at]

    def lookup(self, reviewer_id: str | None, capacity: str | None, on_date: str | None = None) -> tuple[Registration | None, tuple[str, str] | None]:
        """The registration that lets `reviewer_id` act in `capacity` on `on_date`, or (None, (code, why)).

        `on_date` is the date the ledger row was recorded; None skips the validity window (used for entry fields that carry no date).
        """
        if not reviewer_id or reviewer_id not in self.identities:
            return None, ("REVIEWER_NOT_REGISTERED", f"{reviewer_id!r} is not in the reviewer registry")
        everything = [r for r in self.registrations.values() if r.reviewer_id == reviewer_id and r.capacity == capacity]
        if not everything:
            return None, ("REVIEWER_CAPACITY_NOT_REGISTERED", f"{reviewer_id} is not registered with capacity {capacity!r}")
        live = [r for r in everything if r.registration_id not in self.revoked_at]
        if not live:
            return None, ("REVIEWER_REVOKED", f"every {capacity!r} registration of {reviewer_id} has been revoked")
        if on_date is not None:
            live = [r for r in live if r.valid_from <= on_date and (r.valid_until is None or on_date <= r.valid_until)]
            if not live:
                return None, ("REVIEWER_NOT_VALID_ON_DATE", f"no {capacity!r} registration of {reviewer_id} covers {on_date}")
        return max(live, key=lambda r: r.sequence), None


def load_registry(rows: list[dict[str, Any]], label: str) -> Registry:
    """Replay the registry ledger. A row that breaks any rule is reported and grants nothing."""
    registry = Registry()
    names: dict[str, str] = {}
    registrars: set[str] = set()
    for row in rows:
        where = f"{label}:row {row['_row']}"
        before = len(registry.findings)
        add = registry.findings.append
        rid, kind, capacity = row["reviewer_id"], row["kind"], row["capacity"]
        if row["_row"] == 1 and not (row["action"] == "register" and capacity == "registrar" and kind == "owner" and row["registered_by"] == rid):
            add(err("REGISTRY_BOOTSTRAP_INVALID", where, "the first row must be the owner's bootstrap: action register, kind owner, capacity registrar, registered_by the same identity"))

        if row["action"] == "register":
            if kind not in KIND_RULES.get(capacity, ()):
                add(err("REGISTRY_KIND_CAPACITY", where, f"capacity {capacity!r} cannot be held by kind {kind!r} (allowed: {', '.join(KIND_RULES.get(capacity, ()))})"))
            if row.get("revokes_registration_id"):
                add(err("REGISTRY_REVOKE_INVALID", where, "a register row cannot name a registration to revoke"))
            known = registry.identities.get(rid)
            if known is not None and known != (kind, row["display_name"]):
                add(err("REGISTRY_IDENTITY_CONFLICT", where, f"{rid} was registered as {known[0]} {known[1]!r}; it cannot become {kind} {row['display_name']!r}"))
            owner_of_name = names.get(normalize_name(row["display_name"]))
            if owner_of_name is not None and owner_of_name != rid:
                add(err("REGISTRY_NAME_DUPLICATE", where, f"the name {row['display_name']!r} already belongs to {owner_of_name}: one person or model under two ids defeats the independence rules"))
            if registry.live(rid, capacity):
                add(err("REGISTRY_DUPLICATE_REGISTRATION", where, f"{rid} already holds an active {capacity!r} registration"))
            domains = frozenset(row["domains"])
            if capacity in NEEDS_DOMAINS and not domains:
                add(err("REGISTRY_DOMAINS_INVALID", where, f"capacity {capacity!r} needs at least one domain"))
            if capacity not in NEEDS_DOMAINS and domains:
                add(err("REGISTRY_DOMAINS_INVALID", where, f"capacity {capacity!r} carries no domains"))
            if "ALL" in domains and capacity not in ALL_ALLOWED:
                add(err("REGISTRY_DOMAINS_INVALID", where, f"ALL is allowed only for {', '.join(sorted(ALL_ALLOWED))}"))
            if capacity in NEEDS_EVIDENCE and not (row.get("qualification_evidence") or "").strip():
                add(err("REGISTRY_EVIDENCE_MISSING", where, f"capacity {capacity!r} needs qualification_evidence"))
            valid_until = row.get("valid_until")
            if valid_until and (not valid_calendar_date(valid_until) or valid_until < row["registered_on"]):
                add(err("REGISTRY_VALIDITY_INVALID", where, "valid_until must be a real date on or after registered_on"))
            bootstrap = row["_row"] == 1
            if not ((bootstrap and row["registered_by"] == rid and capacity == "registrar") or row["registered_by"] in registrars):
                add(err("REGISTRY_REGISTRAR_REQUIRED", where, f"{row['registered_by']} holds no active registrar capacity, so it cannot attest this registration"))
            if len(registry.findings) == before:
                registry.registrations[row["registration_id"]] = Registration(
                    row["registration_id"], rid, row["display_name"], kind, capacity, domains, row.get("qualification_evidence"),
                    row["registered_by"], row["registered_on"], valid_until or None, row["_row"])
                registry.identities.setdefault(rid, (kind, row["display_name"]))
                names.setdefault(normalize_name(row["display_name"]), rid)
                if capacity == "registrar":
                    registrars.add(rid)
        else:
            target_id = row.get("revokes_registration_id")
            target = registry.registrations.get(target_id or "")
            if target is None:
                add(err("REGISTRY_REVOKE_INVALID", where, f"{target_id!r} is not an earlier, valid registration"))
            elif target_id in registry.revoked_at:
                add(err("REGISTRY_REVOKE_INVALID", where, f"{target_id} was already revoked"))
            elif (target.reviewer_id, target.capacity, target.kind) != (rid, capacity, kind):
                add(err("REGISTRY_REVOKE_INVALID", where, f"the row does not repeat the identity, kind and capacity of {target_id}"))
            if row["registered_by"] not in registrars:
                add(err("REGISTRY_REGISTRAR_REQUIRED", where, f"{row['registered_by']} holds no active registrar capacity, so it cannot attest this revocation"))
            if len(registry.findings) == before and target is not None:
                registry.revoked_at[target.registration_id] = row["_row"]
                if target.capacity == "registrar":
                    still = {r.reviewer_id for r in registry.registrations.values()
                             if r.capacity == "registrar" and r.registration_id not in registry.revoked_at}
                    if not still:
                        del registry.revoked_at[target.registration_id]
                        add(err("REGISTRY_LAST_REGISTRAR", where, "this would leave no active registrar: nobody could register or revoke anyone again"))
                    else:
                        registrars = still
    return registry


def check_domains(registry: Registry, known_subjects: set[str], label: str, id_domains: set[str] | None = None) -> list[Finding]:
    """A registered domain must name a real review subject (HZ-/CLS-) or a real identification group (ID-<KIND>, from the taxon schema);
    a typo would silently disqualify a reviewer. With no `id_domains` any ID- name is accepted."""
    found: list[Finding] = []
    for registration in sorted(registry.registrations.values(), key=lambda r: r.sequence):
        for domain in sorted(registration.domains):
            if domain.startswith("ID-") and id_domains is not None:
                if domain not in id_domains:
                    found.append(err("REGISTRY_DOMAIN_UNKNOWN", f"{label}:row {registration.sequence}", f"domain {domain!r} is not an identification group ({', '.join(sorted(id_domains))})"))
                continue
            if domain != "ALL" and not domain.startswith("ID-") and domain not in known_subjects:
                found.append(err("REGISTRY_DOMAIN_UNKNOWN", f"{label}:row {registration.sequence}", f"domain {domain!r} is not a review subject defined in the hazard topics or the classification policy"))
    return found
