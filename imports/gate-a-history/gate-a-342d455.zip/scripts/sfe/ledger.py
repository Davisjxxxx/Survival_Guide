"""Append-only, sequence-ordered, hash-chained ledgers (findings FR-003 and FR-022).

Every ledger CSV (reviewer registry, approvals, safety audits, image audits) carries two machine-written columns:

    sequence       the FIRST column: 1, 2, 3 ... in file order
    chain_sha256   the LAST column: SHA-256 over the previous row's chain value and this row's cells

Why. Precedence used to be decided by a date a reviewer typed and by the row's position in a CSV. A mistyped year, a spreadsheet sort
or a deleted row could therefore change a verdict (FABLE-REVIEW-001, probes P03a, P03b, P08b, P08c, P11a, P11b). Now the sequence alone
orders events, and the chain makes any later edit, deletion, insertion or reordering of an earlier row detectable.

What this is not. The chain is tamper-EVIDENT, not tamper-PROOF: nothing signs it, so someone who rewrites the whole file and
recomputes every hash is not stopped by the file alone. `check_history` closes most of that gap in a Git checkout by requiring every
commit's rows to be a prefix of the next commit's rows. Outside Git (a bare export) a hash chain ALONE cannot detect tail truncation,
because the prefix of a valid chain is itself a valid chain. An independent external **ledger pin** (`ledger pin` / `--pin` /
`SFE_LEDGER_PIN`, kept outside the repository) closes that gap for every row up to the pin, and `release` / `release verify` fail closed
(`LEDGER_PIN_REQUIRED`) whenever ledgers hold rows and no trustworthy external anchor is supplied.

Dates remain in the ledgers as information. They must be real calendar dates and must not decrease along the sequence (a column
named `reviewed_on` or `decided_on` is the date the decision was RECORDED here); no gate ever lets a date decide a verdict.
"""
from __future__ import annotations

import csv
import hashlib
import io
import os
import re
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any

from .common import CsvError, Finding, HEX64_RE, err, note, parse_csv_bytes, read_csv, sha256_bytes, valid_calendar_date, warn

if TYPE_CHECKING:  # pragma: no cover
    from .registry import Repo

GENESIS = "0" * 64
SEQ_COL = "sequence"
CHAIN_COL = "chain_sha256"
PIN_PREFIX = "sfe-pin-v1"
PIN_ENV = "SFE_LEDGER_PIN"
_PIN_DIGEST_RE = re.compile(r"^[0-9a-f]{16}$")
_FS = "\x1f"  # cell separator inside the hashed text
_RS = "\x1e"  # separates the previous chain value from the cells


class LedgerError(ValueError):
    """Raised when a ledger file cannot be sealed safely."""


@dataclass(frozen=True)
class LedgerSpec:
    name: str       # register name in registry.REGISTERS
    date_col: str   # the column holding the date the row was recorded


def chain_value(previous: str, cells: list[str]) -> str:
    digest = hashlib.sha256()
    digest.update(previous.encode("ascii"))
    digest.update(_RS.encode("ascii"))
    digest.update(_FS.join(cells).encode("utf-8"))
    return digest.hexdigest()


def _cells(header: list[str], row: dict[str, str]) -> list[str]:
    return [row[column] for column in header if column != CHAIN_COL]


def check_ledger(rel: str, header: list[str], raw_rows: list[dict[str, str]], spec: LedgerSpec) -> list[Finding]:
    """Verify sequence, chain and date order of one ledger. Reports the FIRST break only: later rows cannot be trusted after it."""
    findings: list[Finding] = []
    previous, broken, last_date = GENESIS, False, None
    for index, row in enumerate(raw_rows, start=1):
        where = f"{rel}:row {index}"
        if any(_FS in value or _RS in value for value in row.values()):
            findings.append(err("LEDGER_CELL_FORBIDDEN_CHAR", where, "a cell contains a control character reserved for the ledger chain"))
        sequence, chain = row.get(SEQ_COL, ""), row.get(CHAIN_COL, "")
        if not sequence and not chain:
            findings.append(err("LEDGER_UNSEALED", where, "the row has no sequence and no chain hash: run `python -m sfe ledger seal`; an unsealed row carries no authority"))
            broken = True
        elif not broken:
            if sequence != str(index):
                findings.append(err("LEDGER_SEQUENCE_BROKEN", where, f"sequence is {sequence!r} but this is row {index}: a row was edited, inserted, deleted or reordered"))
                broken = True
            else:
                expected = chain_value(previous, _cells(header, row))
                if chain != expected:
                    findings.append(err("LEDGER_CHAIN_BROKEN", where, "chain hash does not match the row and its predecessor: an earlier row was edited, inserted, deleted or reordered"))
                    broken = True
                else:
                    previous = chain
        recorded = row.get(spec.date_col, "")
        if len(recorded) == 10 and valid_calendar_date(recorded):
            if last_date is not None and recorded < last_date:
                findings.append(err("LEDGER_DATE_REGRESSION", where, f"{spec.date_col} {recorded} is earlier than the previous row's {last_date}: the date is the day the row was recorded, and it may not decrease"))
            last_date = recorded
    return findings


def ledger_head(header: list[str], raw_rows: list[dict[str, str]]) -> str:
    """The chain value of the last row, or GENESIS for an empty ledger (recorded in manifests)."""
    return raw_rows[-1].get(CHAIN_COL, GENESIS) if raw_rows else GENESIS


def seal_ledger(path: Path) -> list[int]:
    """Assign sequence and chain hash to the unsealed TAIL of a ledger. Sealed rows are never rewritten.

    Refuses (LedgerError) when a sealed row follows an unsealed one, when a sealed row has only one of its two columns, or when the
    sealed prefix no longer matches its own chain (someone edited it). Returns the sequence numbers assigned.
    """
    try:
        header, rows = read_csv(path)
    except CsvError as exc:
        raise LedgerError(f"{path.name}: {exc}") from exc
    missing = [c for c in (SEQ_COL, CHAIN_COL) if c not in header]
    if missing:
        raise LedgerError(f"{path.name}: header lacks {', '.join(missing)}")
    previous, sealed = GENESIS, 0
    for index, row in enumerate(rows, start=1):
        sequence, chain = row[SEQ_COL], row[CHAIN_COL]
        if sequence and chain:
            if sealed != index - 1:
                raise LedgerError(f"{path.name}: row {index} is sealed but an earlier row is not")
            if sequence != str(index):
                raise LedgerError(f"{path.name}: row {index} has sequence {sequence!r}")
            if chain != chain_value(previous, _cells(header, row)):
                raise LedgerError(f"{path.name}: row {index} does not match its chain hash; the sealed rows were edited")
            previous, sealed = chain, index
        elif sequence or chain:
            raise LedgerError(f"{path.name}: row {index} has only one of {SEQ_COL} and {CHAIN_COL}")
    if sealed == len(rows):
        return []

    text = path.read_bytes().decode("utf-8")
    reader = csv.reader(io.StringIO(text, newline=""))
    end_line = []
    for _record in reader:
        end_line.append(reader.line_num)
    kept = "\n".join(text.split("\n")[: end_line[sealed]]) + "\n"  # header + sealed rows, byte for byte

    out, assigned = io.StringIO(), []
    writer = csv.writer(out, lineterminator="\n")
    for index in range(sealed + 1, len(rows) + 1):
        row = dict(rows[index - 1])
        row[SEQ_COL] = str(index)
        row[CHAIN_COL] = chain_value(previous, _cells(header, row))
        previous = row[CHAIN_COL]
        writer.writerow([row[c] for c in header])
        assigned.append(index)
    path.write_text(kept + out.getvalue(), encoding="utf-8", newline="\n")
    return assigned


# ------------------------------------------------------------------------- Git history
def _git(root: Path, *args: str) -> subprocess.CompletedProcess[bytes]:
    """Run git with a minimal environment so a user's configuration cannot change what the history check sees."""
    git = shutil.which("git") or "git"
    return subprocess.run([git, "-C", str(root), *args], capture_output=True, check=False, timeout=60,
                          env={"PATH": str(Path(git).parent), "LC_ALL": "C", "HOME": "/nonexistent", "GIT_CONFIG_NOSYSTEM": "1"})


def _rows_of(raw: bytes) -> tuple[list[str], list[tuple[str, ...]]]:
    header, rows = parse_csv_bytes(raw)
    return header, [tuple(row[c] for c in header) for row in rows]


def check_history(root: Path, rel: str) -> list[Finding]:
    """In a Git checkout, every commit of a ledger must only APPEND rows to the previous commit's rows.

    A header change is allowed only when the earlier version had no rows (nothing to migrate). The working-tree file is compared with
    the last commit. Outside a Git checkout the check cannot run: it reports a note, never a silent pass.
    """
    if not (root / ".git").exists() or shutil.which("git") is None:
        return [note("LEDGER_HISTORY_UNVERIFIED", rel, "not a Git checkout: append-only history was not verified (sequence and chain were)")]
    listing = _git(root, "log", "--format=%H", "--reverse", "--", rel)
    if listing.returncode == 0:
        commits = listing.stdout.decode().split()
    elif b"does not have any commits yet" in listing.stderr:
        commits = []  # a repository with no commits has no history to violate: the working file is all there is
    else:
        return [err("LEDGER_HISTORY_UNREADABLE", rel, "git log failed: " + listing.stderr.decode("utf-8", "replace").strip()[:160])]
    versions: list[tuple[str, list[str] | None, list[tuple[str, ...]]]] = []
    for commit in commits:
        shown = _git(root, "show", f"{commit}:{rel}")
        if shown.returncode != 0:
            versions.append((commit[:10], None, []))
            continue
        try:
            header, rows = _rows_of(shown.stdout)
        except CsvError as exc:
            return [err("LEDGER_HISTORY_UNREADABLE", rel, f"commit {commit[:10]} holds an unparseable ledger: {exc}")]
        versions.append((commit[:10], header, rows))
    path = root / rel
    if path.is_file():
        try:
            header, rows = _rows_of(path.read_bytes())
        except CsvError:
            return []  # the register loader reports an unparseable working file
        versions.append(("working tree", header, rows))
    else:
        versions.append(("working tree", None, []))  # deleted but not yet committed
    findings: list[Finding] = []
    for (old_label, old_header, old_rows), (new_label, new_header, new_rows) in zip(versions, versions[1:]):
        if new_header is None:
            if old_rows:
                findings.append(err("LEDGER_HISTORY_DELETED", rel, f"{new_label} deletes a ledger that held {len(old_rows)} row(s) at {old_label}"))
            continue
        if old_header is None:
            continue
        if old_header != new_header:
            if old_rows:
                findings.append(err("LEDGER_HISTORY_MIGRATION_UNATTESTED", rel, f"{new_label} changes the columns of a ledger that held {len(old_rows)} row(s) at {old_label}"))
            continue
        if new_rows[: len(old_rows)] != old_rows:
            first = next(i for i, (a, b) in enumerate(zip(old_rows, new_rows), start=1) if a != b) if len(new_rows) >= len(old_rows) else len(new_rows) + 1
            findings.append(err("LEDGER_HISTORY_REWRITTEN", rel, f"{new_label} rewrites or removes row {first} that existed at {old_label}: ledgers may only be appended to"))
    return findings


# ------------------------------------------------------------------------- external continuity pin (FR-003 residual)
def _pin_digest(payload: str) -> str:
    return sha256_bytes(payload.encode("ascii"))[:16]


def format_pin(state: dict[str, tuple[int, str]]) -> str:
    """Format a deterministic single-line pin from {ledger_name: (row_count, head_sha256)}."""
    parts = [f"{name}={rows}:{head}" for name, (rows, head) in sorted(state.items())]
    payload = " ".join(parts)
    return f"{PIN_PREFIX} {payload} digest={_pin_digest(payload)}"


def create_pin(repo: "Repo") -> str:
    """Verify every ledger's header, sequence, chain, dates and Git history, then emit an external continuity pin.

    Refuses (LedgerError) if any ledger is missing, unparseable, unsealed, tampered or history-rewritten.
    """
    from .registry import LEDGERS, REGISTERS

    state: dict[str, tuple[int, str]] = {}
    for name in sorted(LEDGERS):
        rel = REGISTERS[name][0]
        path = repo.path(rel)
        if not path.is_file():
            raise LedgerError(f"{rel}: ledger file is missing")
        try:
            header, raw_rows = read_csv(path)
        except CsvError as exc:
            raise LedgerError(f"{rel}: {exc}") from exc
        expected = repo.columns(name)
        if header != expected:
            raise LedgerError(f"{rel}: header does not match schema")
        problems = [f for f in check_ledger(rel, header, raw_rows, LEDGERS[name]) + check_history(repo.root, rel) if f.severity == "error"]
        if problems:
            raise LedgerError(f"{rel}: refusing to pin a broken ledger ({problems[0].code}: {problems[0].message})")
        state[name] = (len(raw_rows), ledger_head(header, raw_rows))
    return format_pin(state)


def parse_pin(text: str, expected_ledgers: set[str] | frozenset[str] | None = None) -> dict[str, tuple[int, str]]:
    """Parse and strictly validate a pin line. Raises LedgerError on any syntax, set or integrity mismatch."""
    from .registry import LEDGERS

    wanted = set(LEDGERS) if expected_ledgers is None else set(expected_ledgers)
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    if len(lines) != 1:
        raise LedgerError("ledger pin must be a single non-empty line")
    tokens = lines[0].split()
    if len(tokens) < 3 or tokens[0] != PIN_PREFIX or not tokens[-1].startswith("digest="):
        raise LedgerError(f"ledger pin must start with '{PIN_PREFIX}' and end with 'digest=<16 hex>'")
    claimed_digest = tokens[-1].split("=", 1)[1]
    if not _PIN_DIGEST_RE.fullmatch(claimed_digest):
        raise LedgerError("ledger pin digest is malformed")
    body_tokens = tokens[1:-1]
    payload = " ".join(body_tokens)
    if _pin_digest(payload) != claimed_digest:
        raise LedgerError("ledger pin digest does not match its body (corrupted or edited pin)")
    parsed: dict[str, tuple[int, str]] = {}
    for token in body_tokens:
        if "=" not in token:
            raise LedgerError(f"malformed pin entry {token!r}")
        name, spec = token.split("=", 1)
        if ":" not in spec or name in parsed:
            raise LedgerError(f"malformed or duplicate pin entry {token!r}")
        rows_str, head = spec.split(":", 1)
        if not re.fullmatch(r"\d+", rows_str) or not HEX64_RE.fullmatch(head):
            raise LedgerError(f"invalid row count or chain hash in pin entry {token!r}")
        rows = int(rows_str)
        if rows == 0 and head != GENESIS:
            raise LedgerError(f"{name}: pin specifies 0 rows with a non-genesis head")
        if rows > 0 and head == GENESIS:
            raise LedgerError(f"{name}: pin specifies {rows} row(s) with genesis head")
        parsed[name] = (rows, head)
    if set(parsed) != wanted:
        raise LedgerError(f"pin covers {{{', '.join(sorted(parsed))}}} instead of expected ledgers {{{', '.join(sorted(wanted))}}}")
    return parsed


def is_inside_repo(repo_root: Path, candidate: Path) -> bool:
    """True when `candidate` resolves inside `repo_root` (a pin kept inside the repo is not an independent anchor)."""
    return candidate.resolve().is_relative_to(repo_root.resolve())


def resolve_pin(repo_root: Path, pin_arg: str | Path | None = None) -> tuple[dict[str, tuple[int, str]] | None, list[Finding]]:
    """Resolve an external pin from `pin_arg` or SFE_LEDGER_PIN. Refuses pin files inside the repository."""
    if pin_arg is not None:
        raw: str | Path | None = pin_arg
        source_label = "pin"
    elif PIN_ENV in os.environ:
        raw = os.environ[PIN_ENV]
        source_label = PIN_ENV
    else:
        return None, []

    if isinstance(raw, str):
        stripped = raw.strip()
        if not stripped:
            return None, [err("LEDGER_PIN_INVALID", source_label, "ledger pin is empty")]
        if stripped.startswith(PIN_PREFIX + " ") or stripped == PIN_PREFIX:
            try:
                return parse_pin(stripped), []
            except LedgerError as exc:
                return None, [err("LEDGER_PIN_INVALID", source_label, str(exc))]
        pin_path = Path(stripped)
    else:
        pin_path = Path(raw)

    if is_inside_repo(repo_root, pin_path):
        return None, [err("LEDGER_PIN_INSIDE_REPO", str(pin_path),
                          "a ledger pin file must live OUTSIDE the repository so rewriting the repository cannot rewrite its anchor")]
    if not pin_path.is_file():
        return None, [err("LEDGER_PIN_INVALID", str(pin_path),
                          f"ledger pin file does not exist (pass a valid external file path or an inline '{PIN_PREFIX} ...' pin)")]
    try:
        text = pin_path.read_text(encoding="utf-8")
        return parse_pin(text), []
    except (OSError, UnicodeDecodeError, LedgerError) as exc:
        return None, [err("LEDGER_PIN_INVALID", str(pin_path), str(exc))]


def check_pin(repo: "Repo", pin_arg: str | Path | None = None, *, require: bool = False) -> list[Finding]:
    """Verify every ledger extends the externally pinned checkpoint.

    - When a pin IS supplied, it is ALWAYS enforced (even if a ledger is now empty — catching full truncation).
    - When NO pin is supplied: if all ledgers are empty, no anchor is needed; if any ledger holds rows,
      `require=True` (release / release verify) fails closed with LEDGER_PIN_REQUIRED, and `require=False`
      (validate) reports LEDGER_CONTINUITY_UNANCHORED as a warning (error under --strict).
    """
    from .registry import LEDGERS, REGISTERS

    current_rows: dict[str, list[dict[str, str]] | None] = {}
    for name in sorted(LEDGERS):
        path = repo.path(REGISTERS[name][0])
        if not path.is_file():
            current_rows[name] = None
            continue
        try:
            _header, rows = read_csv(path)
            current_rows[name] = rows
        except (OSError, CsvError):
            current_rows[name] = None

    parsed, pin_findings = resolve_pin(repo.root, pin_arg)
    if pin_findings:
        return pin_findings

    any_rows = any(bool(rows) for rows in current_rows.values() if rows is not None)
    if parsed is None:
        if not any_rows:
            return []
        if require:
            return [err("LEDGER_PIN_REQUIRED", "reviews",
                        f"ledgers hold rows and no external ledger pin was supplied (--pin or {PIN_ENV}): a hash chain alone cannot detect tail truncation, so this operation fails closed")]
        return [warn("LEDGER_CONTINUITY_UNANCHORED", "reviews",
                     f"ledgers hold rows and no external ledger pin was supplied (--pin or {PIN_ENV}): a hash chain alone cannot detect tail truncation outside Git")]

    findings: list[Finding] = []
    for name in sorted(LEDGERS):
        rel = REGISTERS[name][0]
        rows = current_rows[name]
        if rows is None:
            continue  # register loader already reports missing/corrupt ledger
        pinned_rows, pinned_head = parsed[name]
        if len(rows) < pinned_rows:
            findings.append(err("LEDGER_PIN_TRUNCATED", rel,
                                f"ledger has {len(rows)} row(s) but the external pin requires at least {pinned_rows}: the ledger tail was truncated"))
        elif pinned_rows > 0 and rows[pinned_rows - 1].get(CHAIN_COL) != pinned_head:
            findings.append(err("LEDGER_PIN_REWRITTEN", rel,
                                f"row {pinned_rows} does not match the pinned chain head: earlier ledger rows were rewritten"))
    return findings


def write_pin_file(repo: "Repo", destination: Path) -> str:
    """Create a pin from the verified ledgers and write it to `destination` outside the repository."""
    if is_inside_repo(repo.root, destination):
        raise LedgerError(f"{destination}: refusing to write a ledger pin inside the repository (keep it outside so it stays independent)")
    pin = create_pin(repo)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(pin + "\n", encoding="utf-8", newline="\n")
    return pin
