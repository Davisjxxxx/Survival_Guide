"""The approved package: everything an approval rests on, hashed as one (findings FR-009, FR-010, FR-029).

An approval used to bind to the entry's own text (scripts/sfe/entries.py content_sha256). The page, though, prints more than that: the
captions and credits of its images, the claims and sources behind its text, the species and specimen records its plate stands on.
Those could change after approval and leave the approval standing (FABLE-REVIEW-001, probes P16, P17, P21).

The package is the closure of one revision of one entry:

    entry          the front matter (minus the workflow fields) and the normalised body, and the revision
    classification the review subjects the entry requires, why, and the digest of each subject's definition (the checklist reviewers use)
    claims         the full row of every claim the entry cites (text, locator, source, evidence date, verification)
    sources        the full row of every source those claims and the entry cite (edition, origin, retrieval, local copy hash)
    assets         the full manifest row of every cited image, and the SHA-256 of the file itself, not the one the manifest claims
    taxa/specimens the records those images stand on

Its digest is SHA-256 over a canonical JSON form. Any change to any of it, one printed character of a caption included, is a different
digest, so every approval and review bound to the old one is stale. A change OUTSIDE the closure never touches the digest.

A review packet is that package, stored in the repository (reviews/packets/) and cited by path and file hash from each decision that
rests on it. The gate re-derives the digest from the stored packet and compares it with the entry's current digest, so what the
reviewer was shown is on record. It proves what was put in front of the reviewer, not that the reviewer read it.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .assets import safe_relative_path
from .common import sha256_bytes, sha256_file
from .entries import WORKFLOW_FIELDS, Entry, canonical_body, claim_ids_of

PACKAGE_VERSION = 1
PACKET_VERSION = 1
PACKET_DIR = "reviews/packets/"
EVIDENCE_DIR = "reviews/evidence/"
# Columns that are bookkeeping, not content. Everything else in a row is material: a new column is bound by default (fail closed).
CLAIM_NON_MATERIAL = frozenset({"_row", "entry_ids", "notes"})  # entry_ids is derived: another entry citing a claim must not stale this one
ROW_NON_MATERIAL = frozenset({"_row"})


def canonical_json(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def digest_of(value: Any) -> str:
    return sha256_bytes(canonical_json(value))


def _view(row: dict[str, Any], drop: frozenset[str] = ROW_NON_MATERIAL) -> dict[str, Any]:
    return {key: value for key, value in row.items() if key not in drop}


def definition_sha256(definition: dict[str, Any]) -> str:
    """Digest of a review subject's definition: a checklist that changes after a review makes that review stale."""
    return digest_of(definition)


def file_sha256(repo_root: Path, rel: str | None) -> str | None:
    """SHA-256 of a repo file named by a register, or None when the path is empty, unsafe or absent."""
    if not rel or not safe_relative_path(rel):
        return None
    path = repo_root / rel
    return sha256_file(path) if path.is_file() else None


def asset_record(asset_id: str, *, assets: dict[str, dict[str, Any]], taxa: dict[str, dict[str, Any]],
                 specimens: dict[str, dict[str, Any]], repo_root: Path) -> dict[str, Any]:
    """One image as an audit or an approval sees it: its manifest row, the real file hash, and the records it stands on."""
    row = assets.get(asset_id)
    if row is None:
        return {"unresolved": True}
    record: dict[str, Any] = {
        "manifest": _view(row),
        "file_sha256_actual": file_sha256(repo_root, row.get("local_path")),
        "rights_evidence_sha256_actual": file_sha256(repo_root, row.get("rights_evidence_path")),
    }
    if row.get("taxon_id"):
        taxon = taxa.get(row["taxon_id"])
        record["taxon"] = _view(taxon) if taxon else {"unresolved": True}
    if row.get("specimen_id"):
        specimen = specimens.get(row["specimen_id"])
        record["specimen"] = _view(specimen) if specimen else {"unresolved": True}
    return record


def asset_record_digest(asset_id: str, **kwargs: Any) -> str:
    return digest_of(asset_record(asset_id, **kwargs))


def build_package(entry: Entry, *, claims: dict[str, dict[str, Any]], sources: dict[str, dict[str, Any]], assets: dict[str, dict[str, Any]],
                  taxa: dict[str, dict[str, Any]], specimens: dict[str, dict[str, Any]], repo_root: Path,
                  classification: dict[str, Any]) -> dict[str, Any]:
    """The closure of one revision of one entry. Unresolved references are recorded as such, so resolving one later changes the digest."""
    fm = entry.fm
    claim_ids = sorted(claim_ids_of(fm))
    source_ids = set(fm["source_ids"])
    asset_ids = sorted(set(fm["photo_ids"]) | set(fm["illustration_ids"]))
    for claim_id in claim_ids:
        if claim_id in claims:
            source_ids.add(claims[claim_id]["source_id"])
    records = {asset_id: asset_record(asset_id, assets=assets, taxa=taxa, specimens=specimens, repo_root=repo_root) for asset_id in asset_ids}
    taxon_ids = {fm["taxon_id"]} if fm.get("taxon_id") else set()
    specimen_ids: set[str] = set()
    for asset_id in asset_ids:
        row = assets.get(asset_id) or {}
        if row.get("taxon_id"):
            taxon_ids.add(row["taxon_id"])
        if row.get("specimen_id"):
            specimen_ids.add(row["specimen_id"])
            specimen = specimens.get(row["specimen_id"])
            if specimen and specimen.get("taxon_id"):
                taxon_ids.add(specimen["taxon_id"])
    unresolved = {"unresolved": True}
    return {
        "package_version": PACKAGE_VERSION,
        "entry": {
            "id": fm["id"], "revision": fm["revision"],
            "front_matter": {key: value for key, value in fm.items() if key not in WORKFLOW_FIELDS},
            "body": canonical_body(entry.body),
        },
        "classification": classification,
        "claims": {cid: (_view(claims[cid], CLAIM_NON_MATERIAL) if cid in claims else unresolved) for cid in claim_ids},
        "sources": {sid: (_view(sources[sid]) if sid in sources else unresolved) for sid in sorted(source_ids)},
        "assets": records,
        "taxa": {tid: (_view(taxa[tid]) if tid in taxa else unresolved) for tid in sorted(taxon_ids)},
        "specimens": {sid: (_view(specimens[sid]) if sid in specimens else unresolved) for sid in sorted(specimen_ids)},
    }


def package_digest(package: dict[str, Any]) -> str:
    return digest_of(package)


# ------------------------------------------------------------------------------------- packets
def packet_relpath(entry_id: str, revision: int, digest: str) -> str:
    return f"{PACKET_DIR}{entry_id}/r{revision}-{digest[:16]}.json"


def packet_bytes(package: dict[str, Any], digest: str) -> bytes:
    """The stored form: a pure function of the package, so the same package always yields the same bytes."""
    document = {"packet_version": PACKET_VERSION, "package_sha256": digest, "package": package}
    return (json.dumps(document, sort_keys=True, indent=2, ensure_ascii=False) + "\n").encode("utf-8")


def write_packet(repo_root: Path, package: dict[str, Any], digest: str) -> tuple[str, str]:
    """Store the packet (never overwriting a different one) and return (repo-relative path, SHA-256 of its bytes)."""
    rel = packet_relpath(package["entry"]["id"], package["entry"]["revision"], digest)
    data = packet_bytes(package, digest)
    path = repo_root / rel
    if path.exists():
        if path.read_bytes() != data:
            raise RuntimeError(f"{rel} already exists with different content")
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
    return rel, sha256_bytes(data)


def load_packet(repo_root: Path, rel: str | None, claimed_sha: str | None) -> tuple[dict[str, Any] | None, tuple[str, str] | None]:
    """Read a stored packet and verify it. Returns (document, None) or (None, (code, why))."""
    if not rel or not claimed_sha:
        return None, ("REVIEW_PACKET_MISSING", "the row cites no packet (packet_path and packet_sha256), so what the reviewer saw is not on record")
    if not safe_relative_path(rel) or not rel.startswith(PACKET_DIR) or not rel.endswith(".json"):
        return None, ("REVIEW_PACKET_INVALID", f"packet_path {rel!r} must be a relative .json path under {PACKET_DIR}")
    path = repo_root / rel
    if not path.is_file():
        return None, ("REVIEW_PACKET_MISSING", f"{rel} does not exist")
    raw = path.read_bytes()
    if sha256_bytes(raw) != claimed_sha:
        return None, ("REVIEW_PACKET_HASH_MISMATCH", f"{rel} does not match the packet_sha256 recorded in the ledger: the stored packet was changed")
    try:
        document = json.loads(raw)
    except ValueError:
        return None, ("REVIEW_PACKET_INVALID", f"{rel} is not valid JSON")
    if (not isinstance(document, dict) or set(document) != {"packet_version", "package_sha256", "package"}
            or document["packet_version"] != PACKET_VERSION or not isinstance(document["package"], dict)):
        return None, ("REVIEW_PACKET_INVALID", f"{rel} is not a version {PACKET_VERSION} review packet")
    if package_digest(document["package"]) != document["package_sha256"]:
        return None, ("REVIEW_PACKET_DIGEST_MISMATCH", f"{rel}: the digest it states is not the digest of the package it holds")
    return document, None


def check_evidence(repo_root: Path, rel: str | None, claimed_sha: str | None) -> tuple[str, str] | None:
    """None when the evidence file exists under reviews/evidence/ and matches its recorded hash, else (code, why)."""
    if not rel or not claimed_sha:
        return "EVIDENCE_MISSING", "no evidence file is linked (evidence_path and evidence_sha256)"
    if not safe_relative_path(rel) or not rel.startswith(EVIDENCE_DIR):
        return "EVIDENCE_PATH_INVALID", f"evidence_path {rel!r} must be a relative path under {EVIDENCE_DIR}"
    path = repo_root / rel
    if not path.is_file():
        return "EVIDENCE_MISSING", f"{rel} does not exist"
    if sha256_file(path) != claimed_sha:
        return "EVIDENCE_HASH_MISMATCH", f"{rel} does not match the evidence_sha256 recorded in the ledger"
    return None
