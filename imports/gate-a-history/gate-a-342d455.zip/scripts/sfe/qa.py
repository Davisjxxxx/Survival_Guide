"""PDF quality gates, using poppler only (pdfinfo, pdffonts, pdftotext, pdftohtml, pdftoppm).

Poppler is a single apt package (poppler-utils) and is invoked as separate processes.
Checks are deliberately mechanical: they prove the layout rules were applied (labels,
order, margins, fonts, bookmarks), not that any content is true or safe.
"""
from __future__ import annotations

import html
import os
import re
import shutil
import subprocess
import unicodedata
from pathlib import Path
from typing import Any, Callable, Iterable

from PIL import Image, ImageChops

from .common import Finding, err, warn

_ENV = {**os.environ, "TZ": "UTC", "LC_ALL": "C"}
STANDARD_ORDER = ("WHAT", "WHERE", "WHEN", "IDENTIFY", "MATERIALS", "STEPS", "CHECK", "FAILURE", "REGIONAL", "SOURCES")
_PAGE = re.compile(r'<page width="([\d.]+)" height="([\d.]+)">')
_WORD = re.compile(r'<word xMin="([\d.]+)" yMin="([\d.]+)" xMax="([\d.]+)" yMax="([\d.]+)">(.*?)</word>')


class ToolMissing(RuntimeError):
    """A required poppler tool is not installed."""


def _tool(name: str) -> str:
    path = shutil.which(name)
    if not path:
        raise ToolMissing(f"{name} not found; install poppler-utils")
    return path


def _run(cmd: list[str]) -> str:
    proc = subprocess.run(cmd, capture_output=True, text=True, check=False, env=_ENV, timeout=180)
    if proc.returncode != 0:
        raise RuntimeError(f"{Path(cmd[0]).name} failed: {proc.stderr.strip()[:300]}")
    return proc.stdout


def tool_versions() -> dict[str, str]:
    versions: dict[str, str] = {}
    for tool in ("pdfinfo", "pdftotext", "pdftoppm"):
        proc = subprocess.run([_tool(tool), "-v"], capture_output=True, text=True, check=False, env=_ENV)
        first = (proc.stderr or proc.stdout).strip().splitlines()
        versions[tool] = first[0] if first else "unknown"
    return versions


def pdfinfo(pdf: Path) -> dict[str, str]:
    info: dict[str, str] = {}
    for line in _run([_tool("pdfinfo"), "-isodates", str(pdf)]).splitlines():
        if ":" in line:
            key, value = line.split(":", 1)
            info[key.strip()] = value.strip()
    return info


def pdffonts(pdf: Path) -> list[dict[str, str]]:
    lines = _run([_tool("pdffonts"), str(pdf)]).splitlines()
    if len(lines) < 2:
        return []
    spans = [(m.start(), m.end()) for m in re.finditer(r"-+", lines[1])]
    names = ["name", "type", "encoding", "emb", "sub", "uni", "object"]
    return [{n: line[s:e].strip() for n, (s, e) in zip(names, spans)} for line in lines[2:] if line.strip()]


def words(pdf: Path) -> list[dict[str, Any]]:
    markup = _run([_tool("pdftotext"), "-bbox", str(pdf), "-"])
    found: list[dict[str, Any]] = []
    for number, chunk in enumerate(re.split(r"(?=<page )", markup)[1:], start=1):
        size = _PAGE.search(chunk)
        width, height = (float(size.group(1)), float(size.group(2))) if size else (0.0, 0.0)
        for x0, y0, x1, y1, text in _WORD.findall(chunk):
            found.append({"page": number, "x0": float(x0), "y0": float(y0), "x1": float(x1), "y1": float(y1),
                          "text": html.unescape(text), "pw": width, "ph": height})
    return found


def outline(pdf: Path) -> list[str]:
    xml = _run([_tool("pdftohtml"), "-xml", "-stdout", "-i", "-q", str(pdf)])
    return [html.unescape(t).strip() for t in re.findall(r'<item page="\d+">(.*?)</item>', xml)]


def link_texts(pdf: Path) -> list[str]:
    """Text wrapped by an internal link annotation (poppler's pdftohtml exposes these)."""
    xml = _run([_tool("pdftohtml"), "-xml", "-stdout", "-i", "-q", str(pdf)])
    return [html.unescape(t).strip() for t in re.findall(r'<text [^>]*><a href="[^"]*">(.*?)</a></text>', xml)]


def named_destinations(pdf: Path) -> set[str]:
    return set(re.findall(r'"([^"]+)"\s*$', _run([_tool("pdfinfo"), "-dests", str(pdf)]), re.M))


def page_texts(pdf: Path) -> list[str]:
    """The text of each page in content-stream order (`pdftotext -raw`): for TeX output, the order the page was typeset in."""
    pages = _run([_tool("pdftotext"), "-raw", str(pdf), "-"]).split("\f")
    if pages and not pages[-1].strip():
        pages.pop()
    return pages


def squash(text: str) -> str:
    """Letters and digits only: case-folded, compatibility-normalised (ligatures) and without accents, so hyphenation, quotes, spacing and the
    way an accent is composed cannot make a printed string look absent. It is a presence test, not a typography test."""
    return "".join(ch for ch in unicodedata.normalize("NFKD", text).casefold() if ch.isalnum())


def missing_text(pdf: Path, expected: Iterable[tuple[str, str]], *, furniture: Callable[[int], Iterable[str]] = lambda page: ()) -> list[tuple[str, str]]:
    """The (field, text) pairs whose text is NOT in the PDF's text layer: the check that a layout did not drop approved text.

    `furniture(page)` is the running text of that page (the footer). It is removed first, because a string that the footer also prints (the zone,
    the zone's title) would otherwise be found there after the page itself had dropped it. Each expected string must then be matched by an
    occurrence of its own: the longest are matched first and each match is consumed, so a short string cannot be satisfied by a longer one that
    contains it, and two fields with the same text need two occurrences."""
    pages = []
    for number, text in enumerate(page_texts(pdf), start=1):
        page = squash(text)
        for piece in furniture(number):
            needle = squash(piece)
            at = page.rfind(needle) if needle else -1
            if at >= 0:  # the footer is the last thing on the page, so its LAST occurrence is the one to remove
                page = page[:at] + page[at + len(needle):]
        pages.append(page)
    remaining = "".join(pages)
    wanted = [(index, path, text, squash(text)) for index, (path, text) in enumerate(expected)]
    missing: list[int] = []
    for index, _path, _text, needle in sorted((w for w in wanted if w[3]), key=lambda w: (-len(w[3]), w[0])):
        at = remaining.find(needle)
        if at < 0:
            missing.append(index)
        else:
            remaining = remaining[:at] + "\x00" + remaining[at + len(needle):]
    absent = set(missing)
    return [(path, text) for index, path, text, _needle in wanted if index in absent]


def render_png(pdf: Path, out_png: Path, *, dpi: int = 110, gray: bool = False) -> Path:
    command = [_tool("pdftoppm"), "-r", str(dpi), "-png", "-singlefile"] + (["-gray"] if gray else []) + [str(pdf), str(out_png.with_suffix(""))]
    _run(command)
    if gray:  # some poppler builds write an RGB PNG for -gray; store a true single-channel image
        Image.open(out_png).convert("L").save(out_png, format="PNG")
    return out_png


def _ink_stats(png: Path, edge_px: int) -> dict[str, float]:
    gray = Image.open(png).convert("L")
    low, high = gray.getextrema()
    histogram = gray.histogram()
    total = sum(histogram)
    dark = sum(histogram[:128]) / total
    width, height = gray.size
    edges = [gray.crop((0, 0, width, edge_px)), gray.crop((0, height - edge_px, width, height)),
             gray.crop((0, 0, edge_px, height)), gray.crop((width - edge_px, 0, width, height))]
    edge_ink = sum(sum(e.histogram()[:200]) for e in edges) / sum(sum(e.histogram()) for e in edges)
    rgb = Image.open(png).convert("RGB")
    chroma = max(hi for hi in (ImageChops.difference(a, b).getextrema()[1] for a, b in
                               ((rgb.getchannel(0), rgb.getchannel(1)), (rgb.getchannel(1), rgb.getchannel(2)), (rgb.getchannel(0), rgb.getchannel(2)))))
    return {"min": float(low), "max": float(high), "dark_fraction": dark, "edge_ink_fraction": edge_ink, "max_chroma": float(chroma)}


def check_pdf(pdf: Path, *, expect: dict[str, Any], preview_dir: Path | None = None) -> tuple[list[Finding], dict[str, Any]]:
    """Run the layout gates on one PDF. `expect` carries the profile and proof parameters."""
    where = pdf.name
    findings: list[Finding] = []
    info = pdfinfo(pdf)
    facts: dict[str, Any] = {"pages": int(info.get("Pages", "0")), "page_size": info.get("Page size", ""),
                             "producer": info.get("Producer", ""), "tagged": info.get("Tagged", "")}

    if expect["pages"] is None:
        if facts["pages"] < 1:
            findings.append(err("PDF_PAGE_COUNT", where, "PDF has no pages"))
    elif facts["pages"] != expect["pages"]:
        findings.append(err("PDF_PAGE_COUNT", where, f"expected {expect['pages']} page(s), found {facts['pages']}"))
    size = re.match(r"([\d.]+) x ([\d.]+) pts", info.get("Page size", ""))
    if not size or abs(float(size.group(1)) - expect["width_pt"]) > 1 or abs(float(size.group(2)) - expect["height_pt"]) > 1:
        findings.append(err("PDF_PAGE_SIZE", where, f"expected {expect['width_pt']} x {expect['height_pt']} pt, found {info.get('Page size')!r}"))
    title = info.get("Title", "")
    for token in expect["title_contains"]:
        if token not in title:
            findings.append(err("PDF_TITLE", where, f"metadata Title must contain {token!r}, found {title!r}"))
    if info.get("CreationDate") != expect["creation_iso"]:
        findings.append(err("PDF_CREATION_DATE", where, f"CreationDate must be {expect['creation_iso']} (fixed build epoch), found {info.get('CreationDate')!r}"))
    if info.get("Tagged", "").lower() != "yes":
        findings.append(warn("PDF_UNTAGGED", where, "PDF is not tagged: accessibility tagging is unavailable with TeX Live 2023 pdfLaTeX (open decision, see BUILD_PLAN.md)"))

    fonts = pdffonts(pdf)
    facts["fonts"] = sorted({f["name"].split("+", 1)[-1] for f in fonts})
    if not fonts:
        findings.append(err("PDF_NO_FONTS", where, "no fonts found"))
    for font in fonts:
        if font.get("emb") != "yes":
            findings.append(err("PDF_FONT_NOT_EMBEDDED", where, f"font {font.get('name')} is not embedded"))
        if font.get("type", "").startswith("Type 3"):
            findings.append(warn("PDF_TYPE3_FONT", where, f"font {font.get('name')} is Type 3 (poor print/scale quality)"))

    word_list = words(pdf)
    text = re.sub(r"\s+", " ", " ".join(w["text"] for w in word_list))
    for needle in expect["required_text"]:
        if needle not in text:
            findings.append(err("PDF_REQUIRED_TEXT", where, f"required text not found in PDF: {needle!r}"))
    findings += _check_order(word_list, where)
    findings += _check_margins(word_list, where, expect["margin_pt"])

    bookmarks = outline(pdf)
    facts["outline_items"] = len(bookmarks)
    if len(bookmarks) < expect["min_outline"]:
        findings.append(err("PDF_BOOKMARKS_MISSING", where, f"expected at least {expect['min_outline']} bookmarks, found {len(bookmarks)}"))
    for label in expect["bookmark_labels"]:
        if label not in bookmarks:
            findings.append(err("PDF_BOOKMARK_LABEL", where, f"bookmark {label!r} not found"))

    links, destinations = link_texts(pdf), named_destinations(pdf)
    facts["internal_links"], facts["named_destinations"] = len(links), len(destinations)
    for needle in expect.get("linked_text", []):
        if needle not in links:
            findings.append(err("PDF_LINK_MISSING", where, f"no clickable link wraps the text {needle!r}"))
    for name in expect.get("named_destinations", []):
        if name not in destinations:
            findings.append(err("PDF_DESTINATION_MISSING", where, f"named destination {name!r} does not exist (a link to it would be dead)"))
    raw = pdf.read_bytes()
    language = expect.get("language")
    if language and not re.search(rb"/Lang ?\(" + re.escape(language.encode()) + rb"\)", raw):
        findings.append(err("PDF_LANGUAGE", where, f"document language {language!r} is not set in the catalog"))
    if not re.search(rb"/DisplayDocTitle true", raw):
        findings.append(err("PDF_DISPLAY_TITLE", where, "the viewer is not told to display the document title"))
    facts["language"] = language

    if preview_dir is not None:
        preview_dir.mkdir(parents=True, exist_ok=True)
        for mode, gray in (("color", False), ("gray", True)):
            png = render_png(pdf, preview_dir / f"{pdf.stem}_{mode}.png", gray=gray)
            stats = _ink_stats(png, edge_px=int(0.25 * 110))
            facts[f"render_{mode}"] = {k: round(v, 4) for k, v in stats.items()}
            if not 0.01 <= stats["dark_fraction"] <= 0.5:
                findings.append(err("PDF_RENDER_INK", f"{png.name}", f"dark-pixel fraction {stats['dark_fraction']:.3f} outside 0.01-0.5 (blank or flooded page?)"))
            if stats["min"] > 60 or stats["max"] < 200:
                findings.append(err("PDF_RENDER_CONTRAST", f"{png.name}", f"luminance range {stats['min']:.0f}-{stats['max']:.0f} is too narrow"))
            if gray and stats["max_chroma"] != 0:
                findings.append(err("PDF_GRAY_PREVIEW_HAS_COLOR", f"{png.name}", "the grayscale preview must contain no colour"))
            if not gray and expect.get("expect_color") and stats["max_chroma"] < 40:
                findings.append(err("PDF_COLOR_PREVIEW_HAS_NO_COLOR", f"{png.name}", "the colour preview must actually use colour, or the grayscale comparison proves nothing"))
            if stats["edge_ink_fraction"] > 0.002:
                findings.append(err("PDF_RENDER_EDGE_INK", f"{png.name}", f"content reaches the page edge (edge ink {stats['edge_ink_fraction']:.4f})"))
    return findings, facts


def _first_positions(word_list: list[dict[str, Any]]) -> dict[str, tuple[float, float]]:
    positions: dict[str, tuple[float, float]] = {}
    for word in sorted(word_list, key=lambda w: (w["page"], w["y0"], w["x0"])):
        if word["text"] in STANDARD_ORDER and word["text"] not in positions and (word["y1"] - word["y0"]) < 30:
            positions[word["text"]] = (word["page"] * 10_000 + word["y0"], word["x0"])
    return positions


def _check_order(word_list: list[dict[str, Any]], where: str) -> list[Finding]:
    """Section titles must read WHAT .. SOURCES: each is below the previous, or level with it and to its right."""
    positions = _first_positions(word_list)
    missing = [label for label in STANDARD_ORDER if label not in positions]
    if missing:
        return [err("PDF_SECTION_MISSING", where, f"section labels not found: {', '.join(missing)}")]
    found: list[Finding] = []
    for earlier, later in zip(STANDARD_ORDER, STANDARD_ORDER[1:]):
        (y1, x1), (y2, x2) = positions[earlier], positions[later]
        if not (y2 > y1 + 4 or (abs(y2 - y1) <= 4 and x2 > x1)):
            found.append(err("PDF_SECTION_ORDER", where, f"{later} appears before {earlier}; the standard entry order was broken"))
    return found


def _check_margins(word_list: list[dict[str, Any]], where: str, margin: float) -> list[Finding]:
    found: list[Finding] = []
    for w in word_list:
        if (w["y1"] - w["y0"]) > 30:  # rotated watermark words have tall axis-aligned boxes
            continue
        if w["x0"] < margin or w["y0"] < margin or w["x1"] > w["pw"] - margin or w["y1"] > w["ph"] - margin:
            found.append(err("PDF_OUTSIDE_MARGIN", where, f"word {w['text']!r} lies outside the {margin:.0f}pt safe margin"))
            break
    return found
