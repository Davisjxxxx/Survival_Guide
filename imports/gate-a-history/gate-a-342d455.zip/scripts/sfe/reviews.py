"""The review gates: approvals, independent safety reviews and image audits (findings FR-002, FR-003, FR-004, FR-005, FR-010, FR-029).

What changed from RUN-002, and why (FABLE-REVIEW-001):

* A review row used to name its reviewer and role in free text, and the gate believed it. Now a row names a REGISTRY id and the capacity it
  acts in; the registry (reviews/reviewers.csv) alone decides kind, capacity, domains and dates (scripts/sfe/reviewers.py).
* Decisions used to be ordered by a typed date and by file position, and only a failure on a tagged topic in the same revision counted.
  Now ledgers are ordered by sequence (scripts/sfe/ledger.py), and an unresolved adverse decision blocks the WHOLE entry (or image)
  whatever its subjects, revision, hash or tags.
* A failure used to be cleared by any later pass. Now it is cleared only by a `resolution` row in the same ledger that names it, links an
  evidence file, and comes from the reviewer who recorded it or a registered adjudicator, never from the entry's author. A pass counts
  only if it comes after the entry's latest adverse or resolution row.
* An approval used to bind to the entry text. Now every decision binds to the package digest (scripts/sfe/package.py) and cites the stored
  packet it was made on.

Nothing here decides whether content is true. It refuses to treat a decision as authoritative unless the identity, the binding and the
order of the evidence say it is.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from . import identification, package as package_mod
from .common import Finding, err
from .entries import Entry
from .registry import ReviewClass

if TYPE_CHECKING:  # pragma: no cover
    from .validate import Context

ADVERSE = frozenset({"fail", "conditional", "rejected", "withdrawn"})
LEDGER_INFO: dict[str, dict[str, str]] = {
    "approvals": {"id": "approval_id", "date": "decided_on", "pass": "approved", "owner": "entry_id"},
    "safety_audit": {"id": "audit_id", "date": "reviewed_on", "pass": "pass", "owner": "entry_id"},
    "image_audit": {"id": "audit_id", "date": "reviewed_on", "pass": "pass", "owner": "asset_id"},
}
VIEW_NAMES = tuple(LEDGER_INFO)


@dataclass
class LedgerView:
    """One review ledger after its resolutions have been validated."""

    name: str
    label: str
    rows: list[dict[str, Any]]
    by_id: dict[str, dict[str, Any]]
    resolutions: dict[str, dict[str, Any]] = field(default_factory=dict)  # target id -> the VALID resolution row that clears it
    voided: set[str] = field(default_factory=set)
    findings: list[Finding] = field(default_factory=list)


def describe(row: dict[str, Any], id_col: str) -> str:
    return f"{row[id_col]} ({row['decision']} by {row['reviewer_id']} as {row['capacity']}, row {row['_row']})"


def entity_rows(view: LedgerView, key: str, value: str) -> list[dict[str, Any]]:
    """Every non-resolution row about one entry or asset, voided rows included (they still mark where a barrier fell)."""
    return [row for row in view.rows if row["decision"] != "resolution" and row.get(key) == value]


def barrier(view: LedgerView, rows: list[dict[str, Any]]) -> int:
    """The row number after which a pass must have been recorded to count: the latest adverse row or resolution of an adverse row.

    Voiding a row that was not adverse moves nothing; voiding or clearing an adverse one does (the work after it has to be redone).
    """
    id_col = LEDGER_INFO[view.name]["id"]
    marks = [0]
    for row in rows:
        if row["decision"] in ADVERSE:
            marks.append(row["_row"])
            resolution = view.resolutions.get(row[id_col])
            if resolution is not None:
                marks.append(resolution["_row"])
    return max(marks)


# ------------------------------------------------------------------------- ledger-level analysis
def analyze_ledger(ctx: "Context", name: str) -> LedgerView:
    """Validate every resolution and every reference in one ledger. Findings here are global: they stop the whole release."""
    info = LEDGER_INFO[name]
    rows, label = ctx.reg[name], ctx.labels[name]
    by_id: dict[str, dict[str, Any]] = {}
    for row in rows:
        by_id.setdefault(row[info["id"]], row)
    view = LedgerView(name, label, rows, by_id)
    entries = {e.entry_id: e for e in ctx.entries}
    for row in rows:
        if row["decision"] == "resolution":
            _validate_resolution(ctx, view, row, entries)
    for row in rows:
        if row["decision"] == "resolution" or row[info["id"]] in view.voided:
            continue
        where = f"{label}:row {row['_row']}"
        if info["owner"] == "entry_id":
            if row.get("entry_id") not in entries:
                view.findings.append(err("LEDGER_ROW_ORPHAN", where, f"entry_id {row.get('entry_id')!r} is not an entry in this repository: a typo, or an entry that was removed (void the row to retire it)"))
        elif row.get("asset_id") not in ctx.assets:
            view.findings.append(err("LEDGER_ROW_ORPHAN", where, f"asset_id {row.get('asset_id')!r} is not in assets/manifest.csv (void the row to retire it)"))
    return view


def _validate_resolution(ctx: "Context", view: LedgerView, row: dict[str, Any], entries: dict[str, Entry]) -> None:
    info = LEDGER_INFO[view.name]
    where = f"{view.label}:row {row['_row']}"
    problems: list[tuple[str, str]] = []
    target_id = row["resolves_id"]
    target = view.by_id.get(target_id)
    kind, capacity = row["resolution_kind"], row["capacity"]
    if target is None or target is row:
        problems.append(("RESOLUTION_TARGET_UNKNOWN", f"{target_id!r} is not a row of this ledger"))
        target = None
    else:
        if target["_row"] >= row["_row"]:
            problems.append(("RESOLUTION_TARGET_NOT_EARLIER", f"{target_id} is recorded at row {target['_row']}, not before this resolution"))
        if target["decision"] == "resolution":
            problems.append(("RESOLUTION_TARGET_IS_RESOLUTION", f"{target_id} is itself a resolution"))
        elif kind == "cleared" and target["decision"] not in ADVERSE:
            problems.append(("RESOLUTION_TARGET_NOT_ADVERSE", f"{target_id} is a {target['decision']} row: only an adverse decision is cleared (use kind void for a row entered in error)"))
        if target_id in view.resolutions:
            problems.append(("RESOLUTION_DUPLICATE", f"{target_id} was already resolved by row {view.resolutions[target_id]['_row']}"))
        about = row.get(info["owner"])
        if about and about != target.get(info["owner"]):
            problems.append(("RESOLUTION_ENTITY_MISMATCH", f"the resolution names {about} but {target_id} concerns {target.get(info['owner'])}"))
    why = package_mod.check_evidence(ctx.repo.root, row.get("evidence_path"), row.get("evidence_sha256"))
    if why:
        problems.append(("RESOLUTION_EVIDENCE_INVALID", why[1]))
    registration, refusal = ctx.registry.lookup(row["reviewer_id"], capacity, row[info["date"]])
    if registration is None:
        problems.append(("RESOLUTION_UNAUTHORIZED", refusal[1] if refusal else "reviewer is not registered"))
    elif target is not None:
        if kind == "cleared":
            if not (capacity == "adjudicator" or row["reviewer_id"] == target["reviewer_id"]):
                problems.append(("RESOLUTION_UNAUTHORIZED", "an adverse decision is cleared by the reviewer who recorded it or by a registered adjudicator"))
        elif capacity not in ("adjudicator", "registrar"):
            problems.append(("RESOLUTION_UNAUTHORIZED", "only a registered adjudicator or the registrar can void a row"))
        entry = entries.get(target.get("entry_id") or "")
        if entry is not None and entry.fm.get("authored_by") == row["reviewer_id"]:
            problems.append(("RESOLUTION_UNAUTHORIZED", "the entry's author cannot clear or void a decision about their own entry"))
    for code, message in problems:
        view.findings.append(err(code, where, message))
    if not problems:
        view.resolutions[target_id] = row
        if kind == "void":
            view.voided.add(target_id)


# ----------------------------------------------------------------------------- reviewer eligibility
def reviewer_problems(ctx: "Context", row: dict[str, Any], cls: ReviewClass, subject: str | None, specialty: set[str], author: str | None,
                      when: str) -> list[tuple[str, str]]:
    """Why `row`'s reviewer cannot satisfy `cls` (empty list: they can). Only the REGISTRY decides; the row's own words count for nothing."""
    reviewer, capacity = row["reviewer_id"], row["capacity"]
    registration, refusal = ctx.registry.lookup(reviewer, capacity, when)
    if registration is None:
        return [refusal] if refusal else [("REVIEWER_NOT_REGISTERED", f"{reviewer} is not registered")]
    out: list[tuple[str, str]] = []
    if capacity not in cls.capacities:
        out.append(("REVIEWER_CAPACITY_NOT_PERMITTED", f"capacity {capacity!r} cannot satisfy {cls.name} (needs {' or '.join(cls.capacities)})"))
    if registration.kind not in cls.kinds:
        out.append(("REVIEWER_KIND_NOT_PERMITTED", f"{reviewer} is registered as {registration.kind}; {cls.name} needs {' or '.join(cls.kinds)}"))
    if subject is not None and subject not in registration.domains and "ALL" not in registration.domains:
        out.append(("REVIEWER_DOMAIN_NOT_COVERED", f"{reviewer} is not registered for {subject}"))
    if cls.specialty_domains:
        for domain in sorted(specialty):
            if domain not in registration.domains:
                out.append(("REVIEWER_DOMAIN_NOT_COVERED", f"{reviewer} is not registered for {domain}"))
    if author is not None and reviewer == author:
        out.append(("REVIEWER_IS_AUTHOR", f"{reviewer} authored this entry and cannot review it"))
    return out


def packet_problem(ctx: "Context", row: dict[str, Any]) -> tuple[str, str] | None:
    """The stored packet a decision cites must exist, match its hash, hold the digest the row states, and be for this entry and revision."""
    document, why = package_mod.load_packet(ctx.repo.root, row.get("packet_path"), row.get("packet_sha256"))
    if why:
        return why
    assert document is not None
    if document["package_sha256"] != row.get("package_sha256"):
        return "REVIEW_PACKET_DIGEST_MISMATCH", "the packet holds a different package than the row's package_sha256"
    shown = document["package"].get("entry", {})
    if shown.get("id") != row.get("entry_id") or shown.get("revision") != row.get("revision"):
        return "REVIEW_PACKET_INVALID", "the packet was made for a different entry or revision"
    return None


def _why(rejected: list[tuple[dict[str, Any], list[tuple[str, str]]]], id_col: str) -> str:
    if not rejected:
        return ""
    parts = [f"{row[id_col]}: " + "; ".join(f"{code} ({message})" for code, message in reasons) for row, reasons in rejected[:4]]
    return " Rejected: " + " | ".join(parts) + ("" if len(rejected) <= 4 else f" | and {len(rejected) - 4} more")


# ------------------------------------------------------------------------------- the approval gate
def check_approvals(ctx: "Context", entry: Entry, digest: str) -> list[Finding]:
    view, fm, where = ctx.views["approvals"], entry.fm, entry.rel
    found: list[Finding] = []
    rows = entity_rows(view, "entry_id", fm["id"])
    acting = [row for row in rows if row["approval_id"] not in view.voided]
    for row in acting:
        if row["decision"] in ADVERSE and row["approval_id"] not in view.resolutions:
            found.append(err("APPROVAL_NOT_CURRENT", where, f"{describe(row, 'approval_id')} blocks this entry until a resolution row clears it"))
    approved = [row for row in acting if row["decision"] == "approved" and row["revision"] == fm["revision"]]
    if not approved:
        found.append(err("APPROVAL_MISSING", where, f"no approved row in reviews/approvals.csv for {fm['id']} revision {fm['revision']}"))
        return found
    matching = [row for row in approved if row["package_sha256"] == digest]
    if not matching:
        found.append(err("APPROVAL_STALE", where, "the entry, or something it rests on (a claim, a source, an image, a record), changed after approval; a new approval row bound to the new package digest is required"))
        return found
    after = barrier(view, rows)
    fresh = [row for row in matching if row["_row"] > after]
    if not fresh:
        found.append(err("APPROVAL_NOT_CURRENT", where, f"every approval of this package was recorded before the latest adverse decision or resolution (row {after}); a new approval is required after it"))
        return found
    editorial: list[dict[str, Any]] = []
    rejected: list[tuple[dict[str, Any], list[tuple[str, str]]]] = []
    for row in fresh:
        reasons: list[tuple[str, str]] = []
        if row["capacity"] != "chatgpt_editorial":
            reasons.append(("REVIEWER_CAPACITY_NOT_PERMITTED", f"capacity {row['capacity']!r} is not chatgpt_editorial"))
        else:
            registration, refusal = ctx.registry.lookup(row["reviewer_id"], "chatgpt_editorial", row["decided_on"])
            if registration is None:
                reasons.append(refusal or ("REVIEWER_NOT_REGISTERED", f"{row['reviewer_id']} is not registered"))
        problem = packet_problem(ctx, row)
        if problem:
            reasons.append(problem)
        if reasons:
            rejected.append((row, reasons))
        else:
            editorial.append(row)
    if not editorial:
        found.append(err("APPROVAL_NOT_CHATGPT_EDITORIAL", where, "approved_by_chatgpt needs a current approval by a registered chatgpt_editorial reviewer, with its packet on record." + _why(rejected, "approval_id")))
        return found
    if fm.get("editorial_reviewer") not in {row["reviewer_id"] for row in editorial}:
        found.append(err("EDITORIAL_REVIEWER_MISMATCH", where, f"editorial_reviewer {fm.get('editorial_reviewer')!r} is not the reviewer of the current editorial approval ({', '.join(sorted({r['reviewer_id'] for r in editorial}))})"))
    return found


# ----------------------------------------------------------------------------------- the safety gate
def check_safety(ctx: "Context", entry: Entry, subjects: dict[str, list[str]], digest: str) -> list[Finding]:
    """Every required subject needs, from every required review class, a current pass by an eligible registered reviewer."""
    fm, where = entry.fm, entry.rel
    if ctx.policy is None or ctx.cls_policy is None:
        return [err("SAFETY_POLICY_UNAVAILABLE", where,
                    "the review policy (schemas/hazard_topics.yaml) or the classification policy (schemas/classification_policy.yaml) is missing or invalid, so no safety review can be accepted")]
    view = ctx.views["safety_audit"]
    found: list[Finding] = []
    rows = entity_rows(view, "entry_id", fm["id"])
    acting = [row for row in rows if row["audit_id"] not in view.voided]
    for row in acting:
        if row["decision"] in ADVERSE and row["audit_id"] not in view.resolutions:
            found.append(err("SAFETY_FAILURE_UNRESOLVED", where, f"{describe(row, 'audit_id')} blocks this entry, whatever its subject, revision or hash, until a resolution row clears it"))
            for subject in row["subjects"]:
                if subject not in subjects:
                    found.append(err("SAFETY_FAILURE_REPORTS_UNCLASSIFIED_HAZARD", where, f"{row['audit_id']} reports {subject}, which the classification did not require for this entry: it must be added so it is reviewed"))
    current_rows = [row for row in acting if row["revision"] == fm["revision"]]
    if not current_rows:
        found.append(err("SAFETY_AUDIT_MISSING", where, "this entry needs independent reviews in reviews/safety-audit.csv for its current revision"))
        return found
    after = barrier(view, rows)
    for subject in subjects:
        definition = ctx.subjects.get(subject)
        if definition is None:  # an unknown TAG never gets here (it is reported as HAZARD_TAG_UNKNOWN); a required subject must be defined
            found.append(err("SAFETY_SUBJECT_UNDEFINED", where, f"{subject} is required for this entry but is defined in neither schemas/hazard_topics.yaml nor schemas/classification_policy.yaml"))
        else:
            found += _safety_subject(ctx, entry, subject, definition, current_rows, after, digest, view)
    return found


def specialty_domains(ctx: "Context", entry: Entry, subject: str) -> set[str]:
    """Extra registered domains a domain expert needs for this subject: for an identification subject, the kind of every taxon the entry
    and its images concern (ID-<KIND>), so a reviewer of mushrooms cannot clear a plant profile."""
    return identification.entry_domains(ctx, entry) if subject in identification.IDENTIFICATION_SUBJECTS else set()


def _safety_subject(ctx: "Context", entry: Entry, subject: str, definition: dict[str, Any], current_rows: list[dict[str, Any]], after: int,
                    digest: str, view: LedgerView) -> list[Finding]:
    fm, where = entry.fm, entry.rel
    cover = [row for row in current_rows if row["decision"] == "pass" and subject in row["subjects"]]
    if not cover:
        return [err("SAFETY_TOPIC_UNCOVERED", where, f"{subject}: no passing safety review lists this subject")]
    bound = [row for row in cover if row["package_sha256"] == digest]
    if not bound:
        return [err("SAFETY_AUDIT_NOT_PASSING_OR_STALE", where,
                    f"{subject}: no passing review matches revision {fm['revision']} and the current package digest ({len(cover)} row(s) cover it; they are bound to other content)")]
    author, specialty = fm.get("authored_by"), specialty_domains(ctx, entry, subject)
    chosen: dict[str, dict[str, Any]] = {}
    superseded: list[str] = []
    missing: list[tuple[str, list[tuple[dict[str, Any], list[tuple[str, str]]]]]] = []
    for class_name in definition["required_reviews"]:
        cls = ctx.policy.classes[class_name]  # type: ignore[union-attr]
        eligible: list[dict[str, Any]] = []
        rejected: list[tuple[dict[str, Any], list[tuple[str, str]]]] = []
        for row in bound:
            reasons = list(reviewer_problems(ctx, row, cls, subject, specialty, author, row["reviewed_on"]))
            problem = packet_problem(ctx, row)
            if problem:
                reasons.append(problem)
            if reasons:
                rejected.append((row, reasons))
            else:
                eligible.append(row)
        current_ok = [row for row in eligible if row["_row"] > after]
        if current_ok:
            chosen[class_name] = max(current_ok, key=lambda r: r["_row"])
        elif eligible:
            superseded.append(class_name)
        else:
            missing.append((class_name, rejected))
    found: list[Finding] = []
    if superseded:
        found.append(err("SAFETY_AUDIT_SUPERSEDED", where,
                         f"{subject}: reviews recorded before the latest adverse decision or resolution (row {after}) no longer count; needs new passing review(s) from: {', '.join(superseded)}"))
    for class_name, rejected in missing:
        cls = ctx.policy.classes[class_name]  # type: ignore[union-attr]
        found.append(err("SAFETY_REVIEW_ROLE_MISSING", where,
                         f"{subject}: no current passing {class_name} review (acceptable: a registered {' or '.join(cls.kinds)} with capacity {' or '.join(cls.capacities)}, "
                         f"whose domains cover {subject}, who is not the author); it must be bound to revision {fm['revision']} and the current package digest."
                         + _why(rejected, "audit_id")))
    if not (superseded or missing):
        ids = [row["reviewer_id"] for row in chosen.values()]
        if len(set(ids)) < len(ids):
            found.append(err("SAFETY_REVIEWERS_NOT_DISTINCT", where, f"{subject}: one reviewer ({', '.join(sorted({i for i in ids if ids.count(i) > 1}))}) fills more than one required review class; the reviews must be independent"))
    return found


# ------------------------------------------------------------------------------- the image-audit gate
def check_asset_audit(ctx: "Context", asset_id: str, where: str) -> list[Finding]:
    """One cited image: an unresolved failure blocks; a pass must match the file AND the record, tick all four checks, and be by an eligible reviewer."""
    asset = ctx.assets.get(asset_id)
    if not asset or not asset.get("sha256"):
        return [err("ASSET_NOT_PUBLISHABLE", where, f"{asset_id} has no catalogued file hash")]
    view = ctx.views["image_audit"]
    found: list[Finding] = []
    rows = entity_rows(view, "asset_id", asset_id)
    acting = [row for row in rows if row["audit_id"] not in view.voided]
    for row in acting:
        if row["decision"] in ADVERSE and row["audit_id"] not in view.resolutions:
            found.append(err("IMAGE_AUDIT_FAILURE_UNRESOLVED", where, f"{describe(row, 'audit_id')} blocks every entry that cites {asset_id} until a resolution row clears it"))
    if not acting:
        found.append(err("IMAGE_AUDIT_MISSING", where, f"no image audit for {asset_id}"))
        return found
    after = barrier(view, rows)
    passes = [row for row in acting if row["decision"] == "pass"]
    fresh = [row for row in passes if row["_row"] > after]
    if not fresh:
        found.append(err("IMAGE_AUDIT_NOT_PASSING", where, f"{asset_id} has no passing image audit after its latest failure or resolution"))
        return found
    file_digest = package_mod.file_sha256(ctx.repo.root, asset.get("local_path")) or asset["sha256"]
    record = package_mod.asset_record_digest(asset_id, assets=ctx.assets, taxa=ctx.taxa, specimens=ctx.specimens, repo_root=ctx.repo.root)
    matching = [row for row in fresh if row["asset_sha256"] == file_digest and row["record_sha256"] == record]
    if not matching:
        found.append(err("IMAGE_AUDIT_STALE", where, f"image audit for {asset_id} does not match the current file hash and record (a caption, name, licence, credit, taxon or specimen changed, or the file was replaced)"))
        return found
    complete = [row for row in matching if all(row[c] is True for c in ("provenance_checked", "license_checked", "identification_checked", "caption_alt_checked"))]
    if not complete:
        found.append(err("IMAGE_AUDIT_CHECKS_INCOMPLETE", where, f"every image audit of {asset_id} that matches leaves one of provenance, licence, identification, caption and alt text unchecked"))
        return found
    class_name = "domain_expert" if asset.get("role") == "verified_diagnostic" else "image_reviewer"
    cls = ctx.policy.classes.get(class_name) if ctx.policy else None
    if cls is None:
        return found + [err("SAFETY_POLICY_UNAVAILABLE", where, "the review policy is missing or invalid, so no image audit can be accepted")]
    specialty = asset_specialty_domains(ctx, asset)
    eligible: list[dict[str, Any]] = []
    rejected: list[tuple[dict[str, Any], list[tuple[str, str]]]] = []
    for row in complete:
        reasons = reviewer_problems(ctx, row, cls, None, specialty, None, row["reviewed_on"])
        if reasons:
            rejected.append((row, reasons))
        else:
            eligible.append(row)
    if not eligible:
        found.append(err("IMAGE_AUDIT_REVIEWER_INVALID", where,
                         f"no image audit of {asset_id} is by a registered {' or '.join(cls.kinds)} with capacity {' or '.join(cls.capacities)} ({class_name})." + _why(rejected, "audit_id")))
    return found


def asset_specialty_domains(ctx: "Context", asset: dict[str, Any]) -> set[str]:
    """Extra registered domains the auditor of this image needs (the kind of the taxon it shows)."""
    return identification.asset_domains(ctx, asset)
