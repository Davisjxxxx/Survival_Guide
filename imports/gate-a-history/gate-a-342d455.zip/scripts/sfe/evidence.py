"""Claim completeness: how much evidence an entry must cite (finding FR-008).

At RUN-003 a claim was required only for a procedure step or a unit-table row. An empty `procedure` and an empty `claim_ids` therefore exempted
a medical or species entry from every claim rule: P19a (a medical entry with no claim reached `published`) and P19b (a species profile with no
claim reached `approved`). The diagnostic features, look-alikes, contraindications, evacuation thresholds and processing restrictions were
untraced prose.

Now the rules come from `schemas/claim_policy.yaml` (engineering initial version, decision D17) and apply from status `researched`:

    every entry          at least `min_claims` registered claims cited, at least `min_steps` procedure steps; a hard floor of ONE claim in code
    by entry type        the cited claims include one of each `required_claim_types` (identification for a species profile, medical for medical guidance)
    medical steps        every step of a medical entry cites a claim of an accepted step type (no unsupported medical procedure)
    bound fields         a non-empty safety-bearing field is bound, in `field_claims`, to a claim whose type the policy accepts for that field
    text triggers        text that makes an edibility or identification statement, or gives medical instruction, needs a claim of the matching
                         type, whatever the entry type

What this does not prove: a claim of the right type shows that a source was cited for a field, not that the source supports the sentence, and
binding is per field, not per list item. The domain expert's review remains the control for that. The trigger words are a safety net that a
paraphrase evades; the type rules do not depend on them.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from .common import Finding, err, load_yaml, nonempty
from .entries import MEDICAL_FIELDS, SPECIES_FIELDS, Entry, claim_ids_of
from .registry import Repo

if TYPE_CHECKING:  # pragma: no cover
    from .validate import Context

POLICY_REL = "schemas/claim_policy.yaml"
FLOOR_MIN_CLAIMS = 1  # an entry that cites no claim traces nothing: no policy may lower this
RULE_KEYS = ("min_claims", "min_steps", "required_claim_types", "step_claim_types")
# The text-bearing entry fields a claim may be bound to (never an id, a date, a status or a list of links).
BINDABLE = frozenset({"what_it_is", "find_where", "find_when", "diagnostic_features", "lookalikes_or_confusions", "materials", "conditions_and_limits",
                      "dangers", "materials_tools", "environmental_constraints", "inspection_acceptance_criteria", "failure_modes",
                      "hazard_boundaries"}) | (SPECIES_FIELDS - {"taxon_id"}) | (MEDICAL_FIELDS - {"evidence_date"})


@dataclass(frozen=True)
class EntryRule:
    min_claims: int
    min_steps: int
    required_claim_types: tuple[str, ...]
    step_claim_types: tuple[str, ...]


@dataclass
class ClaimPolicy:
    entry_types: dict[str, EntryRule]
    bound_fields: dict[str, dict[str, tuple[str, ...]]]
    text_triggers: dict[str, tuple[str, ...]]


def load_claim_policy(repo: Repo, trigger_ids: set[str] | None) -> tuple[ClaimPolicy | None, list[Finding]]:
    """Load and validate schemas/claim_policy.yaml. `trigger_ids` are the classification triggers (None when that policy is itself unusable).

    Returns (None, findings) when the policy cannot be trusted: no entry above `draft` is then approvable."""
    path = repo.path(POLICY_REL)
    if not path.is_file():
        return None, [err("CLAIM_POLICY_MISSING", POLICY_REL, "the claim policy is missing, so no entry can be checked for claim completeness")]
    try:
        data = load_yaml(path.read_text(encoding="utf-8"))
    except Exception as exc:
        return None, [err("CLAIM_POLICY_INVALID", POLICY_REL, f"not valid strict YAML: {exc}")]
    if not isinstance(data, dict) or data.get("schema_version") != 1:
        return None, [err("CLAIM_POLICY_INVALID", POLICY_REL, "expected a mapping with schema_version 1")]
    findings: list[Finding] = []

    def bad(message: str) -> None:
        findings.append(err("CLAIM_POLICY_INVALID", POLICY_REL, message))

    entry_schema, claim_schema = repo.schema("entry.schema.json"), repo.schema("claim.schema.json")
    type_names = set(entry_schema["properties"]["entry_type"]["enum"])
    claim_types = set(claim_schema["properties"]["claim_type"]["enum"])

    def types_of(where: str, value: Any, *, allow_empty: bool) -> tuple[str, ...]:
        if not isinstance(value, list) or not all(isinstance(item, str) for item in value) or (not value and not allow_empty):
            bad(f"{where}: must be a {'list' if allow_empty else 'non-empty list'} of claim types")
            return ()
        for item in value:
            if item not in claim_types:
                bad(f"{where}: {item!r} is not a claim type ({', '.join(sorted(claim_types))})")
        return tuple(value)

    rules: dict[str, EntryRule] = {}
    table = data.get("entry_types")
    if not isinstance(table, dict):
        bad("entry_types: must be a mapping")
        table = {}
    for missing in sorted(type_names - set(table)):
        findings.append(err("CLAIM_POLICY_INCOMPLETE", POLICY_REL, f"entry_types: no row for {missing}: an unlisted type would be treated as needing no evidence"))
    for extra in sorted(set(table) - type_names):
        bad(f"entry_types: unexpected row {extra!r}")
    for name in sorted(type_names & set(table)):
        row = table[name]
        if not isinstance(row, dict) or set(row) != set(RULE_KEYS):
            bad(f"entry_types.{name}: needs exactly {', '.join(RULE_KEYS)}")
            continue
        minimum, steps = row["min_claims"], row["min_steps"]
        if not (isinstance(minimum, int) and not isinstance(minimum, bool) and minimum >= FLOOR_MIN_CLAIMS):
            bad(f"entry_types.{name}.min_claims: must be an integer of at least {FLOOR_MIN_CLAIMS} (an entry that cites no claim traces nothing)")
            continue
        if not (isinstance(steps, int) and not isinstance(steps, bool) and steps >= 0):
            bad(f"entry_types.{name}.min_steps: must be an integer of at least 0")
            continue
        rules[name] = EntryRule(minimum, steps, types_of(f"entry_types.{name}.required_claim_types", row["required_claim_types"], allow_empty=True),
                                types_of(f"entry_types.{name}.step_claim_types", row["step_claim_types"], allow_empty=True))

    bound: dict[str, dict[str, tuple[str, ...]]] = {}
    fields_table = data.get("bound_fields")
    if not isinstance(fields_table, dict):
        bad("bound_fields: must be a mapping")
        fields_table = {}
    for name, fields in fields_table.items():
        if name not in type_names or not isinstance(fields, dict):
            bad(f"bound_fields: {name!r} is not an entry type with a mapping of fields")
            continue
        bound[name] = {}
        for field_name, accepted in fields.items():
            if field_name not in BINDABLE:
                bad(f"bound_fields.{name}: {field_name!r} is not a text field of an entry")
                continue
            bound[name][field_name] = types_of(f"bound_fields.{name}.{field_name}", accepted, allow_empty=False)

    triggers: dict[str, tuple[str, ...]] = {}
    triggers_table = data.get("text_triggers")
    if not isinstance(triggers_table, dict):
        bad("text_triggers: must be a mapping")
        triggers_table = {}
    for trigger_id, accepted in triggers_table.items():
        if trigger_ids is not None and trigger_id not in trigger_ids:
            bad(f"text_triggers: {trigger_id!r} is not a trigger of the classification policy")
            continue
        triggers[trigger_id] = types_of(f"text_triggers.{trigger_id}", accepted, allow_empty=False)
    if findings:
        return None, findings
    return ClaimPolicy(rules, bound, triggers), []


def check_entry(ctx: "Context", entry: Entry, trigger_hits: dict[str, str]) -> list[Finding]:
    """The claim-completeness findings of one entry at `researched` or above. `trigger_hits` maps each classification trigger that matched to its text."""
    fm, where = entry.fm, entry.rel
    policy = ctx.claim_policy
    if policy is None:
        return [err("CLAIM_POLICY_UNAVAILABLE", where, "the claim policy is missing or invalid, so this entry cannot be checked for claim completeness")]
    entry_type = fm["entry_type"]
    rule = policy.entry_types.get(entry_type)
    if rule is None:
        return [err("CLAIM_POLICY_UNAVAILABLE", where, f"the claim policy has no row for entry type {entry_type!r}")]
    found: list[Finding] = []
    # A rejected claim is not evidence. An unverified one still counts at `researched`; from `verified` the verified-claims gate refuses it.
    cited = {cid: ctx.claims[cid] for cid in sorted(claim_ids_of(fm)) if cid in ctx.claims and ctx.claims[cid]["status"] != "rejected"}
    types = {claim["claim_type"] for claim in cited.values()}
    if len(cited) < rule.min_claims:
        found.append(err("ENTRY_CLAIMS_INSUFFICIENT", where, f"it cites {len(cited)} usable registered claim(s); a {entry_type} needs at least {rule.min_claims} "
                                                              "(an empty claim list or procedure exempts nothing)"))
    if len(fm["procedure"]) < rule.min_steps:
        found.append(err("PROCEDURE_STEPS_INSUFFICIENT", where, f"it has {len(fm['procedure'])} procedure step(s); a {entry_type} needs at least {rule.min_steps}"))
    for needed in rule.required_claim_types:
        if needed not in types:
            found.append(err("ENTRY_CLAIM_TYPE_MISSING", where, f"a {entry_type} must cite at least one {needed} claim; the claims it cites are of type "
                                                                f"{', '.join(sorted(types)) or 'none'}"))
    if rule.step_claim_types:
        for step in fm["procedure"]:
            if not any(cid in cited and cited[cid]["claim_type"] in rule.step_claim_types for cid in step["claim_ids"]):
                found.append(err("STEP_CLAIM_TYPE_MISSING", where, f"step {step['step']} must cite a claim of type {' or '.join(rule.step_claim_types)} "
                                                                  f"(a {entry_type} step has no unsupported procedure)"))

    bindings = fm.get("field_claims") or {}
    required = policy.bound_fields.get(entry_type, {})
    for field_name, ids in sorted(bindings.items()):
        if field_name not in BINDABLE:
            found.append(err("FIELD_CLAIMS_UNKNOWN_FIELD", where, f"field_claims names {field_name!r}, which is not a text field of an entry"))
        elif not nonempty(fm.get(field_name)):
            found.append(err("FIELD_CLAIMS_EMPTY_FIELD", where, f"field_claims binds claims to {field_name!r}, which is empty"))
    for field_name, accepted in sorted(required.items()):
        if not nonempty(fm.get(field_name)):
            continue
        ids = bindings.get(field_name) or []
        if not ids:
            found.append(err("FIELD_CLAIM_MISSING", where, f"{field_name} is not bound to any claim: field_claims needs a claim of type {' or '.join(accepted)} for it"))
        elif not any(cid in cited and cited[cid]["claim_type"] in accepted for cid in ids):
            seen = ", ".join(sorted({cited[cid]["claim_type"] for cid in ids if cid in cited})) or "none usable"
            found.append(err("FIELD_CLAIM_TYPE_MISMATCH", where, f"{field_name} needs a claim of type {' or '.join(accepted)}; the claims bound to it are of type {seen}"))
    for trigger_id, accepted in sorted(policy.text_triggers.items()):
        if trigger_id in trigger_hits and not (types & set(accepted)):
            found.append(err("TEXT_CLAIM_MISSING", where, f"the text mentions {trigger_hits[trigger_id]!r} ({trigger_id}), which needs a cited claim of type "
                                                          f"{' or '.join(accepted)}; none of the claims cited is"))
    return found
