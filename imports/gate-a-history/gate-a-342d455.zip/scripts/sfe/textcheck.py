"""Usable text: does a mandatory safety or verification field say anything? (finding FR-021)

At RUN-003 the verified rung only tested that a safety field was not blank, so `abort_if: "N/A"`, `verify: "-"` and `dangers: ["n/a"]` passed
(probe P27) and handoff section 10 ("every physical procedure has a step, a verification check and an error or abort condition") was met by filler.

`assess(text)` returns why a text carries no usable information, or None. It is layered, and no layer is a length test alone:

    EMPTY / NO_LETTERS_OR_DIGITS   blank, or only punctuation ("-", "--", "...", "???")
    NULL_LIKE                      a null phrase after case, punctuation, quotes and dashes are ignored ("N/A.", "(none)", "not applicable", "tbd"),
                                   or a null lead followed by a separator ("N/A - see above", "Not applicable: reason" outside the exception form)
    PLACEHOLDER                    an unfilled template ("[insert abort condition]", "<fill in>", "to be added", "xxx", "lorem ipsum")
    REPEATED                       one character or one word repeated ("aaaa", "ok ok ok")
    TOO_SHORT                      fewer words than the field's floor (two by default; this is the review's one-word rule, never the only test)
    NO_CONTENT                     no content word once stop words and generic filler (ok, fine, check, verify, safe, stop, careful, ...) are removed

The one exception. A step's `verify` or `abort_if` may state that it does not apply, in exactly this form and no other:

    Not applicable [CLM-0007]: <justification>

where the claim is cited by that same step and the justification is itself usable (at least five words and three content words). The declaration is
printed on the card, is part of the reviewed package, and is the only way a field may say it does not apply. It is refused in every other field.

What this does not do: it cannot tell an adequate sentence from a poor one (that stays the reviewer's judgement), and its word lists are finite.
"""
from __future__ import annotations

import re
import unicodedata
from typing import Any

from .common import Finding, err, nonempty, walk_strings

CLAIM = r"(?:DUMMY-)?CLM-\d{4,}"
NOT_APPLICABLE = re.compile(rf"^\s*not\s+applicable\s*\[\s*((?-i:{CLAIM}))\s*\]\s*:\s*(.+?)\s*$", re.IGNORECASE | re.DOTALL)
_WORD = re.compile(r"[a-z0-9]+(?:['’][a-z]+)?")

# A phrase that says nothing applies, or nothing is known, after lower-casing and replacing every run of non-alphanumerics by one space.
NULL_PHRASES = frozenset({
    "n a", "na", "n a n a", "none", "nil", "null", "no", "nope", "nothing", "not applicable", "not available", "not relevant", "not required", "not needed",
    "not necessary", "not specified", "not stated", "not known", "not known yet", "unknown", "unspecified", "undetermined", "undefined", "tbd", "tba",
    "tbc", "to be determined", "to be added", "to be confirmed", "to be completed", "to be written", "todo", "to do", "pending", "see above", "see below",
    "as above", "as below", "same as above", "ditto", "etc", "and so on", "various", "misc", "miscellaneous", "none known", "none required",
    "none needed", "none applicable", "none specified", "none listed", "none stated", "no abort condition", "no abort conditions", "no abort condition applies",
    "no verification", "no verification needed", "no verification required", "no check", "no checks", "no check needed", "nothing to verify",
    "nothing to check", "nothing to abort", "no danger", "no dangers", "no hazard", "no hazards", "no risk", "no risks", "no known danger",
    "no known dangers", "no known hazard", "no known hazards", "no known risk", "no known risks", "no warning", "no warnings", "no limit", "no limits",
    "no restriction", "no restrictions", "no contraindication", "no contraindications", "no special precautions", "no precautions",
})
# A null lead followed by a separator or the end: "N/A - see above", "Not applicable: ...". A sentence that merely STARTS with the word ("None of the
# water should be brown") is a sentence and is not caught here.
NULL_LEAD = re.compile(r"^\W*(?:n\s*/\s*a|n\.\s*a\.?|na|not\s+applicable|nil|tbd|tba|todo)\s*(?:[:;,.\-–—(\[]|$)", re.IGNORECASE)
# Unfilled templates: a bracketed instruction, or filler words.
BRACKETED = re.compile(r"\[[^\]]*\]|<[^>]*>|\{[^}]*\}")
UNFILLED = re.compile(
    r"\b(?:fill\s+(?:in|me)|insert\b[^.]*\bhere|to\s+be\s+(?:added|determined|confirmed|completed|written|filled|decided)|coming\s+soon|work\s+in\s+progress|"
    r"lorem|ipsum|placeholder|asdf|qwer|blah|foobar|tbd|tba)\b|\bx{3,}\b",
    re.IGNORECASE)
STOPWORDS = frozenset({
    "a", "an", "the", "of", "to", "in", "on", "at", "by", "for", "with", "from", "into", "onto", "and", "or", "but", "if", "then", "than", "as", "so",
    "is", "are", "was", "were", "be", "been", "being", "am", "do", "does", "did", "it", "its", "this", "that", "these", "those", "there", "here", "you",
    "your", "we", "our", "they", "their", "he", "she", "his", "her", "not", "no", "can", "could", "may", "might", "must", "should", "would", "will", "shall",
    "has", "have", "had", "any", "all", "some", "when", "while", "until", "once", "after", "before", "about", "up", "out", "off", "over", "under",
})
# Words that name an action or a feeling about safety but nothing specific. A text made only of these and of stop words carries no information.
GENERIC = frozenset({
    "ok", "okay", "fine", "good", "great", "bad", "wrong", "right", "well", "safe", "safely", "unsafe", "check", "checks", "checked", "checking", "verify",
    "verified", "verification", "confirm", "confirmed", "confirmation", "ensure", "ensured", "make", "sure", "stop", "stopped", "abort", "careful",
    "carefully", "caution", "cautious", "warning", "warn", "danger", "dangers", "dangerous", "hazard", "hazards", "hazardous", "risk", "risks", "risky",
    "use", "thing", "things", "stuff", "something", "anything", "everything", "nothing", "applicable", "appropriate", "appropriately", "proper", "properly",
    "correct", "correctly", "necessary", "needed", "required", "need", "normal", "normally", "usual", "usually", "standard", "general", "generally",
    "various", "other", "others", "same", "above", "below", "see", "refer", "note", "noted", "yes", "done", "complete", "completed", "finished", "ready",
    "look", "looks", "seems", "seem", "as", "per", "etc", "step", "steps", "condition", "conditions", "issue", "issues", "problem", "problems",
    # light verbs and adverbs: "Stay safe", "Take care", "Keep going" say nothing; with an object ("Keep away from flames") the object carries the information
    "stay", "keep", "remain", "take", "get", "go", "let", "put", "try", "handle", "proceed", "continue", "follow", "care", "avoid", "wait", "watch", "mind",
    "beware", "always", "never", "just", "please", "kindly", "best", "being", "taking", "keeping", "staying", "going", "doing", "making",
})
# Every word of a null phrase is generic too ("None; n/a", "no restriction none stated"): a text made only of such words says nothing.
GENERIC = GENERIC | frozenset(w for phrase in NULL_PHRASES for w in phrase.split() if len(w) >= 2 and w not in STOPWORDS)
MIN_WORDS = 2
EXCEPTION_MIN_WORDS, EXCEPTION_MIN_CONTENT = 5, 3


def words_of(text: str) -> list[str]:
    folded = unicodedata.normalize("NFKC", text).lower().replace("’", "'")
    return _WORD.findall(folded)


def _phrase(text: str) -> str:
    return " ".join(re.sub(r"[^a-z0-9]+", " ", unicodedata.normalize("NFKC", text).lower()).split())


def content_words(words: list[str]) -> list[str]:
    """Words that can carry information: not a stop word, not generic filler, and not a stray letter (a digit string is information: "15 psi")."""
    return [w for w in words if w not in STOPWORDS and w not in GENERIC and (len(w) >= 2 or w.isdigit())]


def _repeats(words: list[str]) -> bool:
    """One word, or one short run of words (up to three), said again and again: "ok ok ok", "n/a n/a n/a", "aaaa"."""
    if len(words) == 1:
        return bool(re.fullmatch(r"(.)\1{2,}", words[0]))
    return any(len(words) % size == 0 and len(words) // size >= 2 and words == words[:size] * (len(words) // size) for size in (1, 2, 3))


def assess(text: Any, *, minimum_words: int = MIN_WORDS) -> str | None:
    """Why `text` carries no usable information (a short code), or None when it does."""
    if not isinstance(text, str) or not text.strip():
        return "EMPTY"
    words = words_of(text)
    if not words:
        return "NO_LETTERS_OR_DIGITS"
    if _phrase(text) in NULL_PHRASES or NULL_LEAD.match(unicodedata.normalize("NFKC", text)):
        return "NULL_LIKE"
    if UNFILLED.search(text) or (BRACKETED.search(text) and not content_words(words_of(BRACKETED.sub(" ", text)))):
        return "PLACEHOLDER"
    if _repeats(words):
        return "REPEATED"
    if len(words) < minimum_words:
        return "TOO_SHORT"
    if not content_words(words):
        return "NO_CONTENT"
    return None


def parse_not_applicable(text: Any) -> tuple[str, str] | None:
    """(claim id, justification) when `text` is exactly the exception form, else None."""
    match = NOT_APPLICABLE.match(text) if isinstance(text, str) else None
    return (match.group(1), match.group(2)) if match else None


def justification_problem(justification: str) -> str | None:
    words = words_of(justification)
    if assess(justification) is not None:
        return f"the justification is itself not usable ({assess(justification)})"
    if len(words) < EXCEPTION_MIN_WORDS or len(content_words(words)) < EXCEPTION_MIN_CONTENT:
        return f"the justification needs at least {EXCEPTION_MIN_WORDS} words and {EXCEPTION_MIN_CONTENT} content words to say WHY the field does not apply"
    return None


REASONS = {
    "EMPTY": "it is blank", "NO_LETTERS_OR_DIGITS": "it holds no letter or digit", "NULL_LIKE": "it only says nothing applies or nothing is known",
    "PLACEHOLDER": "it is an unfilled placeholder", "REPEATED": "it repeats one character or word", "TOO_SHORT": "it is too short to say anything",
    "NO_CONTENT": "it holds no content word, only filler",
}

# The mandatory text fields the verified rung already requires to be non-empty, with the fewest words each may have. `na` marks the step fields
# that may use the exception form; no other field may.
STEP_FIELDS = {"action": (MIN_WORDS, False), "verify": (MIN_WORDS, True), "abort_if": (MIN_WORDS, True)}
TYPE_TEXT = {
    "technical_procedure": {"materials_tools": 1, "inspection_acceptance_criteria": MIN_WORDS, "failure_modes": MIN_WORDS,
                            "hazard_boundaries": MIN_WORDS, "environmental_constraints": MIN_WORDS},
    "species_profile": {"scientific_name": 1, "geographic_range": 1, "phenology": 1, "regulated_or_protected_status": 1, "lookalikes_or_confusions": 1,
                        "identification_uncertainty": MIN_WORDS, "processing_restrictions": MIN_WORDS, "positive_identification_warning": MIN_WORDS,
                        "expert_identification_criteria": MIN_WORDS},
    "medical_guidance": {"audience_scope": 1, "contraindications": 1, "emergency_evacuation_threshold": MIN_WORDS, "local_emergency_service_guidance": MIN_WORDS},
}
# `dangers` is assessed on every entry that prints a danger line, hazardous or not: a printed filler line is filler wherever it sits.
DANGERS_FLOOR = MIN_WORDS


def _items(value: Any) -> list[tuple[str, Any]]:
    if isinstance(value, list):
        return [(f"[{n}]", item) for n, item in enumerate(value)]
    return [("", value)]


def check_entry(fm: dict[str, Any], where: str) -> list[Finding]:
    """FR-021 findings for one entry at `verified` or above. Blank values are reported by the older field-empty checks and skipped here."""
    found: list[Finding] = []

    def refuse(path: str, text: Any, floor: int) -> None:
        if parse_not_applicable(text) is not None:  # the exception form is legal only where the caller handled it first
            found.append(err("NOT_APPLICABLE_NOT_ALLOWED", where, f"{path}: only a step's verify or abort_if may state that it does not apply; say what is true instead"))
            return
        why = assess(text, minimum_words=floor)
        if why:
            found.append(err("FIELD_NOT_USABLE", where, f"{path} {REASONS[why]} ({why}): {str(text)[:60]!r}"))

    for step in fm["procedure"]:
        for key, (floor, na_allowed) in STEP_FIELDS.items():
            text = step[key]
            if not nonempty(text):
                continue
            path = f"step {step['step']} {key}"
            declared = parse_not_applicable(text)
            if declared is not None and na_allowed:
                claim_id, justification = declared
                weak = justification_problem(justification)
                if weak:
                    found.append(err("NOT_APPLICABLE_JUSTIFICATION_WEAK", where, f"{path}: {weak}"))
                if claim_id not in step["claim_ids"]:
                    found.append(err("NOT_APPLICABLE_CLAIM_NOT_CITED", where, f"{path} names {claim_id}, which step {step['step']} does not cite"))
                continue
            refuse(path, text, floor)
    for suffix, item in _items(fm["dangers"]):
        if isinstance(item, str):
            refuse(f"dangers{suffix}", item, DANGERS_FLOOR)
    for key, floor in TYPE_TEXT.get(fm["entry_type"], {}).items():
        value = fm.get(key)
        if not nonempty(value):
            continue
        for suffix, item in _items(value):
            if isinstance(item, str):
                refuse(f"{key}{suffix}", item, floor)
    # The exception's location rule applies beyond the mandatory fields assessed
    # above. Check only the exact declaration here, without imposing their word
    # floors or filler rules on other text or rejecting prose that merely quotes it.
    assessed_fields = {"procedure", "dangers", *TYPE_TEXT.get(fm["entry_type"], {})}
    for path, text in walk_strings({key: value for key, value in fm.items() if key not in assessed_fields}):
        if parse_not_applicable(text) is not None:
            refuse(path, text, MIN_WORDS)
    return found
