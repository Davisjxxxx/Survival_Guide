"""Entry files: YAML front matter + Markdown body, and the approval content hash.

The content hash is what binds an approval to the exact approved text. It covers
every front-matter field EXCEPT the workflow fields (status, reviewers, approval
flag, revision) plus the normalised body, so moving an entry through the status
ladder does not invalidate its approval but any change to its content does.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .common import load_yaml, sha256_bytes

WORKFLOW_FIELDS = frozenset(
    {"status", "approved_by_chatgpt", "technical_reviewer", "editorial_reviewer", "revision"}
)
# Fields that belong to ONE entry type. They are legal only on that type: a species or medical field on another type would be approved
# text that the layout for that type never prints (FABLE-REVIEW-001 probe P20), and the type's required checks would be skipped.
SPECIES_FIELDS = frozenset({"taxon_id", "scientific_name", "taxonomic_authority", "geographic_range", "phenology", "identification_uncertainty",
                            "regulated_or_protected_status", "processing_restrictions", "positive_identification_warning",
                            "expert_identification_criteria"})
MEDICAL_FIELDS = frozenset({"audience_scope", "evidence_date", "emergency_evacuation_threshold", "contraindications",
                            "local_emergency_service_guidance"})
TYPE_EXCLUSIVE_FIELDS: dict[str, frozenset[str]] = {"species_profile": SPECIES_FIELDS, "medical_guidance": MEDICAL_FIELDS}
_FRONT_MATTER = re.compile(r"\A---\n(.*?)\n---(?:\n(.*))?\Z", re.DOTALL)


class EntryParseError(ValueError):
    """Raised when an entry file cannot be parsed into front matter + body."""


@dataclass
class Entry:
    path: Path
    rel: str
    fm: dict[str, Any]
    body: str

    @property
    def entry_id(self) -> str:
        return str(self.fm.get("id", ""))

    @property
    def content_hash(self) -> str:
        return content_sha256(self.fm, self.body)


def split_front_matter(raw: bytes) -> tuple[str, str]:
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise EntryParseError(f"not valid UTF-8: {exc}") from exc
    if "\r" in text:
        raise EntryParseError("carriage returns found; use LF line endings")
    match = _FRONT_MATTER.match(text)
    if not match:
        raise EntryParseError("file must start with a '---' front-matter fence and close it with '---'")
    return match.group(1), match.group(2) or ""


def parse_entry(raw: bytes) -> tuple[dict[str, Any], str]:
    front, body = split_front_matter(raw)
    try:
        fm = load_yaml(front)
    except Exception as exc:  # yaml errors carry useful marks; surface them verbatim
        raise EntryParseError(f"front matter is not valid strict YAML: {exc}") from exc
    if not isinstance(fm, dict):
        raise EntryParseError("front matter must be a YAML mapping")
    return fm, body


def load_entry(path: Path, root: Path) -> Entry:
    fm, body = parse_entry(path.read_bytes())
    return Entry(path=path, rel=path.relative_to(root).as_posix(), fm=fm, body=body)


def claim_ids_of(fm: dict[str, Any]) -> set[str]:
    """Every claim an entry rests on: its own list, each procedure step's, each dimension row's, and every claim bound to a field (FR-008)."""
    ids = set(fm["claim_ids"])
    for step in fm["procedure"]:
        ids.update(step["claim_ids"])
    ids.update(row["claim_id"] for row in fm.get("dimension_unit_table", []) if row["claim_id"])
    for bound in (fm.get("field_claims") or {}).values():
        ids.update(bound)
    return ids


def canonical_body(body: str) -> str:
    lines = [line.rstrip() for line in body.replace("\r\n", "\n").split("\n")]
    return "\n".join(lines).strip("\n")


def content_sha256(fm: dict[str, Any], body: str) -> str:
    payload = {key: value for key, value in fm.items() if key not in WORKFLOW_FIELDS}
    blob = json.dumps(payload, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return sha256_bytes((blob + "\n" + canonical_body(body)).encode("utf-8"))


def iter_entry_paths(content_dir: Path, zone_dirs: list[str]) -> list[Path]:
    """Entry files are every *.md in a zone directory except README.md."""
    found: list[Path] = []
    for zone_dir in zone_dirs:
        directory = content_dir / zone_dir
        if directory.is_dir():
            found.extend(
                p for p in sorted(directory.iterdir())
                if p.is_file() and p.suffix == ".md" and p.name != "README.md"
            )
    return found
