"""Identification evidence: what a species profile and the photographs under it must rest on (FABLE-REVIEW-001 finding FR-012).

At RUN-002 an identification plate passed with two catalogue rows whose view labels differed, whatever the files showed: one photograph
catalogued twice (probe P13), one file claimed for two different subjects (P13b), two photographs of an unrelated subject under a profile
of another (P14), a plate with no photograph of the target at all (P15), two profiles of one species (P32), and a diagnostic photograph
with no name, place or date (P92).

The model that replaces it has four records, each a register that the package digest covers (so a change after review stales every
approval and review that depended on it):

    taxon      research/taxa.csv        what the thing is called, what kind it is, how risky it is to get wrong
    specimen   assets/specimens.csv     the individual that was photographed: observer, date, place, habitat, and a DETERMINATION by a
                                        registered human specialist on a stated basis
    asset      assets/manifest.csv      each photograph names its taxon and its specimen
    entry      taxon_id                 a species profile is about one taxon; one profile per taxon

What this module is, and is not. It checks RECORDS. It cannot look at a photograph. Hashing detects identical bytes only: a re-encoded,
resized or cropped copy is a different file, and near-duplicate detection is still open. Nothing here claims that automated analysis
(image similarity, a classifier, a detector) establishes what an organism is: identification is a determination recorded by a registered
human specialist, and the checks below refuse every record that leaves that chain incomplete, circular or contradictory. An AI-generated
image is never identification evidence and never a photograph of a specimen.
"""
from __future__ import annotations

from collections import defaultdict
from typing import TYPE_CHECKING, Any

from .common import Finding, err, nonempty
from .registry import Repo

if TYPE_CHECKING:
    from .entries import Entry
    from .validate import Context

# Review subjects whose reviewer must also be registered for the organism group of what is shown (ID-<KIND>).
IDENTIFICATION_SUBJECTS = frozenset({"HZ-FORAGING-ID", "CLS-IDENTIFICATION"})
# A determination that rests on a preserved voucher or on a physical examination. Photographs alone are not enough for a tier A taxon.
TIER_A_BASES = frozenset({"voucher_specimen", "physical_examination"})
# A generated image is not an image of a specimen.
NOT_PHOTOGRAPHS = frozenset({"ai_generated", "rendered", "vector_drawing"})
# A plate needs at least one whole-organism or key-feature view among its target views.
ANCHOR_VIEWS = frozenset({"whole", "key_feature"})
MIN_TARGET_VIEWS = 2


def kind_domain(kind: str) -> str:
    """The registry domain that covers one kind of taxon or material: plant -> ID-PLANT."""
    return f"ID-{kind.upper()}"


def id_domains(repo: Repo) -> set[str]:
    """Every identification domain a registration may name, taken from the taxon schema's kinds so the two cannot drift apart."""
    return {kind_domain(kind) for kind in repo.schema("taxon.schema.json")["properties"]["kind"]["enum"]}


def norm_name(text: Any) -> str:
    return " ".join(str(text or "").lower().split())


# ------------------------------------------------------------------------------------------------ the registers
def check_taxa(ctx: "Context") -> list[Finding]:
    found: list[Finding] = []
    seen: dict[str, str] = {}
    for row in ctx.reg["taxa"]:
        where = f"{ctx.labels['taxa']}:row {row['_row']}"
        name = norm_name(row["scientific_name"])
        if name in seen:
            found.append(err("TAXON_NAME_DUPLICATE", where, f"{row['scientific_name']!r} is already {seen[name]}: one record per accepted name, or two profiles could describe one organism"))
        else:
            seen[name] = row["taxon_id"]
        if row["kind"] == "fungus" and row["risk_tier"] != "A":
            found.append(err("TAXON_TIER_TOO_LOW", where, f"{row['taxon_id']} is a fungus, and any fungus is risk tier A"))
    return found


def check_specimens(ctx: "Context") -> list[Finding]:
    found: list[Finding] = []
    photographers: dict[str, set[str]] = defaultdict(set)
    for asset in ctx.reg["assets"]:
        if asset.get("specimen_id") and nonempty(asset.get("credited_photographer")):
            photographers[asset["specimen_id"]].add(norm_name(asset["credited_photographer"]))
    for row in ctx.reg["specimens"]:
        where = f"{ctx.labels['specimens']}:row {row['_row']}"
        taxon = ctx.taxa.get(row["taxon_id"])
        if taxon is None:
            found.append(err("SPECIMEN_TAXON_UNKNOWN", where, f"taxon {row['taxon_id']} is not in the taxon register"))
        if row["determined_on"] < row["observed_on"]:
            found.append(err("SPECIMEN_DETERMINED_BEFORE_OBSERVED", where, f"determined_on {row['determined_on']} is before observed_on {row['observed_on']}"))
        registration, refusal = ctx.registry.lookup(row["determined_by"], "external_sme", row["determined_on"])
        if registration is None:
            why = refusal[1] if refusal else f"{row['determined_by']} is not registered"
            found.append(err("SPECIMEN_DETERMINER_NOT_QUALIFIED", where, f"{row['determined_by']} cannot determine a specimen: it needs an active registered human external_sme ({why})"))
        elif taxon is not None and kind_domain(taxon["kind"]) not in registration.domains:
            found.append(err("SPECIMEN_DETERMINER_DOMAIN_NOT_COVERED", where, f"{row['determined_by']} is not registered for {kind_domain(taxon['kind'])}, the domain of {taxon['taxon_id']}"))
        if taxon is not None and taxon["risk_tier"] == "A" and row["determination_basis"] not in TIER_A_BASES:
            found.append(err("SPECIMEN_BASIS_BELOW_TIER", where, f"{taxon['taxon_id']} is tier A: it needs a voucher or a physical examination, not {row['determination_basis']}"))
        name = ctx.registry.name_of(row["determined_by"])
        if name and norm_name(name) in photographers.get(row["specimen_id"], set()):
            found.append(err("SPECIMEN_DETERMINER_IS_PHOTOGRAPHER", where, f"{row['determined_by']} is the credited photographer of an image of this specimen and cannot determine it"))
    return found


def check_asset_links(ctx: "Context") -> list[Finding]:
    """Each photograph's taxon and specimen resolve, agree with each other, and exist wherever the image claims to be evidence."""
    found: list[Finding] = []
    for row in ctx.reg["assets"]:
        where = f"{ctx.labels['assets']}:row {row['_row']}"
        taxon_id, specimen_id = row.get("taxon_id"), row.get("specimen_id")
        taxon = ctx.taxa.get(taxon_id) if taxon_id else None
        specimen = ctx.specimens.get(specimen_id) if specimen_id else None
        if taxon_id and taxon is None:
            found.append(err("ASSET_TAXON_UNKNOWN", where, f"taxon {taxon_id} is not in the taxon register"))
        if specimen_id and specimen is None:
            found.append(err("ASSET_SPECIMEN_UNKNOWN", where, f"specimen {specimen_id} is not in the specimen register"))
        if specimen_id and not taxon_id:
            found.append(err("ASSET_SPECIMEN_WITHOUT_TAXON", where, "an image that names a specimen must name its taxon"))
        if taxon_id and specimen is not None and specimen["taxon_id"] != taxon_id:
            found.append(err("ASSET_SPECIMEN_TAXON_MISMATCH", where, f"the image names {taxon_id} but its specimen {specimen_id} was determined to be {specimen['taxon_id']}: one image is evidence for one taxon"))
        shown = norm_name(row.get("subject_scientific_or_material_name"))
        if taxon is not None and shown and shown != norm_name(taxon["scientific_name"]):
            found.append(err("ASSET_SCIENTIFIC_NAME_CONFLICT", where, f"subject name {row['subject_scientific_or_material_name']!r} conflicts with {taxon_id}, {taxon['scientific_name']!r}"))
        if specimen_id and row["generation_method"] in NOT_PHOTOGRAPHS:
            found.append(err("ASSET_GENERATED_HAS_SPECIMEN", where, f"a {row['generation_method']} image is not an image of a specimen, and generated imagery is never identification evidence"))
        if row["role"] == "verified_diagnostic":
            if not taxon_id:
                found.append(err("DIAGNOSTIC_TAXON_MISSING", where, "a diagnostic photograph must name the taxon it shows (taxon_id)"))
            if not specimen_id:
                found.append(err("DIAGNOSTIC_SPECIMEN_MISSING", where, "a diagnostic photograph needs a specimen record: observer, date, place, habitat and a determination by a registered specialist"))
    return found


def check_duplicate_files(ctx: "Context") -> list[Finding]:
    """One catalogue row per file. The hash is taken from the FILE where it exists, never from the manifest's own claim about it."""
    found: list[Finding] = []
    by_hash: dict[str, list[dict[str, Any]]] = defaultdict(list)
    by_path: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in ctx.reg["assets"]:
        digest = ctx.file_hashes.get(row["asset_id"])
        if digest:
            by_hash[digest].append(row)
        if row.get("local_path"):
            by_path[row["local_path"]].append(row)
    label = ctx.labels["assets"]
    for path, rows in sorted(by_path.items()):
        for row in rows[1:]:
            found.append(err("ASSET_DUPLICATE_PATH", f"{label}:row {row['_row']}", f"{row['asset_id']} uses {path}, which {rows[0]['asset_id']} already catalogues"))
    for digest, rows in sorted(by_hash.items()):
        for row in rows[1:]:
            found.append(err("ASSET_DUPLICATE_BYTES", f"{label}:row {row['_row']}",
                             f"{row['asset_id']} has the same file content as {rows[0]['asset_id']} (sha256 {digest[:12]}...): one catalogue row per file; "
                             "different ids, views or subjects do not make independent evidence"))
    return found


def check_identification(ctx: "Context") -> list[Finding]:
    """Every register-level identification rule, once, before any entry is judged."""
    return check_taxa(ctx) + check_specimens(ctx) + check_asset_links(ctx) + check_duplicate_files(ctx)


# ------------------------------------------------------------------------------------------------ a species entry
def species_evidence(ctx: "Context", entry: "Entry") -> list[Finding]:
    """What one species profile must rest on: its taxon, its target views, and the specimens behind them."""
    fm, where = entry.fm, entry.rel
    found: list[Finding] = []
    taxon_id = fm.get("taxon_id")
    taxon = ctx.taxa.get(taxon_id) if nonempty(taxon_id) else None
    if not nonempty(taxon_id):
        found.append(err("SPECIES_TAXON_MISSING", where, "species profiles need a taxon_id: the taxon record (research/taxa.csv) they are about"))
    elif taxon is None:
        found.append(err("SPECIES_TAXON_UNKNOWN", where, f"taxon {taxon_id} is not in the taxon register"))
    else:
        if norm_name(fm.get("scientific_name")) != norm_name(taxon["scientific_name"]):
            found.append(err("SPECIES_SCIENTIFIC_NAME_CONFLICT", where, f"scientific_name {fm.get('scientific_name')!r} conflicts with {taxon_id}, {taxon['scientific_name']!r}"))
        others = sorted(e.entry_id for e in ctx.entries if e is not entry and e.fm.get("entry_type") == "species_profile" and e.fm.get("taxon_id") == taxon_id)
        if others:
            found.append(err("SPECIES_TAXON_DUPLICATE", where, f"{taxon_id} is also the subject of {', '.join(others)}: one species profile per taxon"))

    diagnostic = [ctx.assets[a] for a in fm["photo_ids"] if a in ctx.assets and ctx.assets[a]["role"] == "verified_diagnostic"]
    target: list[dict[str, Any]] = []
    for asset in diagnostic:
        shown = asset.get("taxon_id")
        if asset.get("view") == "look_alike":
            if not shown:
                found.append(err("SPECIES_PLATE_LOOKALIKE_TAXON_MISSING", where, f"{asset['asset_id']} is a look-alike view and must name the look-alike's own taxon"))
            elif shown == taxon_id:
                found.append(err("SPECIES_PLATE_LOOKALIKE_IS_TARGET", where, f"{asset['asset_id']} is a look-alike view but shows the profile's own taxon {taxon_id}"))
        elif nonempty(taxon_id) and shown == taxon_id:
            target.append(asset)
        else:
            found.append(err("SPECIES_PLATE_TAXON_MISMATCH", where, f"{asset['asset_id']} is a target view but shows {shown or 'no recorded taxon'}, and this profile is about {taxon_id or 'no recorded taxon'}"))
    views = {a["view"] for a in target if a.get("view")}
    files = {ctx.file_hashes.get(a["asset_id"]) or a["asset_id"] for a in target}
    if len(views) < MIN_TARGET_VIEWS or len(files) < MIN_TARGET_VIEWS:
        found.append(err("SPECIES_PLATE_VIEWS", where,
                         f"an identification plate needs at least {MIN_TARGET_VIEWS} distinct views of the profile's own taxon from distinct files "
                         f"(found {len(views)} view(s) from {len(files)} file(s); look-alike views never count)"))
    if views and not views & ANCHOR_VIEWS:
        found.append(err("SPECIES_PLATE_NO_WHOLE_OR_KEY", where, "an identification plate needs at least one whole or key_feature view of the target"))
    for asset in diagnostic:
        specimen = ctx.specimens.get(asset.get("specimen_id") or "")
        if specimen is not None and fm.get("authored_by") and specimen["determined_by"] == fm["authored_by"]:
            found.append(err("SPECIMEN_DETERMINER_IS_AUTHOR", where, f"{specimen['specimen_id']} was determined by {fm['authored_by']}, the author of this profile, who cannot determine what they cite"))
    return found


# ------------------------------------------------------------------------------------------------ review domains
def entry_domains(ctx: "Context", entry: "Entry") -> set[str]:
    """The identification domains a reviewer of this entry must hold: the kind of its own taxon and of every taxon its images show,
    look-alikes included."""
    fm = entry.fm
    taxon_ids = {fm["taxon_id"]} if nonempty(fm.get("taxon_id")) else set()
    for asset_id in list(fm.get("photo_ids", [])) + list(fm.get("illustration_ids", [])):
        asset = ctx.assets.get(asset_id)
        if asset and asset.get("taxon_id"):
            taxon_ids.add(asset["taxon_id"])
    return {kind_domain(ctx.taxa[t]["kind"]) for t in taxon_ids if t in ctx.taxa}


def asset_domains(ctx: "Context", asset: dict[str, Any]) -> set[str]:
    """The identification domain the auditor of this image must hold: the kind of the taxon it shows."""
    taxon = ctx.taxa.get(asset.get("taxon_id") or "")
    return {kind_domain(taxon["kind"])} if taxon else set()
