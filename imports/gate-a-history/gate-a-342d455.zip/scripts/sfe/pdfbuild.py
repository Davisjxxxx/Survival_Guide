"""Reproducible PDF pipeline: validate -> render (pdfLaTeX) -> log gate -> QA -> manifest.

Reproducibility: pdfLaTeX runs with SOURCE_DATE_EPOCH + FORCE_SOURCE_DATE=1 (fixed creation
date and file ID), TZ=UTC, no shell escape and paranoid file access. The build epoch is a pipeline
setting in layouts/build.yaml, never the wall clock. Two builds in different directories must be
byte-identical; `check_reproducible` proves it.

Nothing here publishes or uploads anything. The release build writes only under dist/ and refuses
unless at least one entry has status 'published' and every gate passes.
"""
from __future__ import annotations

import json
import os
import platform
import re
import shutil
import subprocess
import tempfile
from dataclasses import dataclass, field
from datetime import datetime, timezone
from importlib import metadata
from pathlib import Path
from typing import Any, Iterable

from . import __version__, derive as derive_mod, qa, release as release_mod
from .assets import APPROVED_DIR
from .common import Finding, err, errors_of, load_yaml, note, read_csv, sha256_bytes, sha256_file, warn
from .ledger import ledger_head
from .registry import LEDGERS, REGISTERS, Repo
from .texgen import KNOWN_UNRENDERED, RenderError, plain, printed_strings, render_document, render_entry, tex_escape
from .validate import build_context, package_of, run_gates

PROOF_INPUTS = (
    "layouts/specimen/specimen_entry.md", "layouts/specimen/specimen_sources.csv",
    "layouts/specimen/specimen_claims.csv", "layouts/specimen/specimen_assets.csv",
    "layouts/sfe.sty", "layouts/build.yaml",
    "schemas/entry.schema.json", "schemas/source.schema.json", "schemas/claim.schema.json", "schemas/asset.schema.json",
)
# The policy tables a release rests on: their digests go into every release manifest, so an edition names the rules it was checked under.
POLICY_FILES = ("schemas/hazard_topics.yaml", "schemas/classification_policy.yaml", "schemas/claim_policy.yaml", "schemas/unit_policy.yaml", "schemas/licenses.yaml")
FONT_FILES = ("qhvr.pfb", "qhvb.pfb", "qhvri.pfb", "qhvbi.pfb", "qcrr.pfb", "qcrb.pfb")
MAX_LATEX_RUNS = 4


class ToolchainError(RuntimeError):
    """A required external tool is missing or failed to run."""


class LatexError(ToolchainError):
    """pdfLaTeX failed or did not converge."""


@dataclass
class ProofResult:
    ok: bool
    findings: list[Finding]
    pdf: Path | None = None
    sha256: str | None = None
    manifest: Path | None = None


@dataclass
class ReleaseResult:
    ok: bool
    findings: list[Finding]
    pdfs: list[Path] = field(default_factory=list)
    edition_id: str | None = None
    state: str | None = None
    actions: list[str] = field(default_factory=list)


# ------------------------------------------------------------------------- config
def load_build_config(repo: Repo) -> dict[str, Any]:
    path = repo.path("layouts/build.yaml")
    if not path.is_file():
        raise ToolchainError("layouts/build.yaml is missing")
    return load_yaml(path.read_text(encoding="utf-8"))


def _epoch_iso(epoch: int) -> str:
    return datetime.fromtimestamp(epoch, tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _first_line(command: list[str]) -> str:
    try:
        proc = subprocess.run(command, capture_output=True, text=True, check=False, timeout=60)
    except FileNotFoundError as exc:
        raise ToolchainError(f"{command[0]} not found") from exc
    lines = (proc.stdout or proc.stderr).strip().splitlines()
    return lines[0] if lines else "unknown"


def toolchain_versions() -> dict[str, Any]:
    versions: dict[str, Any] = {
        "pdflatex": _first_line(["pdflatex", "--version"]),
        "python": platform.python_version(),
        "pyyaml": metadata.version("PyYAML"),
        "jsonschema": metadata.version("jsonschema"),
        "pillow": metadata.version("Pillow"),
    }
    versions.update(qa.tool_versions())
    return versions


def font_hashes() -> dict[str, str]:
    hashes: dict[str, str] = {}
    for name in FONT_FILES:
        proc = subprocess.run(["kpsewhich", name], capture_output=True, text=True, check=False)
        path = proc.stdout.strip()
        if path:
            hashes[name] = sha256_file(Path(path))
    return hashes


def _input_digest(repo: Repo, rels: tuple[str, ...]) -> tuple[dict[str, str], str]:
    hashes = {rel: sha256_file(repo.path(rel)) for rel in rels}
    digest = sha256_bytes("\n".join(f"{h}  {r}" for r, h in sorted(hashes.items())).encode("utf-8"))
    return hashes, digest


# --------------------------------------------------------------------------- LaTeX
_LOG_ERRORS = (
    (re.compile(r"^Overfull \\[hv]box \(([\d.]+)pt too (?:wide|high)\)", re.M), "LAYOUT_OVERFLOW", "content overflows its box by {0}pt"),
    (re.compile(r"^(?:LaTeX|Package \w+) Warning: Reference `([^']*)' on page \d+ undefined", re.M), "UNDEFINED_REFERENCE", "undefined reference {0!r}"),
    (re.compile(r"^LaTeX Warning: Label\(s\) may have changed", re.M), "LABELS_UNSTABLE", "labels still changing after the final run"),
    (re.compile(r"^Package hyperref Warning: Token not allowed in a PDF string", re.M), "BOOKMARK_TOKEN", "a bookmark or metadata string contains a TeX token"),
    (re.compile(r"^Missing character:", re.M), "MISSING_GLYPH", "a character has no glyph in the selected font"),
    (re.compile(r"^LaTeX Font Warning: Font shape", re.M), "FONT_SUBSTITUTED", "a font shape was substituted"),
    (re.compile(r"^pdfTeX warning \(dest\): name\{([^}]*)\} has been referenced but does not exist", re.M), "LINK_TARGET_MISSING", "link target {0!r} does not exist"),
)
# The ONE documented, demonstrably benign toolchain message. Newer TeX Live graphics drivers load epstopdf-base, which warns at LOAD
# time whenever shell escape is off ("Shell escape feature is not enabled"), whether or not any EPS file exists. The package's only
# job is converting EPS images through an external program, which needs shell escape; shell escape stays off by design and this
# pipeline renders PNG, JPEG and PDF only. The allowance is exact-match and guarded; every other warning is still reported.
_EPSTOPDF_SHELL_ESCAPE = re.compile(r"^Package epstopdf(?:-base)? Warning: Shell escape feature is not enabled\.(?: on input line \d+\.)?$", re.M)
_EPSTOPDF_CONVERSION = re.compile(r"^Package epstopdf Info: Source file:|-eps-converted-to", re.M)
_EPS_TYPES = (".eps", ".ps")
_GENERIC_WARNING = re.compile(r"^((?:LaTeX|Package [\w-]+|Class [\w-]+|pdfTeX) (?:Font )?[Ww]arning:.*)$", re.M)


def parse_latex_log(log: str, where: str, graphics_inputs: Iterable[str] = ()) -> list[Finding]:
    """Classify a pdfLaTeX log. `graphics_inputs` are the graphic file names the build includes (used to prove the epstopdf note benign)."""
    findings: list[Finding] = []
    claimed: set[str] = set()
    for pattern, code, template in _LOG_ERRORS:
        for match in pattern.finditer(log):
            findings.append(err(code, where, template.format(*match.groups())))
            claimed.add(match.group(0))
    eps_included = any(Path(name).suffix.lower() in _EPS_TYPES for name in graphics_inputs)
    converting = bool(_EPSTOPDF_CONVERSION.search(log))
    for match in _EPSTOPDF_SHELL_ESCAPE.finditer(log):
        if not eps_included and not converting:  # otherwise it is not benign and stays an ordinary warning below
            findings.append(note("TOOLCHAIN_NOTE_EPSTOPDF_SHELL_ESCAPE", where,
                                 "package epstopdf warns at load time that shell escape is off; it only converts EPS images, this build includes none "
                                 "(PNG, JPEG and PDF only) and shell escape stays disabled, so nothing is lost"))
            claimed.add(match.group(0))
    for match in _GENERIC_WARNING.finditer(log):
        line = match.group(1)
        if not any(line.startswith(c) or c.startswith(line) for c in claimed):
            findings.append(warn("LATEX_WARNING", where, line[:140]))
    return findings


def run_latex(workdir: Path, *, epoch: int, jobname: str = "sfe", main: str = "main.tex") -> tuple[Path, str, int]:
    """Run pdfLaTeX until .aux/.out are stable. Returns (pdf path, final log, runs)."""
    if shutil.which("pdflatex") is None:
        raise ToolchainError("pdflatex not found (install texlive-latex-base, -recommended, -extra, -fonts-recommended, tex-gyre)")
    env = {**os.environ, "SOURCE_DATE_EPOCH": str(epoch), "FORCE_SOURCE_DATE": "1", "TZ": "UTC", "LC_ALL": "C",
           "openin_any": "p", "openout_any": "p"}
    command = ["pdflatex", "-interaction=nonstopmode", "-halt-on-error", "-file-line-error", "--no-shell-escape",
               f"-jobname={jobname}", main]
    previous: tuple[str | None, ...] | None = None
    log_path = workdir / f"{jobname}.log"
    for run in range(1, MAX_LATEX_RUNS + 1):
        proc = subprocess.run(command, cwd=workdir, env=env, capture_output=True, text=True, check=False, timeout=600)
        log = log_path.read_text(encoding="utf-8", errors="replace") if log_path.exists() else proc.stdout
        if proc.returncode != 0:
            tail = "\n".join(log.splitlines()[-25:])
            raise LatexError(f"pdflatex failed on run {run}:\n{tail}")
        state = tuple(sha256_file(workdir / f"{jobname}{ext}") if (workdir / f"{jobname}{ext}").exists() else None for ext in (".aux", ".out"))
        if run >= 2 and state == previous:
            return workdir / f"{jobname}.pdf", log, run
        previous = state
    raise LatexError(f"pdflatex did not converge in {MAX_LATEX_RUNS} runs")


# ---------------------------------------------------------------------- the proof
def build_proof(repo: Repo, *, profile: str = "letter", out_dir: Path | None = None, previews: bool = True) -> ProofResult:
    config = load_build_config(repo)
    if profile not in config["profiles"]:
        raise ToolchainError(f"unknown profile {profile!r}")
    prof = config["profiles"][profile]
    proof_cfg, epoch = config["proof"], int(config["source_date_epoch"])

    ctx, findings = build_context(repo.root, specimen=True)
    findings += run_gates(ctx)
    if errors_of(findings):
        return ProofResult(False, sorted(set(findings)))
    entry = ctx.entries[0]

    hashes, digest = _input_digest(repo, PROOF_INPUTS)
    build_id = f"SPECIMEN-{digest[:12]}"
    fm = entry.fm
    note_n = {"s": len(fm["source_ids"]), "c": len({c for s in fm["procedure"] for c in s["claim_ids"]} | set(fm["claim_ids"])),
              "a": len(fm["photo_ids"]) + len(fm["illustration_ids"]), "u": len(fm.get("dimension_unit_table", []))}
    proof_note = (f"schema OK · sources resolve {note_n['s']}/{note_n['s']} · claims resolve {note_n['c']}/{note_n['c']} · "
                  f"assets labelled {note_n['a']}/{note_n['a']} · unit pairs round-trip {note_n['u']}/{note_n['u']} · "
                  f"reviewers named: 0 · approvals recorded: 0")
    try:
        rendered = render_entry(fm, assets=ctx.assets, sources=ctx.sources, zone_title="", proof=True,
                                repo_root=repo.root, proof_note=proof_note)
    except RenderError as exc:
        return ProofResult(False, sorted(set(findings + [err("RENDER", entry.rel, str(exc))])))

    footer_left = f"PROOF — NOT FOR PUBLICATION · build {build_id}"
    footer_right = f"{prof['label']} · sfe {__version__} · {datetime.fromtimestamp(epoch, tz=timezone.utc):%Y-%m-%d}"
    tex = render_document(
        rendered.tex, paper=prof["paper"], proof=True, title=proof_cfg["title"], author=config["pdf"]["author"],
        subject="Layout proof with dummy content", keywords="DUMMY, PROOF, NOT FOR PUBLICATION",
        footer_left=footer_left, footer_right=tex_escape(footer_right),
        version=__version__, banner=proof_cfg["banner"])

    base = proof_cfg["basename"] + ("" if profile == "letter" else f"_{profile.upper()}")
    destination = Path(out_dir) if out_dir else repo.path("proofs")
    with tempfile.TemporaryDirectory(prefix="sfe-build-") as tmp:
        work = Path(tmp)
        (work / "main.tex").write_text(tex, encoding="utf-8", newline="\n")
        shutil.copyfile(repo.path("layouts/sfe.sty"), work / "sfe.sty")
        pdf, log, runs = run_latex(work, epoch=epoch)
        findings += parse_latex_log(log, "pdflatex log", graphics_inputs=rendered.files)
        staged = work / f"{base}.pdf"
        shutil.copyfile(pdf, staged)
        expect = {"pages": proof_cfg["pages"], "width_pt": prof["width_pt"], "height_pt": prof["height_pt"],
                  "title_contains": ["SPECIMEN", "DUMMY"], "creation_iso": _epoch_iso(epoch),
                  "required_text": [proof_cfg["banner"], fm["id"], "PHOTO SLOT", "ILLUSTRATION — NOT FOR SPECIES IDENTIFICATION",
                                    "DUMMY-SRC-0000", "ICON KEY", "Step 1", "Step 3"],
                  "min_outline": 11, "margin_pt": 21.0, "expect_color": True, "language": config["pdf"]["language"],
                  "linked_text": list(fm["source_ids"]),
                  "named_destinations": [f"sfe:src:{s}" for s in fm["source_ids"]]
                  + [f"sfe:{fm['id']}:{k}" for k in ("top", "what", "where", "when", "identify", "materials", "units", "steps",
                                                      "check", "danger", "regional", "sources")],
                  "bookmark_labels": ["WHAT", "WHERE", "WHEN", "IDENTIFY", "MATERIALS", "STEPS", "CHECK",
                                      "FAILURE / DANGER", "REGIONAL / LEGAL LIMITATIONS", "SOURCES"]}
        qa_findings, facts = qa.check_pdf(staged, expect=expect, preview_dir=(work / "previews") if previews else None)
        findings += qa_findings
        # Renderer totality (FR-011): every string the layout promises for the specimen must be in the PDF's own text layer.
        promised = printed_strings(fm, assets=ctx.assets, sources=ctx.sources, zone_title="")
        missing = qa.missing_text(staged, promised, furniture=lambda page: (footer_left, footer_right))
        for path, text in missing[:25]:
            findings.append(err("RENDER_FIELD_MISSING", entry.rel, f"{path}: text {text[:70]!r} is not in the PDF's text layer"))
        if errors_of(findings):
            return ProofResult(False, sorted(set(findings)))

        out_sha = sha256_file(staged)
        manifest = {
            "artifact": f"{base}.pdf", "kind": "specimen-layout-proof", "dummy_content": True, "profile": profile,
            "pipeline": {"name": "sfe", "version": __version__, "engine": "pdflatex", "gate": "A"},
            "environment": {"SOURCE_DATE_EPOCH": epoch, "FORCE_SOURCE_DATE": "1", "TZ": "UTC", "shell_escape": False},
            "build_id": build_id, "inputs_sha256": digest, "inputs": hashes,
            "toolchain": toolchain_versions(), "fonts_sha256": font_hashes(),
            "latex_runs": runs,
            "output": {"sha256": out_sha, "bytes": staged.stat().st_size, **facts},
            "render_check": {"strings_promised": len(promised), "missing": 0},
            "qa": {"errors": 0, "warnings": sorted({f.code for f in findings if f.severity == "warning"}),
                   **({"notes": sorted({f.code for f in findings if f.severity == "info"})} if any(f.severity == "info" for f in findings) else {})},
            "previews": sorted(p.name for p in (work / "previews").glob("*.png")) if previews else [],
        }
        destination.mkdir(parents=True, exist_ok=True)
        final_pdf = destination / f"{base}.pdf"
        shutil.copyfile(staged, final_pdf)
        manifest_path = destination / f"{base}.build.json"
        manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")
        if previews:
            preview_dir = destination / "previews"
            preview_dir.mkdir(exist_ok=True)
            for png in sorted((work / "previews").glob("*.png")):
                shutil.copyfile(png, preview_dir / png.name)
    return ProofResult(True, sorted(set(findings)), final_pdf, out_sha, manifest_path)


def check_reproducible(repo: Repo) -> tuple[bool, str]:
    """Build the specimen twice in unrelated directories and compare bytes."""
    with tempfile.TemporaryDirectory(prefix="sfe-repro-a-") as a, tempfile.TemporaryDirectory(prefix="sfe-repro-b-") as b:
        first = build_proof(repo, out_dir=Path(a) / "deep" / "out", previews=False)
        second = build_proof(repo, out_dir=Path(b), previews=False)
        if not (first.ok and second.ok):
            return False, "repro: a build failed\n" + "\n".join(str(f) for f in errors_of(first.findings + second.findings))
        same_pdf = first.sha256 == second.sha256
        same_manifest = first.manifest.read_bytes() == second.manifest.read_bytes()  # type: ignore[union-attr]
        verdict = "REPRODUCIBLE" if same_pdf and same_manifest else "NOT REPRODUCIBLE"
        return same_pdf and same_manifest, (
            f"repro: {verdict}\n  build A sha256 {first.sha256}\n  build B sha256 {second.sha256}\n  manifests identical: {same_manifest}")


# --------------------------------------------------------------------- the release
def _ledger_heads(repo: Repo) -> dict[str, str]:
    """The chain head of every ledger: with the entries' package digests, what a release rests on."""
    heads: dict[str, str] = {}
    for name in sorted(LEDGERS):
        header, rows = read_csv(repo.path(REGISTERS[name][0]))
        heads[name] = ledger_head(header, rows)
    return heads


def build_release(repo: Repo, *, out_root: Path | None = None, pin: str | Path | None = None) -> ReleaseResult:
    """Zone PDFs from PUBLISHED entries only, into an immutable edition archive with an explicit active-release manifest (FR-017).

    Fails closed: requires an external ledger pin whenever any ledger has rows (FR-003 residual); if prior state exists under
    `dist`, `reconcile` runs on refusal so an invalidated active edition is withdrawn; if no prior state exists, a refusal
    writes nothing at all (not even the directory).
    """
    dist = Path(out_root) if out_root else repo.path("dist")
    ctx, findings = build_context(repo.root, specimen=False, pin=pin, require_pin=True)
    findings += run_gates(ctx)
    actions: list[str] = []

    def _refuse() -> ReleaseResult:
        if release_mod.has_state(dist):
            try:
                with release_mod.locked(dist):
                    actions.extend(release_mod.reconcile(repo, dist, ctx=ctx, gate_findings=findings, pin=pin))
            except release_mod.ReleaseStateError as exc:
                findings.append(err("RELEASE_STATE_ERROR", "dist", str(exc)))
        pointer, _ = release_mod.read_pointer(dist) if dist.is_dir() else (None, [])
        return ReleaseResult(False, sorted(set(findings)), edition_id=pointer.edition_id if pointer else None,
                             state=pointer.state if pointer else None, actions=actions)

    published = [e for e in ctx.entries if e.fm.get("status") == "published"]
    if errors_of(findings):
        return _refuse()
    if not published:
        findings.append(err("NO_PUBLISHED_ENTRIES", "dist", "fail-closed: no entry has status 'published', so there is nothing to release"))
        return _refuse()

    config = load_build_config(repo)
    prof, epoch = config["profiles"]["letter"], int(config["source_date_epoch"])
    zones = {z["id"]: z for z in ctx.zones}
    ledger_st = release_mod.ledger_state(repo)
    ledger_hds = _ledger_heads(repo)
    pol_digests = release_mod.policy_digests(repo)
    tc_versions = toolchain_versions()
    f_hashes = font_hashes()
    layout_sha = sha256_file(repo.path("layouts/sfe.sty"))
    build_cfg_sha = sha256_file(repo.path("layouts/build.yaml"))
    entry_records = [
        {"id": e.fm["id"], "zone": e.fm["zone"], "revision": e.fm["revision"], "content_sha256": e.content_hash,
         "package_sha256": package_of(ctx, e)[2]}
        for e in sorted(published, key=lambda e: e.fm["id"])
    ]
    edition_id = release_mod.edition_id_of({
        "schema": 1,
        "entries": [{"id": r["id"], "revision": r["revision"], "package_sha256": r["package_sha256"]} for r in entry_records],
        "ledger_state": ledger_st,
        "policy_sha256": pol_digests,
        "layout_sha256": layout_sha,
        "build_config_sha256": build_cfg_sha,
        "pipeline": {"name": "sfe", "version": __version__},
        "toolchain": tc_versions,
        "fonts_sha256": f_hashes,
        "epoch": epoch,
    })

    staged_outputs: list[tuple[str, Path, dict[str, Any]]] = []
    all_derivatives: list[derive_mod.DerivativeRecord] = []
    allowed_asset_roots = tuple(repo.path(d) for d in sorted(set(APPROVED_DIR.values())))
    with tempfile.TemporaryDirectory(prefix="sfe-release-") as tmp:
        for zone_id in sorted({e.fm["zone"] for e in published}):
            zone = zones[zone_id]
            members = [e for e in published if e.fm["zone"] == zone_id]
            work = Path(tmp) / zone["dir"]
            work.mkdir()
            bodies, files = [], {}
            promised: list[tuple[str, str]] = []
            try:
                for entry in members:
                    rendered = render_entry(entry.fm, assets=ctx.assets, sources=ctx.sources, zone_title=zone["title"],
                                            proof=False, repo_root=repo.root, body=entry.body)
                    bodies.append(rendered.tex)
                    files.update(rendered.files)
                    promised += [(f"{entry.fm['id']}:{path}", text) for path, text in
                                 printed_strings(entry.fm, assets=ctx.assets, sources=ctx.sources, zone_title=zone["title"])]
            except RenderError as exc:
                findings.append(err("RENDER", zone["dir"], str(exc)))
                return _refuse()
            zone_derivatives: list[derive_mod.DerivativeRecord] = []
            for name, source in sorted(files.items()):
                aid = Path(name).stem
                asset = ctx.assets.get(aid) or {}
                try:
                    record = derive_mod.derive_image(
                        source, work / name, asset_id=aid, original_rel=asset.get("local_path") or name,
                        expected_sha256=asset.get("sha256"), allowed_roots=allowed_asset_roots)
                except derive_mod.DeriveError as exc:
                    findings.append(err("IMAGE_DERIVE_FAILED", zone["dir"], str(exc)))
                    return _refuse()
                zone_derivatives.append(record)
            all_derivatives += zone_derivatives
            tex = render_document(
                "\n\\clearpage\n".join(bodies), paper=prof["paper"], proof=False,
                title=f"Survival Field Encyclopedia - {zone['title']}", author=config["pdf"]["author"],
                subject=f"Zone {zone_id}", keywords="survival field encyclopedia",
                footer_left=f"Survival Field Encyclopedia · {zone_id} · {zone['title']}",
                footer_right=tex_escape(f"sfe {__version__} · ") + r"page \thepage", version=__version__)
            (work / "main.tex").write_text(tex, encoding="utf-8", newline="\n")
            shutil.copyfile(repo.path("layouts/sfe.sty"), work / "sfe.sty")
            pdf, log, runs = run_latex(work, epoch=epoch)
            findings += parse_latex_log(log, f"{zone['dir']} log", graphics_inputs=files)
            named = work / f"{zone['dir']}.pdf"
            shutil.copyfile(pdf, named)
            expect = {"pages": None, "width_pt": prof["width_pt"], "height_pt": prof["height_pt"],
                      "title_contains": ["Survival Field Encyclopedia"], "creation_iso": _epoch_iso(epoch),
                      "required_text": [e.fm["id"] for e in members], "min_outline": 1, "bookmark_labels": [], "margin_pt": 18.0,
                      "language": config["pdf"]["language"]}
            qa_findings, facts = qa.check_pdf(named, expect=expect)
            findings += qa_findings
            findings += derive_mod.check_pdf_image_metadata(named, zone_derivatives)
            # Renderer totality: every string the layout promised to print for every approved entry must be in the PDF's own text layer.
            missing = qa.missing_text(named, promised, furniture=lambda page: (f"Survival Field Encyclopedia · {zone_id} · {zone['title']}",
                                                                              f"sfe {__version__} · page {page}"))
            for path, text in missing[:25]:
                findings.append(err("RENDER_FIELD_MISSING", zone["dir"], f"{path}: approved text {text[:70]!r} is not in the PDF's text layer"))
            manifest = {
                "artifact": named.name, "edition_id": edition_id, "kind": "zone-release", "zone": zone_id,
                "pipeline": {"name": "sfe", "version": __version__},
                "environment": {"SOURCE_DATE_EPOCH": epoch}, "latex_runs": runs,
                "entries": [{"id": e.fm["id"], "revision": e.fm["revision"], "content_sha256": e.content_hash,
                             "package_sha256": package_of(ctx, e)[2]} for e in members],
                "derivatives": [d.to_manifest() for d in zone_derivatives],
                "ledger_heads": ledger_hds,
                "ledger_state": ledger_st,
                "policy_sha256": pol_digests,
                "render_check": {"strings_promised": len(promised), "missing": len(missing)},
                "known_unrendered": list(KNOWN_UNRENDERED),
                "output": {"sha256": sha256_file(named), **facts},
            }
            staged_outputs.append((zone_id, named, manifest))
        if errors_of(findings):
            return _refuse()

        try:
            with release_mod.locked(dist):
                actions += release_mod.recover(dist) + release_mod.quarantine_legacy(dist)
                stage_base = dist / release_mod.STAGING
                stage_base.mkdir(parents=True, exist_ok=True)
                staged_dir = Path(tempfile.mkdtemp(prefix=f"{edition_id}-", dir=stage_base))
                zones_dir = staged_dir / "zones"
                zones_dir.mkdir()
                artifacts: list[dict[str, Any]] = []
                for zone_id, named, manifest in staged_outputs:
                    pdf_rel = f"zones/{named.name}"
                    manifest_rel = f"zones/{named.stem}.build.json"
                    pdf_dst = staged_dir / pdf_rel
                    manifest_dst = staged_dir / manifest_rel
                    shutil.copyfile(named, pdf_dst)
                    manifest_dst.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
                    artifacts.append({
                        "zone": zone_id, "pdf": pdf_rel, "pdf_sha256": sha256_file(pdf_dst),
                        "manifest": manifest_rel, "manifest_sha256": sha256_file(manifest_dst),
                    })
                edition_doc = {
                    "schema": 1, "edition_id": edition_id,
                    "pipeline": {"name": "sfe", "version": __version__, "engine": "pdflatex"},
                    "environment": {"SOURCE_DATE_EPOCH": epoch, "FORCE_SOURCE_DATE": "1", "TZ": "UTC", "shell_escape": False},
                    "toolchain": tc_versions, "fonts_sha256": f_hashes,
                    "layout_sha256": layout_sha, "build_config_sha256": build_cfg_sha,
                    "entries": entry_records, "derivatives": [d.to_manifest() for d in all_derivatives],
                    "ledger_state": ledger_st, "policy_sha256": pol_digests,
                    "artifacts": artifacts, "known_unrendered": list(KNOWN_UNRENDERED),
                }
                (staged_dir / release_mod.EDITION_FILE).write_bytes(release_mod.edition_bytes(edition_doc))
                orig_findings = derive_mod.check_no_originals_archived(staged_dir, all_derivatives)
                if orig_findings:
                    shutil.rmtree(staged_dir, ignore_errors=True)
                    findings += orig_findings
                    return _refuse()
                promo = release_mod.promote(dist, staged_dir, edition_id)
                pdfs = [promo.directory / a["pdf"] for a in artifacts]
        except release_mod.ReleaseStateError as exc:
            findings.append(err("RELEASE_STATE_ERROR", "dist", str(exc)))
            return _refuse()
    return ReleaseResult(True, sorted(set(findings)), pdfs=pdfs, edition_id=promo.edition_id, state="active", actions=actions)
