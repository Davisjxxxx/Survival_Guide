"""Classification: which review subjects an entry requires (finding FR-001).

A review SUBJECT is something an independent reviewer must speak to: one of the hazard topics of handoff section 6 (schemas/hazard_topics.yaml)
or a classification subject defined in schemas/classification_policy.yaml (medical guidance, identification, high-risk content, and the
screening attestation that no other subject applies).

At RUN-002 the safety gate ran only for an entry that DECLARED a hazard tag or was typed medical_guidance, so a wild-foods or first-aid entry
typed as an ordinary entry with no tags reached `published` with one approval and no safety review (FABLE-REVIEW-001, probes P18, P18b, P46,
P47, P20). Now the subjects are DERIVED, as the union of everything that applies to the entry (see the policy file for the full list):
its zone and the zone's priority, its entry type, the type and risk of every claim it cites, the coverage plan, structural content such as
species or medical fields or a cited diagnostic photograph, and keywords in its text. Declared hazard tags only ADD. When nothing applies
the entry still needs an independent screening review. An unknown classification, or an unusable policy, requires every subject and is an
error: unknown is never treated as safe.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from .common import Finding, err, load_yaml, nonempty, walk_strings
from .entries import MEDICAL_FIELDS, SPECIES_FIELDS, TYPE_EXCLUSIVE_FIELDS, Entry, claim_ids_of
from .registry import Repo, load_hazards, load_zones
from .units import dimension_of

if TYPE_CHECKING:  # pragma: no cover
    from .validate import Context

POLICY_REL = "schemas/classification_policy.yaml"
SUBJECT_ID = re.compile(r"CLS-[A-Z0-9-]+")
SUBJECT_FIELDS = ("handoff_ref", "title", "applies_when", "required_reviews", "reviewer_must_confirm")
SCREENING = "CLS-SCREENING"
HIGH_RISK = "CLS-HIGH-RISK"
# Front-matter keys whose strings are identifiers or dates, not prose: the keyword triggers do not read them.
TEXT_EXCLUDED_KEYS = frozenset({"id", "zone", "status", "entry_type", "hazard_tags", "source_ids", "claim_ids", "field_claims", "photo_ids", "illustration_ids",
                                "authored_by", "technical_reviewer", "editorial_reviewer", "taxon_id", "region", "season", "as_of_date",
                                "evidence_date", "specimen"})


@dataclass(frozen=True)
class Trigger:
    id: str
    subjects: tuple[str, ...]
    regex: re.Pattern[str]


@dataclass
class ClassificationPolicy:
    subjects: dict[str, dict[str, Any]]
    zones: dict[str, dict[str, Any]] = field(default_factory=dict)
    entry_types: dict[str, tuple[str, ...]] = field(default_factory=dict)
    claim_types: dict[str, tuple[str, ...]] = field(default_factory=dict)
    risk_levels: dict[str, tuple[str, ...]] = field(default_factory=dict)
    priority_floor: dict[str, tuple[str, ...]] = field(default_factory=dict)
    structure: dict[str, Any] = field(default_factory=dict)
    triggers: tuple[Trigger, ...] = ()
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass
class Classification:
    subjects: dict[str, list[str]]  # subject id -> the reasons it is required
    findings: list[Finding]
    trigger_hits: dict[str, str] = field(default_factory=dict)  # trigger id -> the text that matched (evidence.py: a statement needs a claim)


# ------------------------------------------------------------------------------------ the policy
def load_classification_policy(repo: Repo) -> tuple[ClassificationPolicy | None, list[Finding]]:
    """Load and validate schemas/classification_policy.yaml. Returns (None, findings) when it cannot be trusted: nothing is then approvable."""
    path = repo.path(POLICY_REL)
    if not path.is_file():
        return None, [err("CLASSIFICATION_POLICY_MISSING", POLICY_REL, "the classification policy is missing, so no entry can be classified")]
    try:
        data = load_yaml(path.read_text(encoding="utf-8"))
    except Exception as exc:
        return None, [err("CLASSIFICATION_POLICY_INVALID", POLICY_REL, f"not valid strict YAML: {exc}")]
    if not isinstance(data, dict) or data.get("schema_version") != 1 or not isinstance(data.get("subjects"), dict):
        return None, [err("CLASSIFICATION_POLICY_INVALID", POLICY_REL, "expected a mapping with schema_version 1 and a subjects mapping")]
    findings: list[Finding] = []

    def bad(message: str) -> None:
        findings.append(err("CLASSIFICATION_POLICY_INVALID", POLICY_REL, message))

    subjects: dict[str, dict[str, Any]] = {}
    for sid, subject in data["subjects"].items():
        if not SUBJECT_ID.fullmatch(str(sid)):
            bad(f"invalid subject id {sid!r} (must look like CLS-NAME)")
            continue
        if not isinstance(subject, dict):
            bad(f"{sid}: must be a mapping")
            continue
        for needed in SUBJECT_FIELDS:
            if not subject.get(needed):
                bad(f"{sid}: missing {needed}")
        subjects[sid] = subject
    topics, _ = load_hazards(repo)
    known = set(topics) | set(subjects)

    def subject_list(where: str, value: Any) -> tuple[str, ...]:
        if not isinstance(value, list) or not all(isinstance(item, str) for item in value):
            bad(f"{where}: must be a list of subject ids")
            return ()
        for item in value:
            if item not in known:
                findings.append(err("CLASSIFICATION_POLICY_UNKNOWN_SUBJECT", POLICY_REL, f"{where}: {item!r} is not a defined review subject"))
        return tuple(value)

    def rows(name: str, expected: set[str]) -> dict[str, Any]:
        table = data.get(name)
        if not isinstance(table, dict):
            bad(f"{name}: must be a mapping")
            return {}
        for missing in sorted(expected - set(table)):
            findings.append(err("CLASSIFICATION_POLICY_INCOMPLETE", POLICY_REL, f"{name}: no row for {missing}: an unclassified value would be treated as safe"))
        for extra in sorted(set(table) - expected):
            bad(f"{name}: unexpected row {extra!r}")
        return {key: value for key, value in table.items() if key in expected}

    entry_schema, claim_schema, zone_schema = repo.schema("entry.schema.json"), repo.schema("claim.schema.json"), repo.schema("zone.schema.json")
    type_names = set(entry_schema["properties"]["entry_type"]["enum"])
    zone_rows, _ = load_zones(repo)
    zone_table = rows("zones", {z["id"] for z in zone_rows})
    zones: dict[str, dict[str, Any]] = {}
    for zid, row in zone_table.items():
        if not isinstance(row, dict) or not isinstance(row.get("identification"), bool):
            bad(f"zones.{zid}: needs required_subjects, allowed_types and a boolean identification")
            continue
        allowed = row.get("allowed_types")
        if not (isinstance(allowed, list) and allowed and set(allowed) <= type_names):
            bad(f"zones.{zid}.allowed_types: must be a non-empty list of entry types ({', '.join(sorted(type_names))})")
            continue
        zones[zid] = {"required_subjects": subject_list(f"zones.{zid}.required_subjects", row.get("required_subjects")),
                      "allowed_types": tuple(allowed), "identification": row["identification"]}

    def simple(name: str, expected: set[str]) -> dict[str, tuple[str, ...]]:
        out: dict[str, tuple[str, ...]] = {}
        for key, row in rows(name, expected).items():
            out[key] = subject_list(f"{name}.{key}.required_subjects", row.get("required_subjects") if isinstance(row, dict) else None)
        return out

    entry_types = simple("entry_types", type_names)
    claim_types = simple("claim_types", set(claim_schema["properties"]["claim_type"]["enum"]))
    risk_levels = simple("risk_levels", set(claim_schema["properties"]["risk_level"]["enum"]))
    priorities = set(zone_schema["properties"]["zones"]["items"]["properties"]["priority"]["enum"])
    floor_table = data.get("priority_floor")
    priority_floor: dict[str, tuple[str, ...]] = {}
    if not isinstance(floor_table, dict):
        bad("priority_floor: must be a mapping")
    else:
        for missing in sorted(priorities - set(floor_table)):
            findings.append(err("CLASSIFICATION_POLICY_INCOMPLETE", POLICY_REL, f"priority_floor: no row for {missing}"))
        priority_floor = {key: subject_list(f"priority_floor.{key}", value) for key, value in floor_table.items() if key in priorities}

    structure_raw = data.get("structure")
    structure: dict[str, Any] = {}
    if not isinstance(structure_raw, dict) or not isinstance(structure_raw.get("units"), dict):
        bad("structure: needs species_fields, medical_fields, diagnostic_photo and a units mapping")
    else:
        for key in ("species_fields", "medical_fields", "diagnostic_photo"):
            structure[key] = subject_list(f"structure.{key}", structure_raw.get(key))
        structure["units"] = {dimension: subject_list(f"structure.units.{dimension}", structure_raw["units"].get(dimension))
                              for dimension in ("pressure", "temperature")}

    triggers: list[Trigger] = []
    raw_triggers = data.get("triggers")
    if not isinstance(raw_triggers, list):
        bad("triggers: must be a list")
    else:
        seen: set[str] = set()
        for number, trigger in enumerate(raw_triggers, start=1):
            if not (isinstance(trigger, dict) and isinstance(trigger.get("id"), str) and trigger["id"] and isinstance(trigger.get("pattern"), str)
                    and trigger["pattern"]):
                bad(f"triggers[{number}]: needs an id, a pattern and subjects")
                continue
            if trigger["id"] in seen:
                bad(f"triggers: duplicate id {trigger['id']!r}")
            seen.add(trigger["id"])
            try:
                regex = re.compile(trigger["pattern"], re.IGNORECASE)
            except re.error as exc:
                findings.append(err("CLASSIFICATION_POLICY_TRIGGER", POLICY_REL, f"{trigger['id']}: the pattern does not compile: {exc}"))
                continue
            triggers.append(Trigger(trigger["id"], subject_list(f"triggers.{trigger['id']}.subjects", trigger.get("subjects")), regex))
    if findings:
        return None, findings
    return ClassificationPolicy(subjects, zones, entry_types, claim_types, risk_levels, priority_floor, structure, tuple(triggers), data), []


# ------------------------------------------------------------------------------ the derivation
def classify(ctx: "Context", entry: Entry) -> Classification:
    """The review subjects `entry` requires: the union of every rule that applies. Nothing an author writes removes a subject."""
    fm, where = entry.fm, entry.rel
    policy = ctx.cls_policy
    reasons: dict[str, set[str]] = {}
    findings: list[Finding] = []
    hits: dict[str, str] = {}

    def add(subjects: Any, why: str) -> None:
        for subject in subjects:
            reasons.setdefault(subject, set()).add(why)

    def declared() -> None:
        add([tag for tag in fm["hazard_tags"] if tag in ctx.subjects], "declared hazard tag")

    if policy is None:
        findings.append(err("CLASSIFICATION_UNKNOWN", where, "the classification policy is missing or invalid, so this entry's classification is unknown: every review subject is required"))
        add([s for s in ctx.subjects if s != SCREENING], "fail closed: the classification policy is unusable")
        declared()
        return Classification({s: sorted(r) for s, r in reasons.items()}, findings)

    zone_id, entry_type = fm["zone"], fm["entry_type"]
    zone = policy.zones.get(zone_id)
    if zone is None:
        findings.append(err("CLASSIFICATION_UNKNOWN", where, f"zone {zone_id} has no row in the classification policy: every review subject is required"))
        add([s for s in ctx.subjects if s != SCREENING], f"fail closed: zone {zone_id} is unclassified")
    else:
        add(zone["required_subjects"], f"zone {zone_id}")
        if entry_type not in zone["allowed_types"]:
            findings.append(err("ENTRY_TYPE_NOT_ALLOWED_IN_ZONE", where, f"zone {zone_id} allows only {', '.join(zone['allowed_types'])}; this entry is {entry_type}"))
        identifies = nonempty(fm["diagnostic_features"]) or nonempty(fm["lookalikes_or_confusions"]) or any(
            (ctx.assets.get(a) or {}).get("role") == "verified_diagnostic" for a in fm["photo_ids"])
        if zone["identification"] and identifies and entry_type != "species_profile":
            findings.append(err("IDENTIFICATION_CONTENT_REQUIRES_PROFILE_TYPE", where,
                                f"zone {zone_id} identifies organisms: an entry with diagnostic features, look-alikes or a diagnostic photograph must be a species_profile, which carries the plate and identification rules"))
    priority = next((z["priority"] for z in ctx.zones if z["id"] == zone_id), None)
    if priority in policy.priority_floor:
        add(policy.priority_floor[priority], f"zone priority {priority}")
    elif priority is not None:
        add([s for s in ctx.subjects if s != SCREENING], f"fail closed: zone priority {priority} is unclassified")
    add(policy.entry_types.get(entry_type, ()), f"entry type {entry_type}")

    for claim_id in sorted(claim_ids_of(fm)):
        claim = ctx.claims.get(claim_id)
        if claim is None:
            add([HIGH_RISK], f"claim {claim_id} is not registered, so its type and risk are unknown")
            continue
        add(policy.claim_types.get(claim["claim_type"], ()), f"claim {claim_id} is of type {claim['claim_type']}")
        add(policy.risk_levels.get(claim["risk_level"], ()), f"claim {claim_id} has risk level {claim['risk_level']}")

    for row in ctx.reg["coverage"]:
        if row.get("planned_entry_id") != fm["id"]:
            continue
        add(row.get("hazard_topics") or [], f"the coverage plan ({row['coverage_id']}) lists it")
        add(policy.risk_levels.get(row["risk_level"], ()), f"the coverage plan ({row['coverage_id']}) rates it {row['risk_level']}")
        if row["entry_type"] != entry_type:
            findings.append(err("COVERAGE_ENTRY_TYPE_MISMATCH", where, f"the coverage plan ({row['coverage_id']}) plans a {row['entry_type']} but the entry is a {entry_type}: the type was changed after planning"))

    structure = policy.structure
    if any(nonempty(fm.get(key)) for key in SPECIES_FIELDS):
        add(structure.get("species_fields", ()), "species fields are present")
    if any(nonempty(fm.get(key)) for key in MEDICAL_FIELDS):
        add(structure.get("medical_fields", ()), "medical fields are present")
    if any((ctx.assets.get(a) or {}).get("role") == "verified_diagnostic" for a in fm["photo_ids"]):
        add(structure.get("diagnostic_photo", ()), "it cites a diagnostic photograph")
    for row in fm.get("dimension_unit_table", []):
        for text in (row["us_customary"], row["metric"]):
            dimension = dimension_of(text)
            if dimension in structure.get("units", {}):
                add(structure["units"][dimension], f"a {dimension} quantity ({text.strip()}) appears in its dimensions")

    for path, text in walk_strings({**fm, "body": entry.body}):
        if path.split(".", 1)[0].split("[", 1)[0] in TEXT_EXCLUDED_KEYS or re.search(r"(?:^|\.)(?:claim_ids?|us_customary|metric)(?:\[|$)", path):
            continue
        for trigger in policy.triggers:
            match = trigger.regex.search(text)
            if match:
                hits.setdefault(trigger.id, match.group(0))
                add(trigger.subjects, f"the text mentions {match.group(0)!r} ({trigger.id})")

    for other_type, fields in TYPE_EXCLUSIVE_FIELDS.items():
        if entry_type != other_type:
            misplaced = sorted(key for key in fields if key in fm)
            if misplaced:
                findings.append(err("ENTRY_FIELD_NOT_FOR_TYPE", where,
                                    f"{', '.join(misplaced)} belong to {other_type} entries; on a {entry_type} entry they would be approved but never printed"))
    declared()
    if not reasons:
        reasons[SCREENING] = {"no other review subject applies"}
    return Classification({s: sorted(r) for s, r in reasons.items()}, findings, hits)
