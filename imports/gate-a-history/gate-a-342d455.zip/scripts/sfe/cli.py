"""Command line: `python -m sfe <command>` (run with PYTHONPATH=scripts; see the Makefile).

Exit codes: 0 success, 1 a gate failed (findings printed), 2 usage or environment error.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from . import __version__
from .registry import Repo, scaffold


def _default_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="sfe", description="Survival Field Encyclopedia build tooling (Gate A scaffold)")
    parser.add_argument("--root", type=Path, default=None, help="repository root (default: the checkout containing this script)")
    parser.add_argument("--version", action="version", version=f"sfe {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("scaffold", help="create missing zone directories, zone READMEs and header-only registers")

    validate = sub.add_parser("validate", help="run every content, register and asset gate")
    validate.add_argument("--specimen", action="store_true", help="validate the dummy specimen and its registers instead of content/")
    validate.add_argument("--strict", action="store_true", help="treat warnings as errors")
    validate.add_argument("--pin", default=None, help="external ledger continuity pin string or file path outside the repository (or set SFE_LEDGER_PIN)")

    proof = sub.add_parser("proof", help="build the labelled dummy specimen PDF")
    proof.add_argument("--profile", choices=("letter", "a4"), default="letter")
    proof.add_argument("--out-dir", type=Path, default=None, help="output directory (default: proofs/)")
    proof.add_argument("--no-previews", action="store_true", help="skip the colour and grayscale PNG previews")

    sub.add_parser("repro", help="build the specimen twice in different directories and compare SHA-256")
    rel = sub.add_parser("release", help="build and manage immutable release editions under dist/ (fails closed when nothing is published)")
    rel.add_argument("--out-dir", type=Path, default=None, help="release state directory (default: dist/)")
    rel.add_argument("--pin", default=None, help="external ledger continuity pin string or file path outside the repository (required once any ledger has rows)")
    rel_sub = rel.add_subparsers(dest="release_command", required=False)
    for name, desc in (("status", "show the active-release pointer"),
                       ("verify", "validate the active release against the current approvals and sources (read-only)"),
                       ("reconcile", "repair interrupted state, quarantine legacy flat output, and withdraw an invalid active release"),
                       ("recover", "repair interrupted promotion state without deleting evidence")):
        p = rel_sub.add_parser(name, help=desc)
        p.add_argument("--out-dir", type=Path, default=None, help="release state directory (default: dist/)")
        if name in ("verify", "reconcile"):
            p.add_argument("--pin", default=None, help="external ledger continuity pin string or file path outside the repository")
    wd = rel_sub.add_parser("withdraw", help="withdraw the active release with a recorded reason (archived artifacts stay intact)")
    wd.add_argument("--reason", required=True, help="why the active release is withdrawn")
    wd.add_argument("--out-dir", type=Path, default=None, help="release state directory (default: dist/)")

    hash_entry = sub.add_parser("hash-entry", help="print the content hash of an entry file (the text part only; approvals bind to the package digest)")
    hash_entry.add_argument("path", type=Path)

    packet = sub.add_parser("packet", help="build the review packet of an entry: what a reviewer is shown, and the package digest every decision binds to")
    packet.add_argument("entry_id")
    packet.add_argument("--write", action="store_true", help="store the packet under reviews/packets/ (never overwrites a different packet)")

    ledger = sub.add_parser("ledger", help="ledger maintenance")
    ledger_sub = ledger.add_subparsers(dest="ledger_command", required=True)
    seal = ledger_sub.add_parser("seal", help="assign sequence and chain hash to appended ledger rows (sealed rows are never touched)")
    seal.add_argument("names", nargs="*", help="ledger register names (default: every ledger)")
    pin_cmd = ledger_sub.add_parser("pin", help="verify every ledger and emit an external continuity pin (keep it outside the repository)")
    pin_cmd.add_argument("--write", type=Path, default=None, help="write the pin to a file OUTSIDE the repository")
    return parser


def _print_findings(findings) -> tuple[int, int, int]:
    """Print every finding; return (errors, warnings, notes). Notes are documented benign toolchain messages: they never fail a run."""
    for finding in findings:
        print(finding)
    count = lambda severity: sum(1 for f in findings if f.severity == severity)  # noqa: E731
    return count("error"), count("warning"), count("info")


def _counts(errors: int, warnings: int, notes: int) -> str:
    return f"{errors} error(s), {warnings} warning(s)" + (f", {notes} note(s)" if notes else "")


def main(argv: list[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    root = (args.root or _default_root()).resolve()
    repo = Repo(root)

    if args.command == "scaffold":
        try:
            for action in scaffold(repo):
                print(action)
        except RuntimeError as exc:
            print(exc, file=sys.stderr)
            return 1
        print("scaffold: done")
        return 0

    if args.command == "validate":
        from .validate import validate_repo

        errors, warnings, notes = _print_findings(validate_repo(root, specimen=args.specimen, pin=args.pin))
        mode = "specimen" if args.specimen else "content"
        print(f"validate[{mode}]: {_counts(errors, warnings, notes)}")
        return 1 if errors or (args.strict and warnings) else 0

    if args.command == "hash-entry":
        from .entries import EntryParseError, content_sha256, parse_entry

        try:
            fm, body = parse_entry(args.path.read_bytes())
        except (EntryParseError, OSError) as exc:
            print(f"hash-entry: {exc}", file=sys.stderr)
            return 2
        print(content_sha256(fm, body))
        return 0

    if args.command == "packet":
        from . import package as package_mod
        from .validate import build_context, package_of

        ctx, _ = build_context(root)
        entry = next((e for e in ctx.entries if e.entry_id == args.entry_id), None)
        if entry is None:
            print(f"packet: no entry {args.entry_id!r} under content/", file=sys.stderr)
            return 2
        subjects, package, digest = package_of(ctx, entry)
        print(f"entry          {entry.entry_id} revision {entry.fm['revision']}")
        print(f"package        {digest}")
        for subject, reasons in sorted(subjects.items()):
            classes = ", ".join(ctx.subjects[subject]["required_reviews"]) if subject in ctx.subjects else "UNDEFINED"
            print(f"requires       {subject}: {classes}  ({'; '.join(sorted(reasons))})")
        rel = package_mod.packet_relpath(entry.entry_id, entry.fm["revision"], digest)
        if args.write:
            try:
                rel, sha = package_mod.write_packet(root, package, digest)
            except RuntimeError as exc:
                print(f"packet: {exc}", file=sys.stderr)
                return 1
            print(f"packet         {rel}\npacket_sha256  {sha}")
        else:
            print(f"packet         {rel}  (not written: add --write)")
        return 0

    if args.command == "ledger":
        from .ledger import LedgerError, create_pin, seal_ledger, write_pin_file
        from .registry import LEDGERS, REGISTERS

        if args.ledger_command == "pin":
            try:
                if args.write is not None:
                    pin = write_pin_file(repo, args.write)
                    print(f"{args.write}: {pin}")
                else:
                    print(create_pin(repo))
            except LedgerError as exc:
                print(exc, file=sys.stderr)
                return 1
            return 0
        names = args.names or list(LEDGERS)
        unknown = [name for name in names if name not in LEDGERS]
        if unknown:
            print(f"unknown ledger(s): {', '.join(unknown)}; choose from {', '.join(LEDGERS)}", file=sys.stderr)
            return 2
        try:
            for name in names:
                rel = REGISTERS[name][0]
                assigned = seal_ledger(repo.path(rel))
                print(f"{rel}: " + (f"sealed row(s) {assigned[0]}..{assigned[-1]}" if assigned else "nothing to seal"))
        except LedgerError as exc:
            print(exc, file=sys.stderr)
            return 1
        return 0

    from . import pdfbuild  # deferred: needs pdflatex and poppler

    try:
        if args.command == "proof":
            result = pdfbuild.build_proof(repo, profile=args.profile, out_dir=args.out_dir, previews=not args.no_previews)
            errors, warnings, notes = _print_findings(result.findings)
            print(f"proof[{args.profile}]: {'OK' if result.ok else 'FAILED'} ({_counts(errors, warnings, notes)})")
            if result.pdf:
                print(f"  pdf    {result.pdf}\n  sha256 {result.sha256}")
            return 0 if result.ok else 1
        if args.command == "repro":
            ok, detail = pdfbuild.check_reproducible(repo)
            print(detail)
            return 0 if ok else 1
        if args.command == "release":
            from . import release as release_mod

            dist = args.out_dir or repo.path("dist")
            subcmd = getattr(args, "release_command", None)
            if subcmd == "status":
                pointer, problems = release_mod.read_pointer(dist)
                _print_findings(problems)
                if problems:
                    print("release[status]: INVALID")
                    return 1
                if pointer is None:
                    print("release[status]: none")
                    return 0
                extra = f" reason={pointer.reason!r}" if pointer.reason else ""
                print(f"release[status]: {pointer.state} edition={pointer.edition_id} generation={pointer.generation} by={pointer.by}{extra}")
                return 0
            if subcmd == "verify":
                verification = release_mod.verify_active(repo, dist, pin=getattr(args, "pin", None))
                errors, warnings, notes = _print_findings(verification.findings)
                ed = f" edition={verification.pointer.edition_id}" if verification.pointer else ""
                why = f" reason={verification.pointer.reason!r}" if verification.pointer and verification.pointer.reason else ""
                print(f"release[verify]: {'OK' if verification.ok else 'INVALID'} state={verification.state}{ed}{why} ({_counts(errors, warnings, notes)})")
                return 0 if verification.ok else 1
            if subcmd == "withdraw":
                try:
                    with release_mod.locked(dist):
                        pointer = release_mod.withdraw(dist, args.reason)
                except release_mod.ReleaseStateError as exc:
                    print(f"release[withdraw]: {exc}", file=sys.stderr)
                    return 1
                print(f"release[withdraw]: withdrawn edition={pointer.edition_id} generation={pointer.generation} reason={pointer.reason!r}")
                return 0
            if subcmd in ("reconcile", "recover"):
                try:
                    if not release_mod.has_state(dist):
                        actions = []
                    else:
                        with release_mod.locked(dist):
                            actions = release_mod.reconcile(repo, dist, pin=getattr(args, "pin", None)) if subcmd == "reconcile" else release_mod.recover(dist)
                except release_mod.ReleaseStateError as exc:
                    print(f"release[{subcmd}]: {exc}", file=sys.stderr)
                    return 1
                for action in actions:
                    print(f"  {action}")
                print(f"release[{subcmd}]: {len(actions)} action(s)")
                return 0
            result = pdfbuild.build_release(repo, out_root=args.out_dir, pin=getattr(args, "pin", None))
            for action in result.actions:
                print(f"release[reconcile]: {action}")
            errors, warnings, notes = _print_findings(result.findings)
            ed_info = f"; edition {result.edition_id} ({result.state})" if result.edition_id else ""
            print(f"release: {'OK' if result.ok else 'REFUSED'} ({_counts(errors, warnings, notes)}){ed_info}; {len(result.pdfs)} PDF(s) written")
            for pdf in result.pdfs:
                print(f"  {pdf}")
            return 0 if result.ok else 1
    except pdfbuild.ToolchainError as exc:
        print(f"toolchain error: {exc}", file=sys.stderr)
        return 2
    return 2
