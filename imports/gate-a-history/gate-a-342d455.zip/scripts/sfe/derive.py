"""Publication image derivatives and PDF metadata verification (finding FR-014, probe P72).

At RUN-003 a release copied each original image file straight into the LaTeX build directory, so pdfTeX
embedded a JPEG's EXIF, artist, description and GPS segments unchanged into the released PDF.

Now:
  1. Originals live under assets/original_photos/ and assets/diagrams/, are opened read-only, and are
     never copied into a LaTeX work directory or a release archive.
  2. `derive_image` produces a deterministic publication derivative: EXIF orientation is baked into the
     pixels (`ImageOps.exif_transpose`), every EXIF, XMP, IPTC, comment and text chunk is dropped, and
     only the ICC colour profile (if present) is kept. A corrupt image fails the release.
  3. After pdfLaTeX builds the PDF, `check_pdf_image_metadata` scans the raw PDF bytes AND extracts every
     embedded image with `pdfimages -all` to confirm zero EXIF/XMP/Photoshop/IPTC/COM/text metadata and
     zero leaked original metadata strings remain in the released PDF.
  4. `check_no_originals_archived` confirms no raster original's SHA-256 appears among archived edition files.

What this does not do: it never infers that a real-looking photograph is authentic (`generation_method` stays
an attested field, FR-013), and it does not resize for file-size budgets (FR-026).
"""
from __future__ import annotations

import shutil
import struct
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from PIL import Image, ImageOps, PngImagePlugin

from . import qa
from .common import Finding, err, sha256_file

RECIPE_RASTER = "strip-metadata-reencode-v1"
RECIPE_PDF = "vector-pdf-passthrough-v1"
FORBIDDEN_PDF_SIGNATURES = (b"Exif\x00\x00", b"http://ns.adobe.com/xap/", b"Photoshop 3.0")
FORBIDDEN_PNG_CHUNKS = frozenset({b"eXIf", b"tEXt", b"zTXt", b"iTXt", b"tIME"})
_EXIF_SUB_IFDS = (0x8769, 0x8825, 0xA005)  # ExifOffset, GPSInfo, Interop
_PNG_NON_TEXT_KEYS = frozenset({"icc_profile", "dpi", "gamma", "srgb", "chromaticity", "transparency", "interlace", "aspect", "background", "jfif", "jfif_version", "jfif_unit", "jfif_density", "adobe", "adobe_transform", "progression"})


class DeriveError(RuntimeError):
    """Raised when an approved image cannot be derived safely into a clean publication derivative."""


@dataclass(frozen=True)
class DerivativeRecord:
    asset_id: str
    original_path: str
    original_sha256: str
    derivative_name: str
    derivative_sha256: str
    format: str
    width: int | None
    height: int | None
    recipe: str
    icc_preserved: bool
    stripped_strings: tuple[str, ...]

    def to_manifest(self) -> dict[str, Any]:
        """Public lineage record written into the release manifest (omits stripped sensitive strings)."""
        return {
            "asset_id": self.asset_id,
            "original_path": self.original_path,
            "original_sha256": self.original_sha256,
            "derivative_name": self.derivative_name,
            "derivative_sha256": self.derivative_sha256,
            "format": self.format,
            "width": self.width,
            "height": self.height,
            "recipe": self.recipe,
            "icc_preserved": self.icc_preserved,
            "stripped_string_count": len(self.stripped_strings),
        }


# ----------------------------------------------------------------------- low-level container inspection
def inspect_jpeg_segments(data: bytes) -> list[str]:
    """Return forbidden segment names present in JPEG bytes. Only APP0 (JFIF) and APP2 (ICC_PROFILE) are allowed."""
    if not data.startswith(b"\xff\xd8"):
        return ["not_a_jpeg"]
    found: list[str] = []
    pos = 2
    end = len(data)
    while pos + 1 < end:
        if data[pos] != 0xFF:
            break
        while pos < end and data[pos] == 0xFF:
            pos += 1
        if pos >= end:
            break
        marker = data[pos]
        pos += 1
        if marker in (0xD8, 0xD9, 0x01) or 0xD0 <= marker <= 0xD7:
            if marker == 0xD9:
                break
            continue
        if marker == 0xDA:  # Start of Scan: image payload follows
            break
        if pos + 2 > end:
            break
        length = struct.unpack(">H", data[pos : pos + 2])[0]
        if length < 2 or pos + length > end:
            break
        payload = data[pos + 2 : pos + length]
        pos += length
        if marker == 0xFE:
            found.append("COM")
        elif marker == 0xE1:
            found.append("APP1(EXIF/XMP)")
        elif marker == 0xE2:
            if not payload.startswith(b"ICC_PROFILE\x00"):
                found.append("APP2(non-ICC)")
        elif 0xE3 <= marker <= 0xEF:
            found.append(f"APP{marker - 0xE0}")
    return found


def inspect_png_chunks(data: bytes) -> list[str]:
    """Return forbidden metadata chunk types present in PNG bytes."""
    if not data.startswith(b"\x89PNG\r\n\x1a\n"):
        return ["not_a_png"]
    found: list[str] = []
    pos = 8
    end = len(data)
    while pos + 8 <= end:
        length = struct.unpack(">I", data[pos : pos + 4])[0]
        ctype = data[pos + 4 : pos + 8]
        pos += 12 + length  # length + type + payload + crc
        if ctype in FORBIDDEN_PNG_CHUNKS:
            found.append(ctype.decode("ascii", "replace"))
        if ctype == b"IEND":
            break
    return found


def _collect_strings(value: Any, out: set[str]) -> None:
    if isinstance(value, bytes):
        try:
            text = value.decode("utf-8")
        except UnicodeDecodeError:
            text = value.decode("latin-1", "ignore")
        value = text
    if isinstance(value, str):
        cleaned = value.replace("\x00", "").strip()
        if len(cleaned) >= 4 and not cleaned.isdigit():
            out.add(cleaned)
    elif isinstance(value, dict):
        for v in value.values():
            _collect_strings(v, out)
    elif isinstance(value, (list, tuple)):
        for item in value:
            _collect_strings(item, out)


def extract_metadata_strings(path: Path) -> tuple[str, ...]:
    """Extract sensitive metadata strings (EXIF, GPS, XMP, COM, PNG text) from an original BEFORE stripping."""
    strings: set[str] = set()
    suffix = path.suffix.lower()
    if suffix == ".pdf":
        return ()
    try:
        with Image.open(path) as img:
            exif = img.getexif()
            for tag, val in exif.items():
                if tag != 0x0112:  # Orientation is a small int
                    _collect_strings(val, strings)
            for ifd_id in _EXIF_SUB_IFDS:
                try:
                    sub = exif.get_ifd(ifd_id)
                except Exception:
                    continue
                if isinstance(sub, dict):
                    for val in sub.values():
                        _collect_strings(val, strings)
            for key, val in img.info.items():
                if key not in _PNG_NON_TEXT_KEYS and key != "exif":
                    _collect_strings(val, strings)
    except Exception:
        return ()
    return tuple(sorted(strings))


def check_image_clean(path: Path) -> list[str]:
    """Verify a JPEG or PNG file carries no EXIF, XMP, IPTC, GPS, COM or text chunks."""
    data = path.read_bytes()
    problems: list[str] = []
    if data.startswith(b"\xff\xd8"):
        problems += inspect_jpeg_segments(data)
    elif data.startswith(b"\x89PNG\r\n\x1a\n"):
        problems += inspect_png_chunks(data)
    else:
        return []
    try:
        with Image.open(path) as img:
            if len(img.getexif()) > 0:
                problems.append("pillow_exif_nonempty")
            for key in img.info:
                if key not in _PNG_NON_TEXT_KEYS:
                    problems.append(f"info:{key}")
    except Exception as exc:
        problems.append(f"unreadable:{exc}")
    return sorted(set(problems))


# --------------------------------------------------------------------------- deterministic derivation
def _inside_any(path: Path, roots: tuple[Path, ...]) -> bool:
    resolved = path.resolve()
    return any(resolved.is_relative_to(root.resolve()) for root in roots)


def derive_image(src: Path, dst: Path, *, asset_id: str, original_rel: str, expected_sha256: str | None = None,
                 allowed_roots: tuple[Path, ...] | None = None) -> DerivativeRecord:
    """Create a clean, deterministic publication derivative from an approved original.

    The original is read-only and never modified. Orientation is applied to pixels; only ICC is preserved.
    """
    if not src.is_file():
        raise DeriveError(f"{asset_id}: original file {src} does not exist")
    if allowed_roots is not None and not _inside_any(src, allowed_roots):
        raise DeriveError(f"{asset_id}: original file {original_rel!r} is outside the approved asset directories")
    original_sha = sha256_file(src)
    if expected_sha256 and original_sha != expected_sha256:
        raise DeriveError(f"{asset_id}: original file hash does not match manifest sha256")

    dst.parent.mkdir(parents=True, exist_ok=True)
    suffix = src.suffix.lower()
    if suffix == ".pdf":
        raw = src.read_bytes()
        if not raw.startswith(b"%PDF-"):
            raise DeriveError(f"{asset_id}: {original_rel} is not a valid PDF graphic")
        for sig in FORBIDDEN_PDF_SIGNATURES:
            if sig in raw:
                raise DeriveError(f"{asset_id}: PDF graphic contains forbidden metadata signature {sig!r}")
        dst.write_bytes(raw)
        return DerivativeRecord(asset_id, original_rel, original_sha, dst.name, sha256_file(dst),
                                "PDF", None, None, RECIPE_PDF, False, ())

    if suffix not in (".jpg", ".jpeg", ".png"):
        raise DeriveError(f"{asset_id}: unsupported image format {suffix!r} for publication derivative")

    stripped_strings = extract_metadata_strings(src)
    try:
        with Image.open(src) as opened:
            opened.load()  # catches truncated / corrupt raster data
            raw_icc = opened.info.get("icc_profile")
            icc = raw_icc if isinstance(raw_icc, bytes) and raw_icc else None
            transposed = ImageOps.exif_transpose(opened)
            if suffix in (".jpg", ".jpeg"):
                if transposed.mode not in ("RGB", "L"):
                    transposed = transposed.convert("RGB")
                clean = Image.frombytes(transposed.mode, transposed.size, transposed.tobytes())
                save_kwargs: dict[str, Any] = {"format": "JPEG", "quality": 92, "subsampling": 0, "optimize": True}
                if icc:
                    save_kwargs["icc_profile"] = icc
                clean.save(dst, **save_kwargs)
                fmt = "JPEG"
            else:
                if transposed.mode == "P":
                    transposed = transposed.convert("RGBA")
                clean = Image.frombytes(transposed.mode, transposed.size, transposed.tobytes())
                save_kwargs = {"format": "PNG", "compress_level": 9, "pnginfo": PngImagePlugin.PngInfo()}
                if icc:
                    save_kwargs["icc_profile"] = icc
                clean.save(dst, **save_kwargs)
                fmt = "PNG"
            width, height = clean.size
    except DeriveError:
        raise
    except Exception as exc:
        raise DeriveError(f"{asset_id}: corrupt or unreadable image {original_rel}: {exc}") from exc

    problems = check_image_clean(dst)
    if problems:
        raise DeriveError(f"{asset_id}: derivative still contains metadata ({', '.join(problems)})")
    if sha256_file(src) != original_sha:
        raise DeriveError(f"{asset_id}: original file changed during derivation")
    return DerivativeRecord(asset_id, original_rel, original_sha, dst.name, sha256_file(dst),
                            fmt, width, height, RECIPE_RASTER, bool(icc), stripped_strings)


# --------------------------------------------------------------------------- post-build PDF checks
def check_pdf_image_metadata(pdf: Path, derivatives: list[DerivativeRecord]) -> list[Finding]:
    """Verify no EXIF/XMP/Photoshop signatures, forbidden embedded segments or leaked metadata strings exist in the PDF."""
    where = pdf.name
    findings: list[Finding] = []
    raw = pdf.read_bytes()
    for sig in FORBIDDEN_PDF_SIGNATURES:
        if sig in raw:
            findings.append(err("IMAGE_METADATA_IN_PDF", where, f"PDF bytes contain forbidden metadata signature {sig!r}"))

    try:
        visible_text = "\n".join(qa.page_texts(pdf))
    except Exception:
        visible_text = ""

    all_stripped = sorted({s for d in derivatives for s in d.stripped_strings})
    for text in all_stripped:
        if text in visible_text:
            continue  # legitimate visible text (e.g. photographer credit on the page); still checked inside extracted image bytes below
        for enc in ("utf-8", "latin-1"):
            needle = text.encode(enc, "ignore")
            if len(needle) >= 4 and needle in raw:
                findings.append(err("IMAGE_METADATA_IN_PDF", where, f"original image metadata string {text[:50]!r} leaked into released PDF bytes"))
                break

    pdfimages = shutil.which("pdfimages")
    if not pdfimages:
        findings.append(err("IMAGE_METADATA_CHECK_UNAVAILABLE", where, "pdfimages not found; cannot verify embedded image streams are stripped"))
        return findings

    with tempfile.TemporaryDirectory(prefix="sfe-pdfimg-") as tmp:
        prefix = Path(tmp) / "img"
        proc = subprocess.run([pdfimages, "-all", str(pdf), str(prefix)], capture_output=True, text=True, check=False, timeout=120)
        if proc.returncode != 0:
            findings.append(err("IMAGE_METADATA_CHECK_UNAVAILABLE", where, f"pdfimages failed: {proc.stderr.strip()[:200]}"))
            return findings
        for extracted in sorted(Path(tmp).iterdir()):
            if not extracted.is_file():
                continue
            problems = check_image_clean(extracted)
            if problems:
                findings.append(err("IMAGE_METADATA_IN_PDF", where, f"embedded image {extracted.name} carries forbidden metadata: {', '.join(problems)}"))
            img_bytes = extracted.read_bytes()
            for text in all_stripped:
                for enc in ("utf-8", "latin-1"):
                    needle = text.encode(enc, "ignore")
                    if len(needle) >= 4 and needle in img_bytes:
                        findings.append(err("IMAGE_METADATA_IN_PDF", where, f"embedded image {extracted.name} contains original metadata string {text[:50]!r}"))
                        break
    return findings


def check_no_originals_archived(edition_dir: Path, derivatives: list[DerivativeRecord]) -> list[Finding]:
    """Confirm no original raster file was copied verbatim into the release archive."""
    raster_originals = {d.original_sha256: d.asset_id for d in derivatives if d.recipe == RECIPE_RASTER}
    if not raster_originals:
        return []
    findings: list[Finding] = []
    for path in sorted(edition_dir.rglob("*")):
        if not path.is_file():
            continue
        digest = sha256_file(path)
        if digest in raster_originals:
            rel = path.relative_to(edition_dir).as_posix()
            findings.append(err("ORIGINAL_PUBLISHED", rel, f"archived file matches original hash of {raster_originals[digest]}; only stripped derivatives may be released"))
    return findings
