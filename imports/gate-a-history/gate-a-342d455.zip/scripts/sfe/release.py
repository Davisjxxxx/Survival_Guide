"""Release state: which build is current, what became of the others, and how that is kept honest (finding FR-017).

At RUN-003 `release` wrote the flat `dist/zones/<ZONE>.pdf` and overwrote it. When an approval was withdrawn the next release was refused, and the earlier PDF
and its manifest stayed exactly where releases are collected (probe P25): a stale PDF that looked current, with nothing to say which approvals it rested on.

THE MODEL. Everything lives under `dist/` (git-ignored build output; the paths are in .gitignore):

    editions/<ED-id>/                    an IMMUTABLE ARCHIVE: one directory per edition, written once, never overwritten, its files made read-only.
        zones/<ZONE>.pdf, .build.json    The id is derived from the build's INPUTS (entries and their package digests, every ledger's row count and head, the
        EDITION.json                     policy digests, layout, build configuration, toolchain, pipeline version), so one tree builds one edition.
    ACTIVE_RELEASE.json                  the EXPLICIT ACTIVE-RELEASE MANIFEST: state `active` or `withdrawn`, the edition, the hash of its EDITION.json, a
                                         generation, and the reason. The only label of "current": no PDF anywhere else is current, and no flat copy exists.
    RELEASE_LOG.csv                      an APPEND-ONLY, hash-chained AUDIT LOG: promote, supersede, withdraw, auto_withdraw, quarantine, recover. The tool never
                                         deletes it, and never deletes an edition.
    .staging/                            transient build output; a leftover is moved to quarantine/ by `recover`, never trusted, never deleted.
    quarantine/<n>/                      what was moved aside (a legacy flat PDF, a leftover staging directory, a partial log line), kept as evidence.

PROMOTION IS ATOMIC. The build and its checks happen in staging; the staging directory is renamed into editions/ (one file system, one rename); the pointer is
written to a temporary file, flushed, and `os.replace`d; then the log is appended. A crash between any two steps leaves a state `recover` repairs (it appends
what the log missed and moves leftovers aside; the pointer is authoritative) and the next release completes. Named fault points let the tests interrupt each step.

VALIDATION OF THE ACTIVE RELEASE (`verify_active`, read-only). The pointer is well formed; the edition exists and its EDITION.json and every artifact match their
recorded hashes; every entry is still published with the same revision and the SAME PACKAGE DIGEST as at build (so a withdrawn approval, an edited claim, source or
image, all show); each ledger still extends the head recorded at build; the policy digests are unchanged; the current tree has no error that concerns the edition
(an error in an unrelated entry does not revoke it; a ledger, register or policy error does). `reconcile` withdraws an edition that fails; every release runs it first.

What this does not do: nothing is signed, so someone with write access to dist/ can edit the pointer (verify re-validates against the tree, which catches a stale or
forged pointer, not a forged edition together with a forged tree); a copied PDF carries no label; the log's tail can be truncated unnoticed; the edition id is not
yet printed in the PDF and there is no errata ledger. A refusal that finds no earlier state writes nothing at all, not even the directory.
"""
from __future__ import annotations

import csv
import io
import json
import os
import re
import shutil
from contextlib import contextmanager
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterator

try:
    import fcntl
except ImportError:  # pragma: no cover - not a POSIX system
    fcntl = None  # type: ignore[assignment]

from . import textcheck
from .common import CsvError, Finding, err, note, parse_csv_bytes, read_csv, sha256_bytes, sha256_file
from .ledger import GENESIS, chain_value, check_pin
from .registry import LEDGERS, REGISTERS, Repo

POINTER = "ACTIVE_RELEASE.json"
LOG = "RELEASE_LOG.csv"
EDITIONS = "editions"
STAGING = ".staging"
QUARANTINE = "quarantine"
LOCK = ".release.lock"
EDITION_FILE = "EDITION.json"
LEGACY_DIRS = ("zones", "complete")  # the pre-RUN-004 flat output: nothing but .gitkeep may sit there
LOG_COLUMNS = ["sequence", "event", "edition_id", "reason", "detail", "chain_sha256"]
EVENTS = ("promote", "supersede", "withdraw", "auto_withdraw", "quarantine", "recover")
STATES = ("active", "withdrawn")
ACTORS = ("release", "withdraw", "reconcile")
ID_RE = re.compile(r"^ED-[0-9a-f]{16}$")
# The policy tables a release rests on: their digests go into every edition, so an edition names the rules it was checked under.
POLICY_FILES = ("schemas/hazard_topics.yaml", "schemas/classification_policy.yaml", "schemas/claim_policy.yaml", "schemas/unit_policy.yaml", "schemas/licenses.yaml")
ENTRY_FILE = re.compile(r"^content/[^/]+/[^/]+\.md$")
MIN_REASON_WORDS = 3

# A test hook: called with the name of each step of a promotion; a test raises from it to simulate a crash there. Production never sets it.
_FAULT: Callable[[str], None] | None = None


class ReleaseStateError(RuntimeError):
    """The release state cannot be changed safely (a lock is held, an edition conflicts, a log is corrupt, a reason is missing)."""


def _fault(step: str) -> None:
    if _FAULT is not None:
        _FAULT(step)


# ------------------------------------------------------------------------------------------------ files
def _fsync_dir(path: Path) -> None:
    try:
        fd = os.open(path, os.O_RDONLY)
    except OSError:  # pragma: no cover - a platform that cannot open a directory
        return
    try:
        os.fsync(fd)
    except OSError:  # pragma: no cover
        pass
    finally:
        os.close(fd)


def _write_atomic(path: Path, data: bytes, *, step: str | None = None) -> None:
    """Write `path` so that a reader sees the old file or the new one, never half of it."""
    temporary = path.with_name(path.name + ".tmp")
    with open(temporary, "wb") as handle:
        handle.write(data)
        handle.flush()
        os.fsync(handle.fileno())
    if step:
        _fault(step)
    os.replace(temporary, path)
    _fsync_dir(path.parent)


def _readonly(tree: Path) -> None:
    """Make the files of an edition read-only (best effort; directories stay writable so that tooling can still clean up a temporary tree)."""
    for path in tree.rglob("*"):
        if path.is_file():
            try:
                path.chmod(0o444)
            except OSError:  # pragma: no cover
                pass


def has_state(dist: Path) -> bool:
    """True when there is anything under `dist` that release state could be about. A refusal that finds none writes nothing."""
    if not dist.is_dir():
        return False
    if any((dist / name).exists() for name in (POINTER, POINTER + ".tmp", LOG, EDITIONS, STAGING, QUARANTINE)):
        return True
    return bool(_legacy_files(dist))


def _legacy_files(dist: Path) -> list[Path]:
    found: list[Path] = []
    for name in LEGACY_DIRS:
        directory = dist / name
        if directory.is_dir():
            found += [p for p in sorted(directory.rglob("*")) if p.is_file() and p.name != ".gitkeep"]
    return found


@contextmanager
def locked(dist: Path) -> Iterator[None]:
    """Exclusive, non-blocking lock on dist/.release.lock (released when the process ends, so a crash leaves no stale lock)."""
    dist.mkdir(parents=True, exist_ok=True)
    handle = open(dist / LOCK, "a+b")
    try:
        if fcntl is not None:
            try:
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError as exc:
                raise ReleaseStateError(f"another release process holds {dist / LOCK}") from exc
        yield
    finally:
        handle.close()


# ----------------------------------------------------------------------------------------------- pointer
@dataclass(frozen=True)
class Pointer:
    state: str
    edition_id: str
    edition_manifest_sha256: str
    generation: int
    reason: str | None
    by: str
    schema: int = 1


def read_pointer(dist: Path) -> tuple[Pointer | None, list[Finding]]:
    path = dist / POINTER
    if not path.is_file():
        return None, []
    where = f"{path.name}"
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        return None, [err("RELEASE_POINTER_INVALID", where, f"not valid JSON: {exc}")]
    keys = {"schema", "state", "edition_id", "edition_manifest_sha256", "generation", "reason", "by"}
    if not isinstance(data, dict) or set(data) != keys:
        return None, [err("RELEASE_POINTER_INVALID", where, f"expected exactly the keys {', '.join(sorted(keys))}")]
    problems = []
    if data["schema"] != 1:
        problems.append("schema must be 1")
    if data["state"] not in STATES:
        problems.append(f"state must be one of {', '.join(STATES)}")
    if not (isinstance(data["edition_id"], str) and ID_RE.fullmatch(data["edition_id"])):
        problems.append("edition_id must look like ED-0123456789abcdef")
    if not (isinstance(data["edition_manifest_sha256"], str) and re.fullmatch(r"[0-9a-f]{64}", data["edition_manifest_sha256"])):
        problems.append("edition_manifest_sha256 must be a SHA-256")
    if not (isinstance(data["generation"], int) and not isinstance(data["generation"], bool) and data["generation"] >= 1):
        problems.append("generation must be a positive integer")
    if data["by"] not in ACTORS:
        problems.append(f"by must be one of {', '.join(ACTORS)}")
    if data["state"] == "withdrawn" and not (isinstance(data["reason"], str) and data["reason"].strip()):
        problems.append("a withdrawn release must carry its reason")
    if problems:
        return None, [err("RELEASE_POINTER_INVALID", where, "; ".join(problems))]
    return Pointer(data["state"], data["edition_id"], data["edition_manifest_sha256"], data["generation"], data["reason"], data["by"]), []


def _write_pointer(dist: Path, pointer: Pointer) -> None:
    _write_atomic(dist / POINTER, (json.dumps(asdict(pointer), indent=2, sort_keys=True) + "\n").encode("utf-8"), step="after_pointer_tmp")


# ---------------------------------------------------------------------------------------------------- log
def _clean(text: str | None) -> str:
    """One line, no control character: the chain reserves two of them and a CSV cell is easier to audit on one line."""
    return " ".join(re.sub(r"[\x00-\x1f\x7f]", " ", text or "").split())


def read_log(dist: Path) -> tuple[list[dict[str, str]], list[Finding]]:
    """The log's rows, with every sequence number and chain value checked. A damaged log is reported and never repaired in place."""
    path = dist / LOG
    if not path.is_file():
        return [], []
    try:
        header, rows = parse_csv_bytes(path.read_bytes())
    except CsvError as exc:
        return [], [err("RELEASE_LOG_INVALID", LOG, str(exc))]
    if header != LOG_COLUMNS:
        return [], [err("RELEASE_LOG_INVALID", LOG, f"header must be {','.join(LOG_COLUMNS)}")]
    previous = GENESIS
    for index, row in enumerate(rows, start=1):
        cells = [row[c] for c in LOG_COLUMNS if c != "chain_sha256"]
        if row["sequence"] != str(index) or row["event"] not in EVENTS or row["chain_sha256"] != chain_value(previous, cells):
            return rows[: index - 1], [err("RELEASE_LOG_INVALID", f"{LOG}:row {index}", "the row was edited, inserted, deleted or reordered (sequence, event or chain does not match)")]
        previous = row["chain_sha256"]
    return rows, []


def append_log(dist: Path, event: str, edition_id: str | None, reason: str | None = None, detail: str | None = None) -> dict[str, str]:
    """Append one row. Refuses when the log is damaged: an audit trail is extended only from a trail that is intact."""
    if event not in EVENTS:
        raise ReleaseStateError(f"unknown release event {event!r}")
    rows, problems = read_log(dist)
    if problems:
        raise ReleaseStateError(f"{LOG} is damaged and is not extended: {problems[0].message}")
    previous = rows[-1]["chain_sha256"] if rows else GENESIS
    cells = [str(len(rows) + 1), event, edition_id or "", _clean(reason), _clean(detail)]
    row = dict(zip(LOG_COLUMNS, [*cells, chain_value(previous, cells)]))
    path = dist / LOG
    fresh = not path.is_file()
    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    if fresh:
        writer.writerow(LOG_COLUMNS)
    writer.writerow([row[c] for c in LOG_COLUMNS])
    with open(path, "ab") as handle:
        handle.write(out.getvalue().encode("utf-8"))
        handle.flush()
        os.fsync(handle.fileno())
    return row


def _log_active(rows: list[dict[str, str]]) -> str | None:
    """The edition the log says is active: the last promoted one, unless a later row withdrew it."""
    active: str | None = None
    for row in rows:
        if row["event"] == "promote":
            active = row["edition_id"]
        elif row["event"] in ("withdraw", "auto_withdraw") and row["edition_id"] == active:
            active = None
    return active


# --------------------------------------------------------------------------------------------- the build state
def ledger_state(repo: Repo) -> dict[str, dict[str, Any]]:
    """For every ledger, its row count and the chain value of its last row: what a release rests on, and what a later tree must still extend."""
    state: dict[str, dict[str, Any]] = {}
    for name in sorted(LEDGERS):
        _header, rows = read_csv(repo.path(REGISTERS[name][0]))
        state[name] = {"rows": len(rows), "head": rows[-1].get("chain_sha256", GENESIS) if rows else GENESIS}
    return state


def policy_digests(repo: Repo) -> dict[str, str]:
    return {rel: (sha256_file(repo.path(rel)) if repo.path(rel).is_file() else "MISSING") for rel in POLICY_FILES}


def edition_id_of(inputs: dict[str, Any]) -> str:
    """The id of an edition: a digest of everything that determines its bytes. The same tree on the same toolchain is the same edition."""
    return "ED-" + sha256_bytes(json.dumps(inputs, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8"))[:16]


def edition_bytes(edition: dict[str, Any]) -> bytes:
    return (json.dumps(edition, indent=2, sort_keys=True, ensure_ascii=False) + "\n").encode("utf-8")


# ----------------------------------------------------------------------------------------------- promotion
@dataclass
class Promotion:
    edition_id: str
    directory: Path
    changed: bool  # False when the edition was already the active one


def _tree_hashes(root: Path) -> dict[str, str]:
    return {p.relative_to(root).as_posix(): sha256_file(p) for p in sorted(root.rglob("*")) if p.is_file()}


def _archive(dist: Path, staged: Path, edition_id: str) -> Path:
    target = dist / EDITIONS / edition_id
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        if _tree_hashes(staged) == _tree_hashes(target):
            shutil.rmtree(staged)  # the same edition, byte for byte: nothing to add (our own staging copy, not evidence)
            try:
                staged.parent.rmdir()
            except OSError:
                pass
            return target
        raise ReleaseStateError(f"edition {edition_id} already exists with different content: an edition is immutable, so this build is refused (EDITION_CONFLICT)")
    os.rename(staged, target)  # one file system, one rename: the edition appears whole or not at all
    _fsync_dir(target.parent)
    _readonly(target)
    try:
        staged.parent.rmdir()
    except OSError:
        pass
    return target


def promote(dist: Path, staged: Path, edition_id: str) -> Promotion:
    """Archive the staged edition and make it the active release. Atomic in the steps that matter; see the module docstring for what a crash leaves."""
    previous, problems = read_pointer(dist)
    if problems:
        raise ReleaseStateError(f"{POINTER} is invalid and is not replaced blindly: {problems[0].message}")
    rows, log_problems = read_log(dist)
    if log_problems:
        raise ReleaseStateError(f"{LOG} is damaged and is not extended: {log_problems[0].message}")
    if (previous and previous.state == "withdrawn" and previous.edition_id == edition_id) or any(
        row["event"] in ("withdraw", "auto_withdraw") and row["edition_id"] == edition_id for row in rows
    ):
        raise ReleaseStateError(f"edition {edition_id} was withdrawn and cannot be reactivated; a new approval or revision is required (EDITION_WITHDRAWN)")
    _fault("before_archive")
    target = _archive(dist, staged, edition_id)
    _fault("after_archive")
    digest = sha256_file(target / EDITION_FILE)
    if previous and previous.state == "active" and previous.edition_id == edition_id and previous.edition_manifest_sha256 == digest:
        return Promotion(edition_id, target, False)
    generation = (previous.generation if previous else 0) + 1
    _write_pointer(dist, Pointer("active", edition_id, digest, generation, None, "release"))
    _fault("after_pointer")
    if previous and previous.state == "active" and previous.edition_id != edition_id:
        append_log(dist, "supersede", previous.edition_id, detail=f"superseded by {edition_id}")
        _fault("mid_log")
    append_log(dist, "promote", edition_id, detail=f"generation {generation}")
    return Promotion(edition_id, target, True)


def withdraw(dist: Path, reason: str, *, by: str = "withdraw") -> Pointer:
    """Take the active release out of service, with a reason that says something. The edition stays in the archive."""
    pointer, problems = read_pointer(dist)
    if problems:
        raise ReleaseStateError(problems[0].message)
    if pointer is None or pointer.state != "active":
        raise ReleaseStateError("there is no active release to withdraw")
    why = _clean(reason)
    if by == "withdraw" and (textcheck.assess(why, minimum_words=MIN_REASON_WORDS) is not None):
        raise ReleaseStateError(f"a withdrawal needs a reason of at least {MIN_REASON_WORDS} words that says something; got {reason!r}")
    withdrawn = Pointer("withdrawn", pointer.edition_id, pointer.edition_manifest_sha256, pointer.generation + 1, why, by)
    _write_pointer(dist, withdrawn)
    _fault("after_withdraw_pointer")
    try:
        append_log(dist, "withdraw" if by == "withdraw" else "auto_withdraw", pointer.edition_id, reason=why)
    except ReleaseStateError:
        if by == "withdraw":
            raise
    return withdrawn


# ------------------------------------------------------------------------------------------ verification
@dataclass
class Verification:
    state: str  # active | withdrawn | none | invalid
    pointer: Pointer | None
    findings: list[Finding] = field(default_factory=list)

    @property
    def errors(self) -> list[Finding]:
        return [f for f in self.findings if f.severity == "error"]

    @property
    def ok(self) -> bool:
        return self.state == "active" and not self.errors


def _relevant(finding: Finding, edition_files: set[str]) -> bool:
    """An error concerns the edition if it is about one of its entries, or about something that is not an entry file at all (a ledger, register, policy, zone)."""
    head = finding.where.split(" ")[0].split(":")[0]
    return head in edition_files if ENTRY_FILE.match(head) else True


def _extends(repo: Repo, name: str, rows: int, head: str) -> bool:
    if rows == 0:
        return True
    try:
        _header, current = read_csv(repo.path(REGISTERS[name][0]))
    except (OSError, CsvError):
        return False
    return len(current) >= rows and current[rows - 1].get("chain_sha256") == head


def verify_active(repo: Repo, dist: Path, *, ctx: Any = None, gate_findings: list[Finding] | None = None, pin: str | Path | None = None) -> Verification:
    """Read-only. Is the active release still the release the approvals in force would produce? See the module docstring for what is checked."""
    from .validate import build_context, package_of, run_gates

    pointer, problems = read_pointer(dist)
    if problems:
        return Verification("invalid", None, problems)
    if pointer is None:
        return Verification("none", None, [])
    if pointer.state == "withdrawn":
        return Verification("withdrawn", pointer, [])
    found: list[Finding] = []
    legacy = _legacy_files(dist)
    if legacy:
        found.append(err("RELEASE_LEGACY_OUTPUT", "dist", f"{len(legacy)} file(s) from the flat layout sit in dist/zones or dist/complete, where a stale PDF looks current "
                                                          f"({legacy[0].relative_to(dist).as_posix()}...): `release reconcile` moves them to dist/{QUARANTINE}/"))
    _rows, log_problems = read_log(dist)
    found += log_problems
    manifest_path = dist / EDITIONS / pointer.edition_id / EDITION_FILE
    if not manifest_path.is_file():
        return Verification("active", pointer, found + [err("RELEASE_EDITION_MISSING", f"{EDITIONS}/{pointer.edition_id}", "the active edition's EDITION.json does not exist")])
    if sha256_file(manifest_path) != pointer.edition_manifest_sha256:
        return Verification("active", pointer, found + [err("RELEASE_EDITION_MODIFIED", f"{EDITIONS}/{pointer.edition_id}/{EDITION_FILE}",
                                                            "EDITION.json does not match the hash the pointer recorded")])
    try:
        edition = json.loads(manifest_path.read_text(encoding="utf-8"))
        artifacts, entries = edition["artifacts"], edition["entries"]
        recorded_ledgers, recorded_policy = edition["ledger_state"], edition["policy_sha256"]
    except (OSError, ValueError, KeyError, TypeError) as exc:
        return Verification("active", pointer, found + [err("RELEASE_EDITION_MODIFIED", f"{EDITIONS}/{pointer.edition_id}/{EDITION_FILE}", f"unreadable: {exc}")])
    base = dist / EDITIONS / pointer.edition_id
    for artifact in artifacts:
        for key in ("pdf", "manifest"):
            path = base / artifact[key]
            if not path.is_file():
                found.append(err("RELEASE_EDITION_MODIFIED", f"{EDITIONS}/{pointer.edition_id}/{artifact[key]}", "an archived artifact is missing"))
            elif sha256_file(path) != artifact[f"{key}_sha256"]:
                found.append(err("RELEASE_EDITION_MODIFIED", f"{EDITIONS}/{pointer.edition_id}/{artifact[key]}", "an archived artifact does not match its recorded SHA-256"))

    if ctx is None:
        ctx, load_findings = build_context(repo.root, pin=pin, require_pin=True)
        gate_findings = load_findings + run_gates(ctx)
    else:
        pin_findings = check_pin(repo, pin, require=True)
        gate_findings = list(gate_findings or []) + pin_findings
    for f in (gate_findings or []):
        if f.severity == "error" and f.code.startswith("LEDGER_PIN_"):
            found.append(f)
    by_id = {e.entry_id: e for e in ctx.entries}
    edition_files = {by_id[item["id"]].rel for item in entries if item["id"] in by_id}
    tree = sorted({(f.code, f.where) for f in (gate_findings or []) if f.severity == "error" and _relevant(f, edition_files)})
    if tree:
        shown = "; ".join(f"{code} in {where}" for code, where in tree[:4]) + (f"; and {len(tree) - 4} more" if len(tree) > 4 else "")
        found.append(err("RELEASE_TREE_INVALID", "dist", f"the tree no longer validates for this edition: {shown}"))
    for item in entries:
        entry = by_id.get(item["id"])
        if entry is None:
            found.append(err("RELEASE_ENTRY_CHANGED", item["id"], "the entry is no longer in the tree"))
        elif entry.fm["status"] != "published":
            found.append(err("RELEASE_ENTRY_CHANGED", item["id"], f"the entry is now {entry.fm['status']}, not published"))
        elif entry.fm["revision"] != item["revision"]:
            found.append(err("RELEASE_ENTRY_CHANGED", item["id"], f"revision {entry.fm['revision']} now, {item['revision']} when built"))
        elif package_of(ctx, entry)[2] != item["package_sha256"]:
            found.append(err("RELEASE_ENTRY_CHANGED", item["id"], "its package digest changed (an approval, claim, source, image or checklist it rests on is not what was built)"))
    for name in sorted(set(recorded_ledgers) | set(LEDGERS)):
        record = recorded_ledgers.get(name)
        if record is None or name not in LEDGERS or not _extends(repo, name, record["rows"], record["head"]):
            found.append(err("RELEASE_LEDGER_NOT_EXTENDED", REGISTERS[name][0] if name in REGISTERS else name,
                             "the ledger no longer begins with the rows that existed at build (a row was edited, removed or the ledger rewound)"))
    if recorded_policy != policy_digests(repo):
        changed = sorted(rel for rel in set(recorded_policy) | set(POLICY_FILES) if recorded_policy.get(rel) != sha256_file(repo.path(rel)) if repo.path(rel).is_file())
        found.append(err("RELEASE_POLICY_CHANGED", "schemas", f"the policy tables differ from those the edition was checked under ({', '.join(changed) or 'a policy file is missing'})"))
    return Verification("active", pointer, found)


# -------------------------------------------------------------------------------------- reconcile, recover
def _next_quarantine(dist: Path) -> Path:
    base = dist / QUARANTINE
    base.mkdir(parents=True, exist_ok=True)
    number = 1 + sum(1 for p in base.iterdir() if p.is_dir())
    target = base / str(number)
    target.mkdir()
    return target


def recover(dist: Path) -> list[str]:
    """Repair what an interrupted run left, without deleting evidence. Returns what it did (empty when nothing was wrong)."""
    actions: list[str] = []
    if not dist.is_dir():
        return actions
    temporary = dist / (POINTER + ".tmp")
    if temporary.exists():
        temporary.unlink()  # a half-written copy of a pointer: the real pointer is intact, this adds nothing
        actions.append("discarded an interrupted write of the active-release pointer")
    log_path = dist / LOG
    if log_path.is_file():
        raw = log_path.read_bytes()
        if raw and not raw.endswith(b"\n"):
            cut = raw.rfind(b"\n") + 1
            quarantine = _next_quarantine(dist)
            (quarantine / "RELEASE_LOG.partial-row").write_bytes(raw[cut:])
            _write_atomic(log_path, raw[:cut])
            actions.append(f"moved a partly written last log row aside to {QUARANTINE}/{quarantine.name}/")
    staging = dist / STAGING
    if staging.is_dir():
        leftovers = [p for p in sorted(staging.iterdir())]
        if leftovers:
            quarantine = _next_quarantine(dist)
            for path in leftovers:
                shutil.move(str(path), str(quarantine / f"staging-{path.name}"))
            actions.append(f"moved {len(leftovers)} leftover staging director{'y' if len(leftovers) == 1 else 'ies'} to {QUARANTINE}/{quarantine.name}/")
        try:
            staging.rmdir()
        except OSError:  # pragma: no cover
            pass
    pointer, problems = read_pointer(dist)
    rows, log_problems = read_log(dist)
    if not problems and not log_problems and pointer is not None:
        recorded = _log_active(rows)
        if pointer.state == "active" and recorded != pointer.edition_id:
            if recorded is not None:
                append_log(dist, "supersede", recorded, detail=f"superseded by {pointer.edition_id} (recorded by recover)")
            append_log(dist, "promote", pointer.edition_id, detail=f"generation {pointer.generation} (recorded by recover: the pointer was replaced but the log was not written)")
            actions.append(f"recorded the promotion of {pointer.edition_id} that the log had missed")
        elif pointer.state == "withdrawn" and not any(
            row["event"] in ("withdraw", "auto_withdraw") and row["edition_id"] == pointer.edition_id for row in rows
        ):
            # Promotion and withdrawal can both stop before their log append.
            # Preserve the authoritative withdrawal even without a promotion
            # row, so replacing the pointer later cannot erase the prohibition.
            event = "auto_withdraw" if pointer.by == "reconcile" else "withdraw"
            append_log(dist, event, pointer.edition_id, reason=pointer.reason, detail="recorded by recover: the pointer was withdrawn but the log was not written")
            actions.append(f"recorded the withdrawal of {pointer.edition_id} that the log had missed")
    editions = dist / EDITIONS
    if editions.is_dir() and not log_problems:
        mentioned = {row["edition_id"] for row in read_log(dist)[0]}
        for path in sorted(editions.iterdir()):
            if path.is_dir() and path.name not in mentioned:
                append_log(dist, "recover", path.name, detail="archived but never promoted (an interrupted release); kept as evidence")
                actions.append(f"noted edition {path.name}, archived but never promoted")
    return actions


def quarantine_legacy(dist: Path) -> list[str]:
    """Move any pre-RUN-004 flat output in dist/zones or dist/complete to quarantine/, never deleting it."""
    legacy = _legacy_files(dist)
    if not legacy:
        return []
    quarantine = _next_quarantine(dist)
    for path in legacy:
        destination = quarantine / path.relative_to(dist)
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(path), str(destination))
    names = sorted({p.relative_to(dist).as_posix() for p in legacy})
    try:
        append_log(dist, "quarantine", None, detail=f"moved {len(names)} legacy file(s) to {QUARANTINE}/{quarantine.name}/: {', '.join(names[:5])}")
    except ReleaseStateError:
        pass
    return [f"moved {len(names)} legacy file(s) from the flat layout to {QUARANTINE}/{quarantine.name}/"]


def reconcile(repo: Repo, dist: Path, *, ctx: Any = None, gate_findings: list[Finding] | None = None, pin: str | Path | None = None) -> list[str]:
    """Bring the state in line with the tree: repair an interrupted run, move legacy flat output aside, and withdraw an active edition that no longer verifies."""
    actions = recover(dist) + quarantine_legacy(dist)
    verification = verify_active(repo, dist, ctx=ctx, gate_findings=gate_findings, pin=pin)
    if verification.state == "active" and verification.errors:
        codes = sorted({f.code for f in verification.errors})
        reason = f"no longer valid against the current approvals and sources: {', '.join(codes)} ({verification.errors[0].message[:140]})"
        withdraw(dist, reason, by="reconcile")
        actions.append(f"withdrew {verification.pointer.edition_id if verification.pointer else '?'}: {', '.join(codes)}")
    return actions
