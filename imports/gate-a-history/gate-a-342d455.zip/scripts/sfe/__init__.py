"""Survival Field Encyclopedia build tooling (Gate A scaffold).

This package validates content and registers, enforces approval gates and
image-provenance rules, and builds reproducible PDFs. It never writes, edits or
invents survival content, research, photographs or approvals.
"""

__version__ = "0.1.0"
