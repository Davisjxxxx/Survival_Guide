# Unresolved research (`NEEDS_CHAT_RESEARCH` cards)

Rule (handoff section 5): research from earlier chats is **not** automatically local. When it is missing, the
build records an explicit card and asks for an export. It never reconstructs, summarises from memory, or invents it.

Status values: `OPEN` (requested, not received) · `SUPPLIED` (files received and hash-recorded) · `WITHDRAWN`.
A card changes status only when real files arrive and their SHA-256 values are written here.

| Card | Item | Status | Needed by | Blocks Gate A? |
|---|---|---|---|---|
| NCR-001 | Preparedness primer PDFs (tracker Evidence E01–E04) | OPEN | before any reuse decision (S02/S03) | No |
| NCR-002 | Research and Production Blueprint (tracker Evidence E05) | OPEN | S02 (feeds the source register) | No |
| NCR-003 | Gate B input packs (S02 deliverables) | OPEN (not yet due) | S02 | No |

## NCR-001 — Preparedness primer PDFs (tracker Evidence E01–E04)

- **Claimed to exist** (tracker sheet "Evidence", plan "Current State"): `Original_Preparedness_Reference_3_Volumes.pdf`
  (28 pp combined) and its three sections `01_Home_Resilience_Field_Manual.pdf` (10 pp),
  `02_Small_Acreage_Self_Reliance.pdf` (9 pp), `03_Thirty_Day_Outage_Operations.pdf` (9 pp). The tracker marks them
  "Verified file in conversation working area", meaning the ChatGPT workspace, not this machine.
- **Local evidence:** none. An exact-name search of the home directory (depth ≤ 6) and of archive entry names found none
  of the four files (see `PROJECT_AUDIT.md`).
- **Why it matters:** sprint S00 requires "inspect previous research". The tracker itself calls them "reusable background,
  not reviewed chapter".
- **Requested:** export the four PDFs to `research/inbox/` (create on first use) and record each SHA-256 below.
- **Rule when supplied:** background only. Nothing is lifted into an entry except through the claim/source process.

## NCR-002 — Research and Production Blueprint (tracker Evidence E05)

- **Claimed to exist:** "Research and Production Blueprint for an Original Comprehensive Survival Manual" (tracker: "Retrieved
  from Library, not a finished manuscript"; ~870-page design target; research architecture, bibliography, safety priorities,
  sample water procedure).
- **Local evidence:** none (same search as NCR-001).
- **Requested:** export as a file with its SHA-256. Its bibliography can seed `research/sources.csv` once each source's
  rights and provenance are recorded individually.
- **Rule when supplied:** the "sample water procedure" is unreviewed. It enters only as claims with source locators,
  never copied as text, and falls under the `HZ-WATER-POTABILITY` gate.

## NCR-003 — Gate B input packs (sprint S02 deliverables)

- **Scheduled (plan, S02):** "Water, CO/fire, exposure, food safety, triage source packs; risk labels".
- **What the pipeline needs from them:** source-register rows (with per-source rights status), claim rows with direct source
  locators, and the authority sources named in handoff section 6 (current CDC/EPA guidance for water; tested USDA/NCHFP
  procedures for preservation).
- **Not requested now.** Recorded so the dependency is visible. Not due until S02.
