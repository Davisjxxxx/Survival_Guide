# Run log

One row per execution run. Each run has its own record file with commands, files changed, tests and blocked items.

| Run | Date | Sprint | Branch | Outcome | Record |
|---|---|---|---|---|---|
| RUN-001 | 2026-11-16 | S00/S01 (Gate A engineering) | `gate-a/scaffold` (tag `gate-a-submission`) | Scaffold, gates, pipeline and dummy specimen built and tested. Submitted for Gate A review; not self-approved. | `RUN-001.md` |
| RUN-002 | 2026-11-16 | Gate A independent-review remediation (GA-001, GA-002, epstopdf) | `gate-a/remediation-1` (tag `gate-a-remediation-1`) | Independent, precedence-aware safety reviews; toolchain note. Evidence submitted; Gate A still not approved. | `RUN-002.md` |
| RUN-003 | 2026-11-17 | Gate A remediation 2: critical trust-model remediation (FR-001 to FR-012, FR-029; `FABLE-REVIEW-001`) | `gate-a/remediation-2` (base: tag `gate-a-remediation-1`) | Derived review requirements, a reviewer registry, hash-chained ledgers, adverse decisions, package-bound reviews, renderer totality and identification evidence built and tested; 42 of 59 probes closed, the rest open or measured. Gate A still not approved; nothing may be published. | `RUN-003.md`, `FINDING_REMEDIATION_MATRIX.md` |
| RUN-004 | 2026-11-20 | Gate A remediation 3: safety and release-integrity remediation (FR-008, FR-021, FR-019, FR-017, FR-014, FR-015, FR-003 residual; `FABLE-REVIEW-001`) | `gate-a/remediation-3` (base: `3ef62a7`, `gate-a/remediation-2`) | Claim completeness, usable safety text, measurement accuracy policy and prose scan, immutable release state and withdrawal, EXIF/GPS-stripped derivatives, controlled licence vocabulary and rights evidence, and external ledger continuity pinning built and tested; 2138 tests pass, 50 of 59 probes closed, 97 new sabotages detected. Gate A still not approved; nothing may be published. | `RUN-004.md`, `FINDING_REMEDIATION_MATRIX.md` |

The earlier read-only audit (`BASELINE_AUDIT_20261116.md`) predates this log and is kept unchanged.
