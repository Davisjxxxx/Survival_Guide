# Project audit: Survival Field Encyclopedia (Gate A, RUN-001)

- **Date:** 2026-11-16 (US Central, UTC−6)
- **Executor:** Claude Code (Sonnet 5.5), acting in the "engineering executor" role the owner assigned. The handoff calls this role "Astra CLI"; the executor is not Astra.
- **Workspace:** `/home/jd/Survival_Guide`
- **Status:** baseline reconciled with the supplied documents; evidence submitted for Gate A0 and Gate A review. Nothing here is self-approved, and no gate is claimed as passed.

## 1. What was found

### 1.1 Workspace and Git

| Item | At the start of RUN-001 | Now |
|---|---|---|
| Workspace contents | `BASELINE_AUDIT_20261116.md` and `handoff/` (5 files) | plus the Gate A scaffold (see §4) |
| Git repository | none: `git rev-parse` failed in the workspace, and there is no `.git` in `/home/jd/Survival_Guide`, `/home/jd`, `/home` or `/` | initialised locally by the owner's authorization, **after** this recheck |
| Branch / remote | n/a | `gate-a/scaffold`; no remote; **no `main` branch exists** (no commit to `main` without the owner's authorization) |
| Git environment | Git 2.43.0; identity configured; no hooks path, template directory or signing requirement | unchanged |

Other projects on the machine (DCTS, Nova, BRAND and others) were not modified. This run wrote only under `/home/jd/Survival_Guide`, plus
session scratch files and pytest temporary directories.

### 1.2 Supplied package (hash-verified before any work)

| File | Bytes | SHA-256 |
|---|---:|---|
| `handoff/SURVIVAL_FIELD_ENCYCLOPEDIA_ASTRA_CLI_HANDOFF.md` | 15,940 | `662d4ae8ac102f83a0620f36300b9135fd1e783e0ee088777f0ba4b7797f8445` |
| `handoff/Survival_Field_Encyclopedia_Master_Sprint_Plan_v1.md` | 11,572 | `387a91d64d0fc1d872b02033e8dcb7011ae36a8690e7f060ca4ea83ebea557dc` |
| `handoff/Survival_Field_Encyclopedia_Sprint_Tracker_v1.xlsx` | 15,433 | `fae9b95d8958614d1c07baa9059c38d2f7f8f1d0276ce2d34612caf47dbbbea8` |
| `handoff/README_INSTALL.md` | 1,766 | `f2ade8d8052dfe456e9c7eb9116a496014aef1b69a8524d7a5f9e687efe7ee56` |
| `handoff/SHA256SUMS.txt` | 351 | `060d128ddfb3f41c4e9f3b3d5edbc466a847a56397cd331686f58d2acf973531` |
| `BASELINE_AUDIT_20261116.md` (earlier audit) | 9,586 | `2ca237c43ace4807a18399453440668bf1c4c83078ec6108b7e4fd5579679624` |
| source ZIP `~/Downloads/Survival_Guide_Gate_A_Package.zip` (outside the repo) | 28,850 | `bfeec1468da54688775eb5aca2348d6deac1483044f97962402ca457fd91152e` |

Verification: `sha256sum -c handoff/SHA256SUMS.txt` passed for its three listed files; all five ZIP entries are byte-identical to the extracted
files; the six in-repo files match the hashes recorded in `PRESERVED_FILES.sha256` before any work began, and Git stored identical bytes
(`git show` of the import commit compared with the recorded hashes). `tests/test_preservation.py` re-checks all of this on every run.

### 1.3 Previous research referred to by the plan

The plan and tracker (Evidence sheet E01–E05) say a 28-page primer (three PDFs of 10, 9 and 9 pages) and a ~870-page research blueprint
exist. The tracker places them in the ChatGPT "conversation working area" and "Library". **None is on this machine**: an exact-name search of the
home directory (depth ≤ 6) and of the entry names of every ZIP in the usual folders found nothing. They are recorded as `NCR-001` and
`NCR-002` in `research/unresolved-research.md`. Nothing was reconstructed or summarised from memory.

## 2. Reconciliation with `BASELINE_AUDIT_20261116.md`

The baseline audit is preserved unchanged. This table records how each finding stands now.

| Baseline finding | Now | Evidence |
|---|---|---|
| F-1 Workspace empty (0 entries) | **Superseded.** True when written; the owner has since supplied `handoff/`, and the scaffold exists. | §1.1, §4 |
| F-2 Not a Git repository | **True at the start of this run (rechecked), then changed** by the authorized local `git init`. | §1.1 |
| F-3 No handoff found | **Resolved.** Supplied and verified. | §1.2 |
| F-4 No master sprint plan found | **Resolved.** Supplied and verified (plus the tracker). | §1.2 |
| F-5 Only DCTS has Astra artifacts on the machine | **Confirmed and still true.** Unrelated; untouched. The supplied handoff is the Survival one. | not re-read |
| F-6 Request text truncated | **Resolved** by the owner's complete request. The lost opening is unrecoverable and no longer needed. | n/a |
| F-7 No repo-level `AGENTS.md` or `CLAUDE.md` | **Still true.** None created (not requested); the global protocol still applies. | workspace listing |
| Baseline §5 next actions 1–3 (supply inputs, confirm repository, re-run baseline) | Done: inputs supplied, repository authorized and rechecked, baseline re-run in this document. | §1 |
| Baseline §5 action 4 (Gate A reviewer decides) | **Pending.** | `RUN-001.md` |

The baseline's search scope and its "not searched" list (Drive, Gmail, ChatGPT history and so on) are unchanged. The owner supplied the files
directly, so those searches were not needed.

## 3. Reconciliation across the three supplied documents

Checked programmatically, and now pinned by `tests/test_zones.py` and `tests/test_handoff_consistency.py` so the reconciliation cannot silently rot.

**Consistent.** The sprint table (S00–S15: ids, start and finish dates, deliverables, owners, gate/exit criteria, status) is identical in the plan
and the tracker. All 16 zones agree on id, name, target pages, priority and start sprint across plan, tracker and handoff; the page allocation
sums to 1,016 as the plan states. Sprints are contiguous 14-day blocks and the five milestone dates fall on sprint ends.

**Discrepancies and observations.**

| # | Observation | Severity | Handling |
|---|---|---|---|
| 1 | **Three gate vocabularies.** Handoff: Gates A–C plus a release Phase D. Plan: `A0, A, B1, B2, C1, D1, D2, E1, E2, F1, F2, G1, G2, H1, H2` in the sprint table, and a separate "Proof Gates" list A–H whose letters mean different things (plan B = evidence, D = identification atlas; handoff B = claims, species and images validated). Tracker: `G0, GA–GH`. Gate A itself is consistent in all three. | Medium | Used Gate A as defined by all three; mapped in the `RUN-001.md` matrix. **Decision requested** on canonical naming. |
| 2 | Coverage text differs for every zone between handoff §2 ("Coverage examples") and the tracker ("Required subtopics"). | Low–medium | Both kept verbatim in `content/zones.yaml`; no merge. **Decision requested** on which is authoritative for topic lists. |
| 3 | Cosmetic naming: Z05 is "look-alikes" (handoff) versus "lookalikes" (plan, tracker); "and" versus "&". | Low | Handoff wording adopted as the canonical title. |
| 4 | Evidence E01–E05 are not local (§1.3). S00 requires "inspect previous research". | Medium | Cards `NCR-001`, `NCR-002`; **owner/ChatGPT to export**. Not blocking Gate A. |
| 5 | First-run outputs: handoff §11 lists six, the plan lists four, the owner's request listed nine. | Info | The union was delivered. |
| 6 | Schedule: S00 is 2026-11-16 → 11-29 and S01 is 11-30 → 12-13 (Gate A scaffolding target 2026-12-13). This run did the S01 engineering on 2026-11-16, ahead of plan. | Info | Nothing beyond Gate A was started. |
| 7 | `README_INSTALL.md` says `SHA256SUMS.txt` covers "all three"; it covers the three documents, not `README_INSTALL.md` or itself. | Low | `PRESERVED_FILES.sha256` covers every supplied file plus the baseline audit. |
| 8 | The tracker workbook's internal creation time (2026-11-16 20:13:00Z) is later than its archive entry time (20:03–20:04) and than the ZIP's download time (14:07 −0600 = 20:07Z). Consistent with clock skew where it was generated. Content hash verified. | Low | Recorded only. |
| 9 | Handoff §8 shows the repository root as `survival-field-encyclopedia/`; the workspace is `/home/jd/Survival_Guide`. | Info | The workspace root is that layout's root; no nested directory. |
| 10 | Handoff §9 asks for "sample placeholder entries". Interpreted as the templates plus the labelled specimen. **No placeholder entries were placed in `content/`**: the gates forbid dummy markers there, so a placeholder entry could be mistaken for content. | Medium (interpretation) | **Decision requested** if per-zone placeholder entries are wanted. |
| 11 | The tracker still reads "Not verified" / "Not supplied" for G0, GA, R04 and E07. It is a preserved document and was not edited. | Info | Suggested updates for the owner are listed in `RUN-001.md`. |

## 4. Inventory of the implementation

**Before RUN-001:** the baseline audit and the five handoff files. No code, no content, no registers, no repository.

**Created in RUN-001** (all on branch `gate-a/scaffold`; commit list in `RUN-001.md`):

| Area | Files |
|---|---|
| Zone structure | `content/zones.yaml`, 16 zone directories with generated READMEs |
| Contracts | 9 JSON Schemas and `hazard_topics.yaml` in `schemas/`; 4 templates in `templates/` |
| Registers (header-only) | `research/sources.csv`, `claims.csv`, `coverage-matrix.csv`; `assets/manifest.csv`; `reviews/approvals.csv`, `image-audit.csv`, `safety-audit.csv`; `research/unresolved-research.md` |
| Tooling | `scripts/sfe/` (12 modules), `Makefile`, `requirements.txt`, `pyproject.toml` |
| Layout and proof | `layouts/sfe.sty`, `layouts/build.yaml`, `layouts/specimen/` (4 labelled dummy inputs), `proofs/` (PDF, manifest, 2 previews) |
| Tests | `tests/` (15 test files plus `conftest.py` and a fixture factory; every test builds throwaway repositories) |
| Documents | `README.md`, `GOVERNANCE.md`, `CHANGELOG.md`, `RUN-LOG.md`, `PROJECT_AUDIT.md`, `BUILD_PLAN.md`, `RUN-001.md` |

There are no entries, no real source/claim/photo rows, no reviewer names, no approvals, no photographs and no zone content. Every zone is
`not_started`.

## 5. No-overwrite plan

1. **Preserved set:** `BASELINE_AUDIT_20261116.md` and everything in `handoff/` (six files). Authority: `PRESERVED_FILES.sha256`, plus `handoff/SHA256SUMS.txt` for the three documents.
2. **Enforcement:** `.gitattributes` (`-text`) stops Git rewriting them; `make verify-preserved` and `tests/test_preservation.py` compare the working files with the recorded hashes *and* with the first committed blobs.
3. **Before any future run writes anything:** run `make verify-preserved`; read `git status`, `git branch` and `git log`; never re-initialise; work on a feature branch; change preserved files never (owner-supplied updates arrive as new files, for example `handoff/v2/`).
4. **Approved text** changes only through a new `revision`, a new approval row bound to the new content hash, and a shown diff.
5. **The tracker** stays untouched; proposed status updates are reported for the owner to apply.

## 6. S00 / S01 deliverables against evidence

| Sprint deliverable (plan / tracker) | Status | Evidence |
|---|---|---|
| S00 Audit actual files | Done | `BASELINE_AUDIT_20261116.md` (read-only, empty workspace), this document (supplied files, hashes, reconciliation) |
| S00 Confirm repo | Done | §1.1: no repository found; owner-authorized local init after the recheck |
| S00 Inspect previous research | **Partial: cannot be completed locally** | §1.3; `NCR-001`, `NCR-002`. This is the one S00 item that needs the owner or ChatGPT |
| S00 exit, Gate A0: auditable baseline, no overwritten work | Evidence submitted | §1.2, §5; `tests/test_preservation.py` |
| S01 Schema | Done | `schemas/*.schema.json`, `templates/` |
| S01 Claim, source and photo registers | Done (header-only by design) | `research/*.csv`, `assets/manifest.csv`, `reviews/*.csv` |
| S01 Specimen PDF | Done | `proofs/SPECIMEN_LAYOUT_PROOF.pdf` |
| S01 Pipeline tests | Done | `tests/`, `make check` |
| S01 exit, Gate A: layout proof and source links | Evidence submitted | the specimen's source chip is a working internal link to its legend entry (checked by the QA gate) |

Open items and decisions: `RUN-001.md` and `BUILD_PLAN.md` §9.
