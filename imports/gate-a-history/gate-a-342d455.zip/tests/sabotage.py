"""Sabotage checks (RUN-003): break ONE safeguard at a time in a scratch copy of the tree and require the tests to fail.

A safeguard whose removal leaves the suite green was never tested. Each experiment below names a file, the exact text of one safeguard and a one-line change that
removes it; the harness copies the tree, first proves the UNMODIFIED copy passes the chosen tests (a control: otherwise "detected" proves nothing), applies the
change and runs them again. A change that no longer matches the source is reported (PATCH-NOT-APPLIED), not skipped, so the list cannot rot silently.

Usage:   python3 tests/sabotage.py SCRATCH_DIR [EXPERIMENT_ID ...]        (all experiments when none is named)
Env:     SABOTAGE_LIVE   the tree to copy (default: this checkout; point it at a snapshot if you keep editing while it runs)
         SABOTAGE_TESTS  comma-separated test files that replace each experiment's own list (for example tests/test_fable_probes.py)
Output:  one line per experiment (DETECTED, NOT DETECTED, CONTROL-FAILED, PATCH-NOT-APPLIED, HARNESS-ERROR); exit status 1 unless every one is DETECTED.
Needs the prerequisites of the full check (see BUILD_PLAN.md); a full run takes about twenty minutes. SCRATCH_DIR must not hold anything you want to keep.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

LIVE = Path(os.environ.get("SABOTAGE_LIVE", Path(__file__).resolve().parents[1]))
TESTS_OVERRIDE = [t for t in os.environ.get("SABOTAGE_TESTS", "").split(",") if t]
SCRATCH = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else None
ONLY = set(sys.argv[2:])
TMP = SCRATCH.parent / "tmp" if SCRATCH else None

# id, description, file, old, new, test files to run
SABOTAGES = [
    ("S01", "adverse safety decisions stop blocking", "scripts/sfe/reviews.py",
     '        if row["decision"] in ADVERSE and row["audit_id"] not in view.resolutions:\n            found.append(err("SAFETY_FAILURE_UNRESOLVED"',
     '        if False and row["decision"] in ADVERSE and row["audit_id"] not in view.resolutions:\n            found.append(err("SAFETY_FAILURE_UNRESOLVED"',
     ["tests/test_adverse_decisions.py", "tests/test_review_independence.py", "tests/test_hazard_gates.py"]),
    ("S02", "a later pass clears an earlier failure (restores the RUN-002 behaviour)", "scripts/sfe/reviews.py",
     '        if row["decision"] in ADVERSE and row["audit_id"] not in view.resolutions:\n            found.append(err("SAFETY_FAILURE_UNRESOLVED"',
     '        if row["decision"] in ADVERSE and row["audit_id"] not in view.resolutions and not any(p["decision"] == "pass" and p["_row"] > row["_row"] for p in acting):\n            found.append(err("SAFETY_FAILURE_UNRESOLVED"',
     ["tests/test_adverse_decisions.py", "tests/test_review_independence.py"]),
    ("S03", "the registry is not consulted for reviewers", "scripts/sfe/reviews.py",
     '    reviewer, capacity = row["reviewer_id"], row["capacity"]\n    registration, refusal = ctx.registry.lookup(reviewer, capacity, when)\n    if registration is None:\n        return [refusal]',
     '    return []\n    reviewer, capacity = row["reviewer_id"], row["capacity"]\n    registration, refusal = ctx.registry.lookup(reviewer, capacity, when)\n    if registration is None:\n        return [refusal]',
     ["tests/test_review_independence.py"]),
    ("S04", "reviews are no longer bound to the package digest", "scripts/sfe/reviews.py",
     '    bound = [row for row in cover if row["package_sha256"] == digest]',
     '    bound = cover',
     ["tests/test_package_binding.py", "tests/test_review_independence.py", "tests/test_hazard_gates.py"]),
    ("S05", "the ledger chain and sequence are not checked", "scripts/sfe/ledger.py",
     '    findings: list[Finding] = []\n    previous, broken, last_date = GENESIS, False, None',
     '    return []\n    findings: list[Finding] = []\n    previous, broken, last_date = GENESIS, False, None',
     ["tests/test_ledger_integrity.py", "tests/test_adverse_decisions.py", "tests/test_review_independence.py"]),
    ("S06", "the author may review their own entry", "scripts/sfe/reviews.py",
     '    if author is not None and reviewer == author:',
     '    if False and author is not None and reviewer == author:',
     ["tests/test_review_independence.py"]),
    ("S07", "a technical reviewer may stand in for the domain expert (undoes D13)", "schemas/hazard_topics.yaml",
     '    domain_expert:\n      capacities: [external_sme]',
     '    domain_expert:\n      capacities: [external_sme, technical_reviewer]',
     ["tests/test_review_independence.py", "tests/test_review_policy.py"]),
    ("S08", "the package covers the entry text only", "scripts/sfe/package.py",
     '        "claims": {cid: (_view(claims[cid], CLAIM_NON_MATERIAL) if cid in claims else unresolved) for cid in claim_ids},\n        "sources": {sid: (_view(sources[sid]) if sid in sources else unresolved) for sid in sorted(source_ids)},\n        "assets": records,',
     '        "claims": {},\n        "sources": {},\n        "assets": {},',
     ["tests/test_package_binding.py"]),
    ("S09", "anyone may clear or void a decision", "scripts/sfe/reviews.py",
     '    if registration is None:\n        problems.append(("RESOLUTION_UNAUTHORIZED", refusal[1] if refusal else "reviewer is not registered"))\n    elif target is not None:',
     '    if False:\n        problems.append(("RESOLUTION_UNAUTHORIZED", refusal[1] if refusal else "reviewer is not registered"))\n    elif False:',
     ["tests/test_adverse_decisions.py"]),
    ("S10", "resolution evidence is not checked", "scripts/sfe/reviews.py",
     '    why = package_mod.check_evidence(ctx.repo.root, row.get("evidence_path"), row.get("evidence_sha256"))\n    if why:',
     '    why = None\n    if why:',
     ["tests/test_adverse_decisions.py"]),
    ("S11", "passes before the latest adverse decision still count", "scripts/sfe/reviews.py",
     '        current_ok = [row for row in eligible if row["_row"] > after]',
     '        current_ok = [row for row in eligible]',
     ["tests/test_adverse_decisions.py", "tests/test_review_independence.py"]),
    ("S12", "a row's capacity is not checked against the class", "scripts/sfe/reviews.py",
     '    if capacity not in cls.capacities:',
     '    if False and capacity not in cls.capacities:',
     ["tests/test_review_independence.py"]),
    ("S13", "orphan ledger rows are accepted", "scripts/sfe/reviews.py",
     '            if row.get("entry_id") not in entries:',
     '            if False and row.get("entry_id") not in entries:',
     ["tests/test_adverse_decisions.py"]),
    ("S14", "an unresolved adverse approval does not block", "scripts/sfe/reviews.py",
     '        if row["decision"] in ADVERSE and row["approval_id"] not in view.resolutions:\n            found.append(err("APPROVAL_NOT_CURRENT"',
     '        if False and row["decision"] in ADVERSE and row["approval_id"] not in view.resolutions:\n            found.append(err("APPROVAL_NOT_CURRENT"',
     ["tests/test_adverse_decisions.py"]),
    ("S15", "an unresolved image failure does not block", "scripts/sfe/reviews.py",
     '        if row["decision"] in ADVERSE and row["audit_id"] not in view.resolutions:\n            found.append(err("IMAGE_AUDIT_FAILURE_UNRESOLVED"',
     '        if False and row["decision"] in ADVERSE and row["audit_id"] not in view.resolutions:\n            found.append(err("IMAGE_AUDIT_FAILURE_UNRESOLVED"',
     ["tests/test_adverse_decisions.py"]),
    ("S16", "calendar dates are checked by pattern only", "scripts/sfe/common.py",
     '    match = _DATE_TEXT.fullmatch(text or "")\n    if not match:\n        return False',
     '    return True\n    match = _DATE_TEXT.fullmatch(text or "")\n    if not match:\n        return False',
     ["tests/test_ledger_integrity.py"]),
    ("S17", "any kind may hold any capacity", "scripts/sfe/reviewers.py",
     '            if kind not in KIND_RULES.get(capacity, ()):',
     '            if False and kind not in KIND_RULES.get(capacity, ()):',
     ["tests/test_reviewer_registry.py", "tests/test_review_independence.py"]),
    ("S18", "an approval needs no stored packet", "scripts/sfe/reviews.py",
     '        problem = packet_problem(ctx, row)\n        if problem:\n            reasons.append(problem)\n        if reasons:\n            rejected.append((row, reasons))\n        else:\n            editorial.append(row)',
     '        if reasons:\n            rejected.append((row, reasons))\n        else:\n            editorial.append(row)',
     ["tests/test_package_binding.py"]),
    ("S19", "the image audit ignores the record digest", "scripts/sfe/reviews.py",
     '    matching = [row for row in fresh if row["asset_sha256"] == file_digest and row["record_sha256"] == record]',
     '    matching = [row for row in fresh if row["asset_sha256"] == file_digest]',
     ["tests/test_package_binding.py"]),
    ("S20", "the Git history check never reports", "scripts/sfe/ledger.py",
     '    findings: list[Finding] = []\n    for (old_label, old_header, old_rows), (new_label, new_header, new_rows) in zip(versions, versions[1:]):',
     '    return []\n    findings: list[Finding] = []\n    for (old_label, old_header, old_rows), (new_label, new_header, new_rows) in zip(versions, versions[1:]):',
     ["tests/test_ledger_integrity.py"]),
    # ---- classification (FR-001)
    ("S21", "the zone's own subjects are not applied", "scripts/sfe/classify.py",
     '        add(zone["required_subjects"], f"zone {zone_id}")', '        pass', ["tests/test_classification.py"]),
    ("S22", "the zone-priority floor is not applied", "scripts/sfe/classify.py",
     '        add(policy.priority_floor[priority], f"zone priority {priority}")', '        pass', ["tests/test_classification.py"]),
    ("S23", "the entry type brings no subjects", "scripts/sfe/classify.py",
     '    add(policy.entry_types.get(entry_type, ()), f"entry type {entry_type}")', '    pass', ["tests/test_classification.py"]),
    ("S24", "cited claims are ignored", "scripts/sfe/classify.py",
     '    for claim_id in sorted(claim_ids_of(fm)):\n        claim = ctx.claims.get(claim_id)', '    for claim_id in []:\n        claim = ctx.claims.get(claim_id)', ["tests/test_classification.py"]),
    ("S25", "the coverage plan is ignored", "scripts/sfe/classify.py",
     '    for row in ctx.reg["coverage"]:\n        if row.get("planned_entry_id") != fm["id"]:', '    for row in []:\n        if row.get("planned_entry_id") != fm["id"]:', ["tests/test_classification.py"]),
    ("S26", "species and medical fields imply nothing", "scripts/sfe/classify.py",
     '    if any(nonempty(fm.get(key)) for key in SPECIES_FIELDS):', '    if False and any(nonempty(fm.get(key)) for key in SPECIES_FIELDS):', ["tests/test_classification.py"]),
    ("S27", "keyword triggers are ignored", "scripts/sfe/classify.py",
     '        for trigger in policy.triggers:\n            match = trigger.regex.search(text)', '        for trigger in ():\n            match = trigger.regex.search(text)', ["tests/test_classification.py"]),
    ("S28", "declared tags REPLACE the derivation instead of adding to it", "scripts/sfe/classify.py",
     '    declared()\n    if not reasons:\n        reasons[SCREENING]', '    declared()\n    if fm["hazard_tags"]:\n        reasons = {t: r for t, r in reasons.items() if t in fm["hazard_tags"]}\n    if not reasons:\n        reasons[SCREENING]', ["tests/test_classification.py"]),
    ("S29", "an unusable policy is treated as nothing to review", "scripts/sfe/classify.py",
     '    if policy is None:\n        findings.append(err("CLASSIFICATION_UNKNOWN"', '    if policy is None:\n        return Classification({SCREENING: ["no policy"]}, [])\n        findings.append(err("CLASSIFICATION_UNKNOWN"', ["tests/test_classification.py"]),
    ("S30", "species or medical fields on another type are accepted", "scripts/sfe/classify.py",
     '            if misplaced:', '            if False and misplaced:', ["tests/test_classification.py"]),
    ("S31", "zone allowed types are not enforced", "scripts/sfe/classify.py",
     '        if entry_type not in zone["allowed_types"]:', '        if False and entry_type not in zone["allowed_types"]:', ["tests/test_classification.py"]),
    ("S32", "the identification-zone rule is off", "scripts/sfe/classify.py",
     '        if zone["identification"] and identifies and entry_type != "species_profile":', '        if False and zone["identification"] and identifies and entry_type != "species_profile":', ["tests/test_classification.py"]),
    ("S33", "an incomplete policy still loads", "scripts/sfe/classify.py",
     '    if findings:\n        return None, findings\n    return ClassificationPolicy(subjects, zones,', '    findings = [f for f in findings if f.code != "CLASSIFICATION_POLICY_INCOMPLETE"]\n    if findings:\n        return None, findings\n    return ClassificationPolicy(subjects, zones,', ["tests/test_classification.py"]),
    ("S34", "an entry nothing applies to needs no screening", "scripts/sfe/classify.py",
     '    if not reasons:\n        reasons[SCREENING] = {"no other review subject applies"}\n    return Classification', '    return Classification', ["tests/test_classification.py", "tests/test_review_independence.py"]),
    # ---- renderer totality (FR-011)
    ("S35", "the renderer does not refuse unprinted fields", "scripts/sfe/texgen.py",
     '    if unprinted:', '    if False and unprinted:', ["tests/test_render_totality.py"]),
    ("S36", "the renderer accepts a body it cannot print", "scripts/sfe/texgen.py",
     '    if body.strip() and not proof:', '    if False and body.strip() and not proof:', ["tests/test_render_totality.py"]),
    ("S37", "the text-layer check never reports a missing string", "scripts/sfe/qa.py",
     '    return [(path, text) for index, path, text, _needle in wanted if index in absent]', '    return []', ["tests/test_render_totality.py", "tests/test_pdf_pipeline.py"]),
    ("S38", "the validator allows a published entry with a body", "scripts/sfe/validate.py",
     '    if entry.body.strip():\n        found.append(err("PUBLISHED_BODY_NOT_RENDERED"', '    if False and entry.body.strip():\n        found.append(err("PUBLISHED_BODY_NOT_RENDERED"', ["tests/test_render_totality.py"]),
    ("S39", "the footer is not removed before the look-up", "scripts/sfe/qa.py",
     '            if at >= 0:  # the footer is the last thing', '            if False and at >= 0:  # the footer is the last thing', ["tests/test_render_totality.py"]),
    ("S40", "matches are not consumed", "scripts/sfe/qa.py",
     '            remaining = remaining[:at] + "\\x00" + remaining[at + len(needle):]', '            pass', ["tests/test_render_totality.py"]),
    ("S41", "the release build does not report missing text", "scripts/sfe/pdfbuild.py",
     '            for path, text in missing[:25]:\n                findings.append(err("RENDER_FIELD_MISSING", zone["dir"]', '            for path, text in []:\n                findings.append(err("RENDER_FIELD_MISSING", zone["dir"]', ["tests/test_render_totality.py"]),
    ("S42", "the proof build does not report missing text", "scripts/sfe/pdfbuild.py",
     '        for path, text in missing[:25]:\n            findings.append(err("RENDER_FIELD_MISSING", entry.rel', '        for path, text in []:\n            findings.append(err("RENDER_FIELD_MISSING", entry.rel', ["tests/test_render_totality.py"]),
    ("S43", "the release manifest omits the package digest", "scripts/sfe/pdfbuild.py",
     '"package_sha256": package_of(ctx, e)[2]}', '"package_sha256": ""}', ["tests/test_render_totality.py", "tests/test_pdf_pipeline.py"]),
    ("S44", "the release manifest omits the ledger heads", "scripts/sfe/pdfbuild.py",
     '                "ledger_heads": _ledger_heads(repo),', '                "ledger_heads": {},', ["tests/test_render_totality.py"]),
    ("S45", "keys printed verbatim are not expected from the PDF", "scripts/sfe/texgen.py",
     '    for key in sorted(PRINTED_KEYS - in_other_form):', '    for key in ():', ["tests/test_render_totality.py", "tests/test_pdf_pipeline.py"]),
    # ---- source strictness (FR-009: P22a, P22b, P49)
    ("S46", "a verified source with an unknown edition or revision is accepted", "scripts/sfe/validate.py",
     '                if _is_unknown(row[key]):', '                if False and _is_unknown(row[key]):', ["tests/test_registers.py"]),
    ("S47", "a verified source of unknown provenance is accepted", "scripts/sfe/validate.py",
     '            if row["provenance_class"] == "unknown":\n                found.append(err("SOURCE_PROVENANCE_UNKNOWN"', '            if False and row["provenance_class"] == "unknown":\n                found.append(err("SOURCE_PROVENANCE_UNKNOWN"', ["tests/test_registers.py"]),
    ("S48", "a background source may back a claim", "scripts/sfe/validate.py",
     '        if source["intended_use"] == "background":', '        if False and source["intended_use"] == "background":', ["tests/test_registers.py"]),
    ("S49", "a rights-rejected source may back a claim", "scripts/sfe/validate.py",
     '        if source["rights_status"] == "rejected":\n            found.append(err("REJECTED_SOURCE_BACKS_CLAIM"', '        if False and source["rights_status"] == "rejected":\n            found.append(err("REJECTED_SOURCE_BACKS_CLAIM"', ["tests/test_registers.py"]),
    ("S50", "a verified source needs no retrieval date or hash (schema type constraint removed; the equivalent `required` removal changes nothing because the loader always supplies every column)", "schemas/source.schema.json",
     '          "verified_on": { "type": "string", "minLength": 1 },\n          "retrieved_on": { "type": "string", "pattern": "^[0-9]{4}-[0-9]{2}-[0-9]{2}$" },\n          "local_sha256": { "type": "string", "pattern": "^[0-9a-f]{64}$" }\n', '          "verified_on": { "type": "string", "minLength": 1 }\n', ["tests/test_registers.py"]),
    ("S51", "UNKNOWN-like markers other than the word UNKNOWN pass as dates", "scripts/sfe/validate.py",
     'UNKNOWN_MARKERS = frozenset({"unknown", "n/a", "na", "tbd", "none", "unspecified", "undated", "n.d.", "nd", "?", "-", "--"})', 'UNKNOWN_MARKERS = frozenset({"unknown"})', ["tests/test_registers.py"]),
    # ---- identification evidence (FR-012)
    ("S52", "duplicate file content is not reported", "scripts/sfe/identification.py",
     '        for row in rows[1:]:\n            found.append(err("ASSET_DUPLICATE_BYTES"', '        for row in []:\n            found.append(err("ASSET_DUPLICATE_BYTES"', ['tests/test_identification_evidence.py']),
    ("S53", "duplicate catalogue paths are not reported", "scripts/sfe/identification.py",
     '        for row in rows[1:]:\n            found.append(err("ASSET_DUPLICATE_PATH"', '        for row in []:\n            found.append(err("ASSET_DUPLICATE_PATH"', ['tests/test_identification_evidence.py']),
    ("S54", "the hash is taken from the manifest cell instead of the file", "scripts/sfe/assets.py",
     '                        hashes[aid] = actual', '                        hashes[aid] = row.get("sha256") or actual', ['tests/test_identification_evidence.py']),
    ("S55", "any non-look-alike photograph counts as a target view whatever taxon it shows", "scripts/sfe/identification.py",
     '        elif nonempty(taxon_id) and shown == taxon_id:\n            target.append(asset)', '        elif True:\n            target.append(asset)', ['tests/test_identification_evidence.py']),
    ("S56", "look-alike views count toward the plate", "scripts/sfe/identification.py",
     '    views = {a["view"] for a in target if a.get("view")}\n    files = {ctx.file_hashes.get(a["asset_id"]) or a["asset_id"] for a in target}', '    views = {a["view"] for a in diagnostic if a.get("view")}\n    files = {ctx.file_hashes.get(a["asset_id"]) or a["asset_id"] for a in diagnostic}', ['tests/test_identification_evidence.py']),
    ("S57", "a plate needs no whole or key_feature view", "scripts/sfe/identification.py",
     '    if views and not views & ANCHOR_VIEWS:', '    if False and views and not views & ANCHOR_VIEWS:', ['tests/test_identification_evidence.py']),
    ("S58", "several species profiles may share a taxon", "scripts/sfe/identification.py",
     '        if others:', '        if False and others:', ['tests/test_identification_evidence.py']),
    ("S59", "a species entry may contradict its taxon's name", "scripts/sfe/identification.py",
     '        if norm_name(fm.get("scientific_name")) != norm_name(taxon["scientific_name"]):', '        if False and norm_name(fm.get("scientific_name")) != norm_name(taxon["scientific_name"]):', ['tests/test_identification_evidence.py']),
    ("S60", "an image's typed name may contradict its taxon", "scripts/sfe/identification.py",
     '        if taxon is not None and shown and shown != norm_name(taxon["scientific_name"]):', '        if False and taxon is not None and shown and shown != norm_name(taxon["scientific_name"]):', ['tests/test_identification_evidence.py']),
    ("S61", "a diagnostic photograph needs no specimen", "scripts/sfe/identification.py",
     '            if not specimen_id:\n                found.append(err("DIAGNOSTIC_SPECIMEN_MISSING"', '            if False and not specimen_id:\n                found.append(err("DIAGNOSTIC_SPECIMEN_MISSING"', ['tests/test_identification_evidence.py']),
    ("S62", "a diagnostic photograph needs no taxon", "scripts/sfe/identification.py",
     '            if not taxon_id:\n                found.append(err("DIAGNOSTIC_TAXON_MISSING"', '            if False and not taxon_id:\n                found.append(err("DIAGNOSTIC_TAXON_MISSING"', ['tests/test_identification_evidence.py']),
    ("S63", "an image's taxon may differ from its specimen's", "scripts/sfe/identification.py",
     '        if taxon_id and specimen is not None and specimen["taxon_id"] != taxon_id:', '        if False and taxon_id and specimen is not None and specimen["taxon_id"] != taxon_id:', ['tests/test_identification_evidence.py']),
    ("S64", "any registered identity, whatever its capacity, may determine a specimen", "scripts/sfe/identification.py",
     'ctx.registry.lookup(row["determined_by"], "external_sme", row["determined_on"])', 'ctx.registry.lookup(row["determined_by"], next((r.capacity for r in ctx.registry.registrations.values() if r.reviewer_id == row["determined_by"]), "external_sme"), row["determined_on"])', ['tests/test_identification_evidence.py']),
    ("S65", "a determiner need not hold the taxon's identification domain", "scripts/sfe/identification.py",
     '        elif taxon is not None and kind_domain(taxon["kind"]) not in registration.domains:', '        elif False and taxon is not None and kind_domain(taxon["kind"]) not in registration.domains:', ['tests/test_identification_evidence.py']),
    ("S66", "tier A needs no voucher or physical examination", "scripts/sfe/identification.py",
     '        if taxon is not None and taxon["risk_tier"] == "A" and row["determination_basis"] not in TIER_A_BASES:', '        if False and taxon is not None and taxon["risk_tier"] == "A" and row["determination_basis"] not in TIER_A_BASES:', ['tests/test_identification_evidence.py']),
    ("S67", "the photographer may determine their own photograph", "scripts/sfe/identification.py",
     '        if name and norm_name(name) in photographers.get(row["specimen_id"], set()):', '        if False and name and norm_name(name) in photographers.get(row["specimen_id"], set()):', ['tests/test_identification_evidence.py']),
    ("S68", "the author may determine what their profile cites", "scripts/sfe/identification.py",
     '        if specimen is not None and fm.get("authored_by") and specimen["determined_by"] == fm["authored_by"]:', '        if False and specimen is not None and fm.get("authored_by") and specimen["determined_by"] == fm["authored_by"]:', ['tests/test_identification_evidence.py']),
    ("S69", "entry reviewers need no organism-group domain", "scripts/sfe/reviews.py",
     '    return identification.entry_domains(ctx, entry) if subject in identification.IDENTIFICATION_SUBJECTS else set()', '    return set()', ['tests/test_identification_evidence.py']),
    ("S70", "image auditors need no organism-group domain", "scripts/sfe/reviews.py",
     '    return identification.asset_domains(ctx, asset)', '    return set()', ['tests/test_identification_evidence.py']),
    ("S71", "a fungus may be below tier A", "scripts/sfe/identification.py",
     '        if row["kind"] == "fungus" and row["risk_tier"] != "A":', '        if False and row["kind"] == "fungus" and row["risk_tier"] != "A":', ['tests/test_identification_evidence.py']),
    ("S72", "two taxon records may share a name", "scripts/sfe/identification.py",
     '        if name in seen:', '        if False and name in seen:', ['tests/test_identification_evidence.py']),
    ("S73", "a mistyped ID- domain is accepted in the registry", "scripts/sfe/reviewers.py",
     '                if domain not in id_domains:', '                if False and domain not in id_domains:', ['tests/test_identification_evidence.py']),
    ("S74", "a determination may precede the observation", "scripts/sfe/identification.py",
     '        if row["determined_on"] < row["observed_on"]:', '        if False and row["determined_on"] < row["observed_on"]:', ['tests/test_identification_evidence.py']),
    ("S75", "a generated image may carry a specimen", "scripts/sfe/identification.py",
     '        if specimen_id and row["generation_method"] in NOT_PHOTOGRAPHS:', '        if False and specimen_id and row["generation_method"] in NOT_PHOTOGRAPHS:', ['tests/test_identification_evidence.py']),
    ("S76", "an AI illustration with a blank subject needs no label", "scripts/sfe/assets.py",
     '(subject or method == "ai_generated") and _bare(row, "overlay_label") != REQUIRED_LABEL', 'subject and _bare(row, "overlay_label") != REQUIRED_LABEL', ['tests/test_identification_evidence.py']),
    ("S77", "the review packet leaves out the taxa", "scripts/sfe/package.py",
     '        "taxa": {tid: (_view(taxa[tid]) if tid in taxa else unresolved) for tid in sorted(taxon_ids)},', '        "taxa": {},', ['tests/test_identification_evidence.py']),
    ("S78", "the review packet leaves out the specimens", "scripts/sfe/package.py",
     '        "specimens": {sid: (_view(specimens[sid]) if sid in specimens else unresolved) for sid in sorted(specimen_ids)},', '        "specimens": {},', ['tests/test_identification_evidence.py']),
    ("S79", "a pass that lists no subject covers every subject", "scripts/sfe/reviews.py",
     '    cover = [row for row in current_rows if row["decision"] == "pass" and subject in row["subjects"]]', '    cover = [row for row in current_rows if row["decision"] == "pass" and (subject in row["subjects"] or not row["subjects"])]', ["tests/test_review_independence.py"]),
    ("S80", "a repository with no commits yet is reported as an unreadable ledger history", "scripts/sfe/ledger.py",
     '    elif b"does not have any commits yet" in listing.stderr:', '    elif False:', ["tests/test_ledger_integrity.py"]),
    # ---- RUN-004: claim completeness (FR-008)
    ("S81", "the minimum number of cited claims is not enforced", "scripts/sfe/evidence.py",
     '    if len(cited) < rule.min_claims:', '    if False and len(cited) < rule.min_claims:', ["tests/test_claim_completeness.py"]),
    ("S82", "an empty procedure exempts a technical procedure", "scripts/sfe/evidence.py",
     '    if len(fm["procedure"]) < rule.min_steps:', '    if False and len(fm["procedure"]) < rule.min_steps:', ["tests/test_claim_completeness.py"]),
    ("S83", "the claim types a species or medical entry must cite are not required", "scripts/sfe/evidence.py",
     '    for needed in rule.required_claim_types:\n        if needed not in types:', '    for needed in rule.required_claim_types:\n        if False and needed not in types:', ["tests/test_claim_completeness.py"]),
    ("S84", "a medical step needs no medical claim", "scripts/sfe/evidence.py",
     '    if rule.step_claim_types:', '    if False and rule.step_claim_types:', ["tests/test_claim_completeness.py"]),
    ("S85", "a safety-bearing field needs no claim bound to it", "scripts/sfe/evidence.py",
     '        if not ids:\n            found.append(err("FIELD_CLAIM_MISSING"', '        if False and not ids:\n            found.append(err("FIELD_CLAIM_MISSING"', ["tests/test_claim_completeness.py"]),
    ("S86", "a bound field accepts a claim of any type", "scripts/sfe/evidence.py",
     '        elif not any(cid in cited and cited[cid]["claim_type"] in accepted for cid in ids):', '        elif False:', ["tests/test_claim_completeness.py"]),
    ("S87", "a rejected claim counts as evidence", "scripts/sfe/evidence.py",
     'if cid in ctx.claims and ctx.claims[cid]["status"] != "rejected"}', 'if cid in ctx.claims}', ["tests/test_claim_completeness.py"]),
    ("S88", "a foraging or medical statement needs no claim", "scripts/sfe/evidence.py",
     '        if trigger_id in trigger_hits and not (types & set(accepted)):', '        if False and trigger_id in trigger_hits and not (types & set(accepted)):', ["tests/test_claim_completeness.py"]),
    ("S89", "a claim cited only through field_claims is not part of the package", "scripts/sfe/entries.py",
     '    for bound in (fm.get("field_claims") or {}).values():\n        ids.update(bound)\n    return ids', '    return ids', ["tests/test_claim_completeness.py"]),
    ("S90", "the policy may lower the floor of one claim", "scripts/sfe/evidence.py",
     'if not (isinstance(minimum, int) and not isinstance(minimum, bool) and minimum >= FLOOR_MIN_CLAIMS):', 'if not isinstance(minimum, int):', ["tests/test_claim_completeness.py"]),
    ("S91", "an unusable claim policy leaves entries unchecked", "scripts/sfe/evidence.py",
     '    if policy is None:\n        return [err("CLAIM_POLICY_UNAVAILABLE", where, "the claim policy is missing', '    if policy is None:\n        return []\n        return [err("CLAIM_POLICY_UNAVAILABLE", where, "the claim policy is missing', ["tests/test_claim_completeness.py"]),
    ("S92", "a binding to a name that is not a text field is accepted", "scripts/sfe/evidence.py",
     '        if field_name not in BINDABLE:\n            found.append(err("FIELD_CLAIMS_UNKNOWN_FIELD"', '        if False and field_name not in BINDABLE:\n            found.append(err("FIELD_CLAIMS_UNKNOWN_FIELD"', ["tests/test_claim_completeness.py"]),
    # ---- RUN-004: usable text in mandatory safety fields (FR-021)
    ("S93", "the usable-text check is not run at the verified rung", "scripts/sfe/validate.py",
     '    found += textcheck_mod.check_entry(fm, where)  # FR-021: a non-blank safety field must also say something', '    pass', ["tests/test_usable_text.py"]),
    ("S94", "null phrases are not recognised", "scripts/sfe/textcheck.py",
     '    if _phrase(text) in NULL_PHRASES or NULL_LEAD.match(unicodedata.normalize("NFKC", text)):\n        return "NULL_LIKE"', '    if False:\n        return "NULL_LIKE"', ["tests/test_usable_text.py"]),
    ("S95", "a null lead followed by a separator is accepted as text", "scripts/sfe/textcheck.py",
     '    if _phrase(text) in NULL_PHRASES or NULL_LEAD.match(unicodedata.normalize("NFKC", text)):', '    if _phrase(text) in NULL_PHRASES:', ["tests/test_usable_text.py"]),
    ("S96", "text with no letter or digit is not named", "scripts/sfe/textcheck.py",
     '    if not words:\n        return "NO_LETTERS_OR_DIGITS"', '    if False:\n        return "NO_LETTERS_OR_DIGITS"', ["tests/test_usable_text.py"]),
    ("S97", "an unfilled placeholder is accepted", "scripts/sfe/textcheck.py",
     '    if UNFILLED.search(text) or (BRACKETED.search(text) and not content_words(words_of(BRACKETED.sub(" ", text)))):\n        return "PLACEHOLDER"',
     '    if False:\n        return "PLACEHOLDER"', ["tests/test_usable_text.py"]),
    ("S98", "a repeated word is accepted", "scripts/sfe/textcheck.py",
     '    if _repeats(words):\n        return "REPEATED"', '    if False:\n        return "REPEATED"', ["tests/test_usable_text.py"]),
    ("S99", "the two-word floor is not enforced", "scripts/sfe/textcheck.py",
     '    if len(words) < minimum_words:\n        return "TOO_SHORT"', '    if False:\n        return "TOO_SHORT"', ["tests/test_usable_text.py"]),
    ("S100", "text made only of filler is accepted", "scripts/sfe/textcheck.py",
     '    if not content_words(words):\n        return "NO_CONTENT"', '    if False:\n        return "NO_CONTENT"', ["tests/test_usable_text.py"]),
    ("S101", "a stray single letter counts as a content word", "scripts/sfe/textcheck.py",
     'and (len(w) >= 2 or w.isdigit())]', 'and True]', ["tests/test_usable_text.py"]),
    ("S102", "the exception needs no claim cited by its step", "scripts/sfe/textcheck.py",
     '                if claim_id not in step["claim_ids"]:', '                if False and claim_id not in step["claim_ids"]:', ["tests/test_usable_text.py"]),
    ("S103", "the exception's justification is not checked", "scripts/sfe/textcheck.py",
     '                weak = justification_problem(justification)\n                if weak:', '                weak = None\n                if weak:', ["tests/test_usable_text.py"]),
    ("S104", "the exception is accepted in every field", "scripts/sfe/textcheck.py",
     '        if parse_not_applicable(text) is not None:  # the exception form is legal only where the caller handled it first', '        if False and parse_not_applicable(text) is not None:', ["tests/test_usable_text.py"]),
    ("S105", "the exception is accepted in a step's action", "scripts/sfe/textcheck.py",
     'STEP_FIELDS = {"action": (MIN_WORDS, False),', 'STEP_FIELDS = {"action": (MIN_WORDS, True),', ["tests/test_usable_text.py"]),
    ("S106", "a medical field is dropped from the usable-text table", "scripts/sfe/textcheck.py",
     '"audience_scope": 1, "contraindications": 1, "emergency_evacuation_threshold": MIN_WORDS,', '"audience_scope": 1, "emergency_evacuation_threshold": MIN_WORDS,', ["tests/test_usable_text.py"]),
    ("S107", "dangers are not assessed", "scripts/sfe/textcheck.py",
     '            refuse(f"dangers{suffix}", item, DANGERS_FLOOR)', '            pass', ["tests/test_usable_text.py"]),
    ("S108", "only the first item of a list is assessed", "scripts/sfe/textcheck.py",
     '        return [(f"[{n}]", item) for n, item in enumerate(value)]', '        return [(f"[{n}]", item) for n, item in enumerate(value[:1])]', ["tests/test_usable_text.py"]),
    ("S109", "a blank string is not called empty", "scripts/sfe/textcheck.py",
     '    if not isinstance(text, str) or not text.strip():\n        return "EMPTY"', '    if not isinstance(text, str):\n        return "EMPTY"', ["tests/test_usable_text.py"]),
    # ---- RUN-004: measurement accuracy (FR-019)
    ("S110", "the relative-error bound is not enforced", "scripts/sfe/units.py",
     '        if error > bound:', '        if False and error > bound:', ["tests/test_unit_equivalence.py", "tests/test_units.py"]),
    ("S111", "the bound is exclusive instead of inclusive", "scripts/sfe/units.py",
     '        if error > bound:', '        if error >= bound:', ["tests/test_unit_equivalence.py", "tests/test_units.py"]),
    ("S112", "the error is taken against the smaller value", "scripts/sfe/units.py",
     '    return abs(conversion - stated) / max(abs(conversion), abs(stated))', '    return abs(conversion - stated) / min(abs(conversion), abs(stated))', ["tests/test_unit_equivalence.py", "tests/test_units.py"]),
    ("S113", "the round trip is not required of an unmarked pair", "scripts/sfe/units.py",
     '        if kind != "approximate":', '        if False and kind != "approximate":', ["tests/test_unit_equivalence.py", "tests/test_units.py"]),
    ("S114", "a marker does not make the bound looser", "scripts/sfe/units.py",
     '    kind = "safety" if safety else ("approximate" if us.approximate or me.approximate else "precise")', '    kind = "safety" if safety else "precise"', ["tests/test_unit_equivalence.py", "tests/test_units.py"]),
    ("S115", "a marker loosens a safety-critical pair", "scripts/sfe/units.py",
     '    kind = "safety" if safety else ("approximate" if us.approximate or me.approximate else "precise")',
     '    kind = "approximate" if us.approximate or me.approximate else ("safety" if safety else "precise")', ["tests/test_unit_equivalence.py", "tests/test_units.py"]),
    ("S116", "pressure and temperature are not safety-critical by dimension", "scripts/sfe/units.py",
     '    safety = strictness == "safety" or us.dimension in policy.safety_dimensions', '    safety = strictness == "safety"', ["tests/test_unit_equivalence.py", "tests/test_units.py"]),
    ("S117", "an interval and an absolute temperature may be paired", "scripts/sfe/units.py",
     '    elif us.interval != me.interval:', '    elif False:', ["tests/test_unit_equivalence.py", "tests/test_units.py"]),
    ("S118", "a range need not match its counterpart in shape", "scripts/sfe/units.py",
     '    if len(us.ends) != len(me.ends):', '    if False and len(us.ends) != len(me.ends):', ["tests/test_unit_equivalence.py", "tests/test_units.py"]),
    ("S119", "a range may run from the higher value to the lower", "scripts/sfe/units.py",
     '        if len(measure.ends) == 2 and measure.ends[0].value > measure.ends[1].value:', '        if False and len(measure.ends) == 2 and measure.ends[0].value > measure.ends[1].value:', ["tests/test_unit_equivalence.py", "tests/test_units.py"]),
    ("S120", "a fraction with a zero denominator is not refused", "scripts/sfe/units.py",
     '        if den == 0:', '        if False:', ["tests/test_unit_equivalence.py", "tests/test_units.py"]),
    ("S121", "an unknown unit (a dose or a household measure) is not refused", "scripts/sfe/units.py",
     '    if unit not in _UNITS and unit not in _TEMPERATURE:\n        raise UnitError(f"unknown unit', '    if False and unit not in _UNITS and unit not in _TEMPERATURE:\n        raise UnitError(f"unknown unit', ["tests/test_unit_equivalence.py", "tests/test_units.py"]),
    ("S122", "a character the layout cannot print is read", "scripts/sfe/units.py",
     '    if not isinstance(text, str) or not _OK_CHARS.match(text):', '    if not isinstance(text, str):', ["tests/test_unit_equivalence.py", "tests/test_units.py"]),
    ("S123", "a temperature interval converts with the offset", "scripts/sfe/units.py",
     '        return value if interval else value + _KELVIN_OFFSET', '        return value + _KELVIN_OFFSET', ["tests/test_unit_equivalence.py", "tests/test_units.py"]),
    ("S124", "conversions written in text are not scanned", "scripts/sfe/validate.py",
     '    for path, text in _prose_strings(entry):\n        result = units_mod.scan_text(', '    for path, text in []:\n        result = units_mod.scan_text(', ["tests/test_unit_equivalence.py", "tests/test_units.py"]),
    ("S125", "the prose scan ignores a conversion in parentheses", "scripts/sfe/units.py",
     '    for pattern in (paren, slash, word):', '    for pattern in (slash, word):', ["tests/test_unit_equivalence.py", "tests/test_units.py"]),
    ("S126", "the prose scan ignores a conversion with a slash", "scripts/sfe/units.py",
     '    for pattern in (paren, slash, word):', '    for pattern in (paren, word):', ["tests/test_unit_equivalence.py", "tests/test_units.py"]),
    ("S127", "the prose scan ignores a conversion joined by a word", "scripts/sfe/units.py",
     '    for pattern in (paren, slash, word):', '    for pattern in (paren, slash):', ["tests/test_unit_equivalence.py", "tests/test_units.py"]),
    ("S128", "a conversion that starts with the metric value is read the wrong way round", "scripts/sfe/units.py",
     '        us, metric = (a, b) if a.system == "us" else (b, a)', '        us, metric = a, b', ["tests/test_unit_equivalence.py", "tests/test_units.py"]),
    ("S129", "two quantities in the same system are checked as a conversion", "scripts/sfe/units.py",
     '        if a.system == b.system or a.dimension != b.dimension:', '        if False:', ["tests/test_unit_equivalence.py", "tests/test_units.py"]),
    ("S130", "a hazardous entry is not held to the safety bound", "scripts/sfe/validate.py",
     '    strict_entry = (not ctx.specimen) and _is_hazardous(ctx, entry)', '    strict_entry = False', ["tests/test_unit_equivalence.py", "tests/test_units.py"]),
    ("S131", "a table row ignores the entry's strictness", "scripts/sfe/validate.py",
     'strictness="safety" if strict_entry else "precise", policy=policy):\n            found.append(err("UNIT_INCONSISTENT", where, problem))', 'strictness="precise", policy=policy):\n            found.append(err("UNIT_INCONSISTENT", where, problem))', ["tests/test_unit_equivalence.py", "tests/test_units.py"]),
    ("S132", "an unusable unit policy is not an error", "scripts/sfe/validate.py",
     '    unit_policy, found = units_mod.load_unit_policy(repo)\n    findings += found\n', '    unit_policy, found = units_mod.load_unit_policy(repo)\n', ["tests/test_unit_equivalence.py", "tests/test_units.py"]),
    ("S133", "an unusable unit policy falls back to the default instead of the strictest bound", "scripts/sfe/validate.py",
     'unit_policy=unit_policy or units_mod.STRICT_POLICY)', 'unit_policy=unit_policy or units_mod.DEFAULT_POLICY)', ["tests/test_unit_equivalence.py", "tests/test_units.py"]),
    ("S134", "the policy may loosen a bound past the ceiling", "scripts/sfe/units.py",
     '            elif Decimal(str(value)) > CEILING[name]:', '            elif False:', ["tests/test_unit_equivalence.py", "tests/test_units.py"]),
    ("S135", "the policy may drop pressure and temperature from the safety dimensions", "scripts/sfe/units.py",
     'or not FLOOR_SAFETY_DIMENSIONS <= set(dims) or not set(dims) <= DIMENSIONS:', 'or not set(dims) <= DIMENSIONS:', ["tests/test_unit_equivalence.py", "tests/test_units.py"]),
    ("S136", "a quantity with a unit word that is also an ordinary word is reported alone", "scripts/sfe/units.py",
     '_AMBIGUOUS_ALONE = frozenset({"in", "l"})', '_AMBIGUOUS_ALONE = frozenset()', ["tests/test_unit_equivalence.py", "tests/test_units.py"]),
    ("S137", "an abbreviation period between the two quantities hides the conversion", "scripts/sfe/units.py",
     "    paren = re.compile(rf\"(?<![\\w]){qty('a')}\\.?\\s*\\(", "    paren = re.compile(rf\"(?<![\\w]){qty('a')}\\s*\\(", ["tests/test_unit_equivalence.py", "tests/test_units.py"]),
    # ---- RUN-004: FR-017 (release state)
    ("S138", "release does not reconcile prior state when a build is refused", "scripts/sfe/pdfbuild.py",
     "        if release_mod.has_state(dist):", "        if False and release_mod.has_state(dist):", ["tests/test_release_state.py"]),
    ("S139", "reconcile does not withdraw an invalid active edition", "scripts/sfe/release.py",
     '    if verification.state == "active" and verification.errors:', '    if False and verification.state == "active" and verification.errors:', ["tests/test_release_state.py"]),
    ("S140", "an existing edition with conflicting content is overwritten instead of refused", "scripts/sfe/release.py",
     '        raise ReleaseStateError(f"edition {edition_id} already exists with different content', '        shutil.rmtree(target); os.rename(staged, target); return target  #', ["tests/test_release_state.py"]),
    ("S141", "archived edition files are not made read-only", "scripts/sfe/release.py",
     "    _readonly(target)", "    pass  # _readonly(target)", ["tests/test_release_state.py"]),
    ("S142", "manual withdrawal accepts a meaningless reason like N/A", "scripts/sfe/release.py",
     '    if by == "withdraw" and (textcheck.assess(why, minimum_words=MIN_REASON_WORDS) is not None):', '    if False:', ["tests/test_release_state.py"]),
    ("S143", "release log chain is not verified", "scripts/sfe/release.py",
     '        if row["sequence"] != str(index) or row["event"] not in EVENTS or row["chain_sha256"] != chain_value(previous, cells):', '        if False:', ["tests/test_release_state.py"]),
    ("S144", "verify_active ignores entry package digest changes", "scripts/sfe/release.py",
     '        elif package_of(ctx, entry)[2] != item["package_sha256"]:', '        elif False:', ["tests/test_release_state.py"]),
    ("S145", "verify_active ignores ledger rewind", "scripts/sfe/release.py",
     '        if record is None or name not in LEDGERS or not _extends(repo, name, record["rows"], record["head"]):', '        if False:', ["tests/test_release_state.py"]),
    ("S146", "verify_active ignores policy file changes", "scripts/sfe/release.py",
     "    if recorded_policy != policy_digests(repo):", "    if False:", ["tests/test_release_state.py"]),
    ("S147", "verify_active ignores tampered archived artifacts", "scripts/sfe/release.py",
     '            elif sha256_file(path) != artifact[f"{key}_sha256"]:', '            elif False:', ["tests/test_release_state.py"]),
    ("S148", "recover deletes leftover staging directories instead of quarantining them", "scripts/sfe/release.py",
     '                shutil.move(str(path), str(quarantine / f"staging-{path.name}"))', '                shutil.rmtree(path)', ["tests/test_release_state.py"]),
    ("S149", "recover does not backfill a promotion missing from the log", "scripts/sfe/release.py",
     '        if pointer.state == "active" and recorded != pointer.edition_id:', '        if False:', ["tests/test_release_state.py"]),
    ("S150", "reconcile leaves legacy flat PDFs in dist/zones instead of quarantining them", "scripts/sfe/release.py",
     'def quarantine_legacy(dist: Path) -> list[str]:\n    """Move any pre-RUN-004 flat output in dist/zones or dist/complete to quarantine/, never deleting it."""\n    legacy = _legacy_files(dist)', 'def quarantine_legacy(dist: Path) -> list[str]:\n    legacy = []', ["tests/test_release_state.py"]),
    ("S151", "verify_active ignores legacy flat PDFs sitting in dist/zones", "scripts/sfe/release.py",
     '    if legacy:\n        found.append(err("RELEASE_LEGACY_OUTPUT",', '    if False and legacy:\n        found.append(err("RELEASE_LEGACY_OUTPUT",', ["tests/test_release_state.py"]),
    # ---- RUN-004: FR-014 & FR-015 (image metadata stripping, derivatives, licences, rights evidence, quarantine)
    ("S152", "JPEG EXIF orientation is not transposed before stripping", "scripts/sfe/derive.py",
     "            transposed = ImageOps.exif_transpose(opened)", "            transposed = opened", ["tests/test_image_publication.py"]),
    ("S153", "JPEG derivative copies the original bytes instead of stripping EXIF/GPS", "scripts/sfe/derive.py",
     "                clean.save(dst, **save_kwargs)", "                shutil.copyfile(src, dst)", ["tests/test_image_publication.py"]),
    ("S154", "PNG derivative drops the clean PngInfo stripping", "scripts/sfe/derive.py",
     '                save_kwargs = {"format": "PNG", "compress_level": 9, "pnginfo": PngImagePlugin.PngInfo()}', '                shutil.copyfile(src, dst); return DerivativeRecord(asset_id, original_rel, original_sha, dst.name, sha256_file(dst), "PNG", 1, 1, RECIPE_RASTER, True, stripped_strings); save_kwargs = {}', ["tests/test_image_publication.py"]),
    ("S155", "PDF post-build metadata check skips forbidden signatures", "scripts/sfe/derive.py",
     "    raw = pdf.read_bytes()\n    for sig in FORBIDDEN_PDF_SIGNATURES:", "    raw = pdf.read_bytes()\n    for sig in ():", ["tests/test_image_publication.py"]),
    ("S156", "check_no_originals_archived stops flagging originals copied into editions", "scripts/sfe/derive.py",
     "        if digest in raster_originals:", "        if False:", ["tests/test_image_publication.py"]),
    ("S157", "world-writable originals are accepted without error", "scripts/sfe/assets.py",
     "                    if approved and not specimen and (file_path.stat().st_mode & 0o002):", "                    if False:", ["tests/test_image_publication.py"]),
    ("S158", "unknown licence outside schemas/licenses.yaml is accepted", "scripts/sfe/assets.py",
     '        if entry is None:\n            findings.append(err("LICENSE_UNKNOWN",', '        if False and entry is None:\n            findings.append(err("LICENSE_UNKNOWN",', ["tests/test_licences.py"]),
    ("S159", "incompatible/restrictive licence permissions are not checked", "scripts/sfe/assets.py",
     '            missing = sorted(op for op in policy.required_operations if not entry.permissions.get(op))', '            missing = []', ["tests/test_licences.py"]),
    ("S160", "LicenseRef-Permission ignores missing rights_granted operations", "scripts/sfe/assets.py",
     '            missing = sorted(policy.required_operations - granted)', '            missing = []', ["tests/test_licences.py"]),
    ("S161", "allowed_derivatives=none is not rejected", "scripts/sfe/assets.py",
     '    if deriv_text in FORBIDDEN_DERIVATIVE_TEXT:', '    if False:', ["tests/test_licences.py"]),
    ("S162", "rights evidence hash mismatch is not checked", "scripts/sfe/assets.py",
     '            elif sha256_file(full) != ev_sha:', '            elif False:', ["tests/test_licences.py"]),
    ("S163", "rights evidence path outside assets/rights/ is accepted", "scripts/sfe/assets.py",
     '        elif not safe_relative_path(ev_path) or not ev_path.startswith(RIGHTS_DIR):', '        elif False:', ["tests/test_licences.py"]),
    ("S164", "uncatalogued files in quarantine directory are not reported", "scripts/sfe/assets.py",
     '                    findings.append(err("QUARANTINE_UNCATALOGUED_FILE",', '                    pass  #', ["tests/test_licences.py"]),
    ("S165", "unexpected files directly under assets/ are not reported", "scripts/sfe/assets.py",
     '                    findings.append(err("ASSET_DIRECTORY_UNEXPECTED",', '                    pass  #', ["tests/test_licences.py"]),
    ("S166", "licence policy may drop floor operations like modify", "scripts/sfe/assets.py",
     '        missing_floor = sorted(FLOOR_OPERATIONS - req_ops)', '        missing_floor = []', ["tests/test_licences.py"]),
    ("S167", "rights evidence file hash is not bound into package_of", "scripts/sfe/package.py",
     '        "rights_evidence_sha256_actual": file_sha256(repo_root, row.get("rights_evidence_path")),', '        "rights_evidence_sha256_actual": None,', ["tests/test_licences.py"]),
    # ---- RUN-004: FR-003 residual (external ledger continuity pin)
    ("S168", "validate does not check the external ledger pin", "scripts/sfe/validate.py",
     "        findings += ledger_mod.check_pin(ctx.repo, ctx.pin, require=ctx.require_pin)", "        pass", ["tests/test_ledger_pin.py"]),
    ("S169", "release does not require a ledger pin when ledgers hold rows", "scripts/sfe/pdfbuild.py",
     "    ctx, findings = build_context(repo.root, specimen=False, pin=pin, require_pin=True)", "    ctx, findings = build_context(repo.root, specimen=False, pin=pin, require_pin=False)", ["tests/test_ledger_pin.py"]),
    ("S170", "verify_active does not require a ledger pin", "scripts/sfe/release.py",
     "        ctx, load_findings = build_context(repo.root, pin=pin, require_pin=True)", "        ctx, load_findings = build_context(repo.root, pin=pin, require_pin=False)", ["tests/test_ledger_pin.py"]),
    ("S171", "check_pin ignores tail truncation", "scripts/sfe/ledger.py",
     "        if len(rows) < pinned_rows:", "        if False:", ["tests/test_ledger_pin.py"]),
    ("S172", "check_pin ignores rewritten pinned prefix", "scripts/sfe/ledger.py",
     "        elif pinned_rows > 0 and rows[pinned_rows - 1].get(CHAIN_COL) != pinned_head:", "        elif False:", ["tests/test_ledger_pin.py"]),
    ("S173", "resolve_pin accepts a pin file stored inside the repository", "scripts/sfe/ledger.py",
     "    if is_inside_repo(repo_root, pin_path):", "    if False:", ["tests/test_ledger_pin.py"]),
    ("S174", "parse_pin ignores the pin integrity digest", "scripts/sfe/ledger.py",
     "    if _pin_digest(payload) != claimed_digest:", "    if False:", ["tests/test_ledger_pin.py"]),
    ("S175", "parse_pin accepts a pin covering a subset of ledgers", "scripts/sfe/ledger.py",
     "    if set(parsed) != wanted:", "    if False:", ["tests/test_ledger_pin.py"]),
    ("S176", "create_pin issues a pin from a broken ledger", "scripts/sfe/ledger.py",
     '        if problems:\n            raise LedgerError(f"{rel}: refusing to pin a broken ledger', '        if False:\n            raise LedgerError(f"{rel}: refusing to pin a broken ledger', ["tests/test_ledger_pin.py"]),
    ("S177", "unpinned non-empty ledgers produce no warning on validate", "scripts/sfe/ledger.py",
     '        return [warn("LEDGER_CONTINUITY_UNANCHORED", "reviews",\n                     f"ledgers hold rows and no external ledger pin was supplied (--pin or {PIN_ENV}): a hash chain alone cannot detect tail truncation outside Git")]', '        return []', ["tests/test_ledger_pin.py"]),
    ("S178", "promote silently reactivates a previously withdrawn edition", "scripts/sfe/release.py",
     '    if (previous and previous.state == "withdrawn" and previous.edition_id == edition_id) or any(\n        row["event"] in ("withdraw", "auto_withdraw") and row["edition_id"] == edition_id for row in rows\n    ):', '    if False:', ["tests/test_release_state.py"]),
]


def fresh_copy() -> None:
    if SCRATCH.exists():
        shutil.rmtree(SCRATCH)
    shutil.copytree(LIVE, SCRATCH, ignore=shutil.ignore_patterns(".git", ".serena", "__pycache__", ".pytest_cache", "dist"))
    (SCRATCH / "dist/zones").mkdir(parents=True, exist_ok=True)
    (SCRATCH / "dist/complete").mkdir(parents=True, exist_ok=True)


def run_tests(tests: list[str], tag: str) -> tuple[int, int, str, str]:
    """(failed, errors, summary line, full output). The temp directory of the run is removed afterwards (a run leaves ~100k files behind)."""
    basetemp = SCRATCH.parent / f"pt-{tag}"
    proc = subprocess.run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", f"--basetemp={basetemp}", *tests],
                          cwd=SCRATCH, capture_output=True, text=True, env={**os.environ, "PYTHONPATH": "scripts", "TMPDIR": str(TMP)})
    shutil.rmtree(basetemp, ignore_errors=True)
    out = proc.stdout + proc.stderr
    tail = proc.stdout.strip().splitlines()[-1] if proc.stdout.strip() else out[-200:]
    failed = int(m.group(1)) if (m := re.search(r"(\d+) failed", tail)) else 0
    errors = int(m.group(1)) if (m := re.search(r"(\d+) error", tail)) else 0
    return failed, errors, tail, out


def main() -> None:
    if SCRATCH is None:
        sys.exit(__doc__)
    TMP.mkdir(parents=True, exist_ok=True)
    results = []
    controls: dict[tuple[str, ...], tuple[int, int, str]] = {}
    for sid, description, rel, old, new, tests in SABOTAGES:
        if ONLY and sid not in ONLY:
            continue
        tests = TESTS_OVERRIDE or tests
        fresh_copy()
        key = tuple(tests)
        if key not in controls:  # the UNMODIFIED copy must pass these tests, or "detected" proves nothing
            failed, errors, tail, out = run_tests(tests, "control")
            controls[key] = (failed, errors, tail)
            if failed or errors or "No space left" in out:
                print(f"CONTROL FAILED for {', '.join(tests)}: {tail}")
        failed_c, errors_c, tail_c = controls[key]
        if failed_c or errors_c:
            results.append((sid, description, "CONTROL-FAILED", tail_c))
            print(f"{sid} CONTROL-FAILED: the unmodified copy does not pass {', '.join(tests)}")
            continue
        target = SCRATCH / rel
        text = target.read_text(encoding="utf-8")
        if old not in text:
            results.append((sid, description, "PATCH-NOT-APPLIED", ""))
            print(f"{sid} PATCH NOT APPLIED: {description}")
            continue
        target.write_text(text.replace(old, new, 1), encoding="utf-8")
        failed, errors, tail, out = run_tests(tests, sid)
        if "No space left" in out or "OSError" in out and "Errno 28" in out:
            verdict = "HARNESS-ERROR"
        elif failed or errors:
            verdict = "DETECTED"
        else:
            verdict = "NOT DETECTED"
        results.append((sid, description, verdict, tail))
        print(f"{sid} {verdict:12s} {failed:3d} failed, {errors} error(s) | control: {tail_c} | {description}")
    (SCRATCH.parent / "sabotage_results.json").write_text(json.dumps(results, indent=1), encoding="utf-8")
    missed = [r for r in results if r[2] != "DETECTED"]
    print(f"\n{len(results) - len(missed)} of {len(results)} sabotages detected")
    shutil.rmtree(SCRATCH, ignore_errors=True)
    sys.exit(1 if missed else 0)


if __name__ == "__main__":
    main()
