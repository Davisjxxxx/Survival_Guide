"""Publication image derivatives, EXIF/GPS stripping, orientation & ICC handling, and PDF byte verification (finding FR-014, probe P72).

Verifies:
- EXIF, GPS, artist, description, camera make/model, XMP, IPTC/Photoshop, JPEG COM and PNG text chunks are stripped from publication derivatives;
- EXIF orientation is applied to pixels and ICC colour profiles are preserved;
- Derivatives are deterministic across runs;
- Originals are opened read-only, kept separately under assets/original_photos/ with access controls, and stay byte-identical;
- Released PDFs carry zero EXIF/GPS/artist bytes and zero forbidden segments in `pdfimages -all` output;
- Unstripped leaks in PDFs or originals copied into archives are caught (`IMAGE_METADATA_IN_PDF`, `ORIGINAL_PUBLISHED`);
- Corrupt images and images outside approved directories fail closed (`IMAGE_DERIVE_FAILED`, `RENDER`).
"""
from __future__ import annotations

import json
import subprocess
from pathlib import Path

import pytest
from PIL import Image, ImageCms, PngImagePlugin

from factories import add_asset, build_world, codes, make_repo, pin_for
from sfe import derive, pdfbuild
from sfe.common import sha256_file
from sfe.validate import validate_repo


def make_exif_jpeg(path: Path, *, artist: str = "Fixture EXIF artist QQXIFARTIST",
                   description: str = "Fixture secret locality QQXIFDESC",
                   orientation: int | None = None, icc: bytes | None = None,
                   comment: bytes | None = b"Fixture JPEG comment QQXIFCOM") -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    img = Image.new("RGB", (120, 80), (140, 150, 160))
    # Draw an asymmetric top-left corner marker so orientation transpose is verifiable on pixels
    for x in range(20):
        for y in range(20):
            img.putpixel((x, y), (240, 20, 20))
    exif = img.getexif()
    exif[0x013B] = artist
    exif[0x010E] = description
    exif[0x010F] = "FixtureCameraMake"
    exif[0x0110] = "FixtureCameraModel"
    if orientation is not None:
        exif[0x0112] = orientation
    gps = exif.get_ifd(0x8825)
    gps[1], gps[2], gps[3], gps[4] = "N", (44.0, 58.0, 12.34), "W", (93.0, 15.0, 56.78)
    kwargs = {"format": "JPEG", "exif": exif}
    if icc is not None:
        kwargs["icc_profile"] = icc
    if comment is not None:
        kwargs["comment"] = comment
    img.save(path, **kwargs)
    return path


def make_text_png(path: Path, *, author: str = "Fixture PNG author QQPNGMETA", icc: bytes | None = None) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    img = Image.new("RGB", (100, 60), (90, 120, 150))
    info = PngImagePlugin.PngInfo()
    info.add_text("Author", author)
    info.add_text("Comment", "GPS 44.9700 N, 93.2600 W QQPNGGPS")
    kwargs = {"format": "PNG", "pnginfo": info}
    if icc is not None:
        kwargs["icc_profile"] = icc
    img.save(path, **kwargs)
    return path


def srgb_icc() -> bytes:
    return ImageCms.ImageCmsProfile(ImageCms.createProfile("sRGB")).tobytes()


# ============================================================================== fast unit tests for derive.py
def test_jpeg_derivative_strips_exif_gps_and_comment_deterministically_and_preserves_original(tmp_path):
    src = make_exif_jpeg(tmp_path / "orig/PHO-0001.jpg", icc=srgb_icc())
    orig_sha = sha256_file(src)
    assert derive.inspect_jpeg_segments(src.read_bytes()), "fixture JPEG must start with EXIF/COM"
    assert "Fixture EXIF artist QQXIFARTIST" in derive.extract_metadata_strings(src)

    dst_a = tmp_path / "out_a/PHO-0001.jpg"
    dst_b = tmp_path / "out_b/PHO-0001.jpg"
    rec_a = derive.derive_image(src, dst_a, asset_id="PHO-0001", original_rel="assets/original_photos/PHO-0001.jpg",
                                expected_sha256=orig_sha, allowed_roots=(tmp_path / "orig",))
    rec_b = derive.derive_image(src, dst_b, asset_id="PHO-0001", original_rel="assets/original_photos/PHO-0001.jpg",
                                expected_sha256=orig_sha, allowed_roots=(tmp_path / "orig",))

    assert sha256_file(src) == orig_sha, "original must never be modified"
    assert rec_a.derivative_sha256 == rec_b.derivative_sha256 == sha256_file(dst_a)
    assert dst_a.read_bytes() == dst_b.read_bytes(), "derivative must be deterministic"
    assert rec_a.derivative_sha256 != orig_sha
    assert derive.check_image_clean(dst_a) == []
    raw = dst_a.read_bytes()
    for secret in (b"QQXIFARTIST", b"QQXIFDESC", b"QQXIFCOM", b"FixtureCameraMake", b"Exif\x00\x00"):
        assert secret not in raw
    assert rec_a.icc_preserved is True
    with Image.open(dst_a) as out_img:
        assert isinstance(out_img.info.get("icc_profile"), bytes) and len(out_img.info["icc_profile"]) > 0


def test_jpeg_orientation_is_applied_to_pixels_before_stripping(tmp_path):
    # Orientation 6 = rotate 90 degrees clockwise (270 CCW): 120x80 becomes 80x120, top-left red moves to top-right
    src = make_exif_jpeg(tmp_path / "orig/PHO-0002.jpg", orientation=6)
    dst = tmp_path / "out/PHO-0002.jpg"
    rec = derive.derive_image(src, dst, asset_id="PHO-0002", original_rel="assets/original_photos/PHO-0002.jpg")
    assert (rec.width, rec.height) == (80, 120)
    with Image.open(dst) as img:
        assert img.size == (80, 120)
        assert len(img.getexif()) == 0
        # Top-right corner should now be red-ish (high R, low G/B)
        r, g, b = img.getpixel((70, 10))
        assert r > 180 and g < 80 and b < 80


def test_png_derivative_strips_text_chunks_and_preserves_icc(tmp_path):
    src = make_text_png(tmp_path / "orig/PHO-0003.png", icc=srgb_icc())
    assert "tEXt" in derive.inspect_png_chunks(src.read_bytes())
    dst = tmp_path / "out/PHO-0003.png"
    rec = derive.derive_image(src, dst, asset_id="PHO-0003", original_rel="assets/original_photos/PHO-0003.png")
    assert derive.check_image_clean(dst) == []
    assert b"QQPNGMETA" not in dst.read_bytes() and b"QQPNGGPS" not in dst.read_bytes()
    assert rec.icc_preserved is True


def test_corrupt_image_and_outside_approved_root_refuse_derivation(tmp_path):
    bad = tmp_path / "orig/bad.jpg"
    bad.parent.mkdir(parents=True)
    bad.write_bytes(b"\xff\xd8\xff\xe0corrupt-truncated-jpeg")
    with pytest.raises(derive.DeriveError, match="corrupt"):
        derive.derive_image(bad, tmp_path / "out/bad.jpg", asset_id="PHO-0001", original_rel="assets/original_photos/bad.jpg")

    outside = make_exif_jpeg(tmp_path / "rejected/PHO-0001.jpg")
    with pytest.raises(derive.DeriveError, match="outside"):
        derive.derive_image(outside, tmp_path / "out/PHO-0001.jpg", asset_id="PHO-0001",
                            original_rel="assets/rejected_unverified/PHO-0001.jpg", allowed_roots=(tmp_path / "orig",))


def test_world_writable_original_is_refused_for_access_control(tmp_path):
    repo = make_repo(tmp_path)
    add_asset(repo, 1)
    orig = repo.path("assets/original_photos/PHO-0001.png")
    assert codes(validate_repo(repo.root)) == set()
    orig.chmod(0o666)
    try:
        assert "ASSET_PERMISSIONS_TOO_OPEN" in codes(validate_repo(repo.root))
    finally:
        orig.chmod(0o644)


def test_check_no_originals_archived_catches_copied_original(tmp_path):
    orig = make_exif_jpeg(tmp_path / "orig/PHO-0001.jpg")
    rec = derive.derive_image(orig, tmp_path / "work/PHO-0001.jpg", asset_id="PHO-0001", original_rel="assets/original_photos/PHO-0001.jpg")
    edition = tmp_path / "edition"
    edition.mkdir()
    assert derive.check_no_originals_archived(edition, [rec]) == []
    (edition / "leaked.jpg").write_bytes(orig.read_bytes())
    assert "ORIGINAL_PUBLISHED" in codes(derive.check_no_originals_archived(edition, [rec]))


def test_check_pdf_image_metadata_catches_leaked_exif_signature_and_string(tmp_path):
    # Signature check works even when no stripped strings are passed
    sig_pdf = tmp_path / "sig_only.pdf"
    sig_pdf.write_bytes(b"%PDF-1.4\nExif\x00\x00binary-gps-payload\n%%EOF\n")
    assert "IMAGE_METADATA_IN_PDF" in codes(derive.check_pdf_image_metadata(sig_pdf, []))

    # Stripped-string check works even when no binary EXIF signature is present
    str_pdf = tmp_path / "str_only.pdf"
    str_pdf.write_bytes(b"%PDF-1.4\nFixture EXIF artist QQXIFARTIST\n%%EOF\n")
    rec = derive.DerivativeRecord("PHO-0001", "assets/original_photos/PHO-0001.jpg", "a" * 64, "PHO-0001.jpg",
                                  "b" * 64, "JPEG", 10, 10, derive.RECIPE_RASTER, False, ("Fixture EXIF artist QQXIFARTIST",))
    assert "IMAGE_METADATA_IN_PDF" in codes(derive.check_pdf_image_metadata(str_pdf, [rec]))


# ============================================================================== end-to-end release builds (slow)
@pytest.mark.slow
def test_p72_release_strips_exif_gps_and_records_derivative_lineage(tmp_path):
    repo = make_repo(tmp_path / "repo")
    orig = make_exif_jpeg(repo.path("assets/original_photos/PHO-0001.jpg"), icc=srgb_icc())
    orig_sha = sha256_file(orig)
    add_asset(repo, 1, local_path="assets/original_photos/PHO-0001.jpg", write_file=False, sha256=orig_sha)
    build_world(repo, "published", photo_ids=["PHO-0001"])

    dist = tmp_path / "dist"
    result = pdfbuild.build_release(repo, out_root=dist, pin=pin_for(repo))
    assert result.ok and result.edition_id, [str(f) for f in result.findings]
    assert sha256_file(orig) == orig_sha, "original must remain untouched"

    pdf = result.pdfs[0]
    raw_pdf = pdf.read_bytes()
    for secret in (b"QQXIFARTIST", b"QQXIFDESC", b"QQXIFCOM", b"FixtureCameraMake", b"Exif\x00\x00"):
        assert secret not in raw_pdf, f"metadata {secret!r} leaked into PDF bytes"

    # Extract embedded images independently with pdfimages -all and confirm every one is clean
    ext_dir = tmp_path / "extracted"
    ext_dir.mkdir()
    subprocess.run(["pdfimages", "-all", str(pdf), str(ext_dir / "img")], check=True)
    extracted = sorted(p for p in ext_dir.iterdir() if p.is_file())
    assert extracted, "expected at least one embedded image in the PDF"
    for img_file in extracted:
        assert derive.check_image_clean(img_file) == [], f"{img_file.name} still carries metadata"

    # Lineage is recorded in both zone manifest and EDITION.json, without leaking sensitive strings
    ed_dir = dist / "editions" / result.edition_id
    zone_manifest = json.loads((ed_dir / "zones/Z09_tools_construction.build.json").read_text(encoding="utf-8"))
    ed_manifest = json.loads((ed_dir / "EDITION.json").read_text(encoding="utf-8"))
    assert len(zone_manifest["derivatives"]) == 1
    lineage = zone_manifest["derivatives"][0]
    assert lineage["asset_id"] == "PHO-0001"
    assert lineage["original_sha256"] == orig_sha
    assert lineage["derivative_sha256"] != orig_sha
    assert lineage["recipe"] == derive.RECIPE_RASTER
    assert lineage["icc_preserved"] is True
    assert ed_manifest["derivatives"] == zone_manifest["derivatives"]
    assert "QQXIFARTIST" not in json.dumps(ed_manifest)


@pytest.mark.slow
def test_corrupt_approved_jpeg_refuses_release(tmp_path):
    repo = make_repo(tmp_path / "repo")
    corrupt = repo.path("assets/original_photos/PHO-0001.jpg")
    corrupt.parent.mkdir(parents=True, exist_ok=True)
    corrupt.write_bytes(b"\xff\xd8\xff\xe0corrupt-truncated-jpeg")
    add_asset(repo, 1, local_path="assets/original_photos/PHO-0001.jpg", write_file=False, sha256=sha256_file(corrupt))
    build_world(repo, "published", photo_ids=["PHO-0001"])
    dist = tmp_path / "dist"
    result = pdfbuild.build_release(repo, out_root=dist, pin=pin_for(repo))
    assert not result.ok and "IMAGE_DERIVE_FAILED" in codes(result.findings)
    assert not dist.exists()
