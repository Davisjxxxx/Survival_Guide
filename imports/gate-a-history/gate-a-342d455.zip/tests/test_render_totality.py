"""Renderer totality (FR-011; Fable probe P20): approved text that the layout would drop is refused or found missing, never shipped silently.

Three layers are tested, and each can fail on its own:

  1. the validator: a published entry may not carry a body (PUBLISHED_BODY_NOT_RENDERED); species and medical fields on another entry type are
     errors (tests/test_classification.py);
  2. the renderer: render_entry refuses a non-empty key it does not print and a body it has no section for;
  3. the PDF: after the build every string the layout promises is looked up in the PDF's own text layer (qa.missing_text); a miss is
     RENDER_FIELD_MISSING and the release is refused.

The PDF layer is exercised against the committed specimen proof (a rich entry that uses every field) and against real release builds.
"""
from __future__ import annotations

import re

import json
from shutil import copytree

import pytest
from PIL import Image

from factories import (
    DATE, REAL, add_asset, asset_row, build_world, codes, context, entry_dict, entry_hash, make_repo, pin_for, rewrite_entry, source_row, species_dict,
)
from sfe import __version__, qa
from sfe.common import read_csv, sha256_file, walk_strings
from sfe.entries import MEDICAL_FIELDS, SPECIES_FIELDS
from sfe.ledger import ledger_head
from sfe.pdfbuild import build_proof, build_release
from sfe.registry import LEDGERS, REGISTERS, Repo
from sfe.texgen import KNOWN_UNRENDERED, METADATA_KEYS, PRINTED_KEYS, UNPRINTED_SUBFIELDS, RenderError, printed_strings, render_entry
from sfe.validate import build_context, package_of, validate_repo

ZONE_PDF = "zones/Z09_tools_construction.pdf"
ZONE_MANIFEST = "zones/Z09_tools_construction.build.json"
LIST_FIELDS = {"expert_identification_criteria", "contraindications"}


def run(repo):
    return validate_repo(repo.root)


def render(fm, *, body="", proof=False, assets=None, sources=None):
    return render_entry(fm, assets=assets or {}, sources=sources or {}, zone_title="Fixture zone", proof=proof, repo_root=REAL, body=body)


def token_overrides():
    """Every printable field of an entry, each carrying a token that occurs nowhere else. A mandatory safety field says two words ("Fixture TokX"),
    because a one-word value is refused by the usable-text rule (FR-021); the token is the part that occurs nowhere else."""
    return dict(
        title="TokTitle", what_it_is="TokWhat", find_where="TokWhere", find_when="TokWhen", region=["tokregion"], season=["tokseason"],
        diagnostic_features=["TokDiag"], lookalikes_or_confusions=["TokLook"], materials=["TokMat"], materials_tools=["TokTool"],
        conditions_and_limits=["TokLimit"], dangers=["Fixture TokDanger"], environmental_constraints=["Fixture TokEnv"],
        inspection_acceptance_criteria=["Fixture TokCrit"], failure_modes=["Fixture TokFail"], hazard_boundaries=["Fixture TokBound"], as_of_date=DATE,
        procedure=[{"step": 1, "action": "Fixture TokActOne", "verify": "Fixture TokVerOne", "abort_if": "Fixture TokAbortOne", "claim_ids": ["CLM-0001"]},
                   {"step": 2, "action": "Fixture TokActTwo", "verify": "Fixture TokVerTwo", "abort_if": "Fixture TokAbortTwo", "claim_ids": ["CLM-0001"]}],
        dimension_unit_table=[{"quantity": "TokQuantity", "us_customary": "4 in", "metric": "101.6 mm", "claim_id": "CLM-0001"}],
    )


def tokens():
    return [found for _, text in walk_strings(token_overrides()) for found in re.findall(r"Tok[A-Za-z]+", text)]


def pdf_text(pdf):
    return qa.squash("".join(qa.page_texts(pdf)))


# ===================================================================== which keys the layout knows
def test_every_key_of_the_entry_schema_is_classified():
    """A new schema key must be put on the printed list (and printed) or the metadata list ON PURPOSE: this test fails until it is."""
    schema = json.loads((REAL / "schemas/entry.schema.json").read_text(encoding="utf-8"))
    assert set(schema["properties"]) == PRINTED_KEYS | METADATA_KEYS | SPECIES_FIELDS | MEDICAL_FIELDS


def test_the_printed_and_metadata_lists_do_not_overlap():
    assert not PRINTED_KEYS & METADATA_KEYS
    assert not (PRINTED_KEYS | METADATA_KEYS) & (SPECIES_FIELDS | MEDICAL_FIELDS), "species and medical fields have no layout: they are never printed"


def item_fields(schema, key):
    items = schema["properties"][key]["items"]
    if "$ref" in items:
        items = schema["$defs"][items["$ref"].rsplit("/", 1)[1]]
    return set(items["properties"])


def test_the_unprinted_subfields_name_real_subfields():
    schema = json.loads((REAL / "schemas/entry.schema.json").read_text(encoding="utf-8"))
    for key, subfields in UNPRINTED_SUBFIELDS.items():
        assert key in PRINTED_KEYS and subfields <= item_fields(schema, key), key


# ============================================================================ the renderer refuses
@pytest.mark.parametrize("key", sorted(SPECIES_FIELDS | MEDICAL_FIELDS))
def test_a_non_empty_field_the_layout_does_not_print_is_refused(key):
    fm = entry_dict()
    fm[key] = ["Fixture text"] if key in LIST_FIELDS else "Fixture text"
    with pytest.raises(RenderError, match=key):
        render(fm)


def test_p20_every_unprinted_field_is_named_in_one_refusal():
    fm = entry_dict()
    fm.update(scientific_name="Fixture speciesus", contraindications=["Fixture"])
    with pytest.raises(RenderError) as caught:
        render(fm)
    assert "contraindications" in str(caught.value) and "scientific_name" in str(caught.value)


def test_an_empty_unprinted_field_drops_nothing_so_the_renderer_leaves_it_to_validation():
    fm = entry_dict()
    fm.update(scientific_name="", contraindications=[], taxonomic_authority=None)
    render(fm)


def test_metadata_keys_are_never_refused():
    fm = entry_dict(hazard_tags=["HZ-WATER-POTABILITY"], authored_by="REV-0002", technical_reviewer="REV-0005", editorial_reviewer="REV-0003",
                    approved_by_chatgpt=True, specimen=False)
    render(fm)


def test_a_body_is_refused_in_a_release_and_tolerated_in_a_proof():
    with pytest.raises(RenderError, match="body"):
        render(entry_dict(), body="Approved prose the layout has no section for.\n")
    render(entry_dict(), body="Approved prose the layout has no section for.\n", proof=True)
    render(entry_dict(), body="  \n\n")


def test_an_entry_type_without_a_layout_is_still_refused():
    with pytest.raises(RenderError, match="not implemented"):
        render(species_dict())


# ====================================================================== what the layout promises
def promised_for_tokens():
    fm = entry_dict(**token_overrides(), photo_ids=["PHO-0001"])
    return printed_strings(fm, assets={"PHO-0001": asset_row(1)}, sources={"SRC-0001": source_row()}, zone_title="Fixture zone")


def test_every_token_and_every_printed_form_is_promised():
    promised = promised_for_tokens()
    texts = {text for _, text in promised}
    missing = [token for token in tokens() if not any(token in text for text in texts)]  # a token sits inside the string the layout promises
    assert not missing, missing
    assert f"as of {DATE}" in texts
    assert "Z09-FIXTURE-001 ZONE Z09 · Fixture zone STATUS: DRAFT REV 1" in texts, "the header is promised in the order the layout sets it"
    assert {"CLM-0001", "SRC-0001", "Fixture source", "permitted", "verified", "claim_source"} <= texts
    assert {"PHO-0001", "verified diagnostic", "view whole", "license CC-BY-4.0", "credit Fixture Photographer", "fixture-agency.gov",
            "Fixture caption 1."} <= texts


def test_what_the_layout_never_prints_is_not_promised():
    paths = [path for path, _ in promised_for_tokens()]
    texts = {text for _, text in promised_for_tokens()}
    assert "Fixture alt text 1." not in texts, "alt text is printed in proofs only (KNOWN_UNRENDERED)"
    assert not any(path.endswith(".claim_id") or ".claim_ids[" in path for path in paths), "claim ids of steps and unit rows are links, not text"


def test_a_source_the_register_does_not_know_is_not_promised():
    fm = entry_dict(source_ids=["SRC-9999"])
    assert not [p for p, _ in printed_strings(fm, assets={}, sources={}, zone_title="Z") if p.startswith("source")]


def test_a_subfield_added_to_a_printed_key_is_expected_too():
    """Fail closed: a layout that does not print a new sub-field fails the PDF check instead of dropping the text without a word."""
    fm = entry_dict()
    fm["procedure"][0]["notes"] = "TokNewSubfield"
    fm["dimension_unit_table"][0]["footnote"] = "TokNewCell"
    texts = {text for _, text in printed_strings(fm, assets={}, sources={}, zone_title="Z")}
    assert {"TokNewSubfield", "TokNewCell"} <= texts


def test_the_specimen_exercises_every_field_the_promise_list_names():
    """The oracle for the PDF tests below is only as good as the entry: the specimen must use each optional field."""
    ctx, _ = build_context(REAL, specimen=True)
    fm = ctx.entries[0].fm
    for key in PRINTED_KEYS - {"as_of_date"}:
        assert fm.get(key), f"the specimen has no {key}"


# ============================================================================== the text-layer check
SPECIMEN_PDF = REAL / "proofs/SPECIMEN_LAYOUT_PROOF.pdf"


@pytest.fixture(scope="module")
def specimen():
    ctx, findings = build_context(REAL, specimen=True)
    assert not [f for f in findings if f.severity == "error"]
    manifest = json.loads((REAL / "proofs/SPECIMEN_LAYOUT_PROOF.build.json").read_text(encoding="utf-8"))
    footer = f"PROOF — NOT FOR PUBLICATION · build {manifest['build_id']}"
    return ctx, ctx.entries[0], footer


def test_the_committed_proof_carries_every_string_the_layout_promises(specimen):
    ctx, entry, footer = specimen
    promised = printed_strings(entry.fm, assets=ctx.assets, sources=ctx.sources, zone_title="")
    assert len(promised) >= 45
    assert qa.missing_text(SPECIMEN_PDF, promised, furniture=lambda page: (footer,)) == []


def test_a_string_that_was_never_printed_is_reported(specimen):
    ctx, entry, footer = specimen
    promised = printed_strings(entry.fm, assets=ctx.assets, sources=ctx.sources, zone_title="") + [("fabricated", "Text no layout ever printed.")]
    assert qa.missing_text(SPECIMEN_PDF, promised, furniture=lambda page: (footer,)) == [("fabricated", "Text no layout ever printed.")]


def test_a_string_only_the_footer_prints_is_not_satisfied_by_the_footer(specimen):
    _, _, footer = specimen
    build_id = footer.rsplit(" ", 1)[1]
    assert qa.missing_text(SPECIMEN_PDF, [("zone tag", build_id)]) == [], "without furniture removal the footer would satisfy it"
    assert qa.missing_text(SPECIMEN_PDF, [("zone tag", build_id)], furniture=lambda page: (footer,)) == [("zone tag", build_id)]


def test_a_short_string_is_not_satisfied_by_a_longer_one_that_contains_it():
    longer = "[DUMMY] Stand-in text for the WHAT field. It has no field meaning."
    shorter = "Stand-in text for the WHAT field"
    assert qa.missing_text(SPECIMEN_PDF, [("a", longer)]) == []
    assert qa.missing_text(SPECIMEN_PDF, [("a", longer), ("b", shorter)]) == [("b", shorter)]


def test_two_fields_with_the_same_text_need_two_occurrences():
    text = "[DUMMY] look-alike A (stand-in)"
    assert qa.missing_text(SPECIMEN_PDF, [("one", text)]) == []
    assert qa.missing_text(SPECIMEN_PDF, [("one", text), ("two", text)]) == [("two", text)]


def test_squash_ignores_what_typography_and_encoding_change():
    assert qa.squash("ﬁnd-ing") == qa.squash("finding") == "finding"
    assert qa.squash("Café") == qa.squash("Café") == qa.squash("cafe")
    assert qa.squash("“Quoted”, ­soft-hyphen   spacing") == "quotedsofthyphenspacing"
    assert qa.squash("— · … ") == "", "a string with nothing to look up is not looked up"


def test_a_page_with_no_text_layer_fails_every_expectation(tmp_path):
    """A scanned or image-only PDF has nothing to find: every promised string is reported."""
    image = tmp_path / "scan.pdf"
    Image.new("RGB", (200, 200), "white").save(image)
    assert qa.missing_text(image, [("a", "Fixture text")]) == [("a", "Fixture text")]


# ===================================================================== the validator: published bodies
def test_a_published_entry_with_body_text_is_refused(repo):
    build_world(repo, "published", body="Prose the layout would drop.\n")
    assert "PUBLISHED_BODY_NOT_RENDERED" in codes(run(repo))


def test_a_whitespace_only_body_is_no_text(repo):
    build_world(repo, "published", body="  \n\n")
    assert codes(run(repo)) == set()


def test_an_approved_entry_may_still_carry_a_body(repo):
    build_world(repo, "approved")
    assert codes(run(repo)) == set()


def test_publishing_an_entry_that_has_a_body_is_refused_though_its_approval_stays_valid(repo):
    path = build_world(repo, "approved")
    rewrite_entry(path, lambda fm: fm.update(status="published", revision=1))
    assert codes(run(repo)) == {"PUBLISHED_BODY_NOT_RENDERED"}


def test_p20_is_refused_at_validation_and_at_render(repo):
    """Approved species text on an entry typed `general`: the layout never printed it, the species rules never ran."""
    build_world(repo, "approved", entry_type="general", scientific_name="Fixture speciesus", positive_identification_warning="Fixture warning")
    assert "ENTRY_FIELD_NOT_FOR_TYPE" in codes(run(repo))
    ctx = context(repo)
    with pytest.raises(RenderError, match="scientific_name"):
        render_entry(ctx.entries[0].fm, assets=ctx.assets, sources=ctx.sources, zone_title="Z", proof=False, repo_root=repo.root)


# ===================================================================== real release builds (slow)
def published_world(tmp_path, **over):
    tmp_path.mkdir(exist_ok=True)
    repo = make_repo(tmp_path)
    add_asset(repo, 1)
    add_asset(repo, 1, kind="illustration")
    return repo, build_world(repo, "published", photo_ids=["PHO-0001"], illustration_ids=["ILL-0001"], **over)


@pytest.fixture(scope="module")
def token_release(tmp_path_factory):
    root = tmp_path_factory.mktemp("token_release")
    repo, path = published_world(root / "repo", **token_overrides())
    out = root / "out"
    return repo, path, out, build_release(repo, out_root=out, pin=pin_for(repo))


def zone_title(ctx):
    return next(z["title"] for z in ctx.zones if z["id"] == "Z09")


@pytest.mark.slow
def test_a_unique_token_in_every_printed_field_is_found_in_the_release_pdf(token_release):
    repo, _, out, result = token_release
    assert result.ok and result.edition_id, [str(f) for f in result.findings]
    document = pdf_text(out / "editions" / result.edition_id / ZONE_PDF)
    for token in tokens():
        assert qa.squash(token) in document, f"{token} was approved and is not in the PDF"


@pytest.mark.slow
def test_the_independent_text_check_agrees_with_the_pipelines(token_release):
    """The test does its own look-up, so it can fail on an omitted field even if the pipeline's check were removed."""
    repo, _, out, result = token_release
    ed_dir = out / "editions" / result.edition_id
    ctx = context(repo)
    entry = ctx.entries[0]
    title = zone_title(ctx)
    promised = printed_strings(entry.fm, assets=ctx.assets, sources=ctx.sources, zone_title=title)
    assert len(promised) >= 40
    missing = qa.missing_text(ed_dir / ZONE_PDF, promised, furniture=lambda page: (f"Survival Field Encyclopedia · Z09 · {title}", f"sfe {__version__} · page {page}"))
    assert missing == []
    manifest = json.loads((ed_dir / ZONE_MANIFEST).read_text(encoding="utf-8"))
    assert manifest["render_check"] == {"strings_promised": len(promised), "missing": 0}


@pytest.mark.slow
def test_the_release_manifest_records_what_the_release_rests_on(token_release):
    repo, path, out, result = token_release
    manifest = json.loads((out / "editions" / result.edition_id / ZONE_MANIFEST).read_text(encoding="utf-8"))
    ctx = context(repo)
    entry = ctx.entries[0]
    assert manifest["edition_id"] == result.edition_id
    assert manifest["entries"] == [{"id": "Z09-FIXTURE-001", "revision": 1, "content_sha256": entry_hash(path), "package_sha256": package_of(ctx, entry)[2]}]
    assert set(manifest["ledger_heads"]) == set(LEDGERS)
    for name, head in manifest["ledger_heads"].items():
        header, rows = read_csv(repo.path(REGISTERS[name][0]))
        assert head == ledger_head(header, rows) and len(head) == 64, name
        assert manifest["ledger_state"][name] == {"rows": len(rows), "head": head}
    from sfe.pdfbuild import POLICY_FILES
    assert set(POLICY_FILES) >= {"schemas/hazard_topics.yaml", "schemas/classification_policy.yaml", "schemas/claim_policy.yaml", "schemas/unit_policy.yaml", "schemas/licenses.yaml"}
    assert manifest["policy_sha256"] == {rel: sha256_file(repo.path(rel)) for rel in POLICY_FILES}
    assert manifest["known_unrendered"] == list(KNOWN_UNRENDERED)


SABOTAGES = {
    "asset_line": (r"\newcommand{\sfeAssetLine}[1]{{\scriptsize\raggedright #1\par}}", r"\newcommand{\sfeAssetLine}[1]{}",
                   {"assets.PHO-0001.caption", "assets.PHO-0001.credit", "assets.PHO-0001.license", "assets.ILL-0001.caption"}),
    "legend_row": (r"{\ttfamily\footnotesize #1} & #2 & #3 & #4 & #5}", r"{\ttfamily\footnotesize #1} & #2 & & & }",
                   {"sources.SRC-0001.rights_status", "sources.SRC-0001.verification_status", "sources.SRC-0001.intended_use"}),
}


@pytest.mark.slow
@pytest.mark.parametrize("name", sorted(SABOTAGES))
def test_a_layout_that_drops_a_field_refuses_the_release(tmp_path, name):
    """The acceptance criterion: a sabotaged renderer that swallows approved text is caught, and nothing is written."""
    old, new, dropped = SABOTAGES[name]
    repo, _ = published_world(tmp_path / "repo")
    sty = repo.path("layouts/sfe.sty")
    text = sty.read_text(encoding="utf-8")
    assert old in text, "the layout changed: update this sabotage"
    sty.write_text(text.replace(old, new, 1), encoding="utf-8", newline="\n")
    result = build_release(repo, out_root=tmp_path / "out", pin=pin_for(repo))
    assert not result.ok and "RENDER_FIELD_MISSING" in codes(result.findings)
    reported = " ".join(f.message for f in result.findings if f.code == "RENDER_FIELD_MISSING")
    for path in dropped:
        assert path in reported, f"{path} was dropped and not reported"
    assert not (tmp_path / "out").exists()


@pytest.mark.slow
def test_a_layout_that_drops_a_field_refuses_the_proof_too(tmp_path):
    """The proof is the layout's own reference build: it carries the same text-layer check, so a broken layout cannot produce a green proof."""
    root = tmp_path / "repo"
    for rel in ("schemas", "layouts", "content"):
        copytree(REAL / rel, root / rel)
    sty = root / "layouts/sfe.sty"
    old = SABOTAGES["asset_line"][0]
    text = sty.read_text(encoding="utf-8")
    assert old in text
    sty.write_text(text.replace(old, SABOTAGES["asset_line"][1], 1), encoding="utf-8", newline="\n")
    result = build_proof(Repo(root), out_dir=tmp_path / "out", previews=False)
    assert not result.ok and "RENDER_FIELD_MISSING" in codes(result.findings)
    assert not (tmp_path / "out").exists() or not list((tmp_path / "out").glob("*.pdf"))


@pytest.mark.slow
def test_a_published_body_never_reaches_the_renderer(tmp_path):
    repo, _ = published_world(tmp_path / "repo", body="Prose the layout would drop.\n")
    result = build_release(repo, out_root=tmp_path / "out", pin=pin_for(repo))
    assert not result.ok and "PUBLISHED_BODY_NOT_RENDERED" in codes(result.findings) and "RENDER" not in codes(result.findings)
    assert not (tmp_path / "out").exists()
