"""FABLE-REVIEW-001 probes, ported to the RUN-003 trust model.

The originals (Survival_Guide_Fable_Review/evidence/probes*.py) build ledger rows with RUN-002's columns (reviewer, reviewer_role) and so cannot
run against this tree. Each probe here builds the SAME scenario with the current model's records, and returns what the validator says.

    BLOCKED   the validator refused the scenario (the counterexample no longer works)
    ELIGIBLE  it did not (for an in-scope probe that is a regression; for an out-of-scope one it is the finding that stays open)
    INFO      measured, not judged

A probe passes only if it is BLOCKED *for the stated reason*, and only if the valid world it started from was itself clean (`control`):
a counterexample refused because the fixture was already broken proves nothing.

`scope` is "in" for what RUN-003 claims to close and "out" for what it does not (FINDING_REMEDIATION_MATRIX.md section 4). Out-of-scope probes
are measured and reported, never asserted: they must not become tests that pin an open hole in place.

Run as a script for the before/after table:  PYTHONPATH=scripts:tests python3 tests/fable_probes.py <tmp dir> [probe-id ...]
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tempfile
import time
import traceback
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

import yaml

import factories as F
from sfe import package as package_mod
from sfe.common import sha256_file
from sfe.validate import package_of, validate_repo

D = F.DATE  # 2026-01-15
W = "HZ-WATER-POTABILITY"
FORAGE = "HZ-FORAGING-ID"


@dataclass
class Result:
    verdict: str
    errors: list[str]
    warnings: list[str] = field(default_factory=list)
    control: list[str] | None = None  # the errors of the valid world BEFORE the counterexample; must be empty
    info: dict[str, Any] = field(default_factory=dict)
    messages: list[str] = field(default_factory=list)  # the text of every error: what exactly was refused


@dataclass
class Probe:
    pid: str
    title: str
    finding: str
    fn: Callable[["Kit"], Result]
    expect: tuple[str, ...] = ()  # codes that must all be present
    expect_any: tuple[str, ...] = ()  # at least one of these must be present
    expect_text: tuple[str, ...] = ()  # each must occur in the message of some error: names WHICH subject, field or record was refused
    scope: str = "in"
    slow: bool = False
    no_control: str = ""  # why a control is not meaningful, when it is not


PROBES: list[Probe] = []


def probe(pid: str, title: str, finding: str, *, expect: tuple[str, ...] = (), expect_any: tuple[str, ...] = (), expect_text: tuple[str, ...] = (),
          scope: str = "in", slow: bool = False, no_control: str = ""):
    def deco(fn):
        PROBES.append(Probe(pid, title, finding, fn, expect, expect_any, expect_text, scope, slow, no_control))
        return fn
    return deco


class Kit:
    """A throwaway workspace: every repository a probe builds lives under `tmp`."""

    def __init__(self, tmp: Path):
        self.tmp = Path(tmp)
        self.repo = self.new_repo()

    def new_repo(self):
        return F.make_repo(Path(tempfile.mkdtemp(prefix="probe-", dir=self.tmp)))

    @staticmethod
    def errors(repo) -> list[str]:
        return sorted(F.codes(validate_repo(repo.root)))

    def verdict(self, repo, control: list[str] | None = None, **info: Any) -> Result:
        found = validate_repo(repo.root)
        errors = sorted(F.codes(found))
        messages = sorted({f.message for f in found if f.severity == "error"})
        return Result("BLOCKED" if errors else "ELIGIBLE", errors, sorted(F.codes(found, "warning")), control, info, messages)

    def clean(self, build: Callable[[Any], Any]) -> list[str]:
        """The errors of the valid world `build` makes in a repository of its own: the control for a counterexample that REPLACES something."""
        repo = self.new_repo()
        build(repo)
        return self.errors(repo)


# ------------------------------------------------------------------------------------------------ worlds
def haz(repo, status="approved", tags=(W,), reviews=True, **over):
    """A hazard-tagged entry of the neutral zone with everything its classification requires, all by registered fixture reviewers."""
    return F.build_world(repo, status, hazard_tags=list(tags), as_of_date=D, reviews=reviews, **over)


def awaiting_review(repo, tags=(W,), **over):
    """The same entry with its editorial approval and NO safety review yet."""
    path = haz(repo, tags=tags, reviews=False, **over)
    F.add_approval(repo, path)
    return path


def species_world(repo, status="approved", views=("whole", "key_feature"), reviews=True, **over):
    photos = []
    for n, view in enumerate(views, start=1):
        F.add_asset(repo, n, view=view)
        photos.append(f"PHO-{n:04d}")
    return F.build_world(repo, status, fm_factory=F.species_dict, photo_ids=photos, reviews=reviews, **over)


def fail(repo, path, topics, on, role="external_sme", **o):
    return F.add_safety(repo, path, topics, role=role, decision="fail", reviewed_on=on, **o)


def release(kit: Kit, repo, *, pin: Any = "AUTO"):
    from sfe import pdfbuild
    from sfe.ledger import LedgerError
    out = Path(tempfile.mkdtemp(prefix="rel-", dir=kit.tmp))
    if pin == "AUTO":
        try:
            pin = F.pin_for(repo)
        except LedgerError:
            pin = None
    started = time.monotonic()
    result = pdfbuild.build_release(repo, out_root=out, pin=pin)
    return result, out, time.monotonic() - started


def pdf_text(pdf) -> str:
    return " ".join(subprocess.run(["pdftotext", "-layout", str(pdf), "-"], capture_output=True, text=True, check=True).stdout.split())


# ============================================================================== the safety ledger (FR-002, FR-003, FR-004, FR-005)
@probe("P01", "GA-001: one user-role pass row satisfies a hazard topic", "FR-005", expect=("SAFETY_REVIEW_ROLE_MISSING",))
def p01(kit):
    ctl = kit.clean(haz)
    path = awaiting_review(kit.repo)
    F.add_safety(kit.repo, path, [W], role="user")
    return kit.verdict(kit.repo, ctl)


@probe("P02", "GA-002: pass pair, then a LATER-dated fail", "FR-002", expect=("SAFETY_FAILURE_UNRESOLVED",))
def p02(kit):
    path = haz(kit.repo)
    ctl = kit.errors(kit.repo)
    fail(kit.repo, path, [W], "2026-01-20")
    return kit.verdict(kit.repo, ctl)


@probe("P03a", "pass pair dated 2099-01-01; fail appended afterwards dated 2026-11-17", "FR-002, FR-003",
       expect=("SAFETY_FAILURE_UNRESOLVED", "LEDGER_DATE_REGRESSION"))
def p03a(kit):
    path = awaiting_review(kit.repo)
    F.add_safety_pair(kit.repo, path, [W], reviewed_on="2099-01-01")
    ctl = kit.errors(kit.repo)
    fail(kit.repo, path, [W], "2026-11-17")
    return kit.verdict(kit.repo, ctl)


@probe("P03b", "pass pair dated 2026-01-15; fail appended afterwards but dated one day earlier", "FR-002, FR-003",
       expect=("SAFETY_FAILURE_UNRESOLVED", "LEDGER_DATE_REGRESSION"))
def p03b(kit):
    path = haz(kit.repo)
    ctl = kit.errors(kit.repo)
    fail(kit.repo, path, [W], "2026-01-14")
    return kit.verdict(kit.repo, ctl)


@probe("P04", "fail row with EMPTY subjects on a hazard-tagged entry (after a pass pair)", "FR-002", expect_any=("SAFETY_FAILURE_UNRESOLVED", "ROW_SCHEMA"))
def p04(kit):
    path = haz(kit.repo)
    ctl = kit.errors(kit.repo)
    fail(kit.repo, path, [], "2026-01-20")
    return kit.verdict(kit.repo, ctl)


@probe("P05", "fail row naming a hazard topic the entry is NOT tagged with (after a pass pair)", "FR-002", expect=("SAFETY_FAILURE_UNRESOLVED",))
def p05(kit):
    path = haz(kit.repo)
    ctl = kit.errors(kit.repo)
    fail(kit.repo, path, ["HZ-COMBUSTION-CO"], "2026-01-20")
    return kit.verdict(kit.repo, ctl)


@probe("P06", "untagged, non-medical entry with a recorded safety FAIL", "FR-002", expect=("SAFETY_FAILURE_UNRESOLVED",))
def p06(kit):
    path = F.build_world(kit.repo, "published")
    ctl = kit.errors(kit.repo)
    fail(kit.repo, path, [W], "2026-02-01")
    return kit.verdict(kit.repo, ctl)


@probe("P07", "SME fail, then the SAME two reviewers re-pass later with no content change", "FR-002", expect=("SAFETY_FAILURE_UNRESOLVED",))
def p07(kit):
    path = haz(kit.repo)
    ctl = kit.errors(kit.repo)
    fail(kit.repo, path, [W], "2026-01-20")
    F.add_safety_pair(kit.repo, path, [W], reviewed_on="2026-01-21")
    return kit.verdict(kit.repo, ctl)


@probe("P08a", "same-day rows, file order [pass, pass, fail]", "FR-002", expect=("SAFETY_FAILURE_UNRESOLVED",))
def p08a(kit):
    path = haz(kit.repo)
    ctl = kit.errors(kit.repo)
    fail(kit.repo, path, [W], D)
    return kit.verdict(kit.repo, ctl)


@probe("P08b", "the SAME three rows re-sorted to file order [fail, pass, pass] (e.g. a spreadsheet sort)", "FR-003",
       expect_any=("LEDGER_SEQUENCE_BROKEN", "LEDGER_CHAIN_BROKEN"))
def p08b(kit):
    ctl = kit.clean(haz)  # the control: the same entry, honestly appended
    path = haz(kit.repo)
    fail(kit.repo, path, [W], D)
    F.tamper(kit.repo, "safety_audit", lambda body: [body[0], body[3], body[1], body[2]])
    return kit.verdict(kit.repo, ctl)


@probe("P08c", "fail row deleted from the ledger after it blocked", "FR-003", expect=("LEDGER_HISTORY_REWRITTEN",))
def p08c(kit):
    """Removing the LAST row leaves a valid chain. A Git checkout catches it via history; a bare export catches it via an external
    continuity pin (LEDGER_PIN_TRUNCATED), and without a pin release fails closed (LEDGER_PIN_REQUIRED) while validate warns."""
    from sfe import pdfbuild
    repo = kit.repo

    def git(*args):
        return subprocess.run(["git", "-c", "user.name=Fixture", "-c", "user.email=fixture@example.invalid", "-c", "commit.gpgsign=false",
                               "-C", str(repo.root), *args], capture_output=True, text=True, check=True)
    git("init", "-q", "-b", "main")
    path = haz(repo, status="published")
    ctl = kit.errors(repo)
    fail(repo, path, [W], "2026-01-20")
    git("add", "-A")
    git("commit", "-q", "-m", "the failure is recorded")
    pin = F.pin_for(repo)
    blocked_before = kit.errors(repo)
    rows = F.read_rows(repo, "safety_audit")
    F.write_rows(repo, "safety_audit", rows[:-1])  # re-sealed: internally consistent, as a careful editor would leave it
    result = kit.verdict(repo, ctl, blocked_while_recorded=bool(blocked_before))
    bare = Path(tempfile.mkdtemp(prefix="bare-", dir=kit.tmp)) / "export"
    shutil.copytree(repo.root, bare, ignore=shutil.ignore_patterns(".git"))
    bare_with_pin = sorted(F.codes(validate_repo(bare, pin=pin)))
    bare_unpinned_warnings = sorted(F.codes(validate_repo(bare), "warning"))
    bare_unpinned_release = pdfbuild.build_release(F.Repo(bare), out_root=Path(tempfile.mkdtemp(prefix="rel-", dir=kit.tmp)), pin=None)
    result.info["outside_git_with_pin"] = bare_with_pin
    result.info["outside_git_unpinned_validate_warnings"] = bare_unpinned_warnings
    result.info["outside_git_unpinned_release_errors"] = sorted(F.codes(bare_unpinned_release.findings))
    return result


@probe("P09", "both review classes satisfied by rows whose reviewer names are two AI model labels", "FR-005", expect=("SAFETY_REVIEW_ROLE_MISSING",))
def p09(kit):
    ctl = kit.clean(lambda repo: haz(repo, tags=(FORAGE,)))
    repo = kit.repo
    path = awaiting_review(repo, tags=(FORAGE,))
    F.register(repo, "REV-0007", "technical_reviewer", kind="ai_model", name="GPT-6 High", domains=F.ALL_DOMAINS, evidence="Fixture model card")
    F.add_safety(repo, path, [FORAGE], role="technical_reviewer", reviewer_id="REV-0007", capacity="technical_reviewer")
    F.add_safety(repo, path, [FORAGE], role="chatgpt_editorial", reviewer="GPT-6 Extra High")
    return kit.verdict(repo, ctl)


@probe("P09b", "same reviewer name in BOTH review classes", "FR-005", expect=("SAFETY_REVIEW_ROLE_MISSING",),
       expect_any=("REGISTRY_KIND_CAPACITY", "REGISTRY_NAME_DUPLICATE", "REGISTRY_IDENTITY_CONFLICT"))
def p09b(kit):
    """One identity cannot be both a human domain expert and an AI validator: the registry refuses the second capacity, so the second class stays unmet."""
    ctl = kit.clean(lambda repo: haz(repo, status="published"))
    repo = kit.repo
    path = awaiting_review(repo, status="published")
    F.add_safety(repo, path, [W], role="external_sme", reviewer="Fixture Same Person")
    F.add_safety(repo, path, [W], role="chatgpt_editorial", reviewer="Fixture Same Person")
    return kit.verdict(repo, ctl)


@probe("P36", "medical_guidance entry tagged with one topic: pair rows list ONLY that topic", "FR-001", expect=("SAFETY_TOPIC_UNCOVERED",))
def p36(kit):
    def world(repo):
        return F.build_world(repo, "approved", fm_factory=F.medical_dict, hazard_tags=[W], as_of_date=D)
    ctl = kit.clean(world)
    repo = kit.repo
    path = F.build_world(repo, "approved", fm_factory=F.medical_dict, hazard_tags=[W], as_of_date=D, reviews=False)
    F.add_approval(repo, path)
    F.add_safety_pair(repo, path, [W])
    return kit.verdict(repo, ctl)


@probe("P52", "fail row keyed to revision 2 while the entry says revision 1 (same content hash)", "FR-002", expect=("SAFETY_FAILURE_UNRESOLVED",))
def p52(kit):
    path = haz(kit.repo)
    ctl = kit.errors(kit.repo)
    fail(kit.repo, path, [W], "2026-01-20", revision=2)
    return kit.verdict(kit.repo, ctl)


@probe("P53", "fail row whose entry_id is a one-character typo of the real id (orphan ledger row)", "FR-004", expect=("LEDGER_ROW_ORPHAN",))
def p53(kit):
    path = haz(kit.repo)
    ctl = kit.errors(kit.repo)
    fail(kit.repo, path, [W], "2026-01-20", entry_id="Z09-FIXTURF-001")
    return kit.verdict(kit.repo, ctl)


# ============================================================================== the approvals ledger (FR-002, FR-003, FR-005)
UNRESOLVED_APPROVAL = "blocks this entry until a resolution row clears it"


@probe("P10a", "approvals: chatgpt approved -> chatgpt WITHDRAWN -> technical_reviewer approved (later)", "FR-002", expect=("APPROVAL_NOT_CURRENT",),
       expect_text=(UNRESOLVED_APPROVAL, "REVIEWER_CAPACITY_NOT_PERMITTED"))
def p10a(kit):
    path = F.build_world(kit.repo, "published")
    ctl = kit.errors(kit.repo)
    F.add_approval(kit.repo, path, decision="withdrawn", decided_on="2026-02-01")
    F.add_approval(kit.repo, path, reviewer_id="REV-0005", capacity="technical_reviewer", decided_on="2026-02-02")
    return kit.verdict(kit.repo, ctl)


@probe("P10b", "approvals: chatgpt approved -> external_sme REJECTED -> user approved (later)", "FR-002", expect=("APPROVAL_NOT_CURRENT",),
       expect_text=(UNRESOLVED_APPROVAL, "REVIEWER_CAPACITY_NOT_PERMITTED"))
def p10b(kit):
    path = F.build_world(kit.repo, "published")
    ctl = kit.errors(kit.repo)
    F.add_approval(kit.repo, path, decision="rejected", reviewer_id="REV-0004", capacity="external_sme", decided_on="2026-02-01")
    F.add_approval(kit.repo, path, reviewer_id="REV-0001", capacity="registrar", decided_on="2026-02-02")
    return kit.verdict(kit.repo, ctl)


@probe("P11a", "approvals: approval dated 2099-01-01, then chatgpt withdrawal appended dated 2026-11-17", "FR-002, FR-003",
       expect=("LEDGER_DATE_REGRESSION", "APPROVAL_NOT_CURRENT"), expect_text=(UNRESOLVED_APPROVAL,))
def p11a(kit):
    path = F.build_world(kit.repo, "published")
    ctl = kit.errors(kit.repo)
    F.edit_rows(kit.repo, "approvals", lambda rows: rows[0].update(decided_on="2099-01-01"))
    F.add_approval(kit.repo, path, decision="withdrawn", decided_on="2026-11-17")
    return kit.verdict(kit.repo, ctl)


@probe("P11b", "approvals: withdrawal appended later but dated one day before the approval", "FR-002, FR-003",
       expect=("LEDGER_DATE_REGRESSION", "APPROVAL_NOT_CURRENT"), expect_text=(UNRESOLVED_APPROVAL,))
def p11b(kit):
    path = F.build_world(kit.repo, "published")
    ctl = kit.errors(kit.repo)
    F.add_approval(kit.repo, path, decision="withdrawn", decided_on="2026-01-14")
    return kit.verdict(kit.repo, ctl)


@probe("P24", "calendar-impossible dates accepted (decided_on 2026-02-31, as_of_date 2026-13-45)", "FR-003", expect=("DATE_INVALID",))
def p24(kit):
    path = F.build_world(kit.repo, "published")
    ctl = kit.errors(kit.repo)
    F.rewrite_entry(path, lambda fm: fm.update(as_of_date="2026-13-45"))
    F.edit_rows(kit.repo, "approvals", lambda rows: rows[0].update(decided_on="2026-02-31"))
    return kit.verdict(kit.repo, ctl)


# ============================================================================== images and species (FR-009, FR-010, FR-012)
@probe("P12", "image audits: decision=pass with identification/license/provenance checked = false, role user", "FR-010",
       expect=("IMAGE_AUDIT_CHECKS_INCOMPLETE",))
def p12(kit):
    ctl = kit.clean(species_world)
    repo = kit.repo
    for n, view in enumerate(("whole", "key_feature"), start=1):
        F.add_asset(repo, n, view=view, audited=False)
        F.add_image_audit(repo, f"PHO-{n:04d}", provenance_checked=False, license_checked=False, identification_checked=False,
                          reviewer_id="REV-0001", capacity="registrar")
    F.build_world(repo, "approved", fm_factory=F.species_dict, photo_ids=["PHO-0001", "PHO-0002"])
    return kit.verdict(repo, ctl)


@probe("P13", "species plate: ONE photo file catalogued twice (two ids, two 'views') satisfies the two-view rule", "FR-012",
       expect=("ASSET_DUPLICATE_BYTES", "SPECIES_PLATE_VIEWS"))
def p13(kit):
    ctl = kit.clean(species_world)
    repo = kit.repo
    first = F.add_asset(repo, 1, view="whole")
    F.add_asset(repo, 2, view="key_feature", local_path=first["local_path"], write_file=False, sha256=first["sha256"])
    F.build_world(repo, "approved", fm_factory=F.species_dict, photo_ids=["PHO-0001", "PHO-0002"])
    return kit.verdict(repo, ctl)


@probe("P13b", "ONE image file catalogued as verified_diagnostic for TWO different subjects", "FR-012", expect=("ASSET_DUPLICATE_BYTES",))
def p13b(kit):
    ctl = kit.clean(lambda repo: [F.add_asset(repo, 1, view="whole"), F.add_asset(repo, 2, view="whole", taxon="TAX-0002")])
    repo = kit.repo
    first = F.add_asset(repo, 1, view="whole", subject_scientific_or_material_name="Fixture speciesus")
    F.add_asset(repo, 2, view="whole", local_path=first["local_path"], write_file=False, sha256=first["sha256"], taxon="TAX-0002",
                subject_scientific_or_material_name="Fixture alius 2")
    return kit.verdict(repo, ctl)


@probe("P14", "species plate: both diagnostic photos are catalogued as a DIFFERENT subject than the entry's scientific_name", "FR-012",
       expect=("SPECIES_PLATE_TAXON_MISMATCH", "SPECIES_PLATE_VIEWS"))
def p14(kit):
    ctl = kit.clean(species_world)
    repo = kit.repo
    F.add_taxon(repo, 2, scientific_name="Fixtura aliena")
    for n, view in enumerate(("whole", "key_feature"), start=1):
        F.add_asset(repo, n, view=view, taxon="TAX-0002", subject_common_name="Fixture unrelated subject", subject_scientific_or_material_name="Fixtura aliena")
    F.build_world(repo, "approved", fm_factory=F.species_dict, photo_ids=["PHO-0001", "PHO-0002"], scientific_name="Fixtura vera")
    return kit.verdict(repo, ctl)


@probe("P15", "species plate made only of views 'look_alike' + 'other' (no photo of the target organism)", "FR-012",
       expect=("SPECIES_PLATE_VIEWS", "SPECIES_PLATE_NO_WHOLE_OR_KEY"))
def p15(kit):
    ctl = kit.clean(species_world)
    species_world(kit.repo, views=("look_alike", "other"))
    return kit.verdict(kit.repo, ctl)


def relabel(rows):
    rows[0].update(caption="Fixture caption REWRITTEN after approval.", subject_common_name="Fixture different subject",
                   license="Fixture-Other-License-9.9", credited_photographer="Fixture Someone Else")


@probe("P16", "after approval + audits: manifest caption, subject names and license text rewritten", "FR-009, FR-010",
       expect=("APPROVAL_STALE", "IMAGE_AUDIT_STALE", "SAFETY_AUDIT_NOT_PASSING_OR_STALE"))
def p16(kit):
    species_world(kit.repo, status="published")
    ctl = kit.errors(kit.repo)
    F.edit_rows(kit.repo, "assets", relabel)
    return kit.verdict(kit.repo, ctl)


@probe("P17", "after approval + safety review: image file swapped, manifest hash updated, new image audit by role user", "FR-010",
       expect=("APPROVAL_STALE",))
def p17(kit):
    repo = kit.repo
    species_world(repo, status="published")
    ctl = kit.errors(repo)
    target = repo.path("assets/original_photos/PHO-0001.png")
    F.make_png(target, color=(10, 20, 30))
    new = sha256_file(target)
    F.edit_rows(repo, "assets", lambda rows: rows[0].update(sha256=new))
    F.add_image_audit(repo, "PHO-0001", provenance_checked=False, license_checked=False, identification_checked=False, caption_alt_checked=False,
                      reviewer_id="REV-0001", capacity="registrar", reviewed_on="2026-03-01")
    return kit.verdict(repo, ctl)


@probe("P32", "two species entries with the same scientific_name and the same photos", "FR-012", expect=("SPECIES_TAXON_DUPLICATE",))
def p32(kit):
    repo = kit.repo
    species_world(repo, status="verified")
    ctl = kit.errors(repo)
    F.write_entry(repo, F.species_dict(id="Z05-FIXTURE-002", status="verified", technical_reviewer="REV-0005", photo_ids=["PHO-0001", "PHO-0002"],
                                       title="Fixture entry two"))
    return kit.verdict(repo, ctl)


@probe("P34", "AI-generated illustration with blank subject fields and no overlay label", "FR-012", expect=("ILLUSTRATION_LABEL_MISSING",))
def p34(kit):
    ctl = kit.clean(lambda repo: [F.add_asset(repo, 1, kind="illustration", generation_method="ai_generated", subject_common_name=None),
                                  F.build_world(repo, "published", illustration_ids=["ILL-0001"])])
    repo = kit.repo
    F.add_asset(repo, 1, kind="illustration", generation_method="ai_generated", subject_common_name=None, overlay_label=None)
    F.build_world(repo, "published", illustration_ids=["ILL-0001"])
    return kit.verdict(repo, ctl)


@probe("P92", "verified_diagnostic photo with no scientific name, no locality, no observation date", "FR-012",
       expect=("DIAGNOSTIC_TAXON_MISSING", "DIAGNOSTIC_SPECIMEN_MISSING"))
def p92(kit):
    ctl = kit.clean(lambda repo: F.add_asset(repo, 1))
    F.add_asset(kit.repo, 1, subject_scientific_or_material_name=None, location_region=None, date_observed=None, taxon=None, specimen=None)
    return kit.verdict(kit.repo, ctl)


# ============================================================================== classification and traceability (FR-001)
@probe("P18", "Z05 entry typed 'general' with no hazard tags reaches published with one approval row and no safety review", "FR-001",
       expect=("SAFETY_TOPIC_UNCOVERED", "ENTRY_TYPE_NOT_ALLOWED_IN_ZONE", "IDENTIFICATION_CONTENT_REQUIRES_PROFILE_TYPE"),
       expect_text=("HZ-FORAGING-ID: no passing", "CLS-IDENTIFICATION: no passing", "CLS-HIGH-RISK: no passing"))
def p18(kit):
    """The original scenario (one approval, no safety review) is refused with SAFETY_AUDIT_MISSING (recorded in `without_any_review`). The scenario
    asserted adds the one review a plain entry would need, so what is left uncovered is exactly what the ZONE and the TYPE derive."""
    ctl = kit.clean(lambda repo: F.build_world(repo, "published", id="Z05-FIXTURE-001", zone="Z05", diagnostic_features=[], lookalikes_or_confusions=[]))
    repo = kit.repo
    path = F.build_world(repo, "published", id="Z05-FIXTURE-001", zone="Z05", entry_type="general", reviews=False)
    F.add_approval(repo, path)
    original = kit.errors(repo)
    F.add_safety(repo, path, ["CLS-SCREENING"], role="technical_reviewer")
    return kit.verdict(repo, ctl, without_any_review=original, safety_rows_in_the_original=0)


@probe("P18b", "Z10 (wilderness medicine) entry typed technical_procedure, no tags: published with no safety review", "FR-001",
       expect=("SAFETY_TOPIC_UNCOVERED", "ENTRY_TYPE_NOT_ALLOWED_IN_ZONE"), expect_text=("CLS-MEDICAL: no passing", "CLS-HIGH-RISK: no passing"))
def p18b(kit):
    """As P18: the original (no safety review at all) is recorded in `without_any_review`; the asserted scenario adds only the screening review."""
    ctl = kit.clean(lambda repo: F.build_world(repo, "published", fm_factory=F.medical_dict))
    repo = kit.repo
    path = F.build_world(repo, "published", id="Z10-FIXTURE-001", zone="Z10", reviews=False)
    F.add_approval(repo, path)
    original = kit.errors(repo)
    F.add_safety(repo, path, ["CLS-SCREENING"], role="technical_reviewer")
    return kit.verdict(repo, ctl, without_any_review=original, safety_rows_in_the_original=0)


@probe("P47", "untagged 'general' entry resting on a claim of type medical, risk critical", "FR-001", expect=("SAFETY_TOPIC_UNCOVERED",),
       expect_text=("CLS-MEDICAL: no passing", "CLS-HIGH-RISK: no passing"))
def p47(kit):
    F.build_world(kit.repo, "published", entry_type="general")
    ctl = kit.errors(kit.repo)
    F.edit_rows(kit.repo, "claims", lambda rows: rows[0].update(claim_type="medical", risk_level="critical"))
    return kit.verdict(kit.repo, ctl)


@probe("P46", "coverage row plans the entry with hazard_topics=[HZ-FORAGING-ID]; the entry carries no tags", "FR-001", expect=("SAFETY_TOPIC_UNCOVERED",),
       expect_text=("HZ-FORAGING-ID: no passing", "CLS-HIGH-RISK: no passing"))
def p46(kit):
    F.build_world(kit.repo, "published")
    ctl = kit.errors(kit.repo)
    F.append_row(kit.repo, "coverage", {"coverage_id": "COV-0001", "zone_id": "Z09", "topic": "Fixture topic", "entry_type": "species_profile",
                                        "risk_level": "critical", "planned_entry_id": "Z09-FIXTURE-001", "hazard_topics": [FORAGE],
                                        "source_coverage": "complete", "claim_coverage": "complete", "photo_coverage": "complete", "status": "published"})
    return kit.verdict(kit.repo, ctl)


@probe("P20", "'general' entry carrying approved medical/species safety fields: are they in the release PDF?", "FR-011",
       expect=("ENTRY_FIELD_NOT_FOR_TYPE",), no_control="the scenario is the entry itself; its release is refused before any PDF is built")
def p20(kit):
    repo = kit.repo
    F.add_asset(repo, 1)
    F.build_world(repo, "published", entry_type="general", photo_ids=["PHO-0001"], contraindications=["Fixture contraindication ZZQJ"],
                  emergency_evacuation_threshold="Fixture threshold XXQJ", positive_identification_warning="Fixture warning QQZJ",
                  identification_uncertainty="Fixture uncertainty UUZJ", processing_restrictions="Fixture restriction RRZJ")
    result = kit.verdict(repo)
    release_result, out, _ = release(kit, repo)
    result.info.update(release_ok=release_result.ok, release_errors=sorted(F.codes(release_result.findings)),
                       dist_written=(out / "editions").exists() or (out / "ACTIVE_RELEASE.json").exists())
    return result


# ============================================================================== claims and sources (FR-009)
@probe("P21", "after approval: claim text + locator rewritten, claim re-pointed, source edition changed", "FR-009",
       expect=("APPROVAL_STALE", "SAFETY_AUDIT_NOT_PASSING_OR_STALE"))
def p21(kit):
    haz(kit.repo, status="published")
    ctl = kit.errors(kit.repo)
    F.edit_rows(kit.repo, "claims", lambda rows: rows[0].update(claim_text="Fixture claim text REWRITTEN after verification.", source_locator="p. 999"))
    F.edit_rows(kit.repo, "sources", lambda rows: rows[0].update(edition_date="2031 (different edition)", url_or_local_origin="https://fixture-agency.gov/other-doc"))
    return kit.verdict(kit.repo, ctl)


@probe("P22a", "verified source with rights_status=rejected and provenance_class=third_party_mirror backs a published entry", "FR-009",
       expect=("REJECTED_SOURCE_BACKS_CLAIM",))
def p22a(kit):
    F.build_world(kit.repo, "published")
    ctl = kit.errors(kit.repo)
    F.edit_rows(kit.repo, "sources", lambda rows: rows[0].update(rights_status="rejected", provenance_class="third_party_mirror"))
    return kit.verdict(kit.repo, ctl)


@probe("P22b", "source with intended_use=background backs a verified claim and a published entry", "FR-009", expect=("BACKGROUND_SOURCE_BACKS_CLAIM",))
def p22b(kit):
    F.build_world(kit.repo, "published")
    ctl = kit.errors(kit.repo)
    F.edit_rows(kit.repo, "sources", lambda rows: rows[0].update(intended_use="background"))
    return kit.verdict(kit.repo, ctl)


@probe("P49", "verified source with edition_date=UNKNOWN, revision_date=UNKNOWN, no retrieval date, no hash, type website", "FR-009",
       expect=("SOURCE_EDITION_UNKNOWN", "ROW_SCHEMA"))
def p49(kit):
    F.build_world(kit.repo, "published")
    ctl = kit.errors(kit.repo)
    F.edit_rows(kit.repo, "sources", lambda rows: rows[0].update(edition_date="UNKNOWN", revision_date="UNKNOWN", retrieved_on=None, local_sha256=None,
                                                                 source_type="website", url_or_local_origin="https://fixture-blog.net/post"))
    return kit.verdict(kit.repo, ctl)


@probe("P60", "hazard-topic checklist changed AFTER the safety reviews were recorded", "FR-007 (digest of the checklist is part of the package)",
       expect=("APPROVAL_STALE", "SAFETY_AUDIT_NOT_PASSING_OR_STALE"))
def p60(kit):
    haz(kit.repo, status="published")
    ctl = kit.errors(kit.repo)
    target = kit.repo.path("schemas/hazard_topics.yaml")
    text = target.read_text(encoding="utf-8")
    marker = '      - "Claims cite current CDC/EPA guidance."\n'
    assert marker in text
    target.write_text(text.replace(marker, marker + '      - "Fixture NEW mandatory confirmation added after an incident."\n'), encoding="utf-8")
    return kit.verdict(kit.repo, ctl)


@probe("P93", "'verified' rung: technical_reviewer is any non-empty string, with no ledger row behind it", "FR-006", expect=("TECHNICAL_REVIEWER_NOT_REGISTERED",))
def p93(kit):
    """A well-formed id that nobody registered is refused by the registry; the literal 'x' of the original is refused earlier, by the schema."""
    path = F.build_world(kit.repo, "verified")
    ctl = kit.errors(kit.repo)
    F.rewrite_entry(path, lambda fm: fm.update(technical_reviewer="REV-0099"))
    result = kit.verdict(kit.repo, ctl)
    F.rewrite_entry(path, lambda fm: fm.update(technical_reviewer="x"))
    result.info["literal_x"] = kit.errors(kit.repo)
    return result


# ---- FR-008 (RUN-004): claim completeness
CLAIM_REFUSALS = ("ENTRY_CLAIMS_INSUFFICIENT", "ENTRY_CLAIM_TYPE_MISSING", "FIELD_CLAIM_MISSING")


@probe("P19a", "medical_guidance entry with ZERO claims (procedure [], claim_ids [], field_claims {}) reaches published", "FR-008", expect=CLAIM_REFUSALS)
def p19a(kit):
    ctl = kit.clean(lambda repo: F.build_world(repo, "published", fm_factory=F.medical_dict))  # the control: the same entry WITH its claims
    F.build_world(kit.repo, "published", fm_factory=F.medical_dict, procedure=[], claim_ids=[], field_claims={})
    return kit.verdict(kit.repo, ctl)


@probe("P19b", "species_profile with ZERO claims (claim_ids [], field_claims {}) reaches approved", "FR-008", expect=CLAIM_REFUSALS)
def p19b(kit):
    ctl = kit.clean(lambda repo: species_world(repo))
    species_world(kit.repo, claim_ids=[], field_claims={})
    return kit.verdict(kit.repo, ctl)


# ---- FR-021 (RUN-004): placeholder safety text
@probe("P27", "hazard-tagged verified entry: abort_if='N/A', verify='-', dangers=['n/a']", "FR-021", expect=("FIELD_NOT_USABLE",),
       expect_text=("step 1 abort_if", "step 1 verify", "dangers[0]", "NULL_LIKE", "NO_LETTERS_OR_DIGITS"))
def p27(kit):
    ctl = kit.clean(lambda repo: haz(repo, status="verified"))  # the control: the same entry with real text in those fields
    path = haz(kit.repo, status="verified", dangers=["n/a"])

    def fn(fm):
        for step in fm["procedure"]:
            step.update(abort_if="N/A", verify="-")
    F.rewrite_entry(path, fn)
    return kit.verdict(kit.repo, ctl)


# ---- FR-019 (RUN-004): measurement accuracy
LOOSE_PAIRS = [("1 mi", "2 km"), ("1 in", "3 cm"), ("2 lb", "1 kg"), ("3 ft", "1 m"), ("1 gal", "4 L"), ("1 qt", "1 L"), ("1 yd", "1 m")]
CLOSE_PAIRS = [("1 mi", "1.6 km"), ("1 in", "2.54 cm"), ("2 lb", "0.9 kg"), ("3 ft", "0.91 m"), ("1 gal", "3.8 L"), ("1 qt", "0.95 L"), ("1 yd", "0.91 m")]
P23_TABLE = LOOSE_PAIRS + [("18 °F", "10 °C"), ("18 °F difference", "10 °C difference"), ("1/4 in", "6.35 mm"), ("4-6 in", "102-152 mm"), ("8 fl oz", "237 ml"),
                           ("1 tsp", "5 ml"), ("15 psi", "103 kPa")]


def _unit_table_world(repo, pairs):
    path = F.build_world(repo, "verified")
    F.rewrite_entry(path, lambda fm: fm.update(dimension_unit_table=[
        {"quantity": f"Fixture length {n}", "us_customary": us, "metric": metric, "claim_id": "CLM-0001"} for n, (us, metric) in enumerate(pairs, start=1)]))
    return path


@probe("P23", "unit pairs the round-trip rule alone accepted: 1 mi / 2 km, 1 in / 3 cm, 2 lb / 1 kg, 3 ft / 1 m, 1 gal / 4 L, 1 qt / 1 L, 1 yd / 1 m", "FR-019",
       expect=("UNIT_INCONSISTENT",), expect_text=("differ by", "at most 1.00%"))
def p23(kit):
    from sfe.units import check_pair
    ctl = kit.clean(lambda repo: _unit_table_world(repo, CLOSE_PAIRS))  # the control: the same quantities stated closely enough
    _unit_table_world(kit.repo, LOOSE_PAIRS)
    result = kit.verdict(kit.repo, ctl)
    result.info.update({f"{us} / {me}": ("ACCEPTED" if not check_pair(us, me) else "REJECTED") for us, me in P23_TABLE})
    return result


@probe("P28", "step text carries an inconsistent inline conversion ('4 in (100 mm)') outside the unit table", "FR-019", expect=("UNIT_INCONSISTENT",),
       expect_text=("'4 in (100 mm)'", "converts to 102 mm"))
def p28(kit):
    def world(repo, text):
        path = F.build_world(repo, "verified")
        F.rewrite_entry(path, lambda fm: fm["procedure"][0].update(action=text))
    ctl = kit.clean(lambda repo: world(repo, "Fixture action using 4 in (101.6 mm) of fixture material."))
    world(kit.repo, "Fixture action using 4 in (100 mm) of fixture material.")
    return kit.verdict(kit.repo, ctl)


# ---- FR-017 (RUN-004): release state
@probe("P25", "release built; an approval withdrawal is then recorded; active release is withdrawn and archived edition stays intact", "FR-017",
       expect=("APPROVAL_NOT_CURRENT",), slow=True)
def p25(kit):
    from sfe import pdfbuild, release as release_mod
    repo = kit.repo
    path = haz(repo, status="published")
    out = Path(tempfile.mkdtemp(prefix="rel-", dir=kit.tmp))
    first = pdfbuild.build_release(repo, out_root=out, pin=F.pin_for(repo))
    before_verify = release_mod.verify_active(repo, out, pin=F.pin_for(repo))
    ctl = sorted(F.codes(first.findings)) + sorted(F.codes(before_verify.findings))
    if not (first.ok and before_verify.ok and first.edition_id):
        ctl.append("CONTROL_RELEASE_FAILED")
    archived_pdf = first.pdfs[0]
    archived_sha = sha256_file(archived_pdf)
    F.add_approval(repo, path, decision="withdrawn", decided_on="2026-03-01")
    pin2 = F.pin_for(repo)
    second = pdfbuild.build_release(repo, out_root=out, pin=pin2)
    pointer, ptr_problems = release_mod.read_pointer(out)
    after_verify = release_mod.verify_active(repo, out, pin=pin2)
    log_rows, log_problems = release_mod.read_log(out)
    stray_pdfs = [p.relative_to(out).as_posix() for p in sorted(out.rglob("*.pdf")) if "editions/" not in p.relative_to(out).as_posix()]
    state_ok = (
        not second.ok and not ptr_problems and not log_problems
        and pointer is not None and pointer.state == "withdrawn" and bool(pointer.reason)
        and pointer.edition_id == first.edition_id
        and not after_verify.ok and after_verify.state == "withdrawn"
        and not stray_pdfs and archived_pdf.is_file() and sha256_file(archived_pdf) == archived_sha
        and [r["event"] for r in log_rows] == ["promote", "auto_withdraw"]
    )
    errors = sorted(F.codes(second.findings))
    messages = sorted({f.message for f in second.findings if f.severity == "error"})
    return Result("BLOCKED" if state_ok else "ELIGIBLE", errors, control=ctl, messages=messages,
                  info={"first_edition": first.edition_id, "pointer_state": pointer.state if pointer else None,
                        "pointer_reason": pointer.reason if pointer else None, "verify_after_ok": after_verify.ok,
                        "stray_pdfs": stray_pdfs, "archive_intact": archived_pdf.is_file() and sha256_file(archived_pdf) == archived_sha,
                        "log_events": [r["event"] for r in log_rows]})


# ====================================================================================== OUT OF SCOPE: measured, never asserted
@probe("P29", "HZ-HARVEST-LEGAL entry: as_of_date=1990-01-01, region=['anywhere']", "FR-016 (open)", scope="out")
def p29(kit):
    F.build_world(kit.repo, "approved", hazard_tags=["HZ-HARVEST-LEGAL"], as_of_date="1990-01-01", region=["anywhere"])
    return kit.verdict(kit.repo)


def second_published_entry(repo):
    """A second published entry in the same zone, with its own approval and reviews, citing the same source."""
    fm = F.entry_dict(id="Z09-FIXTURE-002", title="Fixture entry two", status="published", technical_reviewer="REV-0005", editorial_reviewer="REV-0003",
                      approved_by_chatgpt=True)
    path = F.write_entry(repo, fm, "")
    F.set_zone(repo, "Z09", status="in_drafting", approved_cards=2)
    F.add_approval(repo, path)
    F.add_required_reviews(repo, path)
    return path


@probe("P26", "zone PDF with two published entries citing the same source: link/destination integrity", "FR-018 (open)", scope="out", slow=True)
def p26(kit):
    repo = kit.repo
    F.build_world(repo, "published")
    second_published_entry(repo)
    result = kit.verdict(repo)
    from sfe import pdfbuild
    captured: dict[str, str] = {}
    original = pdfbuild.parse_latex_log
    pdfbuild.parse_latex_log = lambda log, where, *a, **k: (captured.__setitem__(where, log), original(log, where, *a, **k))[1]
    try:
        out = Path(tempfile.mkdtemp(prefix="rel-", dir=kit.tmp))
        built = pdfbuild.build_release(repo, out_root=out, pin=F.pin_for(repo))
    finally:
        pdfbuild.parse_latex_log = original
    log = "\n".join(captured.values())
    result.info.update(release_ok=built.ok, release_errors=sorted(F.codes(built.findings)),
                       duplicate_destination_lines=sum(1 for line in log.splitlines() if "destination with the same identifier" in line))
    return result


@probe("P94", "two published entries, one zone PDF: where does the shared source link land?", "FR-018 (open)", scope="out", slow=True)
def p94(kit):
    repo = kit.repo
    F.build_world(repo, "published")
    second_published_entry(repo)
    built, _, _ = release(kit, repo)
    dests: list[str] = []
    if built.ok:
        listing = subprocess.run(["pdfinfo", "-dests", str(built.pdfs[0])], capture_output=True, text=True).stdout
        dests = [" ".join(line.split()) for line in listing.splitlines() if "sfe:src:" in line or ":sources" in line]
    return Result("INFO", [], info={"release_ok": built.ok, "release_errors": sorted(F.codes(built.findings)), "destinations": dests})


@probe("P70", "layout: 60 danger lines in one entry (minipage cannot break across pages)", "FR-020 (open)", scope="out", slow=True)
def p70(kit):
    F.build_world(kit.repo, "published", dangers=[f"Fixture danger boundary line number {n} with some fixture padding words." for n in range(1, 61)])
    result = kit.verdict(kit.repo)
    built, _, secs = release(kit, kit.repo)
    result.info.update(release_ok=built.ok, release_errors=sorted(F.codes(built.findings)), seconds=round(secs, 1))
    return result


@probe("P71", "layout: 40 procedure steps (breakable box) across pages", "FR-020 (open)", scope="out", slow=True)
def p71(kit):
    steps = [{"step": n, "action": f"Fixture action number {n} with fixture padding words to fill a line or two of the column.",
              "verify": f"Fixture verify {n}.", "abort_if": f"Fixture abort {n}.", "claim_ids": ["CLM-0001"]} for n in range(1, 41)]
    F.build_world(kit.repo, "published", procedure=steps)
    result = kit.verdict(kit.repo)
    built, _, secs = release(kit, kit.repo)
    result.info.update(release_ok=built.ok, release_errors=sorted(F.codes(built.findings)), seconds=round(secs, 1))
    if built.ok:
        text = pdf_text(built.pdfs[0])
        result.info["actions_present"] = sum(1 for n in range(1, 41) if f"action number {n} " in text)
    return result


# ---- FR-014 (RUN-004): EXIF/GPS stripped in publication derivatives and verified in PDF bytes
@probe("P72", "JPEG with EXIF (artist, description, GPS) embedded through a release build: stripped in PDF and verified", "FR-014",
       expect=("IMAGE_METADATA_IN_PDF",), slow=True)
def p72(kit):
    from PIL import Image
    from sfe import derive

    def build_clean(r):
        target = r.path("assets/original_photos/PHO-0001.jpg")
        target.parent.mkdir(parents=True, exist_ok=True)
        Image.new("RGB", (320, 240), (150, 160, 170)).save(target, format="JPEG")
        F.add_asset(r, 1, local_path="assets/original_photos/PHO-0001.jpg", write_file=False, sha256=sha256_file(target))
        F.build_world(r, "published", photo_ids=["PHO-0001"])
    ctl = kit.clean(build_clean)

    repo = kit.repo
    target = repo.path("assets/original_photos/PHO-0001.jpg")
    target.parent.mkdir(parents=True, exist_ok=True)
    image = Image.new("RGB", (320, 240), (150, 160, 170))
    exif = image.getexif()
    exif[0x013B] = "Fixture EXIF artist QQXIFARTIST"
    exif[0x010E] = "Fixture EXIF description QQXIFDESC"
    gps = exif.get_ifd(0x8825)
    gps[1], gps[2], gps[3], gps[4] = "N", (44.0, 58.0, 12.34), "W", (93.0, 15.0, 56.78)
    image.save(target, format="JPEG", exif=exif)
    orig_sha = sha256_file(target)
    F.add_asset(repo, 1, local_path="assets/original_photos/PHO-0001.jpg", write_file=False, sha256=orig_sha)
    F.build_world(repo, "published", photo_ids=["PHO-0001"])
    built, _, _ = release(kit, repo)

    exif_in_pdf = True
    extracted_clean = False
    if built.ok and built.pdfs:
        raw = built.pdfs[0].read_bytes()
        exif_in_pdf = any(s in raw for s in (b"QQXIFARTIST", b"QQXIFDESC", b"Exif\x00\x00"))
        ext = Path(tempfile.mkdtemp(prefix="pdfimg-", dir=kit.tmp))
        subprocess.run(["pdfimages", "-all", str(built.pdfs[0]), str(ext / "img")], check=True)
        extracted = [p for p in ext.iterdir() if p.is_file()]
        extracted_clean = bool(extracted) and all(derive.check_image_clean(p) == [] for p in extracted)

    # Also verify that if an unstripped PDF were ever produced, the post-build check rejects it with IMAGE_METADATA_IN_PDF
    leaked = Path(tempfile.mkdtemp(prefix="leak-", dir=kit.tmp)) / "leaked.pdf"
    if built.ok and built.pdfs:
        leaked.write_bytes(built.pdfs[0].read_bytes() + b"\n% Exif\x00\x00 Fixture EXIF artist QQXIFARTIST\n")
    else:
        leaked.write_bytes(b"%PDF-1.4\nExif\x00\x00Fixture EXIF artist QQXIFARTIST\n%%EOF\n")
    rec = derive.DerivativeRecord("PHO-0001", "assets/original_photos/PHO-0001.jpg", orig_sha, "PHO-0001.jpg",
                                  "0" * 64, "JPEG", 320, 240, derive.RECIPE_RASTER, False, ("Fixture EXIF artist QQXIFARTIST",))
    leak_findings = derive.check_pdf_image_metadata(leaked, [rec])
    leak_errors = sorted(F.codes(leak_findings))

    original_untouched = sha256_file(target) == orig_sha
    blocked = built.ok and (not exif_in_pdf) and extracted_clean and original_untouched and ("IMAGE_METADATA_IN_PDF" in leak_errors)
    return Result("BLOCKED" if blocked else "ELIGIBLE", leak_errors if blocked else [], control=ctl,
                  messages=[f.message for f in leak_findings if f.severity == "error"],
                  info={"release_ok": built.ok, "exif_artist_in_pdf_bytes": exif_in_pdf,
                        "extracted_images_clean": extracted_clean, "original_untouched": original_untouched})


# ---- FR-015 (RUN-004): controlled licence vocabulary and rights evidence
@probe("P90", "restrictive or unverified licence texts offered as an APPROVED licence", "FR-015",
       expect=("LICENSE_INCOMPATIBLE", "LICENSE_UNKNOWN", "LICENSE_AMBIGUOUS", "LICENSE_DERIVATIVES_FORBIDDEN"))
def p90(kit):
    ctl = kit.clean(lambda r: F.add_asset(r, 1, license="CC-BY-4.0"))
    out = {}
    all_errors: set[str] = set()
    all_messages: list[str] = []
    any_accepted = False
    for lic, deriv in [("All rights reserved", "none"), ("CC BY-NC-ND 4.0", "none"), ("Fair use", "resize and crop"),
                       ("Copyright Fixture Publisher", "unknown"), ("public domain", "resize and crop")]:
        repo = kit.new_repo()
        F.add_asset(repo, 1, license=lic, allowed_derivatives=deriv)
        found = validate_repo(repo.root)
        errs = sorted(F.codes(found))
        if not errs:
            any_accepted = True
        all_errors.update(errs)
        all_messages += [f.message for f in found if f.severity == "error"]
        out[f"{lic} / {deriv}"] = "ACCEPTED" if not errs else "REJECTED " + ",".join(errs)
    return Result("ELIGIBLE" if any_accepted else "BLOCKED", sorted(all_errors), control=ctl, messages=sorted(set(all_messages)), info=out)


@probe("P73", "release determinism: same published tree built twice", "(property kept)", scope="out", slow=True)
def p73(kit):
    repo = kit.repo
    F.add_asset(repo, 1)
    F.build_world(repo, "published", photo_ids=["PHO-0001"])
    a, _, _ = release(kit, repo)
    b, _, _ = release(kit, repo)
    return Result("INFO", [], info={"both_ok": a.ok and b.ok, "byte_identical": bool(a.ok and b.ok and sha256_file(a.pdfs[0]) == sha256_file(b.pdfs[0]))})


@probe("P91", "generation_method is self-declared (an AI image declared as a photograph is indistinguishable to the gate)", "FR-013 (open)", scope="out")
def p91(kit):
    out = {}
    for method in ("camera_photo", "scan"):
        repo = kit.new_repo()
        F.add_asset(repo, 1, generation_method=method)
        out[method] = "ACCEPTED" if not kit.errors(repo) else "REJECTED " + ",".join(kit.errors(repo))
    return Result("INFO", [], info=out)


def bulk(repo, n_entries: int, zone: str = "Z09", claims_per_entry: int = 3) -> None:
    """n published entries in one zone, each with its own claims, editorial approval and screening review. Neutral fixture text only.
    Built in bulk: ONE context yields every package, packet and ledger row (a context per entry would be quadratic)."""
    F.append_row(repo, "sources", F.source_row())
    claims, number = [], 0
    zdir = F.zone_dir(repo, zone)
    for i in range(1, n_entries + 1):
        ids = []
        for _ in range(claims_per_entry):
            number += 1
            ids.append(f"CLM-{number:04d}")
            claims.append(F.claim_row(claim_id=f"CLM-{number:04d}"))
        topic = "".join("ABCDEFGHIJ"[(i // 10 ** k) % 10] for k in range(4))
        fm = F.entry_dict(id=f"{zone}-FIX{topic}-{(i % 999) + 1:03d}", zone=zone, title=f"Fixture entry {i}", status="published", technical_reviewer="REV-0005",
                          editorial_reviewer="REV-0003", approved_by_chatgpt=True, claim_ids=ids,
                          procedure=[{"step": k, "action": f"Fixture action {k}.", "verify": f"Fixture verify {k}.", "abort_if": f"Fixture abort {k}.",
                                      "claim_ids": ids} for k in (1, 2)],
                          dimension_unit_table=[{"quantity": "Fixture length", "us_customary": "4 in", "metric": "101.6 mm", "claim_id": ids[0]}])
        repo.path(f"content/{zdir}/{fm['id']}.md").write_text("---\n" + yaml.safe_dump(fm, sort_keys=False, allow_unicode=True) + "---\n", encoding="utf-8", newline="\n")
    F.write_rows(repo, "claims", claims)
    F.set_zone(repo, zone, status="in_drafting", approved_cards=n_entries)
    ctx = F.context(repo)
    approvals, safety = [], []
    for k, entry in enumerate(ctx.entries, start=1):
        _subjects, package, digest = package_of(ctx, entry)
        rel, sha = package_mod.write_packet(repo.root, package, digest)
        base = {"entry_id": entry.fm["id"], "revision": entry.fm["revision"], "package_sha256": digest, "packet_path": rel, "packet_sha256": sha}
        approvals.append({"approval_id": f"APR-{k:04d}", **base, "decision": "approved", "reviewer_id": "REV-0003", "capacity": "chatgpt_editorial", "decided_on": D})
        safety.append({"audit_id": f"SAF-{k:04d}", **base, "subjects": ["CLS-SCREENING"], "decision": "pass", "reviewer_id": "REV-0005",
                       "capacity": "technical_reviewer", "reviewed_on": D})
    F.write_rows(repo, "approvals", approvals)
    F.write_rows(repo, "safety_audit", safety)


@probe("P80", "scale: validate published entries, claims, approvals and screening reviews", "(measured)", scope="out", slow=True)
def p80(kit, n: int = 1000):
    started = time.monotonic()
    bulk(kit.repo, n)
    built = time.monotonic() - started
    started = time.monotonic()
    result = kit.verdict(kit.repo)
    result.info.update(entries=n, build_fixture_seconds=round(built, 1), validate_seconds=round(time.monotonic() - started, 1))
    result.errors = result.errors[:5]
    return result


@probe("P81", "scale: one zone PDF with 120 published entries", "(measured)", scope="out", slow=True)
def p81(kit):
    bulk(kit.repo, 120)
    result = kit.verdict(kit.repo)
    built, out, secs = release(kit, kit.repo)
    result.errors = result.errors[:5]
    result.info.update(release_ok=built.ok, release_errors=sorted(F.codes(built.findings))[:6], seconds=round(secs, 1))
    if built.ok:
        meta = subprocess.run(["pdfinfo", str(built.pdfs[0])], capture_output=True, text=True).stdout
        result.info["pages"] = meta.split("Pages:")[1].split()[0]
        manifest = json.loads(built.pdfs[0].with_suffix(".build.json").read_text(encoding="utf-8"))
        result.info["render_check"] = manifest.get("render_check")
    return result


# ================================================================================================ script entry
def run_probe(p: Probe, tmp: Path) -> Result:
    try:
        return p.fn(Kit(tmp))
    except Exception as exc:  # a probe that cannot run is reported, never hidden
        return Result("PROBE-ERROR", [], info={"exception": f"{type(exc).__name__}: {exc}", "trace": traceback.format_exc().splitlines()[-4:]})


def main() -> None:
    tmp = Path(sys.argv[1]).resolve()
    only = set(sys.argv[2:])
    tmp.mkdir(parents=True, exist_ok=True)
    results = []
    for p in PROBES:
        if only and p.pid not in only:
            continue
        r = run_probe(p, tmp)
        judged = r.verdict
        if p.scope == "in" and r.verdict == "BLOCKED":
            ok = (set(p.expect) <= set(r.errors) and (not p.expect_any or bool(set(p.expect_any) & set(r.errors))) and (r.control in (None, []) or p.no_control)
                  and all(any(text in m for m in r.messages) for text in p.expect_text))
            judged = "BLOCKED" if ok else "BLOCKED-UNEXPECTEDLY"
        print(f"{p.pid:5s} {judged:11s} {p.title}")
        if r.errors:
            print(f"        errors:   {', '.join(r.errors)}")
        if r.control:
            print(f"        CONTROL NOT CLEAN: {', '.join(r.control)}")
        for key, value in r.info.items():
            print(f"        {key}: {json.dumps(value, ensure_ascii=False)}")
        results.append({"id": p.pid, "scope": p.scope, "finding": p.finding, "verdict": judged, "errors": r.errors, "control": r.control, "info": r.info})
    print(json.dumps({"results": results}, ensure_ascii=False), file=sys.stderr)


if __name__ == "__main__":
    main()
