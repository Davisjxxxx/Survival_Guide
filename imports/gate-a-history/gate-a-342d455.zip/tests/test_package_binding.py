"""An approval binds to the whole reviewed artifact, not to the entry text alone (FR-009, FR-010, FR-029).

At RUN-002 the approval hash covered the entry's own fields. The page also prints image captions and credits and rests on claims, sources and
records that could change after approval and leave it standing (Fable probes P16, P17, P21, P60). The package digest covers all of it;
a review packet stores what the reviewer was shown.
"""
from __future__ import annotations

import json

import pytest
import yaml

from factories import (
    add_asset, add_image_audit, append_row, build_world, claim_row, codes, context, edit_rows, entry_dict, entry_hash, entry_in, make_png, make_repo,
    packet_for, read_rows, register, rewrite_entry, source_row, write_entry, write_rows,
)
from sfe import package as package_mod
from sfe.cli import main
from sfe.common import sha256_file
from sfe.validate import package_of, validate_repo

STALE = {"APPROVAL_STALE", "SAFETY_AUDIT_NOT_PASSING_OR_STALE"}


def run(repo):
    return validate_repo(repo.root)


def world(repo, **over):
    """An approved entry that cites a photograph and an illustration, with approval, reviews and image audits: every part of the closure."""
    add_asset(repo, 1, role="supporting_habitat", view="habitat")  # a diagnostic photograph would bring in the identification subject
    add_asset(repo, 1, kind="illustration")
    path = build_world(repo, "approved", photo_ids=["PHO-0001"], illustration_ids=["ILL-0001"], **over)
    found = run(repo)
    assert codes(found) == set(), [str(f) for f in found]
    return path


def package(repo, path):
    ctx = context(repo)
    return package_of(ctx, entry_in(ctx, path))[1]


def digest(repo, path):
    ctx = context(repo)
    return package_of(ctx, entry_in(ctx, path))[2]


def is_stale(repo):
    return STALE <= codes(run(repo))


def sweep(repo, name, mutations, expect_stale=True):
    """Apply each mutation to register `name` in turn (restoring it after), and return the ones that did NOT behave as expected."""
    baseline = read_rows(repo, name)
    wrong = []
    for label, fn in mutations:
        edit_rows(repo, name, fn)
        if is_stale(repo) is not expect_stale:
            wrong.append(label)
        write_rows(repo, name, baseline)
        assert codes(run(repo)) == set(), f"restoring {label} did not restore eligibility"
    return wrong


# ====================================================================================== the digest
def test_the_digest_is_a_pure_function_of_the_closure(tmp_path):
    """Two repositories in different directories with the same inputs have the same digest: nothing local leaks in."""
    a = make_repo(tmp_path / "a")
    b = make_repo(tmp_path / "b")
    first, second = world(a), world(b)
    assert digest(a, first) == digest(b, second)
    assert digest(a, first) == digest(a, first)


def test_the_package_holds_the_whole_closure(repo):
    path = world(repo, hazard_tags=["HZ-WATER-POTABILITY"], as_of_date="2026-01-15")
    ctx = context(repo)
    subjects, package, _ = package_of(ctx, entry_in(ctx, path))
    assert package["package_version"] == package_mod.PACKAGE_VERSION and package["entry"]["revision"] == 1
    assert package["entry"]["front_matter"]["title"] == "Fixture entry one" and package["entry"]["body"] == "Fixture body text."
    assert set(package["claims"]) == {"CLM-0001"} and set(package["sources"]) == {"SRC-0001"}
    assert set(package["assets"]) == {"PHO-0001", "ILL-0001"}
    assert package["assets"]["PHO-0001"]["file_sha256_actual"] == sha256_file(repo.path("assets/original_photos/PHO-0001.png"))
    assert package["assets"]["PHO-0001"]["manifest"]["caption"] == "Fixture caption 1."
    assert set(package["classification"]["subjects"]) == {"HZ-WATER-POTABILITY"} == set(subjects)
    assert len(package["classification"]["subjects"]["HZ-WATER-POTABILITY"]["definition_sha256"]) == 64


def test_the_workflow_fields_are_not_part_of_the_digest_but_the_revision_is(repo):
    path = world(repo)
    before = digest(repo, path)
    rewrite_entry(path, lambda fm: fm.update(status="published", technical_reviewer="REV-0004"))
    assert digest(repo, path) == before
    rewrite_entry(path, lambda fm: fm.update(revision=2))
    assert digest(repo, path) != before


def test_moving_an_approved_entry_to_published_does_not_stale_it(repo):
    path = world(repo)
    rewrite_entry(path, lambda fm: fm.update(status="published"))
    assert not STALE & codes(run(repo))


def test_a_new_revision_needs_its_own_approval_and_reviews(repo):
    path = world(repo)
    rewrite_entry(path, lambda fm: fm.update(revision=2))
    found = codes(run(repo))
    assert {"APPROVAL_MISSING", "SAFETY_AUDIT_MISSING"} <= found


# ============================================================================== the entry, every field
ENTRY_CHANGES = [
    ("title", {"title": "Fixture entry, retitled"}), ("what_it_is", {"what_it_is": "Fixture what, changed."}),
    ("find_where", {"find_where": "Fixture where, changed."}), ("find_when", {"find_when": "Fixture when, changed."}),
    ("region", {"region": ["fixture_region", "another"]}), ("season", {"season": ["winter"]}),
    ("diagnostic_features", {"diagnostic_features": ["Fixture feature", "Another feature"]}),
    ("lookalikes_or_confusions", {"lookalikes_or_confusions": ["Another lookalike"]}), ("materials", {"materials": ["Another material"]}),
    ("conditions_and_limits", {"conditions_and_limits": ["Another limit"]}), ("dangers", {"dangers": ["Another danger boundary"]}),
    ("materials_tools", {"materials_tools": ["Another tool"]}), ("environmental_constraints", {"environmental_constraints": ["Another constraint"]}),
    ("inspection_acceptance_criteria", {"inspection_acceptance_criteria": ["Another criterion"]}),
    ("failure_modes", {"failure_modes": ["Another failure mode"]}), ("hazard_boundaries", {"hazard_boundaries": ["Another boundary"]}),
    ("as_of_date", {"as_of_date": "2026-01-16"}), ("source_ids", {"source_ids": ["SRC-0001", "SRC-0002"]}),
    ("hazard_tags", {"hazard_tags": ["HZ-WATER-POTABILITY"]}),
    ("dimension_unit_table", {"dimension_unit_table": [{"quantity": "Fixture length", "us_customary": "5 in", "metric": "127 mm", "claim_id": "CLM-0001"}]}),
]


def test_every_entry_field_is_bound(repo):
    path = world(repo)
    append_row(repo, "sources", source_row(source_id="SRC-0002"))
    text = path.read_bytes()
    wrong = []
    for label, change in ENTRY_CHANGES:
        rewrite_entry(path, lambda fm, change=change: fm.update(change))
        found = codes(run(repo))
        # a new hazard tag adds a subject that no review lists at all (uncovered); every other change leaves the reviews stale
        safety = "SAFETY_TOPIC_UNCOVERED" if label == "hazard_tags" else "SAFETY_AUDIT_NOT_PASSING_OR_STALE"
        if not {"APPROVAL_STALE", safety} <= found:
            wrong.append(label)
        path.write_bytes(text)
    assert wrong == [], f"changing these fields after approval left the approval standing: {wrong}"


def test_a_changed_procedure_step_is_bound(repo):
    path = world(repo)
    for key in ("action", "verify", "abort_if"):
        original = path.read_bytes()
        rewrite_entry(path, lambda fm, key=key: fm["procedure"][1].update({key: "Fixture step, changed."}))
        assert is_stale(repo), key
        path.write_bytes(original)


def test_the_body_is_bound(repo):
    path = world(repo)
    path.write_text(path.read_text(encoding="utf-8").replace("Fixture body text.", "Fixture body text, quietly rewritten."), encoding="utf-8")
    assert is_stale(repo)


def test_the_author_is_bound(repo):
    path = world(repo)
    register(repo, "REV-0010", "author", kind="human", name="Another Author")
    rewrite_entry(path, lambda fm: fm.update(authored_by="REV-0010"))
    assert is_stale(repo)


def test_formatting_noise_in_the_body_is_not_a_change(repo):
    path = world(repo)
    path.write_text(path.read_text(encoding="utf-8").replace("Fixture body text.\n", "\n\nFixture body text.   \n\n\n"), encoding="utf-8")
    assert codes(run(repo)) == set()


# ====================================================================== claims (FR-009, probe P21)
CLAIM_CHANGES = [
    ("claim_text", lambda r: r[0].update(claim_text="Fixture claim text REWRITTEN after verification.")),
    ("claim_type", lambda r: r[0].update(claim_type="measurement")), ("risk_level", lambda r: r[0].update(risk_level="medium")),
    ("source_locator", lambda r: r[0].update(source_locator="p. 999")), ("evidence_date", lambda r: r[0].update(evidence_date="2026-01-14")),
    ("verified_by", lambda r: r[0].update(verified_by="Someone Else")), ("verified_on", lambda r: r[0].update(verified_on="2026-01-14")),
    ("re-pointed to another source", lambda r: r[0].update(source_id="SRC-0002")),
]


def test_every_material_claim_column_is_bound(repo):
    world(repo)
    append_row(repo, "sources", source_row(source_id="SRC-0002"))
    assert sweep(repo, "claims", CLAIM_CHANGES) == []


def test_a_claim_cited_only_by_a_step_or_a_unit_row_is_bound_too(repo):
    path = build_world(repo, "draft")
    for number in (2, 3):
        append_row(repo, "claims", claim_row(claim_id=f"CLM-000{number}", status="UNVERIFIED", verified_by=None, verified_on=None, evidence_date=None))
    rewrite_entry(path, lambda fm: (fm["procedure"][0].update(claim_ids=["CLM-0001", "CLM-0002"]),
                                    fm["dimension_unit_table"][0].update(claim_id="CLM-0003")))
    before = digest(repo, path)
    for index in (1, 2):
        edit_rows(repo, "claims", lambda rows, index=index: rows[index].update(claim_text=f"Fixture claim {index}, rewritten."))
        assert digest(repo, path) != before, f"claim row {index + 1} is cited only by a step or a unit row and must still be bound"
        edit_rows(repo, "claims", lambda rows, index=index: rows[index].update(claim_text="Fixture claim text."))
    assert digest(repo, path) == before


def test_p21_changing_a_claim_after_approval_stales_it(repo):
    world(repo)
    edit_rows(repo, "claims", lambda r: r[0].update(claim_text="Fixture claim text REWRITTEN after verification.", source_locator="p. 999"))
    assert is_stale(repo)


def test_a_claim_nobody_cites_can_change_freely(repo):
    world(repo)
    append_row(repo, "claims", claim_row(claim_id="CLM-0002"))
    assert codes(run(repo)) == set()
    edit_rows(repo, "claims", lambda r: r[1].update(claim_text="Another claim, edited."))
    assert codes(run(repo)) == set()


def test_the_derived_and_editorial_claim_columns_are_not_material(repo):
    """entry_ids is derived (another entry citing the claim must not stale this one) and notes is editorial."""
    world(repo)
    edit_rows(repo, "claims", lambda r: r[0].update(entry_ids="Z09-FIXTURE-001|Z09-OTHER-001", notes="An editorial remark."))
    assert codes(run(repo)) == set()


# ===================================================================== sources (FR-009, probe P21)
SOURCE_CHANGES = [
    ("document_title", lambda r: r[0].update(document_title="Fixture source, retitled")),
    ("issuing_body_author", lambda r: r[0].update(issuing_body_author="Another Agency")),
    ("edition_date", lambda r: r[0].update(edition_date="2031 (different edition)")),
    ("url_or_local_origin", lambda r: r[0].update(url_or_local_origin="https://fixture-agency.gov/other-doc")),
    ("access_usage_rights", lambda r: r[0].update(access_usage_rights="Other terms")),
    ("revision_date", lambda r: r[0].update(revision_date="2022-02-02")), ("reliability_notes", lambda r: r[0].update(reliability_notes="Other notes")),
    ("sections_pages_relevant", lambda r: r[0].update(sections_pages_relevant="p. 9")), ("verified_by", lambda r: r[0].update(verified_by="Someone Else")),
    ("verified_on", lambda r: r[0].update(verified_on="2026-01-14")),
]


def test_every_source_column_is_bound(repo):
    world(repo)
    assert sweep(repo, "sources", SOURCE_CHANGES) == []


def test_a_source_nobody_cites_can_change_freely(repo):
    world(repo)
    append_row(repo, "sources", source_row(source_id="SRC-0002"))
    edit_rows(repo, "sources", lambda r: r[1].update(edition_date="1999"))
    assert codes(run(repo)) == set()


# ============================================================ images (FR-010, probes P16 and P17)
ASSET_CHANGES = [
    ("caption", {"caption": "Fixture caption, REWRITTEN after approval."}), ("alt_text", {"alt_text": "Another description."}),
    ("subject_common_name", {"subject_common_name": "Fixture different subject"}),
    ("subject_scientific_or_material_name", {"subject_scientific_or_material_name": "Fixtura mutata"}),
    ("view", {"view": "key_feature"}), ("provenance_url", {"provenance_url": "https://fixture-agency.gov/other-photo"}),
    ("organization", {"organization": "Another Agency"}), ("credited_photographer", {"credited_photographer": "Someone Else"}),
    ("license", {"license": "Fixture-Other-License-9.9"}), ("allowed_derivatives", {"allowed_derivatives": "none"}),
    ("acquired_on", {"acquired_on": "2026-01-10"}), ("location_region", {"location_region": "Fixture county"}),
    ("date_observed", {"date_observed": "2025-09"}), ("reviewer", {"reviewer": "Another Image Reviewer"}),
    ("reviewed_on", {"reviewed_on": "2026-01-14"}),
]


def test_p16_every_printed_or_evidentiary_image_field_is_bound(repo):
    world(repo)
    mutations = [(label, lambda rows, change=change: rows[0].update(change)) for label, change in ASSET_CHANGES]
    assert sweep(repo, "assets", mutations) == []


def test_the_illustrations_label_and_caption_are_bound_too(repo):
    world(repo)
    mutations = [("ILL caption", lambda r: r[1].update(caption="Another caption.")), ("ILL role", lambda r: r[1].update(role="decorative_only")),
                 ("ILL overlay", lambda r: r[1].update(overlay_label="ILLUSTRATION — NOT FOR SPECIES IDENTIFICATION (edited)"))]
    assert sweep(repo, "assets", mutations) == []


def test_changing_an_image_makes_its_audit_stale_as_well(repo):
    world(repo)
    edit_rows(repo, "assets", lambda r: r[0].update(caption="Fixture caption, REWRITTEN after approval."))
    assert "IMAGE_AUDIT_STALE" in codes(run(repo))


def test_p17_a_replaced_image_file_stales_the_entry_even_with_a_new_manifest_hash_and_a_fresh_audit(repo):
    """Swap the file, record its new hash, add a new audit by a qualified reviewer: the image side is now consistent, but the approval and the
    safety reviews were of a different picture and must be stale."""
    world(repo)
    target = repo.path("assets/original_photos/PHO-0001.png")
    make_png(target, color=(10, 20, 30))
    edit_rows(repo, "assets", lambda r: r[0].update(sha256=sha256_file(target)))
    add_image_audit(repo, "PHO-0001")
    found = codes(run(repo))
    assert "IMAGE_AUDIT_STALE" not in found and "ASSET_HASH_MISMATCH" not in found, "the image side is consistent again"
    assert STALE <= found, "but the entry's approval and reviews were of the old picture"


def test_a_replaced_file_with_the_old_manifest_hash_is_caught_twice(repo):
    world(repo)
    make_png(repo.path("assets/original_photos/PHO-0001.png"), color=(10, 20, 30))
    found = codes(run(repo))
    assert {"ASSET_HASH_MISMATCH"} <= found and is_stale(repo), "the package uses the REAL file hash, not the one the manifest claims"


def test_an_image_nobody_cites_can_change_freely(repo):
    world(repo)
    add_asset(repo, 2)
    edit_rows(repo, "assets", lambda r: r[2].update(caption="Another caption, edited."))
    assert "APPROVAL_STALE" not in codes(run(repo))


# ============================================================ the review checklist (FR-007, probe P60)
def test_p60_a_changed_checklist_stales_the_reviews_that_relied_on_it(repo):
    world(repo, hazard_tags=["HZ-WATER-POTABILITY"], as_of_date="2026-01-15")
    policy = repo.path("schemas/hazard_topics.yaml")
    data = yaml.safe_load(policy.read_text(encoding="utf-8"))
    for topic in data["topics"]:
        if topic["id"] == "HZ-WATER-POTABILITY":
            topic["reviewer_must_confirm"].append("Fixture NEW mandatory confirmation added after an incident.")
    policy.write_text(yaml.safe_dump(data, sort_keys=False), encoding="utf-8")
    assert is_stale(repo)


def test_a_changed_checklist_of_a_subject_the_entry_does_not_require_changes_nothing(repo):
    world(repo)
    policy = repo.path("schemas/hazard_topics.yaml")
    data = yaml.safe_load(policy.read_text(encoding="utf-8"))
    data["topics"][0]["reviewer_must_confirm"].append("Fixture NEW confirmation for an unrelated topic.")
    policy.write_text(yaml.safe_dump(data, sort_keys=False), encoding="utf-8")
    assert codes(run(repo)) == set()


def test_a_changed_screening_checklist_stales_a_screened_entry(repo):
    world(repo)
    policy = repo.path("schemas/classification_policy.yaml")
    data = yaml.safe_load(policy.read_text(encoding="utf-8"))
    data["subjects"]["CLS-SCREENING"]["reviewer_must_confirm"].append("Fixture NEW screening question.")
    policy.write_text(yaml.safe_dump(data, sort_keys=False), encoding="utf-8")
    assert is_stale(repo)


# ==================================================================== unresolved references
def test_resolving_a_reference_later_changes_the_digest(repo):
    path = build_world(repo, "draft", source_ids=["SRC-0001", "SRC-0002"])
    before = digest(repo, path)
    assert package(repo, path)["sources"]["SRC-0002"] == {"unresolved": True}
    append_row(repo, "sources", source_row(source_id="SRC-0002"))
    assert digest(repo, path) != before


# ================================================================================ review packets (FR-029)
def test_a_decision_without_a_packet_does_not_count(repo):
    world(repo)
    edit_rows(repo, "approvals", lambda r: r[0].update(packet_path="", packet_sha256=""))
    found = run(repo)
    assert "APPROVAL_NOT_CHATGPT_EDITORIAL" in codes(found)
    assert "REVIEW_PACKET_MISSING" in " ".join(f.message for f in found if f.code == "APPROVAL_NOT_CHATGPT_EDITORIAL")


def test_a_review_without_a_packet_does_not_count(repo):
    world(repo)
    edit_rows(repo, "safety_audit", lambda r: [row.update(packet_path="", packet_sha256="") for row in r])
    found = run(repo)
    assert "SAFETY_REVIEW_ROLE_MISSING" in codes(found)
    assert "REVIEW_PACKET_MISSING" in " ".join(f.message for f in found if f.code == "SAFETY_REVIEW_ROLE_MISSING")


def packet_file(repo):
    return repo.path(read_rows(repo, "approvals")[0]["packet_path"])


def test_a_deleted_packet_means_what_the_reviewer_saw_is_no_longer_on_record(repo):
    world(repo)
    packet_file(repo).unlink()
    assert "APPROVAL_NOT_CHATGPT_EDITORIAL" in codes(run(repo))


def test_an_edited_packet_is_detected_by_its_hash(repo):
    world(repo)
    file = packet_file(repo)
    file.write_text(file.read_text(encoding="utf-8").replace("Fixture entry one", "Fixture entry ONE"), encoding="utf-8")
    found = run(repo)
    assert "REVIEW_PACKET_HASH_MISMATCH" in " ".join(f.message for f in found if f.code == "APPROVAL_NOT_CHATGPT_EDITORIAL")


def test_a_packet_that_states_the_wrong_digest_is_rejected(repo):
    world(repo)
    file = packet_file(repo)
    document = json.loads(file.read_text(encoding="utf-8"))
    document["package_sha256"] = "0" * 64
    file.write_text(json.dumps(document, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    edit_rows(repo, "approvals", lambda r: r[0].update(packet_sha256=sha256_file(file)))
    assert "REVIEW_PACKET_DIGEST_MISMATCH" in " ".join(f.message for f in run(repo) if f.code == "APPROVAL_NOT_CHATGPT_EDITORIAL")


def test_a_packet_that_was_made_for_a_different_entry_is_rejected(repo):
    world(repo)
    other = write_entry(repo, entry_dict(id="Z09-OTHER-001", title="Fixture entry two", status="draft"))
    foreign = packet_for(repo, other)
    edit_rows(repo, "approvals", lambda r: r[0].update(packet_path=foreign["packet_path"], packet_sha256=foreign["packet_sha256"]))
    found = run(repo)
    assert "REVIEW_PACKET_DIGEST_MISMATCH" in " ".join(f.message for f in found if f.code == "APPROVAL_NOT_CHATGPT_EDITORIAL") or \
        "different entry" in " ".join(f.message for f in found if f.code == "APPROVAL_NOT_CHATGPT_EDITORIAL")


@pytest.mark.parametrize("bad_path", ["assets/original_photos/PHO-0001.png", "../packet.json", "reviews/evidence/x.json", "/etc/passwd"])
def test_a_packet_path_outside_reviews_packets_is_rejected(repo, bad_path):
    world(repo)
    edit_rows(repo, "approvals", lambda r: r[0].update(packet_path=bad_path))
    assert "APPROVAL_NOT_CHATGPT_EDITORIAL" in codes(run(repo))


def test_a_packet_that_is_not_json_is_rejected(repo):
    world(repo)
    file = packet_file(repo)
    file.write_text("not json at all", encoding="utf-8")
    edit_rows(repo, "approvals", lambda r: r[0].update(packet_sha256=sha256_file(file)))
    assert "APPROVAL_NOT_CHATGPT_EDITORIAL" in codes(run(repo))


def test_a_row_whose_digest_differs_from_its_packets_is_stale(repo):
    world(repo)
    edit_rows(repo, "approvals", lambda r: r[0].update(package_sha256="f" * 64))
    assert "APPROVAL_STALE" in codes(run(repo))


def test_the_old_packet_keeps_what_the_reviewer_saw_after_the_entry_changes(repo):
    """The point of storing packets: after the text changes, the record of what was approved is still there."""
    path = world(repo)
    old = json.loads(packet_file(repo).read_text(encoding="utf-8"))
    rewrite_entry(path, lambda fm: fm.update(title="Fixture entry, retitled after approval"))
    assert is_stale(repo)
    assert old["package"]["entry"]["front_matter"]["title"] == "Fixture entry one"
    assert packet_file(repo).is_file()


def test_writing_the_same_packet_twice_is_a_no_op_and_a_conflicting_file_is_refused(repo):
    path = world(repo)
    ctx = context(repo)
    _, package, digest_value = package_of(ctx, entry_in(ctx, path))
    first = package_mod.write_packet(repo.root, package, digest_value)
    assert package_mod.write_packet(repo.root, package, digest_value) == first
    repo.path(first[0]).write_text("tampered", encoding="utf-8")
    with pytest.raises(RuntimeError, match="already exists with different content"):
        package_mod.write_packet(repo.root, package, digest_value)


def test_the_packet_path_names_the_entry_revision_and_digest(repo):
    assert package_mod.packet_relpath("Z09-FIXTURE-001", 3, "ab" * 32) == "reviews/packets/Z09-FIXTURE-001/r3-abababababababab.json"


def test_the_packet_bytes_are_a_pure_function_of_the_package(repo):
    path = world(repo)
    ctx = context(repo)
    _, package, digest_value = package_of(ctx, entry_in(ctx, path))
    assert package_mod.packet_bytes(package, digest_value) == package_mod.packet_bytes(json.loads(json.dumps(package)), digest_value)


# ========================================================================================== the CLI
def test_the_packet_command_prints_the_digest_and_what_is_required(repo, capsys):
    path = world(repo)
    assert main(["--root", str(repo.root), "packet", "Z09-FIXTURE-001"]) == 0
    out = capsys.readouterr().out
    assert digest(repo, path) in out and "CLS-SCREENING: independent_screen" in out and "not written" in out


def test_the_packet_command_writes_on_request_and_is_idempotent(repo, capsys):
    path = world(repo)
    assert main(["--root", str(repo.root), "packet", "Z09-FIXTURE-001", "--write"]) == 0
    first = capsys.readouterr().out
    assert main(["--root", str(repo.root), "packet", "Z09-FIXTURE-001", "--write"]) == 0
    assert first == capsys.readouterr().out
    rel = next(line.split()[-1] for line in first.splitlines() if line.startswith("packet "))
    assert repo.path(rel).is_file() and digest(repo, path)[:16] in rel


def test_the_packet_command_refuses_an_unknown_entry(repo, capsys):
    assert main(["--root", str(repo.root), "packet", "Z09-NOPE-001"]) == 2
    assert "no entry" in capsys.readouterr().err


# ============================================================ the legacy content hash still exists
def test_the_text_only_content_hash_is_a_part_of_the_package_not_a_substitute(repo):
    """hash-entry prints the text-only hash. It is NOT what approvals bind to any more."""
    path = world(repo)
    h_text = entry_hash(path)
    edit_rows(repo, "claims", lambda r: r[0].update(claim_text="changed"))
    assert entry_hash(path) == h_text and is_stale(repo), "the text hash cannot see the claim change; the package digest can"
