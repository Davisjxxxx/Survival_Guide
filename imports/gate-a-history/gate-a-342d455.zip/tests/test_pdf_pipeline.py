"""The PDF pipeline end to end (needs pdflatex and poppler). Each build takes a few seconds."""
from __future__ import annotations

import json
import subprocess

import pytest
from PIL import Image

from factories import (
    REAL, add_asset, build_world, codes, context, edit_rows, entry_hash, make_repo, pin_for, species_dict,
)
from sfe import __version__, qa
from sfe.common import sha256_file
from sfe.pdfbuild import (
    FONT_FILES, LatexError, build_proof, build_release, check_reproducible, font_hashes, load_build_config, run_latex,
    toolchain_versions,
)
from sfe.registry import Repo
from sfe.texgen import printed_strings
from sfe.validate import package_of, validate_repo

pytestmark = pytest.mark.slow
COMMITTED = REAL / "proofs"


@pytest.fixture(scope="module")
def proof(tmp_path_factory):
    out = tmp_path_factory.mktemp("proof")
    result = build_proof(Repo(REAL), out_dir=out)
    assert result.ok, [str(f) for f in result.findings]
    return result, out


@pytest.fixture(scope="module")
def proof_a4(tmp_path_factory):
    out = tmp_path_factory.mktemp("proof_a4")
    return build_proof(Repo(REAL), profile="a4", out_dir=out, previews=False), out


def words_of(pdf):
    return " ".join(w["text"] for w in qa.words(pdf))


# ------------------------------------------------------------------- the specimen proof
def test_proof_passes_every_gate(proof):
    result, _ = proof
    assert result.ok and not [f for f in result.findings if f.severity == "error"]
    warnings = {f.code for f in result.findings if f.severity == "warning"}
    notes = {f.code for f in result.findings if f.severity == "info"}
    assert warnings <= {"PDF_UNTAGGED"}, "only the documented untagged-PDF limitation may remain as a warning"
    assert notes <= {"TOOLCHAIN_NOTE_EPSTOPDF_SHELL_ESCAPE"}, "the one documented benign toolchain note is the only note allowed (tests/test_toolchain_compat.py)"


def test_proof_is_one_letter_page_with_embedded_fonts(proof):
    pdf = proof[0].pdf
    info = qa.pdfinfo(pdf)
    assert info["Pages"] == "1" and "612 x 792 pts (letter)" in info["Page size"]
    assert "SPECIMEN" in info["Title"] and "DUMMY" in info["Title"]
    assert info["CreationDate"] == "2026-11-16T00:00:00Z"
    fonts = qa.pdffonts(pdf)
    assert fonts and all(f["emb"] == "yes" for f in fonts)
    assert info["Tagged"] == "no"  # honest record of the limitation: no kernel-level tagging in TeX Live 2023


def test_proof_is_unmistakably_dummy(proof):
    text = words_of(proof[0].pdf)
    for needle in ("SPECIMEN LAYOUT PROOF", "DUMMY CONTENT", "NOT FIELD GUIDANCE", "NOT FOR PUBLICATION", "PHOTO SLOT",
                   "no real photograph attached", "ILLUSTRATION — NOT FOR SPECIES IDENTIFICATION", "DUMMY-SRC-0000",
                   "reviewers named: 0", "approvals recorded: 0", "ICON KEY"):
        assert needle in text, needle
    assert text.count("[DUMMY]") >= 20


def test_proof_follows_the_standard_entry_order_and_has_bookmarks(proof):
    pdf = proof[0].pdf
    assert qa._check_order(qa.words(pdf), "proof") == []
    assert qa.outline(pdf) == ["Entry: [DUMMY] SPECIMEN LAYOUT ENTRY", "WHAT", "WHERE", "WHEN", "IDENTIFY", "MATERIALS",
                               "DIMENSIONS", "STEPS", "CHECK", "FAILURE / DANGER", "REGIONAL / LEGAL LIMITATIONS", "SOURCES"]


def test_proof_text_stays_inside_the_safe_margin(proof):
    assert qa._check_margins(qa.words(proof[0].pdf), "proof", 21.0) == []


def test_proof_manifest_is_complete_and_portable(proof):
    result, out = proof
    manifest = json.loads(result.manifest.read_text(encoding="utf-8"))
    assert manifest["dummy_content"] is True and manifest["environment"]["shell_escape"] is False
    assert manifest["environment"]["SOURCE_DATE_EPOCH"] == load_build_config(Repo(REAL))["source_date_epoch"]
    assert manifest["output"]["sha256"] == sha256_file(result.pdf) == result.sha256
    assert manifest["output"]["pages"] == 1 and manifest["qa"]["errors"] == 0 and manifest["qa"]["warnings"] == ["PDF_UNTAGGED"]
    for rel, digest in manifest["inputs"].items():
        assert sha256_file(REAL / rel) == digest, rel
    assert set(manifest["fonts_sha256"]) == set(FONT_FILES)
    blob = json.dumps(manifest)
    assert "/home/" not in blob and "/tmp/" not in blob, "the manifest must not leak local paths"


def _chroma(image):
    from PIL import ImageChops
    rgb = image.convert("RGB")
    channels = [rgb.getchannel(i) for i in range(3)]
    return max(ImageChops.difference(a, b).getextrema()[1] for a, b in ((channels[0], channels[1]), (channels[1], channels[2]), (channels[0], channels[2])))


def test_color_preview_uses_colour_and_grayscale_preview_is_a_faithful_gray_of_it(proof):
    """The pair only proves legibility without colour if the colour render really uses colour and the gray one drops exactly that."""
    from PIL import ImageChops, ImageStat
    _, out = proof
    color = Image.open(out / "previews/SPECIMEN_LAYOUT_PROOF_color.png").convert("RGB")
    gray = Image.open(out / "previews/SPECIMEN_LAYOUT_PROOF_gray.png")
    assert gray.mode == "L" and color.size == gray.size
    assert _chroma(color) >= 40, "the colour preview must actually contain colour"
    assert _chroma(gray) == 0
    low, high = gray.getextrema()
    assert low < 40 and high > 215, "the grayscale render must keep strong contrast"
    difference = ImageChops.difference(color.convert("L"), gray)
    assert difference.getextrema()[1] <= 3 and ImageStat.Stat(difference).mean[0] < 0.5, "same layout; only the colour is dropped"


def test_a4_profile_builds_and_passes(proof_a4):
    result, _ = proof_a4
    assert result.ok, [str(f) for f in result.findings]
    info = qa.pdfinfo(result.pdf)
    assert result.pdf.name == "SPECIMEN_LAYOUT_PROOF_A4.pdf" and info["Pages"] == "1" and "A4" in info["Page size"]


def test_builds_are_byte_reproducible_across_directories():
    ok, detail = check_reproducible(Repo(REAL))
    assert ok, detail


# ------------------------------------------------------------- the committed proof is current
def test_committed_proof_is_not_stale():
    """If a layout, schema or specimen input changes, the proof must be rebuilt (make proof) in the same change."""
    manifest = json.loads((COMMITTED / "SPECIMEN_LAYOUT_PROOF.build.json").read_text(encoding="utf-8"))
    for rel, digest in manifest["inputs"].items():
        assert sha256_file(REAL / rel) == digest, f"{rel} changed since the committed proof was built: run `make proof`"
    assert manifest["output"]["sha256"] == sha256_file(COMMITTED / "SPECIMEN_LAYOUT_PROOF.pdf")


def test_committed_proof_equals_a_fresh_build_when_the_toolchain_matches(proof):
    manifest = json.loads((COMMITTED / "SPECIMEN_LAYOUT_PROOF.build.json").read_text(encoding="utf-8"))
    now = toolchain_versions()
    if manifest["toolchain"]["pdflatex"] != now["pdflatex"] or manifest["fonts_sha256"] != font_hashes():
        pytest.skip(f"toolchain differs from the one recorded in the committed manifest ({manifest['toolchain']['pdflatex']} vs {now['pdflatex']}); "
                    "byte comparison is only meaningful on the recorded toolchain")
    assert proof[0].sha256 == sha256_file(COMMITTED / "SPECIMEN_LAYOUT_PROOF.pdf")


# --------------------------------------------------------------------------- the release
def published_world(tmp_path, **over):
    repo = make_repo(tmp_path)
    add_asset(repo, 1)
    add_asset(repo, 1, kind="illustration")
    return repo, build_world(repo, "published", photo_ids=["PHO-0001"], illustration_ids=["ILL-0001"], **over)


def test_release_builds_a_published_entry_with_real_images(tmp_path):
    """Replaces RUN-002's version (and updated in RUN-004 for the immutable edition archive, FR-017): every string the layout
    promises for the entry is looked up in the archived PDF here, independently of the pipeline's own check, and no flat copy sits in dist/zones."""
    repo, path = published_world(tmp_path)
    out = tmp_path / "out"
    result = build_release(repo, out_root=out, pin=pin_for(repo))
    assert result.ok and result.edition_id and result.state == "active", [str(f) for f in result.findings]
    ed_dir = out / "editions" / result.edition_id
    pdf = ed_dir / "zones/Z09_tools_construction.pdf"
    assert result.pdfs == [pdf] and pdf.is_file()
    assert not (out / "zones").exists(), "no flat copy may sit outside editions/"
    pointer = json.loads((out / "ACTIVE_RELEASE.json").read_text(encoding="utf-8"))
    assert pointer["state"] == "active" and pointer["edition_id"] == result.edition_id
    text = words_of(pdf)
    assert "Z09-FIXTURE-001" in text and "Fixture caption 1." in text
    assert "NOT FOR PUBLICATION" not in text and "DUMMY" not in text, "a release carries no proof furniture"
    listing = subprocess.run(["pdfimages", "-list", str(pdf)], capture_output=True, text=True, check=True).stdout.splitlines()[2:]
    assert len(listing) >= 2, "both the photo and the illustration must be embedded"
    ctx = context(repo)
    entry = ctx.entries[0]
    title = next(z["title"] for z in ctx.zones if z["id"] == "Z09")
    promised = printed_strings(entry.fm, assets=ctx.assets, sources=ctx.sources, zone_title=title)
    assert len(promised) >= 25
    assert qa.missing_text(pdf, promised, furniture=lambda page: (f"Survival Field Encyclopedia · Z09 · {title}", f"sfe {__version__} · page {page}")) == []
    manifest = json.loads((ed_dir / "zones/Z09_tools_construction.build.json").read_text(encoding="utf-8"))
    assert manifest["edition_id"] == result.edition_id
    assert manifest["entries"] == [{"id": "Z09-FIXTURE-001", "revision": 1, "content_sha256": entry_hash(path), "package_sha256": package_of(ctx, entry)[2]}]
    assert manifest["render_check"] == {"strings_promised": len(promised), "missing": 0}


def test_release_refuses_when_nothing_is_published(real_repo, tmp_path):
    result = build_release(real_repo, out_root=tmp_path / "out")
    assert not result.ok and "NO_PUBLISHED_ENTRIES" in codes(result.findings)
    assert not (tmp_path / "out").exists()


@pytest.mark.parametrize("status", ["draft", "researched", "verified", "approved"])
def test_release_never_includes_unpublished_entries(tmp_path, status):
    repo = make_repo(tmp_path)
    build_world(repo, status)
    result = build_release(repo, out_root=tmp_path / "out", pin=pin_for(repo))
    assert not result.ok and "NO_PUBLISHED_ENTRIES" in codes(result.findings)
    assert not (tmp_path / "out").exists()


def test_release_refuses_if_any_gate_fails(tmp_path):
    repo, _ = published_world(tmp_path)
    edit_rows(repo, "claims", lambda rows: rows[0].update(status="UNVERIFIED", verified_by="", verified_on="", evidence_date=""))
    result = build_release(repo, out_root=tmp_path / "out", pin=pin_for(repo))
    assert not result.ok and "CLAIM_NOT_VERIFIED" in codes(result.findings)
    assert not (tmp_path / "out").exists()


def test_release_refuses_entry_types_without_a_layout(tmp_path):
    repo = make_repo(tmp_path)
    add_asset(repo, 1, view="whole")
    add_asset(repo, 2, view="key_feature")
    # build_world supplies the editorial approval and both independent reviews, so every gate passes and the RENDER refusal is what is tested.
    build_world(repo, "published", fm_factory=species_dict, photo_ids=["PHO-0001", "PHO-0002"])
    assert not [f for f in validate_repo(repo.root) if f.severity == "error"]
    result = build_release(repo, out_root=tmp_path / "out", pin=pin_for(repo))
    assert not result.ok and "RENDER" in codes(result.findings)
    assert "not implemented" in next(f.message for f in result.findings if f.code == "RENDER")
    assert not (tmp_path / "out").exists()


# ---------------------------------------------------------------------------- safety
def test_hostile_text_is_rendered_literally_and_executes_nothing(tmp_path):
    victim = tmp_path / "pwned"
    hostile = rf"\input{{/etc/passwd}} \immediate\write18{{touch {victim}}} 100% $5 & #1 _x_ {{a}} ~ ^ [b] *s"
    repo, _ = published_world(tmp_path / "w", what_it_is=hostile)
    result = build_release(repo, out_root=tmp_path / "out", pin=pin_for(repo))
    assert result.ok, [str(f) for f in result.findings]
    assert r"\input{/etc/passwd}" in words_of(result.pdfs[0])
    assert not victim.exists()


def test_shell_escape_is_disabled(tmp_path):
    victim = tmp_path / "shell_escape_ran"
    (tmp_path / "main.tex").write_text(
        "\\documentclass{article}\\begin{document}\\immediate\\write18{touch " + str(victim) + "}x\\end{document}\n", encoding="utf-8")
    run_latex(tmp_path, epoch=1794787200)
    assert not victim.exists()


def test_tex_cannot_read_files_outside_its_tree(tmp_path):
    (tmp_path / "main.tex").write_text("\\documentclass{article}\\begin{document}\\input{/etc/passwd}\\end{document}\n", encoding="utf-8")
    with pytest.raises(LatexError):
        run_latex(tmp_path, epoch=1794787200)


def test_a_latex_failure_is_reported_not_swallowed(tmp_path):
    (tmp_path / "main.tex").write_text("\\documentclass{article}\\begin{document}\\undefinedcommand\\end{document}\n", encoding="utf-8")
    with pytest.raises(LatexError, match="Undefined control sequence"):
        run_latex(tmp_path, epoch=1794787200)


def test_latex_always_runs_with_the_hardened_flags_and_environment(tmp_path, monkeypatch):
    """Pins the security and reproducibility posture itself, so quietly dropping a flag fails a test."""
    calls = []

    class Done:
        returncode, stdout, stderr = 0, "", ""

    def fake_run(command, **kwargs):
        calls.append((command, kwargs))
        return Done()

    monkeypatch.setattr("sfe.pdfbuild.subprocess.run", fake_run)
    run_latex(tmp_path, epoch=1794787200)
    command, kwargs = calls[0]
    assert command[0] == "pdflatex" and "--no-shell-escape" in command and "-halt-on-error" in command
    assert "-jobname=sfe" in command
    env = kwargs["env"]
    assert env["SOURCE_DATE_EPOCH"] == "1794787200" and env["FORCE_SOURCE_DATE"] == "1" and env["TZ"] == "UTC"
    assert env["openin_any"] == "p" and env["openout_any"] == "p"
    assert kwargs["cwd"] == tmp_path


# ----------------------------------------------------------------- the QA gates can fail
def _base_expect(**over):
    config = load_build_config(Repo(REAL))
    letter = config["profiles"]["letter"]
    expect = {"pages": 1, "width_pt": letter["width_pt"], "height_pt": letter["height_pt"], "title_contains": ["SPECIMEN", "DUMMY"],
              "creation_iso": "2026-11-16T00:00:00Z", "required_text": ["PHOTO SLOT"], "min_outline": 11, "margin_pt": 21.0,
              "bookmark_labels": ["WHAT", "SOURCES"], "language": "en-US", "linked_text": ["DUMMY-SRC-0000"],
              "named_destinations": ["sfe:src:DUMMY-SRC-0000"]}
    expect.update(over)
    return expect


def test_proof_has_a_working_source_link(proof):
    pdf = proof[0].pdf
    assert qa.link_texts(pdf) == ["DUMMY-SRC-0000"], "the source chip must be a clickable link"
    assert "sfe:src:DUMMY-SRC-0000" in qa.named_destinations(pdf), "and its target (the legend entry) must exist"
    raw = pdf.read_bytes()
    assert b"/Lang(en-US)" in raw and b"/DisplayDocTitle true" in raw


def test_qa_accepts_the_correct_expectation(proof):
    findings, facts = qa.check_pdf(proof[0].pdf, expect=_base_expect())
    assert [f for f in findings if f.severity == "error"] == []
    assert facts["internal_links"] == 1 and facts["language"] == "en-US"


@pytest.mark.parametrize("override,code", [
    ({"linked_text": ["NOT-A-LINK"]}, "PDF_LINK_MISSING"),
    ({"named_destinations": ["sfe:src:NOPE"]}, "PDF_DESTINATION_MISSING"),
    ({"language": "fr-FR"}, "PDF_LANGUAGE"),
    ({"pages": 2}, "PDF_PAGE_COUNT"),
    ({"width_pt": 595.28, "height_pt": 841.89}, "PDF_PAGE_SIZE"),
    ({"title_contains": ["NOT IN THE TITLE"]}, "PDF_TITLE"),
    ({"creation_iso": "2000-01-01T00:00:00Z"}, "PDF_CREATION_DATE"),
    ({"required_text": ["TEXT THAT IS NOT THERE"]}, "PDF_REQUIRED_TEXT"),
    ({"min_outline": 99}, "PDF_BOOKMARKS_MISSING"),
    ({"bookmark_labels": ["NO SUCH BOOKMARK"]}, "PDF_BOOKMARK_LABEL"),
    ({"margin_pt": 200.0}, "PDF_OUTSIDE_MARGIN"),
])
def test_qa_gate_fails_closed(proof, override, code):
    findings, _ = qa.check_pdf(proof[0].pdf, expect=_base_expect(**override))
    assert code in {f.code for f in findings if f.severity == "error"}


def test_qa_rejects_a_colour_preview_that_has_no_colour(proof, tmp_path):
    """Feed the gray render back in as if it were the colour one: the gate must notice there is no colour."""
    from sfe.qa import _ink_stats
    gray = proof[1] / "previews/SPECIMEN_LAYOUT_PROOF_gray.png"
    assert _ink_stats(gray, edge_px=27)["max_chroma"] == 0
    color = proof[1] / "previews/SPECIMEN_LAYOUT_PROOF_color.png"
    assert _ink_stats(color, edge_px=27)["max_chroma"] >= 40
