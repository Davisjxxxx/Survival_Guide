"""The 16-zone structure, cross-checked against the supplied handoff, sprint plan and Excel tracker."""
from __future__ import annotations

import re

import openpyxl
import pytest

from factories import REAL, make_repo
from sfe.registry import README_MARKER, load_zones, scaffold, zone_readme

HANDOFF = REAL / "handoff/SURVIVAL_FIELD_ENCYCLOPEDIA_ASTRA_CLI_HANDOFF.md"
PLAN = REAL / "handoff/Survival_Field_Encyclopedia_Master_Sprint_Plan_v1.md"
TRACKER = REAL / "handoff/Survival_Field_Encyclopedia_Sprint_Tracker_v1.xlsx"


def table_rows(path, first_cell_pattern):
    rows = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.startswith("|"):
            cells = [c.strip() for c in line.strip().strip("|").split("|")]
            if re.fullmatch(first_cell_pattern, cells[0]):
                rows.append(cells)
    return rows


def norm(text):
    return re.sub(r"\s+", " ", text.lower().replace("&", "and").replace("-", "")).strip()


@pytest.fixture(scope="module")
def zones(real_repo):
    loaded, findings = load_zones(real_repo)
    assert findings == []
    return loaded


def test_there_are_sixteen_zones_in_order(zones):
    assert [z["id"] for z in zones] == [f"Z{n:02d}" for n in range(1, 17)]


def test_every_zone_has_a_directory_and_a_current_readme(real_repo, zones):
    for zone in zones:
        directory = real_repo.path(f"content/{zone['dir']}")
        assert directory.is_dir(), zone["dir"]
        readme = (directory / "README.md").read_text(encoding="utf-8")
        assert readme == zone_readme(zone), f"{zone['dir']}/README.md is out of sync; run python -m sfe scaffold"
        assert readme.startswith(README_MARKER)


def test_handoff_names_the_two_directories_we_copied_verbatim(zones):
    text = HANDOFF.read_text(encoding="utf-8")
    assert "Z01_fundamentals/" in text and "Z16_field_atlas" in text
    dirs = {z["id"]: z["dir"] for z in zones}
    assert dirs["Z01"] == "Z01_fundamentals" and dirs["Z16"] == "Z16_field_atlas"


def test_ids_titles_and_coverage_examples_match_handoff_section_2(zones):
    rows = {r[0]: r for r in table_rows(HANDOFF, r"Z\d\d")}
    assert sorted(rows) == [z["id"] for z in zones]
    for zone in zones:
        _id, title, examples = rows[zone["id"]]
        assert zone["title"] == title, zone["id"]
        assert zone["coverage_examples_handoff"] == examples, zone["id"]


def test_pages_priority_and_start_sprint_match_the_sprint_plan(zones):
    rows = {r[0]: r for r in table_rows(PLAN, r"Z\d\d")}
    assert sorted(rows) == [z["id"] for z in zones]
    for zone in zones:
        _id, subject, pages, priority, start = rows[zone["id"]]
        assert norm(subject) == norm(zone["title"]), zone["id"]
        assert (zone["draft_pages"], zone["priority"], zone["start_sprint"]) == (int(pages), priority, start), zone["id"]
    assert sum(z["draft_pages"] for z in zones) == 1016  # the plan's stated total


def test_registry_matches_the_excel_tracker(zones):
    sheet = openpyxl.load_workbook(TRACKER, data_only=True)["Zones"]
    rows = {str(r[0].value): [c.value for c in r] for r in sheet.iter_rows(min_row=2)}
    assert sorted(rows) == [z["id"] for z in zones]
    for zone in zones:
        _z, domain, pages, priority, sprint, subtopics, status, approved, *_ = rows[zone["id"]]
        assert norm(domain) == norm(zone["title"]), zone["id"]
        assert (zone["draft_pages"], zone["priority"], zone["start_sprint"]) == (pages, priority, sprint), zone["id"]
        assert zone["required_subtopics_tracker"] == subtopics, zone["id"]
        assert status == "Not started" and approved == "0 approved"


def test_zone_flags_come_from_handoff_section_2(zones):
    by_id = {z["id"]: z["flags"] for z in zones}
    assert by_id["Z05"] == {"standalone_major_zone": True}
    for zid in ("Z04", "Z08"):
        assert by_id[zid] == {"requires_midwest_field_examples": True, "requires_photographic_reference_specimens": True}
    assert all(flags == {} for zid, flags in by_id.items() if zid not in ("Z04", "Z05", "Z08"))
    text = HANDOFF.read_text(encoding="utf-8")
    assert "Z05 **must be a standalone major zone**" in text
    assert "Z08 and Z04 must include Midwest-relevant field examples and photographic reference specimens" in text


def test_z05_is_the_largest_zone(zones):
    largest = max(zones, key=lambda z: z["draft_pages"])
    assert largest["id"] == "Z05"


@pytest.mark.gate_a_snapshot
def test_no_zone_is_started_or_complete_at_gate_a(zones):
    assert {z["status"] for z in zones} == {"not_started"}
    assert {z["approved_cards"] for z in zones} == {0}


def test_scaffold_is_idempotent_and_never_overwrites_hand_edits(tmp_path):
    repo = make_repo(tmp_path)
    assert scaffold(repo) == []  # second run changes nothing
    readme = repo.path("content/Z03_fire/README.md")
    readme.write_text("# hand-written notes\n", encoding="utf-8")
    actions = scaffold(repo)
    assert any(a.startswith("SKIP content/Z03_fire/README.md") for a in actions)
    assert readme.read_text(encoding="utf-8") == "# hand-written notes\n"


def test_scaffold_refreshes_generated_readmes(tmp_path):
    repo = make_repo(tmp_path)
    readme = repo.path("content/Z04_water/README.md")
    readme.write_text(README_MARKER + "\nstale generated text\n", encoding="utf-8")
    assert any(a.startswith("update ") for a in scaffold(repo))
    assert "Draft page allocation" in readme.read_text(encoding="utf-8")
