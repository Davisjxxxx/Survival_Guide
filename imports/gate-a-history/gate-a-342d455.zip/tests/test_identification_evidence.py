"""Identification evidence (FR-012; Fable probes P13, P13b, P14, P15, P32, P34, P92).

At RUN-002 a species plate passed with two catalogue rows whose view labels differed, whatever the files showed. The replacement is a chain of
records, and each test below breaks one link and expects the build to refuse:

    taxon (research/taxa.csv)  ->  specimen (assets/specimens.csv, determined by a registered human specialist)  ->  photograph  ->  plate

Two limits are part of the contract and are asserted here so nobody mistakes the gate for more than it is: hashing detects identical bytes
only (a re-encoded copy is a different file), and nothing in the build claims that automated analysis establishes what an organism is.
"""
from __future__ import annotations

import hashlib
import shutil

import pytest
from PIL import Image

from factories import (
    CLS_SUBJECTS, HZ_TOPICS, REAL, add_approval, add_asset, add_image_audit, add_safety, add_specimen, add_taxon, append_row, build_world, codes, context,
    edit_rows, entry_in, read_rows, register, required_subjects, rewrite_entry, species_dict, specimen_row, taxon_row, write_entry,
)
from sfe.identification import kind_domain
from sfe.registry import REGISTERS
from sfe.validate import package_of, validate_repo

PLANT, FUNGUS = "ID-PLANT", "ID-FUNGUS"


def run(repo):
    return validate_repo(repo.root)


def plate(repo, views=("whole", "key_feature"), **over):
    """Diagnostic photographs of the fixture taxon, one per view, and the verified species profile that cites them."""
    for n, view in enumerate(views, start=1):
        add_asset(repo, n, view=view)
    return build_world(repo, over.pop("status", "verified"), fm_factory=species_dict, photo_ids=[f"PHO-{n:04d}" for n in range(1, len(views) + 1)], **over)


# ================================================================================ the shape of the records
def test_the_real_registers_are_header_only_and_match_their_schemas(real_repo):
    for name in ("taxa", "specimens"):
        header = real_repo.path(REGISTERS[name][0]).read_text(encoding="utf-8").splitlines()
        assert header == [",".join(real_repo.columns(name))]


def test_identification_domains_are_the_kinds_of_the_taxon_schema(real_repo):
    kinds = real_repo.schema("taxon.schema.json")["properties"]["kind"]["enum"]
    assert [kind_domain(k) for k in kinds] == ["ID-PLANT", "ID-FUNGUS", "ID-LICHEN", "ID-MINERAL", "ID-ROCK", "ID-MATERIAL"]


def test_a_clean_plate_passes(repo):
    plate(repo)
    assert codes(run(repo)) == set()


# ======================================================================================= the taxon register
@pytest.mark.parametrize("column", ["taxon_id", "scientific_name", "name_authority", "kind", "risk_tier"])
def test_a_taxon_row_needs_every_required_column(repo, column):
    append_row(repo, "taxa", taxon_row(**{column: None}))
    assert "ROW_SCHEMA" in codes(run(repo))


@pytest.mark.parametrize("column,value", [("taxon_id", "TAXON-1"), ("kind", "animal"), ("risk_tier", "D"), ("risk_tier", "a")])
def test_a_taxon_row_is_checked_against_its_schema(repo, column, value):
    append_row(repo, "taxa", taxon_row(**{column: value}))
    assert "ROW_SCHEMA" in codes(run(repo))


@pytest.mark.parametrize("duplicate", ["Fixture speciesus", "FIXTURE SPECIESUS", "  fixture   speciesus "])
def test_one_record_per_accepted_name(repo, duplicate):
    add_taxon(repo, 1)
    append_row(repo, "taxa", taxon_row(2, scientific_name=duplicate))
    assert "TAXON_NAME_DUPLICATE" in codes(run(repo))


def test_a_taxon_id_cannot_repeat(repo):
    add_taxon(repo, 1)
    append_row(repo, "taxa", taxon_row(1, scientific_name="Fixture other"))
    assert "DUPLICATE_ID" in codes(run(repo))


@pytest.mark.parametrize("tier", ["B", "C"])
def test_any_fungus_is_tier_a(repo, tier):
    append_row(repo, "taxa", taxon_row(1, kind="fungus", risk_tier=tier))
    assert "TAXON_TIER_TOO_LOW" in codes(run(repo))


def test_a_fungus_at_tier_a_and_a_plant_at_any_tier_are_accepted(repo):
    append_row(repo, "taxa", taxon_row(1, kind="fungus", risk_tier="A"))
    append_row(repo, "taxa", taxon_row(2, kind="plant", risk_tier="C"))
    assert codes(run(repo)) == set()


# =================================================================================== the specimen register
@pytest.mark.parametrize("column", ["specimen_id", "taxon_id", "observer", "observed_on", "locality", "habitat", "determination_basis", "determined_by",
                                    "determined_on"])
def test_a_specimen_record_needs_observer_date_locality_habitat_and_a_determination(repo, column):
    """P92: a diagnostic photograph with no place, no date and no name."""
    add_taxon(repo, 1)
    append_row(repo, "specimens", specimen_row(1, **{column: None}))
    assert "ROW_SCHEMA" in codes(run(repo))


def test_a_label_from_a_source_is_not_a_determination(repo):
    add_taxon(repo, 1)
    for basis in ("source_label", "uploader_label", "undetermined", "software"):
        append_row(repo, "specimens", specimen_row(1, determination_basis=basis))
        assert "ROW_SCHEMA" in codes(run(repo)), basis
        edit_rows(repo, "specimens", lambda rows: rows.clear())


def test_a_voucher_determination_needs_the_voucher_reference(repo):
    add_taxon(repo, 1)
    append_row(repo, "specimens", specimen_row(1, determination_basis="voucher_specimen"))
    assert "ROW_SCHEMA" in codes(run(repo))
    edit_rows(repo, "specimens", lambda rows: rows[0].update(voucher_reference="Fixture Herbarium 2026-0001"))
    assert codes(run(repo)) == set()


def test_a_specimen_of_an_unknown_taxon_is_refused(repo):
    append_row(repo, "specimens", specimen_row(1, taxon_id="TAX-0042"))
    assert "SPECIMEN_TAXON_UNKNOWN" in codes(run(repo))


def test_a_determination_cannot_precede_the_observation(repo):
    add_taxon(repo, 1)
    append_row(repo, "specimens", specimen_row(1, observed_on="2026-01-15", determined_on="2026-01-14"))
    assert "SPECIMEN_DETERMINED_BEFORE_OBSERVED" in codes(run(repo))


def test_a_specimen_dates_must_be_real_calendar_dates(repo):
    add_taxon(repo, 1)
    append_row(repo, "specimens", specimen_row(1, observed_on="2026-02-31"))
    assert "DATE_INVALID" in codes(run(repo))


# ----------------------------------------------------------------------------------------- the determiner
@pytest.mark.parametrize("determiner,why", [
    ("REV-0099", "not registered"), ("REV-0005", "a technical reviewer"), ("REV-0003", "an AI model"), ("REV-0006", "an adjudicator"),
    ("REV-0002", "an author"), ("REV-0001", "the owner"),
])
def test_only_a_registered_human_domain_expert_can_determine(repo, determiner, why):
    add_taxon(repo, 1)
    append_row(repo, "specimens", specimen_row(1, determined_by=determiner))
    assert "SPECIMEN_DETERMINER_NOT_QUALIFIED" in codes(run(repo)), why


def test_a_determiner_registered_for_another_kind_is_refused(repo):
    register(repo, "REV-0007", "external_sme", kind="human", name="Fixture Mycologist", domains=[FUNGUS], evidence="Fixture credential")
    add_taxon(repo, 1)
    append_row(repo, "specimens", specimen_row(1, determined_by="REV-0007"))
    assert "SPECIMEN_DETERMINER_DOMAIN_NOT_COVERED" in codes(run(repo))


def test_the_same_determiner_is_accepted_for_the_kind_they_hold(repo):
    register(repo, "REV-0007", "external_sme", kind="human", name="Fixture Botanist", domains=[PLANT], evidence="Fixture credential")
    add_taxon(repo, 1)
    append_row(repo, "specimens", specimen_row(1, determined_by="REV-0007"))
    assert codes(run(repo)) == set()


def test_a_revoked_determiner_never_counts(repo):
    add_taxon(repo, 1)
    append_row(repo, "specimens", specimen_row(1))
    assert codes(run(repo)) == set()
    register(repo, "REV-0004", "external_sme", kind="human", name="Fixture Domain Expert", action="revoke", revokes="REG-0004")
    assert "SPECIMEN_DETERMINER_NOT_QUALIFIED" in codes(run(repo))


def test_a_determination_made_before_the_registration_began_does_not_count(repo):
    add_taxon(repo, 1)
    append_row(repo, "specimens", specimen_row(1, observed_on="2025-12-01", determined_on="2025-12-02"))
    assert "SPECIMEN_DETERMINER_NOT_QUALIFIED" in codes(run(repo))


def test_the_photographer_cannot_determine_their_own_photograph(repo):
    add_asset(repo, 1, credited_photographer="  fixture DOMAIN   expert ")  # REV-0004's registered name, differently spaced and cased
    assert "SPECIMEN_DETERMINER_IS_PHOTOGRAPHER" in codes(run(repo))


def test_a_determiner_who_did_not_take_the_photograph_is_accepted(repo):
    add_asset(repo, 1, credited_photographer="Fixture Photographer")
    assert codes(run(repo)) == set()


def test_the_author_cannot_determine_what_their_profile_cites(repo):
    register(repo, "REV-0004", "author", kind="human", name="Fixture Domain Expert")
    plate(repo, authored_by="REV-0004", technical_reviewer="REV-0005")
    assert "SPECIMEN_DETERMINER_IS_AUTHOR" in codes(run(repo))


# ----------------------------------------------------------------------------------------- the basis
def test_tier_a_needs_a_voucher_or_a_physical_examination(repo):
    add_taxon(repo, 1, risk_tier="A")
    append_row(repo, "specimens", specimen_row(1, determination_basis="photograph_review"))
    assert "SPECIMEN_BASIS_BELOW_TIER" in codes(run(repo))


@pytest.mark.parametrize("tier", ["B", "C"])
def test_a_lower_tier_may_be_determined_from_photographs(repo, tier):
    add_taxon(repo, 1, risk_tier=tier)
    append_row(repo, "specimens", specimen_row(1, determination_basis="photograph_review"))
    assert codes(run(repo)) == set()


@pytest.mark.parametrize("basis,extra", [("physical_examination", {}), ("voucher_specimen", {"voucher_reference": "Fixture Herbarium 2026-0001"})])
def test_tier_a_accepts_the_two_strong_bases(repo, basis, extra):
    add_taxon(repo, 1, risk_tier="A")
    append_row(repo, "specimens", specimen_row(1, determination_basis=basis, **extra))
    assert codes(run(repo)) == set()


# ========================================================================================= asset links
def test_an_image_cannot_name_a_taxon_that_is_not_registered(repo):
    add_asset(repo, 1, taxon="TAX-0001")
    edit_rows(repo, "assets", lambda rows: rows[0].update(taxon_id="TAX-0042"))
    assert "ASSET_TAXON_UNKNOWN" in codes(run(repo))


def test_an_image_cannot_name_a_specimen_that_is_not_recorded(repo):
    add_asset(repo, 1)
    edit_rows(repo, "assets", lambda rows: rows[0].update(specimen_id="SPM-0042"))
    assert "ASSET_SPECIMEN_UNKNOWN" in codes(run(repo))


def test_a_specimen_without_a_taxon_is_refused(repo):
    add_asset(repo, 1)
    edit_rows(repo, "assets", lambda rows: rows[0].update(taxon_id=""))
    assert {"ASSET_SPECIMEN_WITHOUT_TAXON", "DIAGNOSTIC_TAXON_MISSING"} <= codes(run(repo))


def test_one_image_is_evidence_for_one_taxon(repo):
    """The image names one taxon but its specimen was determined to be another."""
    add_asset(repo, 1)
    add_taxon(repo, 2)
    edit_rows(repo, "assets", lambda rows: rows[0].update(taxon_id="TAX-0002"))
    assert "ASSET_SPECIMEN_TAXON_MISMATCH" in codes(run(repo))


def test_a_typed_scientific_name_may_not_contradict_the_taxon(repo):
    add_asset(repo, 1, subject_scientific_or_material_name="Fixtura aliena")
    assert "ASSET_SCIENTIFIC_NAME_CONFLICT" in codes(run(repo))


@pytest.mark.parametrize("typed", ["Fixture speciesus", "fixture SPECIESUS", " Fixture  speciesus ", ""])
def test_a_typed_scientific_name_that_matches_or_is_absent_is_fine(repo, typed):
    add_asset(repo, 1, subject_scientific_or_material_name=typed or None)
    assert codes(run(repo)) == set()


def test_p92_a_diagnostic_photograph_with_no_taxon_and_no_specimen_is_refused(repo):
    add_asset(repo, 1, taxon=None, specimen=None)
    assert {"DIAGNOSTIC_TAXON_MISSING", "DIAGNOSTIC_SPECIMEN_MISSING"} <= codes(run(repo))


@pytest.mark.parametrize("missing", ["taxon", "specimen"])
def test_a_diagnostic_photograph_needs_both_links(repo, missing):
    add_asset(repo, 1, **{missing: None})
    assert {"taxon": "DIAGNOSTIC_TAXON_MISSING", "specimen": "DIAGNOSTIC_SPECIMEN_MISSING"}[missing] in codes(run(repo))


def test_other_images_need_no_evidence_records(repo):
    add_asset(repo, 1, role="supporting_habitat", view="habitat")
    add_asset(repo, 1, kind="illustration")
    assert codes(run(repo)) == set()


def test_an_illustration_may_name_its_taxon_without_a_specimen(repo):
    add_asset(repo, 1, kind="illustration", taxon="TAX-0001")
    assert codes(run(repo)) == set()


@pytest.mark.parametrize("method", ["ai_generated", "rendered", "vector_drawing"])
def test_a_generated_image_is_never_an_image_of_a_specimen(repo, method):
    add_asset(repo, 1, kind="illustration", generation_method=method, taxon="TAX-0001", specimen="SPM-0001")
    assert "ASSET_GENERATED_HAS_SPECIMEN" in codes(run(repo))


def test_ai_generated_imagery_cannot_be_diagnostic_evidence(repo):
    add_asset(repo, 1, generation_method="ai_generated")
    assert "AI_ASSET_AS_EVIDENCE" in codes(run(repo))


def test_p34_an_ai_illustration_with_blank_subject_fields_still_needs_the_label(repo):
    """RUN-002 asked for the label only when the image named a subject, so blanking the subject removed the requirement."""
    add_asset(repo, 1, kind="illustration", generation_method="ai_generated", subject_common_name=None, overlay_label=None)
    assert "ILLUSTRATION_LABEL_MISSING" in codes(run(repo))


def test_a_labelled_ai_illustration_is_accepted(repo):
    add_asset(repo, 1, kind="illustration", generation_method="ai_generated", subject_common_name=None)
    assert codes(run(repo)) == set()


# ===================================================================================== one file, one row
def test_p13_one_photograph_catalogued_twice_is_not_two_views(repo):
    first = add_asset(repo, 1, view="whole")
    add_asset(repo, 2, view="key_feature", local_path=first["local_path"], write_file=False, sha256=first["sha256"])
    build_world(repo, "verified", fm_factory=species_dict, photo_ids=["PHO-0001", "PHO-0002"])
    assert {"ASSET_DUPLICATE_BYTES", "ASSET_DUPLICATE_PATH", "SPECIES_PLATE_VIEWS"} <= codes(run(repo))


def test_p13b_one_file_cannot_be_evidence_for_two_taxa(repo):
    first = add_asset(repo, 1, view="whole", subject_scientific_or_material_name="Fixture speciesus")
    add_asset(repo, 2, view="whole", local_path=first["local_path"], write_file=False, sha256=first["sha256"], taxon="TAX-0002",
              subject_scientific_or_material_name="Fixture alius 2")
    assert "ASSET_DUPLICATE_BYTES" in codes(run(repo))


def test_two_files_with_the_same_content_are_one_file_whatever_their_names(repo):
    add_asset(repo, 1, view="whole")
    shutil.copyfile(repo.path("assets/original_photos/PHO-0001.png"), repo.path("assets/original_photos/PHO-0002.png"))
    row = read_rows(repo, "assets")[0]
    add_asset(repo, 2, view="key_feature", write_file=False, sha256=row["sha256"])
    assert "ASSET_DUPLICATE_BYTES" in codes(run(repo))


def test_the_hash_is_taken_from_the_file_not_from_the_manifests_own_claim(repo):
    """Two identical files whose manifest rows state different hashes: the second row lies about its file, and the lie does not hide the duplicate."""
    add_asset(repo, 1, view="whole")
    shutil.copyfile(repo.path("assets/original_photos/PHO-0001.png"), repo.path("assets/original_photos/PHO-0002.png"))
    add_asset(repo, 2, view="key_feature", write_file=False, sha256="0" * 64)
    found = codes(run(repo))
    assert {"ASSET_HASH_MISMATCH", "ASSET_DUPLICATE_BYTES"} <= found


def test_a_photograph_and_an_illustration_cannot_share_a_file(repo):
    add_asset(repo, 1, view="whole")
    shutil.copyfile(repo.path("assets/original_photos/PHO-0001.png"), repo.path("assets/diagrams/ILL-0001.png"))
    add_asset(repo, 1, kind="illustration", write_file=False, sha256=read_rows(repo, "assets")[0]["sha256"])
    assert "ASSET_DUPLICATE_BYTES" in codes(run(repo))


def test_rows_with_no_file_and_no_hash_do_not_collide(repo):
    """A quarantined placeholder has nothing to hash: two of them are not duplicates of each other."""
    for n in (1, 2):
        add_asset(repo, n, license_status="pending", local_path=None, sha256=None, license=None, allowed_derivatives=None, acquired_on=None, reviewer=None,
                  reviewed_on=None, review_status="unreviewed", role="decorative_only", taxon=None, specimen=None, write_file=False, audited=False)
    assert not {c for c in codes(run(repo)) if c.startswith("ASSET_DUPLICATE")}


def test_hashing_detects_identical_bytes_only(repo):
    """Documented limit (FR-012, still open): a re-encoded or cropped copy is a different file and is NOT detected here. Nothing in the build
    claims otherwise, and nothing claims that image analysis establishes what an organism is."""
    add_asset(repo, 1, view="whole")
    original = repo.path("assets/original_photos/PHO-0001.png")
    reencoded = repo.path("assets/original_photos/PHO-0002.png")
    with Image.open(original) as image:
        image.save(reencoded, format="PNG", compress_level=1, pnginfo=None, optimize=False, dpi=(300, 300))  # the same pixels, different bytes
    assert original.read_bytes() != reencoded.read_bytes()
    add_asset(repo, 2, view="key_feature", write_file=False, sha256=hashlib.sha256(reencoded.read_bytes()).hexdigest(),
              local_path="assets/original_photos/PHO-0002.png")
    assert not {c for c in codes(run(repo)) if c.startswith("ASSET_DUPLICATE")}


# ======================================================================================== the species plate
def test_p14_target_views_of_another_taxon_do_not_make_a_plate(repo):
    for n, view in enumerate(("whole", "key_feature"), start=1):
        add_asset(repo, n, view=view, taxon="TAX-0002")
    build_world(repo, "verified", fm_factory=species_dict, photo_ids=["PHO-0001", "PHO-0002"])
    found = codes(run(repo))
    assert {"SPECIES_PLATE_TAXON_MISMATCH", "SPECIES_PLATE_VIEWS"} <= found


def test_p14_an_entry_whose_name_contradicts_its_taxon_is_refused(repo):
    plate(repo, scientific_name="Fixtura vera")
    assert "SPECIES_SCIENTIFIC_NAME_CONFLICT" in codes(run(repo))


def test_p15_look_alike_and_other_views_are_no_plate(repo):
    for n, view in enumerate(("look_alike", "other"), start=1):
        add_asset(repo, n, view=view)
    build_world(repo, "verified", fm_factory=species_dict, photo_ids=["PHO-0001", "PHO-0002"])
    assert {"SPECIES_PLATE_VIEWS", "SPECIES_PLATE_NO_WHOLE_OR_KEY"} <= codes(run(repo))


def test_a_look_alike_view_never_counts_toward_the_minimum(repo):
    plate(repo, views=("whole", "look_alike"))
    assert "SPECIES_PLATE_VIEWS" in codes(run(repo))


def test_a_look_alike_view_beside_a_complete_plate_is_welcome(repo):
    plate(repo, views=("whole", "key_feature", "look_alike"))
    assert codes(run(repo)) == set()


def test_a_look_alike_view_must_name_a_different_taxon(repo):
    for n, view in enumerate(("whole", "key_feature", "look_alike"), start=1):
        add_asset(repo, n, view=view, taxon="TAX-0001")
    build_world(repo, "verified", fm_factory=species_dict, photo_ids=["PHO-0001", "PHO-0002", "PHO-0003"])
    assert "SPECIES_PLATE_LOOKALIKE_IS_TARGET" in codes(run(repo))


def test_a_look_alike_view_must_name_its_own_taxon(repo):
    add_asset(repo, 1, view="whole")
    add_asset(repo, 2, view="key_feature")
    add_asset(repo, 3, view="look_alike", taxon=None, specimen=None)
    build_world(repo, "verified", fm_factory=species_dict, photo_ids=["PHO-0001", "PHO-0002", "PHO-0003"])
    assert "SPECIES_PLATE_LOOKALIKE_TAXON_MISSING" in codes(run(repo))


@pytest.mark.parametrize("views", [("whole", "whole"), ("key_feature", "key_feature"), ("whole",), ("habitat", "other")])
def test_two_distinct_target_views_one_of_them_whole_or_key_feature(repo, views):
    plate(repo, views=views)
    assert {"SPECIES_PLATE_VIEWS", "SPECIES_PLATE_NO_WHOLE_OR_KEY"} & codes(run(repo))


@pytest.mark.parametrize("views", [("whole", "key_feature"), ("whole", "habitat"), ("key_feature", "other"), ("whole", "key_feature", "habitat")])
def test_complete_plates_pass(repo, views):
    plate(repo, views=views)
    assert codes(run(repo)) == set()


def test_supporting_photographs_do_not_count_toward_the_plate(repo):
    add_asset(repo, 1, view="whole")
    add_asset(repo, 2, view="habitat", role="supporting_habitat")
    build_world(repo, "verified", fm_factory=species_dict, photo_ids=["PHO-0001", "PHO-0002"])
    assert "SPECIES_PLATE_VIEWS" in codes(run(repo))


def test_a_species_profile_needs_a_taxon(repo):
    plate(repo, taxon_id=None)
    assert "SPECIES_TAXON_MISSING" in codes(run(repo))


def test_a_species_profile_cannot_name_an_unregistered_taxon(repo):
    path = plate(repo)
    rewrite_entry(path, lambda fm: fm.update(taxon_id="TAX-0042"))
    assert "SPECIES_TAXON_UNKNOWN" in codes(run(repo))


def test_p32_one_species_profile_per_taxon(repo):
    plate(repo)
    write_entry(repo, species_dict(id="Z05-FIXTURE-002", title="Fixture entry two", status="verified", technical_reviewer="REV-0005",
                                   photo_ids=["PHO-0001", "PHO-0002"]))
    found = [f for f in run(repo) if f.code == "SPECIES_TAXON_DUPLICATE"]
    assert {f.where.split("/")[-1] for f in found} == {"Z05-FIXTURE-001.md", "Z05-FIXTURE-002.md"}


def test_a_taxon_id_on_another_entry_type_is_an_error(repo):
    build_world(repo, "draft", taxon_id="TAX-0001")
    assert "ENTRY_FIELD_NOT_FOR_TYPE" in codes(run(repo))


def test_the_species_rules_wait_for_the_verified_rung(repo):
    add_asset(repo, 1, view="whole")
    build_world(repo, "researched", fm_factory=species_dict, photo_ids=["PHO-0001"])
    assert not {c for c in codes(run(repo)) if c.startswith("SPECIES_PLATE")}


# ==================================================================================== who may review it
def approved_species(repo, *, reviews: bool):
    return plate(repo, status="approved", reviews=reviews, technical_reviewer="REV-0005")


def review_by(repo, path, sme):
    """Every review the species entry needs, the domain expert's rows by `sme` (a registry id with external_sme capacity)."""
    add_approval(repo, path)
    ctx = context(repo)
    subjects = [s for s in required_subjects(ctx, entry_in(ctx, path)) if s != "CLS-SCREENING"]
    add_safety(repo, path, subjects, role="external_sme", reviewer_id=sme, capacity="external_sme")
    add_safety(repo, path, subjects, role="chatgpt_editorial", reviewer="Fixture ChatGPT Editorial")


def sme(repo, reviewer_id, name, kinds):
    register(repo, reviewer_id, "external_sme", kind="human", name=name, domains=HZ_TOPICS + CLS_SUBJECTS + list(kinds), evidence="Fixture credential")


def test_an_identification_review_needs_the_organism_groups_domain(repo):
    """Domain 'HZ-FORAGING-ID' alone is not enough: a reviewer of mushrooms cannot clear a plant profile."""
    sme(repo, "REV-0007", "Fixture Mycologist", [FUNGUS])
    path = approved_species(repo, reviews=False)
    review_by(repo, path, "REV-0007")
    found = [f for f in run(repo) if f.code == "SAFETY_REVIEW_ROLE_MISSING"]
    assert found and "not registered for ID-PLANT" in " ".join(f.message for f in found)


def test_an_identification_review_by_a_reviewer_of_the_right_group_passes(repo):
    sme(repo, "REV-0007", "Fixture Botanist", [PLANT])
    path = approved_species(repo, reviews=False)
    review_by(repo, path, "REV-0007")
    assert codes(run(repo)) == set()


def test_the_reviewer_needs_the_look_alikes_group_too(repo):
    add_taxon(repo, 2, kind="fungus")
    sme(repo, "REV-0007", "Fixture Botanist", [PLANT])
    for n, view in enumerate(("whole", "key_feature", "look_alike"), start=1):
        add_asset(repo, n, view=view)
    path = build_world(repo, "approved", fm_factory=species_dict, photo_ids=["PHO-0001", "PHO-0002", "PHO-0003"], reviews=False, technical_reviewer="REV-0005")
    review_by(repo, path, "REV-0007")
    assert "not registered for ID-FUNGUS" in " ".join(f.message for f in run(repo) if f.code == "SAFETY_REVIEW_ROLE_MISSING")


def test_a_look_alike_of_another_kind_is_covered_by_a_reviewer_of_both(repo):
    add_taxon(repo, 2, kind="fungus")
    sme(repo, "REV-0008", "Fixture Both", [PLANT, FUNGUS])
    for n, view in enumerate(("whole", "key_feature", "look_alike"), start=1):
        add_asset(repo, n, view=view)
    path = build_world(repo, "approved", fm_factory=species_dict, photo_ids=["PHO-0001", "PHO-0002", "PHO-0003"], reviews=False, technical_reviewer="REV-0005")
    review_by(repo, path, "REV-0008")
    assert codes(run(repo)) == set()


def test_an_image_audit_of_a_diagnostic_photograph_needs_the_organism_groups_domain(repo):
    sme(repo, "REV-0007", "Fixture Mycologist", [FUNGUS])
    add_asset(repo, 1, view="whole", audited=False)
    add_asset(repo, 2, view="key_feature", audited=False)
    for n in (1, 2):
        add_image_audit(repo, f"PHO-{n:04d}", reviewer_id="REV-0007", capacity="external_sme")
    build_world(repo, "approved", fm_factory=species_dict, photo_ids=["PHO-0001", "PHO-0002"], technical_reviewer="REV-0005")
    assert "IMAGE_AUDIT_REVIEWER_INVALID" in codes(run(repo))


def test_a_registered_identification_domain_must_be_a_real_group(repo):
    register(repo, "REV-0007", "external_sme", kind="human", name="Fixture Typist", domains=["ID-FUNGI"], evidence="Fixture credential")
    assert "REGISTRY_DOMAIN_UNKNOWN" in codes(run(repo))


# ========================================================================= bound to what the reviewers saw
@pytest.mark.parametrize("register_name,key,value", [("taxa", "name_authority", "A different nomenclature"), ("taxa", "risk_tier", "B"),
                                                     ("specimens", "locality", "Somewhere else"), ("specimens", "habitat", "Another habitat"),
                                                     ("specimens", "notes", "Added after approval")])
def test_changing_the_taxon_or_the_specimen_after_review_stales_the_approval(repo, register_name, key, value):
    approved_species(repo, reviews=True)
    assert codes(run(repo)) == set()
    edit_rows(repo, register_name, lambda rows: rows[0].update({key: value}))
    assert "APPROVAL_STALE" in codes(run(repo))


def test_a_changed_specimen_stales_the_image_audit_of_its_photograph(repo):
    approved_species(repo, reviews=True)
    edit_rows(repo, "specimens", lambda rows: rows[0].update(locality="Somewhere else"))
    assert "IMAGE_AUDIT_STALE" in codes(run(repo))


def test_an_uncited_taxon_or_specimen_can_change_without_staling_anything(repo):
    approved_species(repo, reviews=True)
    add_taxon(repo, 9, scientific_name="Fixture unrelated")
    add_specimen(repo, 9, taxon_id="TAX-0009")
    assert codes(run(repo)) == set()
    edit_rows(repo, "taxa", lambda rows: [r.update(notes="edited") for r in rows if r["taxon_id"] == "TAX-0009"])
    edit_rows(repo, "specimens", lambda rows: [r.update(locality="elsewhere") for r in rows if r["specimen_id"] == "SPM-0009"])
    assert codes(run(repo)) == set()


def test_the_packet_shown_to_the_reviewers_contains_the_taxon_and_the_specimen(repo):
    path = approved_species(repo, reviews=True)
    ctx = context(repo)
    _, package, _ = package_of(ctx, entry_in(ctx, path))
    assert set(package["taxa"]) == {"TAX-0001"} and set(package["specimens"]) == {"SPM-0001", "SPM-0002"}
    assert package["taxa"]["TAX-0001"]["scientific_name"] == "Fixture speciesus" and package["specimens"]["SPM-0001"]["determined_by"] == "REV-0004"


def test_the_real_repository_still_validates_with_the_new_registers():
    assert [f for f in validate_repo(REAL) if f.severity == "error"] == []
