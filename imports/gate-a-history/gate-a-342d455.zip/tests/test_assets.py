"""Image provenance and licensing checks (handoff sections 4 and 10)."""
from __future__ import annotations

import pytest

from factories import add_asset, append_row, asset_row, codes, make_png, read_rows
from sfe.assets import REQUIRED_LABEL, safe_relative_path, valid_http_url
from sfe.validate import validate_repo


def run(repo):
    return validate_repo(repo.root)


def test_clean_photo_and_illustration_pass(repo):
    add_asset(repo, 1)
    add_asset(repo, 1, kind="illustration")
    assert codes(run(repo)) == set(), [str(f) for f in run(repo)]


@pytest.mark.parametrize("license_text", ["public domain", "Public-Domain", "FREE", "n/a", "unknown", "found online", "royalty-free", "ok"])
def test_ambiguous_licenses_are_rejected(repo, license_text):
    add_asset(repo, 1, license=license_text)
    assert "LICENSE_AMBIGUOUS" in codes(run(repo))


def test_specific_license_is_accepted(repo):
    add_asset(repo, 1, license="US-Gov-PD (17 USC 105)")
    assert "LICENSE_AMBIGUOUS" not in codes(run(repo))


def test_approved_asset_needs_provenance_url_or_permission(repo):
    add_asset(repo, 1, provenance_url=None, permission_reference=None)
    assert "ASSET_PROVENANCE_INCOMPLETE" in codes(run(repo))


def test_explicit_permission_is_an_acceptable_provenance(repo):
    add_asset(repo, 1, provenance_url=None, permission_reference="Written permission 2026-01-10, Fixture Owner")
    assert "ASSET_PROVENANCE_INCOMPLETE" not in codes(run(repo))


def test_approved_asset_needs_a_credit(repo):
    add_asset(repo, 1, organization=None, credited_photographer=None)
    assert "ASSET_PROVENANCE_INCOMPLETE" in codes(run(repo))


def test_license_approval_needs_review_approval(repo):
    add_asset(repo, 1, review_status="unreviewed")
    assert "ASSET_REVIEW_NOT_APPROVED" in codes(run(repo))


def test_changed_file_is_detected(repo):
    add_asset(repo, 1)
    make_png(repo.path("assets/original_photos/PHO-0001.png"), color=(1, 2, 3))
    assert "ASSET_HASH_MISMATCH" in codes(run(repo))


def test_approved_asset_must_have_its_file(repo):
    add_asset(repo, 1, write_file=False, sha256="a" * 64)
    assert "ASSET_FILE_MISSING" in codes(run(repo))


def test_approved_photo_must_live_in_original_photos(repo):
    add_asset(repo, 1, local_path="assets/diagrams/PHO-0001.png")
    assert "ASSET_WRONG_DIRECTORY" in codes(run(repo))


def test_unverified_files_must_be_quarantined(repo):
    pending = dict(license_status="pending", license=None, allowed_derivatives=None, acquired_on=None, reviewer=None,
                   reviewed_on=None, review_status="unreviewed")
    add_asset(repo, 1, **pending)  # default path is assets/original_photos/: wrong for an unverified file
    assert "ASSET_NOT_QUARANTINED" in codes(run(repo))


def test_quarantined_unverified_file_is_fine(repo):
    add_asset(repo, 1, license_status="pending", local_path="assets/rejected_unverified/PHO-0001.png", license=None,
              allowed_derivatives=None, acquired_on=None, reviewer=None, reviewed_on=None, review_status="unreviewed", audited=False)
    assert codes(run(repo)) == set()


def test_orphan_file_in_an_approved_directory(repo):
    make_png(repo.path("assets/original_photos/stray.png"))
    assert "ORPHAN_ASSET_FILE" in codes(run(repo))


@pytest.mark.parametrize("path", ["assets/../escape.png", "/etc/passwd", "elsewhere/PHO-0001.png"])
def test_unsafe_paths_are_rejected(repo, path):
    add_asset(repo, 1, write_file=False, local_path=path, sha256="a" * 64)
    assert "ASSET_PATH_UNSAFE" in codes(run(repo))


def test_ai_generated_image_can_never_be_a_photo(repo):
    add_asset(repo, 1, generation_method="ai_generated", role="decorative_only", view=None)
    assert {"AI_ASSET_NOT_ILLUSTRATION", "PHOTO_KIND_GENERATED"} <= codes(run(repo))


def test_ai_generated_image_can_never_be_identification_evidence(repo):
    add_asset(repo, 1, kind="illustration", generation_method="ai_generated", role="verified_diagnostic", view="whole")
    assert {"AI_ASSET_AS_EVIDENCE", "DIAGNOSTIC_NOT_REAL_PHOTO"} <= codes(run(repo))


def test_generated_subject_illustration_needs_the_label(repo):
    add_asset(repo, 1, kind="illustration", overlay_label=None)
    assert "ILLUSTRATION_LABEL_MISSING" in codes(run(repo))


def test_wrong_label_text_is_rejected(repo):
    add_asset(repo, 1, kind="illustration", overlay_label="Illustration")
    assert "ILLUSTRATION_LABEL_MISSING" in codes(run(repo))


def test_label_text_is_exactly_the_handoff_wording():
    assert REQUIRED_LABEL == "ILLUSTRATION — NOT FOR SPECIES IDENTIFICATION"


def test_illustration_without_a_subject_needs_no_label(repo):
    add_asset(repo, 1, kind="illustration", subject_common_name=None, overlay_label=None)
    assert "ILLUSTRATION_LABEL_MISSING" not in codes(run(repo))


def test_diagnostic_photo_needs_a_subject(repo):
    add_asset(repo, 1, subject_common_name=None)
    assert "DIAGNOSTIC_SUBJECT_MISSING" in codes(run(repo))


def test_diagnostic_photo_needs_a_view(repo):
    add_asset(repo, 1, view=None)
    assert "DIAGNOSTIC_VIEW_MISSING" in codes(run(repo))


def test_illustration_cannot_be_diagnostic(repo):
    add_asset(repo, 1, kind="illustration", role="verified_diagnostic", view="whole")
    assert "DIAGNOSTIC_NOT_REAL_PHOTO" in codes(run(repo))


def test_asset_id_prefix_must_match_kind(repo):
    add_asset(repo, 1, asset_id="ILL-0001")
    assert "ID_KIND_MISMATCH" in codes(run(repo))


def test_invalid_provenance_url(repo):
    add_asset(repo, 1, provenance_url="not a url")
    assert "PROVENANCE_URL_INVALID" in codes(run(repo))


@pytest.mark.parametrize("url", ["https://example.invalid/x", "https://example.com/x"])
def test_placeholder_provenance_hosts_are_rejected_in_real_manifest(repo, url):
    add_asset(repo, 1, provenance_url=url)
    assert "PROVENANCE_URL_PLACEHOLDER" in codes(run(repo))


def test_unrecognized_host_warns_but_does_not_fail(repo):
    add_asset(repo, 1, provenance_url="https://photos.fixture-blog.net/p/1")
    findings = run(repo)
    assert "PROVENANCE_HOST_UNRECOGNIZED" in codes(findings, "warning")
    assert codes(findings) == set()


@pytest.mark.parametrize("host", ["https://www.usda.gov/x", "https://commons.wikimedia.org/wiki/File:X", "https://www.dnr.state.mn.us/x",
                                  "https://herbarium.umn.edu/x"])
def test_recommended_hosts_do_not_warn(repo, host):
    add_asset(repo, 1, provenance_url=host)
    assert "PROVENANCE_HOST_UNRECOGNIZED" not in codes(run(repo), "warning")


def test_reviewed_asset_needs_caption_and_alt_text(repo):
    add_asset(repo, 1, caption=None, alt_text=None)
    assert {"ASSET_CAPTION_MISSING", "ASSET_ALT_TEXT_MISSING"} <= codes(run(repo))


def test_unsupported_extension_warns(repo):
    add_asset(repo, 1, local_path="assets/original_photos/PHO-0001.bmp")
    assert "ASSET_EXTENSION_UNSUPPORTED" in codes(run(repo), "warning")


def test_dummy_ids_are_rejected_in_the_real_manifest(repo):
    add_asset(repo, 1, asset_id="DUMMY-PHO-0001", local_path="assets/original_photos/DUMMY-PHO-0001.png")
    assert "DUMMY_ID_IN_REAL_REGISTER" in codes(run(repo))


def test_helpers():
    assert valid_http_url("https://x.gov/a") and not valid_http_url("ftp://x") and not valid_http_url("https://x y")
    assert safe_relative_path("assets/a.png") and not safe_relative_path("../a") and not safe_relative_path("/a") and not safe_relative_path("")
