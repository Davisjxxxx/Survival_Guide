"""Claim completeness (FABLE-REVIEW-001 FR-008, RUN-004).

At RUN-003 a medical entry with no claim at all reached `published` (P19a) and a species profile with no claim reached `approved` (P19b), because
a claim was required only for a procedure step or a unit-table row. These tests pin the claim policy (`schemas/claim_policy.yaml`): the minimum
evidence by entry type, the claim types an entry must cite, the claim types that may back each safety-bearing field, and the statements that need
a claim whatever the entry type. Every refusal is asserted from a world proved clean first (a counterexample refused because its fixture was already
broken proves nothing), and every rule has a failing and a passing case.
"""
from __future__ import annotations

import pytest

from factories import (add_asset, append_row, build_world, claim_row, codes, context, entry_dict, medical_dict, rewrite_entry, species_dict,
                       write_entry)
from sfe import texgen
from sfe.entries import claim_ids_of
from sfe.evidence import BINDABLE, FLOOR_MIN_CLAIMS, load_claim_policy
from sfe.registry import Repo
from sfe.validate import package_of, validate_repo
from factories import REAL

POLICY, _FINDINGS = load_claim_policy(Repo(REAL), None)
SPECIES_BOUND = sorted(POLICY.bound_fields["species_profile"].items())
MEDICAL_BOUND = sorted(POLICY.bound_fields["medical_guidance"].items())


def run(repo):
    return validate_repo(repo.root)


def species(repo, status="verified", **over):
    for n, view in enumerate(("whole", "key_feature"), start=1):
        add_asset(repo, n, view=view)
    return build_world(repo, status, fm_factory=species_dict, photo_ids=["PHO-0001", "PHO-0002"], **over)


def medical(repo, status="verified", **over):
    return build_world(repo, status, fm_factory=medical_dict, **over)


def clean(repo, builder, status="verified", **over):
    """Build the world and prove it is clean: the control for the counterexample that follows."""
    path = builder(repo, status, **over)
    assert codes(run(repo)) == set(), [str(f) for f in run(repo)]
    return path


def add_claim(repo, claim_id, claim_type, **over):
    append_row(repo, "claims", claim_row(claim_id=claim_id, claim_type=claim_type, **over))


def bind(path, field_name, ids):
    rewrite_entry(path, lambda fm: fm["field_claims"].update({field_name: ids}))


# ============================================================================================ the policy file
def test_the_real_policy_loads_without_findings_and_covers_every_entry_type():
    assert _FINDINGS == [] and POLICY is not None
    assert set(POLICY.entry_types) == {"general", "species_profile", "technical_procedure", "medical_guidance"}
    assert all(rule.min_claims >= FLOOR_MIN_CLAIMS for rule in POLICY.entry_types.values())
    assert set(POLICY.bound_fields) == {"species_profile", "medical_guidance"}
    assert {field for fields in POLICY.bound_fields.values() for field in fields} <= BINDABLE
    assert set(POLICY.text_triggers) == {"TRG-FORAGING", "TRG-MEDICAL"}


def test_the_policy_names_the_safety_bearing_fields_of_the_two_highest_risk_types():
    species_fields = set(POLICY.bound_fields["species_profile"])
    assert {"diagnostic_features", "lookalikes_or_confusions", "positive_identification_warning", "processing_restrictions",
            "regulated_or_protected_status"} <= species_fields
    medical_fields = set(POLICY.bound_fields["medical_guidance"])
    assert {"contraindications", "emergency_evacuation_threshold", "local_emergency_service_guidance", "audience_scope"} <= medical_fields


POLICY_PATH = "schemas/claim_policy.yaml"


def with_policy(repo, edit):
    path = repo.path(POLICY_PATH)
    text = path.read_text(encoding="utf-8")
    new = edit(text)
    assert new != text, "the edit did not change the policy: the test would prove nothing"
    path.write_text(new, encoding="utf-8", newline="\n")


@pytest.mark.parametrize("edit,code", [
    (lambda t: t.replace("min_claims: 1, min_steps: 0, required_claim_types: [identification]", "min_claims: 0, min_steps: 0, required_claim_types: [identification]"),
     "CLAIM_POLICY_INVALID"),
    (lambda t: t.replace("min_claims: 1, min_steps: 1,", "min_claims: true, min_steps: 1,"), "CLAIM_POLICY_INVALID"),
    (lambda t: t.replace("required_claim_types: [medical]", "required_claim_types: [nonsense]"), "CLAIM_POLICY_INVALID"),
    (lambda t: t.replace("diagnostic_features: [identification]", "id: [identification]"), "CLAIM_POLICY_INVALID"),
    (lambda t: t.replace("TRG-MEDICAL: [medical]", "TRG-NOPE: [medical]"), "CLAIM_POLICY_INVALID"),
    (lambda t: t.replace("contraindications: [medical]", "contraindications: []"), "CLAIM_POLICY_INVALID"),
    (lambda t: t.replace("  technical_procedure:\n    {min_claims: 1, min_steps: 1, required_claim_types: [], step_claim_types: []}\n", ""),
     "CLAIM_POLICY_INCOMPLETE"),
    (lambda t: t.replace("schema_version: 1", "schema_version: 2"), "CLAIM_POLICY_INVALID"),
    (lambda t: ": [unclosed", "CLAIM_POLICY_INVALID"),
], ids=["floor-zero", "bool-count", "unknown-claim-type", "unbindable-field", "unknown-trigger", "empty-accepted-types", "missing-row", "wrong-version",
        "not-yaml"])
def test_an_unusable_policy_is_an_error_and_no_entry_above_draft_passes(repo, edit, code):
    clean(repo, medical, "researched")
    with_policy(repo, edit)
    found = codes(run(repo))
    assert code in found and "CLAIM_POLICY_UNAVAILABLE" in found


def test_a_missing_policy_is_an_error_and_no_entry_above_draft_passes(repo):
    clean(repo, medical, "researched")
    repo.path(POLICY_PATH).unlink()
    found = codes(run(repo))
    assert {"CLAIM_POLICY_MISSING", "CLAIM_POLICY_UNAVAILABLE"} <= found


def test_a_draft_needs_no_claim_policy(repo):
    build_world(repo, "draft", fm_factory=medical_dict, claim_ids=[], field_claims={}, procedure=[])
    repo.path(POLICY_PATH).unlink()
    assert "CLAIM_POLICY_UNAVAILABLE" not in codes(run(repo))


# =========================================================================== P19a and P19b: no claim at all
def test_p19a_a_published_medical_entry_with_no_claim_is_refused_for_each_reason(repo):
    path = clean(repo, medical, "published")  # control: the same entry WITH its claims is clean
    rewrite_entry(path, lambda fm: fm.update(procedure=[], claim_ids=[], field_claims={}))
    found = codes(run(repo))
    assert {"ENTRY_CLAIMS_INSUFFICIENT", "ENTRY_CLAIM_TYPE_MISSING", "FIELD_CLAIM_MISSING"} <= found


def test_p19b_an_approved_species_profile_with_no_claim_is_refused_for_each_reason(repo):
    path = clean(repo, species, "approved")
    rewrite_entry(path, lambda fm: fm.update(claim_ids=[], field_claims={}))
    found = codes(run(repo))
    assert {"ENTRY_CLAIMS_INSUFFICIENT", "ENTRY_CLAIM_TYPE_MISSING", "FIELD_CLAIM_MISSING"} <= found


@pytest.mark.parametrize("builder,status", [(medical, "researched"), (medical, "verified"), (species, "researched"), (species, "verified")])
def test_an_empty_procedure_and_empty_claim_lists_exempt_nothing(repo, builder, status):
    path = clean(repo, builder, status)
    rewrite_entry(path, lambda fm: fm.update(procedure=[], claim_ids=[], field_claims={}))
    assert "ENTRY_CLAIMS_INSUFFICIENT" in codes(run(repo))


def test_a_medical_entry_without_a_procedure_is_allowed_when_its_claims_are_in_place(repo):
    """The rule is that an empty procedure exempts nothing, not that medical guidance must have steps (the policy's min_steps is 0 for it)."""
    path = clean(repo, medical, "verified")
    rewrite_entry(path, lambda fm: fm.update(procedure=[]))
    assert codes(run(repo)) == set()


# ============================================================================================ by entry type
def test_a_technical_procedure_needs_a_step_and_a_claim(repo):
    path = clean(repo, lambda r, s, **o: build_world(r, s, **o), "verified")
    rewrite_entry(path, lambda fm: fm.update(procedure=[], claim_ids=[], dimension_unit_table=[]))
    found = codes(run(repo))
    assert {"PROCEDURE_STEPS_INSUFFICIENT", "ENTRY_CLAIMS_INSUFFICIENT"} <= found


def test_a_technical_procedure_with_steps_that_cite_a_claim_has_cited_a_claim_even_with_an_empty_claim_list(repo):
    path = clean(repo, lambda r, s, **o: build_world(r, s, **o), "verified")
    rewrite_entry(path, lambda fm: fm.update(claim_ids=[], dimension_unit_table=[]))
    assert codes(run(repo)) == set()


def test_a_general_entry_needs_at_least_one_claim(repo):
    path = clean(repo, lambda r, s, **o: build_world(r, s, entry_type="general", **o), "verified")
    rewrite_entry(path, lambda fm: fm.update(procedure=[], claim_ids=[], dimension_unit_table=[]))
    assert "ENTRY_CLAIMS_INSUFFICIENT" in codes(run(repo))
    rewrite_entry(path, lambda fm: fm.update(claim_ids=["CLM-0001"]))
    assert codes(run(repo)) == set()


def test_a_species_profile_must_cite_an_identification_claim(repo):
    path = clean(repo, species, "verified")
    rewrite_entry(path, lambda fm: fm.update(claim_ids=["CLM-0002"], field_claims={k: ["CLM-0002"] for k in fm["field_claims"]}))
    found = codes(run(repo))
    assert "ENTRY_CLAIM_TYPE_MISSING" in found
    message = " ".join(f.message for f in run(repo) if f.code == "ENTRY_CLAIM_TYPE_MISSING")
    assert "identification" in message and "legal" in message  # names what is needed and what was found


def test_a_medical_entry_must_cite_a_medical_claim(repo):
    path = clean(repo, medical, "verified")
    add_claim(repo, "CLM-0003", "specification")
    rewrite_entry(path, lambda fm: fm.update(claim_ids=["CLM-0003"], procedure=[], field_claims={k: ["CLM-0003"] for k in fm["field_claims"]}))
    assert "ENTRY_CLAIM_TYPE_MISSING" in codes(run(repo))


def test_every_step_of_a_medical_entry_must_cite_a_medical_claim(repo):
    path = clean(repo, medical, "verified")
    add_claim(repo, "CLM-0003", "specification")

    def fn(fm):
        fm["claim_ids"] = ["CLM-0001", "CLM-0003"]
        fm["procedure"][1]["claim_ids"] = ["CLM-0003"]  # step 2 rests on a claim that is not medical
    rewrite_entry(path, fn)
    found = run(repo)
    assert "STEP_CLAIM_TYPE_MISSING" in codes(found)
    assert any("step 2" in f.message for f in found if f.code == "STEP_CLAIM_TYPE_MISSING")
    assert not any("step 1" in f.message for f in found if f.code == "STEP_CLAIM_TYPE_MISSING")  # step 1 is fine


def test_a_species_step_has_no_extra_claim_type_rule(repo):
    """The step rule belongs to the policy row of the type: a species profile's steps need only a claim, as before."""
    assert POLICY.entry_types["species_profile"].step_claim_types == ()
    assert POLICY.entry_types["medical_guidance"].step_claim_types == ("medical",)


# ============================================================================================ bound fields
@pytest.mark.parametrize("field_name,accepted", SPECIES_BOUND, ids=[f for f, _ in SPECIES_BOUND])
def test_each_species_field_must_be_bound_to_a_claim(repo, field_name, accepted):
    path = clean(repo, species, "verified")
    rewrite_entry(path, lambda fm: fm["field_claims"].pop(field_name))
    found = run(repo)
    assert "FIELD_CLAIM_MISSING" in codes(found)
    assert any(field_name in f.message for f in found if f.code == "FIELD_CLAIM_MISSING")


@pytest.mark.parametrize("field_name,accepted", MEDICAL_BOUND, ids=[f for f, _ in MEDICAL_BOUND])
def test_each_medical_field_must_be_bound_to_a_claim(repo, field_name, accepted):
    path = clean(repo, medical, "verified")
    rewrite_entry(path, lambda fm: fm["field_claims"].pop(field_name))
    found = run(repo)
    assert "FIELD_CLAIM_MISSING" in codes(found)
    assert any(field_name in f.message for f in found if f.code == "FIELD_CLAIM_MISSING")


def other_type(accepted):
    """A claim type the policy does NOT accept for this field."""
    return next(t for t in ("specification", "measurement", "procedure_step", "other", "legal", "identification", "medical", "safety_boundary") if t not in accepted)


@pytest.mark.parametrize("field_name,accepted", SPECIES_BOUND, ids=[f for f, _ in SPECIES_BOUND])
def test_a_species_field_bound_to_a_claim_of_the_wrong_type_is_refused(repo, field_name, accepted):
    path = clean(repo, species, "verified")
    add_claim(repo, "CLM-0003", other_type(accepted))
    bind(path, field_name, ["CLM-0003"])
    found = run(repo)
    assert "FIELD_CLAIM_TYPE_MISMATCH" in codes(found)
    assert any(field_name in f.message and " or ".join(accepted) in f.message for f in found if f.code == "FIELD_CLAIM_TYPE_MISMATCH")


@pytest.mark.parametrize("field_name,accepted", MEDICAL_BOUND, ids=[f for f, _ in MEDICAL_BOUND])
def test_a_medical_field_bound_to_a_claim_of_the_wrong_type_is_refused(repo, field_name, accepted):
    path = clean(repo, medical, "verified")
    add_claim(repo, "CLM-0003", other_type(accepted))
    bind(path, field_name, ["CLM-0003"])
    assert "FIELD_CLAIM_TYPE_MISMATCH" in codes(run(repo))


@pytest.mark.parametrize("accepted_type", ["identification", "safety_boundary"])
def test_a_field_with_two_accepted_types_takes_either(repo, accepted_type):
    path = clean(repo, species, "verified")
    add_claim(repo, "CLM-0003", accepted_type)
    bind(path, "positive_identification_warning", ["CLM-0003"])
    assert "FIELD_CLAIM_MISSING" not in codes(run(repo)) and "FIELD_CLAIM_TYPE_MISMATCH" not in codes(run(repo))


def test_one_right_claim_among_wrong_ones_is_enough(repo):
    path = clean(repo, species, "verified")
    add_claim(repo, "CLM-0003", "other")
    bind(path, "diagnostic_features", ["CLM-0003", "CLM-0001"])
    assert codes(run(repo)) == set()


def test_an_empty_bound_field_needs_no_claim(repo):
    path = clean(repo, species, "researched")  # `researched` does not require the field itself
    rewrite_entry(path, lambda fm: (fm.update(expert_identification_criteria=[]), fm["field_claims"].pop("expert_identification_criteria")))
    assert "FIELD_CLAIM_MISSING" not in codes(run(repo))


def test_a_binding_to_an_empty_field_is_refused(repo):
    path = clean(repo, species, "researched")
    rewrite_entry(path, lambda fm: fm.update(expert_identification_criteria=[]))  # the binding stays
    assert "FIELD_CLAIMS_EMPTY_FIELD" in codes(run(repo))


@pytest.mark.parametrize("name", ["danger", "id", "procedure", "nonsense", "claim_ids"])
def test_a_binding_to_a_name_that_is_not_a_text_field_is_refused(repo, name):
    path = clean(repo, species, "verified")
    bind(path, name, ["CLM-0001"])
    assert "FIELD_CLAIMS_UNKNOWN_FIELD" in codes(run(repo))


def test_a_binding_to_an_unregistered_claim_is_refused_twice(repo):
    path = clean(repo, species, "verified")
    bind(path, "diagnostic_features", ["CLM-0999"])
    found = codes(run(repo))
    assert {"CLAIM_NOT_REGISTERED", "FIELD_CLAIM_TYPE_MISMATCH"} <= found


def test_a_field_bound_claim_must_rest_on_a_source_the_entry_lists(repo):
    path = clean(repo, species, "verified")
    append_row(repo, "sources", __import__("factories").source_row(source_id="SRC-0002"))
    add_claim(repo, "CLM-0003", "identification", source_id="SRC-0002")
    bind(path, "diagnostic_features", ["CLM-0003"])
    assert "CLAIM_SOURCE_NOT_CITED" in codes(run(repo))


def test_the_schema_accepts_only_claim_ids_in_field_claims(repo):
    path = clean(repo, medical, "verified")
    for bad in ({"contraindications": ["not-a-claim"]}, {"contraindications": "CLM-0001"}, {"contraindications": ["CLM-0001", "CLM-0001"]}):
        rewrite_entry(path, lambda fm, bad=bad: fm.update(field_claims=bad))
        assert "ENTRY_SCHEMA" in codes(run(repo)), bad
    rewrite_entry(path, lambda fm: fm.update(field_claims="CLM-0001"))
    assert "ENTRY_SCHEMA" in codes(run(repo))


# ========================================================================= a rejected or unverified claim
def test_a_rejected_claim_is_not_evidence(repo):
    path = clean(repo, medical, "researched")
    rewrite_entry(path, lambda fm: fm.update(claim_ids=["CLM-0003"], procedure=[], field_claims={}))
    add_claim(repo, "CLM-0003", "medical", status="rejected", verified_by=None, verified_on=None, evidence_date=None)
    assert "ENTRY_CLAIMS_INSUFFICIENT" in codes(run(repo))


def test_an_unverified_claim_counts_at_researched_and_is_refused_from_verified(repo):
    path = clean(repo, medical, "researched")
    rewrite_entry(path, lambda fm: fm.update(claim_ids=["CLM-0003"], procedure=[], field_claims={}))
    add_claim(repo, "CLM-0003", "medical", status="UNVERIFIED", verified_by=None, verified_on=None, evidence_date=None)
    found = codes(run(repo))
    assert "ENTRY_CLAIMS_INSUFFICIENT" not in found and "ENTRY_CLAIM_TYPE_MISSING" not in found
    rewrite_entry(path, lambda fm: fm.update(status="verified", technical_reviewer="REV-0005"))
    assert "CLAIM_NOT_VERIFIED" in codes(run(repo))


# ============================================================================================ text triggers
def plain(repo, text, claim_type="specification", **over):
    """A clean general entry whose `what_it_is` carries `text`, resting on one claim of `claim_type`."""
    append_row(repo, "claims", claim_row(claim_type=claim_type))
    from factories import source_row
    append_row(repo, "sources", source_row())
    over.setdefault("status", "researched")
    fm = entry_dict(entry_type="general", what_it_is=text, **over)
    return write_entry(repo, fm, "")


@pytest.mark.parametrize("text", ["These mushrooms are edible when cooked.", "Foraging for berries.", "A poisonous plant."])
def test_a_statement_about_foraging_needs_an_identification_or_safety_claim_whatever_the_entry_type(repo, text):
    plain(repo, text)
    found = run(repo)
    assert "TEXT_CLAIM_MISSING" in codes(found)
    assert any("TRG-FORAGING" in f.message for f in found if f.code == "TEXT_CLAIM_MISSING")


@pytest.mark.parametrize("claim_type", ["identification", "safety_boundary"])
def test_a_foraging_statement_with_an_accepted_claim_passes_this_rule(repo, claim_type):
    plain(repo, "These mushrooms are edible when cooked.", claim_type)
    assert "TEXT_CLAIM_MISSING" not in codes(run(repo))


def test_a_medical_statement_needs_a_medical_claim_whatever_the_entry_type(repo):
    plain(repo, "Press on the wound to control bleeding.")
    found = run(repo)
    assert any("TRG-MEDICAL" in f.message for f in found if f.code == "TEXT_CLAIM_MISSING")


def test_a_medical_statement_with_a_medical_claim_passes_this_rule(repo):
    plain(repo, "Press on the wound to control bleeding.", "medical")
    assert "TEXT_CLAIM_MISSING" not in codes(run(repo))


def test_text_in_a_draft_triggers_nothing(repo):
    plain(repo, "These mushrooms are edible.", status="draft")
    assert "TEXT_CLAIM_MISSING" not in codes(run(repo))


# ==================================================================== the claims join the package and the page
def test_a_field_bound_claim_is_part_of_the_package_so_changing_it_stales_the_approval(repo):
    path = clean(repo, medical, "approved")
    add_claim(repo, "CLM-0003", "medical")
    rewrite_entry(path, lambda fm: fm["field_claims"].update(contraindications=["CLM-0001", "CLM-0003"]))
    found = codes(run(repo))
    assert "APPROVAL_STALE" in found  # the binding is part of the reviewed text


def test_a_claim_cited_only_through_field_claims_is_in_the_package_claims(repo):
    path = clean(repo, medical, "approved")
    add_claim(repo, "CLM-0003", "medical")
    ctx = context(repo)
    entry = ctx.entries[0]
    before = package_of(ctx, entry)[1]["claims"]
    assert "CLM-0003" not in before
    rewrite_entry(path, lambda fm: fm["field_claims"].update(contraindications=["CLM-0003"]))
    ctx = context(repo)
    entry = ctx.entries[0]
    assert "CLM-0003" in claim_ids_of(entry.fm) and "CLM-0003" in package_of(ctx, entry)[1]["claims"]


def test_editing_a_field_bound_claim_after_approval_stales_the_approval(repo):
    clean(repo, medical, "approved")
    from factories import edit_rows
    edit_rows(repo, "claims", lambda rows: rows[0].update(claim_text="Fixture claim text, edited."))
    assert "APPROVAL_STALE" in codes(run(repo))


def test_the_page_prints_every_claim_id_including_the_field_bound_ones():
    fm = entry_dict(entry_type="general", claim_ids=["CLM-0001"], field_claims={"dangers": ["CLM-0007"]})
    assert texgen.printed_claim_ids(fm) == {"CLM-0001", "CLM-0007"}
    promised = [text for path, text in texgen.printed_strings(fm, assets={}, sources={}, zone_title="Fixture zone") if path == "claim_ids"]
    assert "CLM-0007" in promised


def test_field_claims_is_metadata_the_renderer_accepts_and_the_manifest_names_it():
    assert "field_claims" in texgen.METADATA_KEYS
    assert any("field_claims" in line for line in texgen.KNOWN_UNRENDERED)
    entry = entry_dict(entry_type="general", field_claims={"dangers": ["CLM-0001"]})
    rendered = texgen.render_entry(entry, assets={}, sources={}, zone_title="Fixture zone", proof=False, repo_root=REAL)
    assert "CLM-0001" in rendered.tex


def test_every_bindable_field_is_a_property_of_the_entry_schema(repo):
    properties = set(repo.schema("entry.schema.json")["properties"])
    assert BINDABLE <= properties
