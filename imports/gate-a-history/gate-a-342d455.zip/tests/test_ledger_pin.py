"""External ledger continuity pinning (FR-003 residual; Fable probe P08c in a bare export).

A hash chain alone CANNOT detect tail truncation (removing the last rows leaves a valid chain).
An independent external pin (`python -m sfe ledger pin`, stored outside the repository) closes
tail truncation outside Git for all rows up to the pin, and `release` / `release verify` fail closed
(`LEDGER_PIN_REQUIRED`) whenever ledgers hold rows and no trustworthy external anchor is supplied.
"""
from __future__ import annotations

import shutil
from pathlib import Path

import pytest

from factories import (
    DATE, REAL, add_approval, add_asset, add_image_audit, add_safety, build_world, codes, make_repo, pin_for,
    read_rows, register, tamper, write_rows,
)
from sfe import ledger, pdfbuild, release as rel
from sfe.cli import main as cli_main
from sfe.registry import LEDGERS, REGISTERS, Repo
from sfe.validate import validate_repo


def cli(capsys, *args: str) -> tuple[int, str]:
    code = cli_main(list(args))
    cap = capsys.readouterr()
    return code, cap.out + cap.err


def full_world(tmp_path: Path):
    """A repo where ALL FOUR ledgers (reviewers, approvals, safety_audit, image_audit) hold sealed rows."""
    repo = make_repo(tmp_path / "repo")
    add_asset(repo, 1)
    path = build_world(repo, "published", photo_ids=["PHO-0001"])
    assert codes(validate_repo(repo.root)) == set()
    return repo, path


# ============================================================================== pin creation and parsing
def test_empty_ledgers_need_no_pin_for_validate_or_release(tmp_path):
    repo = make_repo(tmp_path, registry=False)
    findings = validate_repo(repo.root)
    assert codes(findings) == set()
    assert "LEDGER_CONTINUITY_UNANCHORED" not in codes(findings, "warning")
    result = pdfbuild.build_release(repo, out_root=tmp_path / "dist")
    assert "LEDGER_PIN_REQUIRED" not in codes(result.findings)
    assert "NO_PUBLISHED_ENTRIES" in codes(result.findings)


def test_create_pin_is_deterministic_and_refuses_broken_ledgers(tmp_path):
    repo, _ = full_world(tmp_path)
    p1 = ledger.create_pin(repo)
    p2 = ledger.create_pin(repo)
    assert p1 == p2 and p1.startswith(ledger.PIN_PREFIX + " ")
    parsed = ledger.parse_pin(p1)
    assert set(parsed) == set(LEDGERS)
    assert all(rows >= 1 for rows, _head in parsed.values())

    # Tampering any ledger makes create_pin refuse (never pins broken ledgers)
    tamper(repo, "approvals", lambda lines: [lines[0], lines[1].replace("approved", "rejected")])
    with pytest.raises(ledger.LedgerError, match="broken ledger"):
        ledger.create_pin(repo)


def test_unsealed_ledger_cannot_be_pinned(tmp_path):
    repo = make_repo(tmp_path)
    path = repo.path("reviews/approvals.csv")
    cols = repo.columns("approvals")
    with path.open("a", encoding="utf-8", newline="") as fh:
        fh.write(",".join([""] * len(cols)) + "\n")
    with pytest.raises(ledger.LedgerError, match="broken ledger"):
        ledger.create_pin(repo)


@pytest.mark.parametrize("bad_pin", [
    "",
    "   ",
    "not-a-pin",
    "sfe-pin-v2 approvals=0:" + ledger.GENESIS + " digest=0000000000000000",
    "sfe-pin-v1 approvals=0:" + ledger.GENESIS + " digest=deadbeefdeadbeef",
    "sfe-pin-v1 approvals=1:" + ledger.GENESIS + " image_audit=0:" + ledger.GENESIS + " reviewers=0:" + ledger.GENESIS + " safety_audit=0:" + ledger.GENESIS + " digest=0000000000000000",
])
def test_malformed_pins_are_refused(tmp_path, bad_pin):
    repo = make_repo(tmp_path)
    findings = validate_repo(repo.root, pin=bad_pin)
    assert "LEDGER_PIN_INVALID" in codes(findings)


def test_pin_for_wrong_ledger_set_or_corrupted_digest_is_refused(tmp_path):
    repo, _ = full_world(tmp_path)
    pin = ledger.create_pin(repo)
    # Corrupt one hex digit of digest
    bad_digest = pin[:-1] + ("0" if pin[-1] != "0" else "1")
    assert "LEDGER_PIN_INVALID" in codes(validate_repo(repo.root, pin=bad_digest))
    # Valid digest but missing one ledger
    partial = ledger.format_pin({"approvals": (0, ledger.GENESIS), "reviewers": (0, ledger.GENESIS)})
    assert "LEDGER_PIN_INVALID" in codes(validate_repo(repo.root, pin=partial))
    # Valid digest but extra unknown ledger
    extra = ledger.format_pin({**{k: (0, ledger.GENESIS) for k in LEDGERS}, "bogus": (0, ledger.GENESIS)})
    assert "LEDGER_PIN_INVALID" in codes(validate_repo(repo.root, pin=extra))
    # Valid digest but rows=0 with non-genesis head
    bad_zero = ledger.format_pin({**{k: (0, ledger.GENESIS) for k in LEDGERS}, "approvals": (0, "a" * 64)})
    assert "LEDGER_PIN_INVALID" in codes(validate_repo(repo.root, pin=bad_zero))
    # Valid digest but rows=1 with genesis head
    bad_gen = ledger.format_pin({**{k: (0, ledger.GENESIS) for k in LEDGERS}, "approvals": (1, ledger.GENESIS)})
    assert "LEDGER_PIN_INVALID" in codes(validate_repo(repo.root, pin=bad_gen))


# ============================================================================== truncation, rewrite, append
@pytest.mark.parametrize("name", sorted(LEDGERS))
def test_truncating_any_ledger_by_one_row_is_caught_in_bare_export(tmp_path, name):
    repo, _ = full_world(tmp_path)
    pin = ledger.create_pin(repo)
    # Export without .git
    bare_root = tmp_path / "bare"
    shutil.copytree(repo.root, bare_root)
    bare = Repo(bare_root)
    assert codes(validate_repo(bare.root, pin=pin)) == set()

    # Truncate last row and re-seal (chain stays internally valid!)
    rows = read_rows(bare, name)
    write_rows(bare, name, rows[:-1])
    found = codes(validate_repo(bare.root, pin=pin))
    assert "LEDGER_PIN_TRUNCATED" in found


def test_truncating_all_ledgers_to_empty_is_still_caught_when_pin_supplied(tmp_path):
    repo, _ = full_world(tmp_path)
    pin = ledger.create_pin(repo)
    for name in LEDGERS:
        write_rows(repo, name, [])
    found = codes(validate_repo(repo.root, pin=pin))
    assert "LEDGER_PIN_TRUNCATED" in found


def test_rewriting_pinned_prefix_and_resealing_is_caught_in_bare_export(tmp_path):
    repo, _ = full_world(tmp_path)
    pin = ledger.create_pin(repo)
    # Rewrite row 1 of approvals and re-seal (same row count, valid chain, DIFFERENT head)
    rows = read_rows(repo, "approvals")
    rows[0]["notes"] = "Quietly rewritten note."
    write_rows(repo, "approvals", rows)
    found = codes(validate_repo(repo.root, pin=pin))
    assert "LEDGER_PIN_REWRITTEN" in found


def test_appending_new_rows_after_pin_is_accepted(tmp_path):
    repo, path = full_world(tmp_path)
    pin = ledger.create_pin(repo)
    # Append a new valid registration and a new safety pass after the pin
    register(repo, "REV-0099", "technical_reviewer", kind="human", name="Fixture Later Reviewer", domains=["CLS-SCREENING"], evidence="Fixture cred")
    add_safety(repo, path, ["CLS-SCREENING"], role="technical_reviewer", reviewer="Fixture Later Reviewer", reviewed_on="2026-02-01")
    findings = validate_repo(repo.root, pin=pin)
    assert codes(findings) == set()
    assert "LEDGER_CONTINUITY_UNANCHORED" not in codes(findings, "warning")


# ============================================================================== fail closed & external storage
def test_unpinned_nonempty_ledgers_warn_on_validate_and_fail_closed_on_release_and_verify(tmp_path):
    repo, _ = full_world(tmp_path)
    # Validate warns (error under --strict)
    findings = validate_repo(repo.root)
    assert codes(findings) == set()
    assert "LEDGER_CONTINUITY_UNANCHORED" in codes(findings, "warning")

    # Release fails closed with LEDGER_PIN_REQUIRED and writes nothing
    dist = tmp_path / "dist"
    refused = pdfbuild.build_release(repo, out_root=dist)
    assert not refused.ok and "LEDGER_PIN_REQUIRED" in codes(refused.findings)
    assert not dist.exists()

    # After releasing WITH a pin, verify_active WITHOUT a pin also fails closed with LEDGER_PIN_REQUIRED
    pin = ledger.create_pin(repo)
    built = pdfbuild.build_release(repo, out_root=dist, pin=pin)
    assert built.ok
    assert rel.verify_active(repo, dist, pin=pin).ok is True
    unpinned_v = rel.verify_active(repo, dist)
    assert not unpinned_v.ok and "LEDGER_PIN_REQUIRED" in codes(unpinned_v.findings)


def test_pin_file_outside_repo_and_env_var_work_and_inside_repo_is_refused(tmp_path, monkeypatch):
    repo, _ = full_world(tmp_path)
    outside = tmp_path / "external.pin"
    pin = ledger.write_pin_file(repo, outside)
    assert outside.is_file() and outside.read_text(encoding="utf-8").strip() == pin

    # External file via --pin argument
    findings = validate_repo(repo.root, pin=outside)
    assert codes(findings) == set() and "LEDGER_CONTINUITY_UNANCHORED" not in codes(findings, "warning")

    # External file via SFE_LEDGER_PIN env var
    monkeypatch.setenv(ledger.PIN_ENV, str(outside))
    assert codes(validate_repo(repo.root)) == set()
    assert "LEDGER_CONTINUITY_UNANCHORED" not in codes(validate_repo(repo.root), "warning")

    # Inline string via SFE_LEDGER_PIN env var
    monkeypatch.setenv(ledger.PIN_ENV, pin)
    assert codes(validate_repo(repo.root)) == set()

    # Missing file via SFE_LEDGER_PIN fails closed
    monkeypatch.setenv(ledger.PIN_ENV, str(tmp_path / "does_not_exist.pin"))
    assert "LEDGER_PIN_INVALID" in codes(validate_repo(repo.root))
    monkeypatch.delenv(ledger.PIN_ENV)

    # Pin file INSIDE the repository is refused both on write and on read
    inside = repo.path("reviews/my.pin")
    with pytest.raises(ledger.LedgerError, match="outside"):
        ledger.write_pin_file(repo, inside)
    inside.write_text(pin + "\n", encoding="utf-8")
    assert "LEDGER_PIN_INSIDE_REPO" in codes(validate_repo(repo.root, pin=inside))


def test_cli_ledger_pin_and_strict_validate(tmp_path, capsys):
    repo, _ = full_world(tmp_path)
    # Without pin: validate --strict fails on LEDGER_CONTINUITY_UNANCHORED
    code, out = cli(capsys, "--root", str(repo.root), "validate", "--strict")
    assert code == 1 and "LEDGER_CONTINUITY_UNANCHORED" in out

    # ledger pin prints a valid pin line
    code, out = cli(capsys, "--root", str(repo.root), "ledger", "pin")
    assert code == 0 and out.strip().startswith(ledger.PIN_PREFIX + " ")
    pin_str = out.strip()

    # ledger pin --write refuses inside repo, succeeds outside repo
    code, out = cli(capsys, "--root", str(repo.root), "ledger", "pin", "--write", str(repo.path("inside.pin")))
    assert code == 1
    ext_file = tmp_path / "owner.pin"
    code, out = cli(capsys, "--root", str(repo.root), "ledger", "pin", "--write", str(ext_file))
    assert code == 0 and ext_file.is_file()

    # validate --strict --pin passes with 0 warnings
    code, out = cli(capsys, "--root", str(repo.root), "validate", "--strict", "--pin", str(ext_file))
    assert code == 0 and "0 error(s), 0 warning(s)" in out
    code, out = cli(capsys, "--root", str(repo.root), "validate", "--strict", "--pin", pin_str)
    assert code == 0 and "0 error(s), 0 warning(s)" in out


def test_validate_release_and_verify_never_self_generate_a_replacement_pin(tmp_path, monkeypatch):
    """Proves validate, build_release, verify_active, and reconcile cannot silently call create_pin/write_pin_file from the checked ledger."""
    repo, _ = full_world(tmp_path)
    pin = ledger.create_pin(repo)
    dist = tmp_path / "dist"

    def forbid(*_args, **_kwargs):
        raise AssertionError("validation/release/verify must never silently generate a pin from the ledger being checked")

    monkeypatch.setattr(ledger, "create_pin", forbid)
    monkeypatch.setattr(ledger, "write_pin_file", forbid)

    # Unpinned calls fail closed / warn without generating a pin
    assert "LEDGER_CONTINUITY_UNANCHORED" in codes(validate_repo(repo.root), "warning")
    refused = pdfbuild.build_release(repo, out_root=dist)
    assert not refused.ok and "LEDGER_PIN_REQUIRED" in codes(refused.findings)

    # Pinned release, verify, and reconcile all succeed without calling create_pin
    built = pdfbuild.build_release(repo, out_root=dist, pin=pin)
    assert built.ok
    assert rel.verify_active(repo, dist, pin=pin).ok is True
    assert not rel.verify_active(repo, dist).ok
    assert rel.reconcile(repo, dist, pin=pin) == []
