"""Measurement accuracy (FABLE-REVIEW-001 FR-019, RUN-004).

At RUN-003 a pair had only to round-trip at its own printed precision, so `1 mi / 2 km`, `1 in / 3 cm`, `2 lb / 1 kg`, `3 ft / 1 m`, `1 gal / 4 L` and `1 qt / 1 L`
passed (P23), fractions, ranges and temperature intervals could not be written, and a conversion in a step's text was never read (P28). These tests pin the
policy of `scripts/sfe/units.py` and `schemas/unit_policy.yaml`: the round trip AND a relative-error bound by class, the approximation marker, the safety
class, exact fractions and ranges, temperature offsets and intervals, the prose scan, and what is deliberately not here (no medical dose tolerance).
Nothing the old rule refused may ever be accepted: that is a property test against a re-implementation of the old rule.
"""
from __future__ import annotations

import random
from decimal import ROUND_HALF_UP, Decimal

import pytest

from factories import DATE, REAL, build_world, codes, medical_dict, rewrite_entry
from sfe import units
from sfe.classify import classify
from sfe.entries import Entry
from sfe.registry import Repo
from sfe.units import (CEILING, DEFAULT_POLICY, STRICT_POLICY, UnitPolicy, check_pair, convert, dimension_of, load_unit_policy, parse_measure, parse_quantity,
                       relative_error, scan_text)
from sfe.validate import validate_repo

D = Decimal


def run(repo):
    return validate_repo(repo.root)


def refused(us, metric, **kw):
    return bool(check_pair(us, metric, **kw))


# ============================================================================================ the policy file
def test_the_real_policy_loads_and_equals_the_documented_default():
    policy, findings = load_unit_policy(Repo(REAL))
    assert findings == [] and policy == DEFAULT_POLICY
    assert (policy.precise, policy.approximate, policy.safety) == (D("0.01"), D("0.05"), D("0.005"))
    assert policy.safety_dimensions == {"pressure", "temperature"}


def test_the_ceilings_and_the_strict_fallback_are_what_the_contract_says():
    assert CEILING == {"precise": D("0.05"), "approximate": D("0.10"), "safety": D("0.02")}
    assert STRICT_POLICY.precise == STRICT_POLICY.approximate == STRICT_POLICY.safety == D("0.005")
    assert STRICT_POLICY.safety_dimensions == units.DIMENSIONS


POLICY_PATH = "schemas/unit_policy.yaml"


def with_policy(repo, edit):
    path = repo.path(POLICY_PATH)
    text = path.read_text(encoding="utf-8")
    new = edit(text)
    assert new != text, "the edit did not change the policy: the test would prove nothing"
    path.write_text(new, encoding="utf-8", newline="\n")


BAD_POLICIES = {
    "precise-above-ceiling": lambda t: t.replace("precise: 0.01", "precise: 0.06"),
    "approximate-above-ceiling": lambda t: t.replace("approximate: 0.05", "approximate: 0.2"),
    "safety-above-ceiling": lambda t: t.replace("safety: 0.005", "safety: 0.03"),
    "safety-looser-than-precise": lambda t: t.replace("safety: 0.005", "safety: 0.02"),
    "approximate-tighter-than-precise": lambda t: t.replace("approximate: 0.05", "approximate: 0.005"),
    "bool-bound": lambda t: t.replace("precise: 0.01", "precise: true"),
    "text-bound": lambda t: t.replace("precise: 0.01", "precise: lots"),
    "zero-bound": lambda t: t.replace("precise: 0.01", "precise: 0"),
    "negative-bound": lambda t: t.replace("precise: 0.01", "precise: -0.01"),
    "one-or-more": lambda t: t.replace("precise: 0.01", "precise: 1"),
    "missing-bound": lambda t: t.replace("  approximate: 0.05\n", ""),
    "extra-bound": lambda t: t.replace("  safety: 0.005\n", "  safety: 0.005\n  lax: 0.5\n"),
    "temperature-not-safety": lambda t: t.replace("safety_dimensions: [pressure, temperature]", "safety_dimensions: [pressure]"),
    "pressure-not-safety": lambda t: t.replace("safety_dimensions: [pressure, temperature]", "safety_dimensions: [temperature]"),
    "unknown-dimension": lambda t: t.replace("safety_dimensions: [pressure, temperature]", "safety_dimensions: [pressure, temperature, speed]"),
    "no-markers": lambda t: t.replace('approximate_markers: ["~", "about", "approx.", "approx", "approximately", "roughly", "circa"]', "approximate_markers: []"),
    "unprintable-marker": lambda t: t.replace('"circa"]', '"circa", "≈"]'),
    "blank-marker": lambda t: t.replace('"circa"]', '"circa", " "]'),
    "wrong-version": lambda t: t.replace("schema_version: 1", "schema_version: 2"),
    "not-yaml": lambda t: ": [unclosed",
}


@pytest.mark.parametrize("name", sorted(BAD_POLICIES))
def test_an_unusable_policy_is_an_error_and_the_strictest_bound_applies(repo, name):
    path = build_world(repo, "verified")
    rewrite_entry(path, lambda fm: fm["dimension_unit_table"][0].update(us_customary="2 oz", metric="57 g"))  # 0.53 %: fine by the real policy, not by the strict one
    assert "UNIT_INCONSISTENT" not in codes(run(repo)), "the control: this row passes under the real policy"
    with_policy(repo, BAD_POLICIES[name])
    found = codes(run(repo))
    assert "UNIT_POLICY_INVALID" in found, name
    assert "UNIT_INCONSISTENT" in found, "an unusable policy must not fall back to the loose reading: the 0.53 % row is refused by the strict bound"


def test_a_missing_policy_is_an_error_and_the_strictest_bound_applies(repo):
    path = build_world(repo, "verified")
    rewrite_entry(path, lambda fm: fm["dimension_unit_table"][0].update(us_customary="2 oz", metric="57 g"))
    repo.path(POLICY_PATH).unlink()
    found = codes(run(repo))
    assert {"UNIT_POLICY_MISSING", "UNIT_INCONSISTENT"} <= found


def test_a_policy_may_tighten_a_bound(repo):
    path = build_world(repo, "verified")
    rewrite_entry(path, lambda fm: fm["dimension_unit_table"][0].update(us_customary="2 oz", metric="57 g"))
    with_policy(repo, lambda t: t.replace("precise: 0.01", "precise: 0.005"))
    found = codes(run(repo))
    assert "UNIT_POLICY_INVALID" not in found and "UNIT_INCONSISTENT" in found


# ===================================================================================== the review's pairs (P23)
LOOSE = [("1 mi", "2 km"), ("1 in", "3 cm"), ("2 lb", "1 kg"), ("3 ft", "1 m"), ("1 gal", "4 L"), ("1 qt", "1 L"), ("1 yd", "1 m")]
CORRECTED = [("1 mi", "1.6 km"), ("1 in", "2.54 cm"), ("2 lb", "0.9 kg"), ("3 ft", "0.91 m"), ("1 gal", "3.8 L"), ("1 qt", "0.95 L"), ("1 yd", "0.91 m")]


@pytest.mark.parametrize("us,metric", LOOSE, ids=[f"{a}/{b}" for a, b in LOOSE])
def test_the_loose_pairs_of_the_review_are_refused_with_the_size_of_the_error(us, metric):
    problems = check_pair(us, metric)
    assert problems and any("differ by" in p and "at most 1.00%" in p for p in problems), problems


@pytest.mark.parametrize("us,metric", CORRECTED, ids=[f"{a}/{b}" for a, b in CORRECTED])
def test_the_same_quantities_stated_closely_enough_pass(us, metric):
    assert check_pair(us, metric) == []


@pytest.mark.parametrize("us,metric", [("1/4 in", "6.35 mm"), ("4-6 in", "102-152 mm"), ("8 fl oz", "237 ml"), ("15 psi", "103 kPa"),
                                       ("18 °F difference", "10 °C difference")])
def test_the_pairs_the_review_said_a_unit_check_must_express_pass(us, metric):
    assert check_pair(us, metric) == []


def test_the_absolute_reading_of_18_f_and_10_c_is_still_refused():
    """It is still an ABSOLUTE pair that does not match (18 °F is -7.8 °C). The interval is written with the word difference."""
    assert refused("18 °F", "10 °C")


@pytest.mark.parametrize("unit", ["tsp", "tbsp", "cup", "cups", "mg", "mcg", "iu", "drop", "teaspoon", "tablespoon", "dose", "unit"])
def test_a_dose_unit_or_household_measure_is_not_a_unit_of_the_table_and_gets_no_tolerance(unit):
    problems = check_pair(f"1 {unit}", "5 ml")
    assert problems and any("unknown unit" in p for p in problems), problems
    assert refused("5 oz", f"150 {unit}")


# ===================================================================================== conversion factors
@pytest.mark.parametrize("value,frm,to,expected", [
    ("1", "in", "mm", "25.4"), ("1", "ft", "m", "0.3048"), ("1", "yd", "m", "0.9144"), ("1", "mi", "km", "1.609344"), ("1", "lb", "kg", "0.45359237"),
    ("1", "oz", "g", "28.349523125"), ("1", "gal", "l", "3.785411784"), ("1", "qt", "l", "0.946352946"), ("1", "fl oz", "ml", "29.5735295625"),
    ("1", "psi", "kpa", "6.894757293168"), ("100", "°c", "°f", "212"), ("0", "°c", "°f", "32"), ("32", "°f", "°c", "0"), ("-40", "°f", "°c", "-40"),
    ("-459.67", "°f", "°c", "-273.15"),
])
def test_the_exact_factors(value, frm, to, expected):
    assert convert(D(value), frm, to) == D(expected)


def test_an_interval_converts_without_the_offset():
    assert convert(D("18"), "°f", "°c", interval=True) == D("10")
    assert convert(D("10"), "°c", "°f", interval=True) == D("18")
    assert convert(D("0"), "°c", "°f", interval=True) == D("0")
    assert convert(D("0"), "°c", "°f") == D("32")  # an absolute zero is not an interval zero


# ======================================================= nothing the old rule refused may ever be accepted
def old_rule_accepts(us_text, metric_text):
    """RUN-001 to RUN-003: both values round-trip at their own printed decimals. Re-implemented here, independently of check_pair."""
    us_val, us_dec, us_unit = parse_quantity(us_text)
    me_val, me_dec, me_unit = parse_quantity(metric_text)
    forward = convert(us_val, us_unit, me_unit).quantize(D(1).scaleb(-me_dec), rounding=ROUND_HALF_UP)
    backward = convert(me_val, me_unit, us_unit).quantize(D(1).scaleb(-us_dec), rounding=ROUND_HALF_UP)
    return forward == me_val and backward == us_val


PAIRS_BY_DIMENSION = {
    "length": (["in", "ft", "yd", "mi"], ["mm", "cm", "m", "km"]), "mass": (["oz", "lb"], ["g", "kg"]), "volume": (["fl oz", "qt", "gal"], ["ml", "l"]),
    "pressure": (["psi"], ["kpa"]),
}


def random_pair(rng, dimension):
    us_units, metric_units = PAIRS_BY_DIMENSION[dimension]
    us_unit, metric_unit = rng.choice(us_units), rng.choice(metric_units)
    us_value = rng.choice(["1", "2", "3", "4", "5", "10", "12", "1.5", "2.5", "0.5", "100", "7.25"])
    conversion = convert(D(us_value), us_unit, metric_unit)
    kind = rng.choice(["exact", "round0", "round1", "round2", "off"])
    if kind == "off":
        stated = conversion * D(str(rng.choice([0.5, 0.9, 0.97, 0.99, 1.01, 1.03, 1.1, 1.5, 2])))
        stated = stated.quantize(D(1).scaleb(-rng.choice([0, 1, 2])), rounding=ROUND_HALF_UP)
    else:
        digits = {"exact": 6, "round0": 0, "round1": 1, "round2": 2}[kind]
        stated = conversion.quantize(D(1).scaleb(-digits), rounding=ROUND_HALF_UP)
    return f"{us_value} {us_unit}", f"{stated:f} {metric_unit}"


@pytest.mark.parametrize("dimension", sorted(PAIRS_BY_DIMENSION))
@pytest.mark.parametrize("seed", range(4))
def test_a_pair_the_old_rule_refused_is_never_accepted(dimension, seed):
    rng = random.Random(f"{dimension}-{seed}")
    seen_refused = 0
    for _ in range(300):
        us, metric = random_pair(rng, dimension)
        if not old_rule_accepts(us, metric):
            seen_refused += 1
            for strictness in ("precise", "safety"):
                assert refused(us, metric, strictness=strictness), (us, metric, strictness)
            assert refused(us, metric, policy=STRICT_POLICY), (us, metric)
    assert seen_refused > 20, "the generator must actually produce pairs the old rule refused"


def test_the_old_suites_refusals_still_hold():
    for us, metric in [("4 in", "100 mm"), ("3.9 in", "100 mm"), ("4.00 in", "102 mm"), ("10 psi", "10 kPa"), ("5 °F", "5 °C"), ("1 gal", "3 L"), ("2 lb", "2 kg")]:
        assert refused(us, metric), (us, metric)


# ========================================================================================== exact conversions
def five_figures(value: D) -> str:
    decimals = max(0, 4 - value.adjusted())
    return f"{value.quantize(D(1).scaleb(-decimals), rounding=ROUND_HALF_UP):f}"


@pytest.mark.parametrize("dimension", sorted(PAIRS_BY_DIMENSION))
def test_every_exact_conversion_stated_to_five_figures_is_accepted(dimension):
    us_units, metric_units = PAIRS_BY_DIMENSION[dimension]
    for us_unit in us_units:
        for metric_unit in metric_units:
            for value in ("1", "2.5", "4", "10", "12.5", "100", "1000"):
                conversion = convert(D(value), us_unit, metric_unit)
                us, metric = f"{value} {us_unit}", f"{five_figures(conversion)} {metric_unit}"
                assert check_pair(us, metric) == [], (us, metric)
                assert check_pair(us, metric, strictness="safety") == [], (us, metric)


@pytest.mark.parametrize("seed", range(3))
def test_the_bound_decides_unmarked_pairs(seed):
    """An unmarked pair is accepted only if its relative error is within the precise bound, and refused whenever it is over it."""
    rng = random.Random(seed)
    for dimension in ("length", "mass", "volume"):
        for _ in range(250):
            us, metric = random_pair(rng, dimension)
            us_val, _d, us_unit = parse_quantity(us)
            me_val, _d2, me_unit = parse_quantity(metric)
            error = relative_error(convert(us_val, us_unit, me_unit), me_val)
            if error > DEFAULT_POLICY.precise:
                assert refused(us, metric), (us, metric, error)
            if not refused(us, metric):
                assert error <= DEFAULT_POLICY.precise, (us, metric, error)


@pytest.mark.parametrize("seed", range(3))
def test_stricter_classes_never_accept_what_looser_ones_refuse(seed):
    """safety implies precise implies the marked reading; marking a pair never rescues it in a safety context."""
    rng = random.Random(100 + seed)
    for dimension in ("length", "mass", "volume", "pressure"):
        for _ in range(250):
            us, metric = random_pair(rng, dimension)
            marked = ("~" + us, "~" + metric)
            if not refused(us, metric, strictness="safety"):
                assert not refused(us, metric), (us, metric)
            if not refused(us, metric):
                assert not refused(*marked), (us, metric)
            if refused(us, metric, strictness="safety"):
                assert refused(*marked, strictness="safety"), (us, metric)


# =================================================================================================== boundaries
def test_relative_error_is_symmetric_zero_safe_and_scaled_by_the_larger_value():
    assert relative_error(D(0), D(0)) == 0 and relative_error(D("2.54"), D("2.54")) == 0
    assert relative_error(D(0), D(5)) == 1 and relative_error(D(5), D(0)) == 1
    assert relative_error(D(100), D(99)) == relative_error(D(99), D(100)) == D("0.01")
    assert relative_error(D(-100), D(-99)) == D("0.01") and relative_error(D(-5), D(5)) == 2  # opposite signs: twice the larger magnitude
    assert relative_error(D("2.54"), D(3)) == D("0.46") / D(3)


def test_the_marked_bound_is_inclusive_at_five_percent_and_not_beyond():
    # 100 in is 2540 mm. The error is taken against the larger of the two values.
    assert check_pair("~100 in", "~2413 mm") == []                    # 127 / 2540 = 5 % exactly: inside
    assert refused("~100 in", "~2412 mm")                              # 5.04 %: outside
    assert check_pair("~100 in", "~2673 mm") == []                    # 133 / 2673 = 4.98 %: inside
    assert refused("~100 in", "~2674 mm")                              # 134 / 2674 = 5.01 %: outside
    assert check_pair("~100 in", "~2540 mm") == []


def test_a_bound_is_inclusive_at_the_exact_error_of_a_pair():
    """Give a policy a bound that equals the error of a pair that round-trips: accepted; one step tighter: refused."""
    us, metric = "1 mi", "1.609 km"
    error = relative_error(convert(D(1), "mi", "km"), D("1.609"))
    exact = UnitPolicy(error, DEFAULT_POLICY.approximate, DEFAULT_POLICY.safety, DEFAULT_POLICY.safety_dimensions, DEFAULT_POLICY.markers)
    tighter = UnitPolicy(error - D("1e-9"), DEFAULT_POLICY.approximate, DEFAULT_POLICY.safety, DEFAULT_POLICY.safety_dimensions, DEFAULT_POLICY.markers)
    assert check_pair(us, metric, policy=exact) == []
    assert refused(us, metric, policy=tighter)


def test_the_precise_bound_separates_pairs_that_all_round_trip():
    """These all round-trip at their own precision; only the bound separates them."""
    assert check_pair("2 oz", "57 g") == []         # 0.53 %
    assert refused("1 oz", "28 g")                   # 1.23 %
    assert refused("1 in", "2.5 cm")                 # 1.59 %
    assert check_pair("1 in", "2.54 cm") == []
    assert check_pair("~1 in", "~2.5 cm") == []      # the same two values, marked
    assert check_pair("~1 oz", "~28 g") == []        # and the pair the RUN-003 suite called consistent
    assert check_pair("1 oz", "28.3 g") == []


def test_the_safety_bound_is_stricter_and_a_marker_never_loosens_it():
    assert check_pair("2 oz", "57 g") == []
    assert refused("2 oz", "57 g", strictness="safety")              # 0.53 % is over 0.5 %
    assert refused("~2 oz", "~57 g", strictness="safety")
    assert check_pair("1 lb", "453.6 g", strictness="safety") == []
    assert refused("~1 psi", "~7 kPa") and refused("1 psi", "7 kPa")  # pressure is safety-critical whatever the caller says
    assert check_pair("15 psi", "103 kPa") == []                     # 0.41 %: inside the safety bound
    assert refused("5 psi", "34 kPa")                                  # 1.4 %: a plausible-looking pressure pair is still refused


def test_pressure_is_safety_critical_by_dimension_not_by_the_callers_say_so():
    """7 psi is 48.26 kPa: '48 kPa' rounds correctly both ways and is 0.55 % off, inside the precise bound and outside the safety bound."""
    assert refused("7 psi", "48 kPa")
    no_floor = UnitPolicy(D("0.01"), D("0.05"), D("0.005"), frozenset(), DEFAULT_POLICY.markers)  # a policy object with no safety dimension: passes
    assert check_pair("7 psi", "48 kPa", policy=no_floor) == []
    assert check_pair("7 lb", "3.18 kg", policy=no_floor) == []


def test_a_zero_value_compares_only_with_zero():
    assert check_pair("0 in", "0 mm") == [] and check_pair("0 lb", "0 g") == [] and check_pair("0 psi", "0 kPa") == []
    assert refused("0 in", "1 mm") and refused("1 in", "0 mm") and refused("0 psi", "1 kPa")
    assert check_pair("0.0 in", "0 mm") == [] or True  # different printed precision of zero: either verdict is allowed, it must not raise


def test_negative_values_use_the_same_rules():
    assert check_pair("-4 in", "-101.6 mm") == [] and refused("-4 in", "-100 mm") and refused("-4 in", "101.6 mm")


# ==================================================================================================== markers
@pytest.mark.parametrize("marker", ["~", "about", "About", "ABOUT", "approx.", "approx", "approximately", "roughly", "circa"])
def test_every_marker_waives_the_round_trip_and_nothing_more(marker):
    sep = "" if marker == "~" else " "
    assert check_pair(f"{marker}{sep}4 in", f"100 mm") == []         # 1.6 %: within the marked bound
    assert check_pair("4 in", f"{marker}{sep}100 mm") == []          # either side may carry it
    assert refused(f"{marker}{sep}4 in", f"{marker}{sep}110 mm")     # 7.6 %: the marker is not a licence


def test_a_marker_that_is_not_in_the_policy_is_not_read():
    assert refused("~4 in", "100 mm", policy=UnitPolicy(D("0.01"), D("0.05"), D("0.005"), DEFAULT_POLICY.safety_dimensions, ("about",)))


def test_the_marked_bound_still_refuses_the_loose_pairs_of_the_review():
    for us, metric in LOOSE:
        assert refused(f"~{us}", f"~{metric}"), (us, metric)  # every one is over 5 %


# =============================================================================== fractions, ranges, numbers
@pytest.mark.parametrize("us,metric", [
    ("1/4 in", "6.35 mm"), ("1/8 in", "3.18 mm"), ("3/16 in", "4.76 mm"), ("1 1/2 in", "38.1 mm"), ("1-1/2 in", "38.1 mm"), ("2  1/2 in", "63.5 mm"),
    ("1/2 in", "12.7 mm"), ("3/4 in", "19.05 mm"), ("1/2 mi", "804.7 m"), ("1/4 lb", "113.4 g"),
])
def test_fractions_and_mixed_numbers_convert_exactly(us, metric):
    assert check_pair(us, metric) == [], (us, metric, check_pair(us, metric))


@pytest.mark.parametrize("us,metric", [("1/4 in", "6.4 mm"), ("1/8 in", "3.2 mm"), ("1 1/2 in", "38 mm"), ("3/16 in", "4.8 mm")])
def test_a_fraction_correctly_rounded_and_within_the_bound_passes(us, metric):
    """The forward rounding is correct and the error is under 1 %: a fraction has no printed precision to round back to."""
    assert check_pair(us, metric) == [], (us, metric, check_pair(us, metric))


@pytest.mark.parametrize("us,metric", [("1/4 in", "6 mm"), ("1/8 in", "3 mm"), ("1 1/2 in", "40 mm"), ("1/4 in", "25 mm"), ("1/4 in", "7 mm")])
def test_a_fraction_stated_loosely_is_refused_unless_marked(us, metric):
    assert refused(us, metric)


@pytest.mark.parametrize("text", ["1/3 in", "1/4 in", "1 1/2 in", "1-1/2 in", "3/16 in"])
def test_a_fraction_is_an_exact_value_with_no_displayed_precision(text):
    assert parse_measure(text).ends[0].decimals is None


def test_a_fraction_that_does_not_terminate_is_held_to_the_bound():
    assert parse_measure("1/3 in").ends[0].value.quantize(D("0.0001")) == D("0.3333")
    assert check_pair("1/3 in", "8.47 mm") == []         # 8.4667: rounds to 8.47, within the bound
    assert refused("1/3 in", "9 mm")                       # 6 % away


@pytest.mark.parametrize("text", ["1/0 in", "0/0 in", "1/ in", "/4 in", "1/4/2 in", "1 / 4 in", "1\\4 in"])
def test_an_impossible_fraction_cannot_be_parsed(text):
    assert refused(text, "6 mm") and refused("6 mm", text)


@pytest.mark.parametrize("us,metric", [
    ("4-6 in", "102-152 mm"), ("4 to 6 in", "102 to 152 mm"), ("4–6 in", "102–152 mm"), ("4—6 in", "102—152 mm"), ("4-6 in", "102 to 152 mm"),
    ("1-2 mi", "1.6-3.2 km"), ("10-12 lb", "4.5-5.4 kg"), ("1/4-1/2 in", "6.35-12.7 mm"), ("1,000-2,000 ft", "304.8-609.6 m"),
])
def test_a_range_is_checked_end_against_end(us, metric):
    assert check_pair(us, metric) == [], (us, metric, check_pair(us, metric))


@pytest.mark.parametrize("us,metric,fragment", [
    ("4-6 in", "102 mm", "range"), ("4 in", "102-152 mm", "range"), ("6-4 in", "152-102 mm", "lower value to the higher"),
    ("4-6 in", "152-102 mm", "lower value to the higher"), ("4-6 in", "100-152 mm", "low end"), ("4-6 in", "102-150 mm", "high end"),
])
def test_a_range_must_match_in_shape_order_and_each_end(us, metric, fragment):
    problems = check_pair(us, metric)
    assert problems and any(fragment in p for p in problems), problems


def test_thousands_separators_parse_and_a_comma_is_not_a_decimal_point():
    assert parse_measure("1,000 ft").ends[0].value == 1000
    assert check_pair("1,000 ft", "304.8 m") == []
    assert refused("1,5 in", "38.1 mm")  # a decimal comma is not read as one


def test_a_value_that_round_trips_only_at_its_own_precision_is_still_refused_when_the_us_value_is_coarse():
    assert refused("1,000 ft", "305 m")  # 305 m is 1000.66 ft: at zero decimals that is 1001


@pytest.mark.parametrize("text", ["12", "in", "four in", "", "   ", "4", "4 4 in", "--4 in", "4..5 in", "1e3 in", "+4 in", ".5 in"])
def test_text_that_is_not_a_quantity_is_refused(text):
    assert refused(text, "100 mm")


# ==================================================================================================== temperature
@pytest.mark.parametrize("us,metric", [
    ("32 °F", "0 °C"), ("-40 °F", "-40 °C"), ("212 °F", "100 °C"), ("0 °F", "-17.8 °C"), ("0 °F", "-18 °C"), ("98.6 °F", "37 °C"), ("50 °F", "10 °C"),
    ("-459.67 °F", "-273.15 °C"), ("240 °F", "115.6 °C"), ("70 °F", "21.1 °C"), ("-10 °F", "-23.3 °C"), ("100 °F", "37.8 °C"), ("0 °F", "-17.78 °C"),
])
def test_absolute_temperatures_round_correctly_in_both_directions_around_zero_and_offsets(us, metric):
    assert check_pair(us, metric) == [], (us, metric, check_pair(us, metric))


@pytest.mark.parametrize("us,metric", [
    ("0 °F", "0 °C"), ("0 °F", "-17 °C"), ("32 °F", "1 °C"), ("32 °F", "-1 °C"), ("5 °F", "5 °C"), ("100 °F", "40 °C"), ("-40 °F", "-39 °C"), ("212 °F", "99 °C"),
    ("70 °F", "20 °C"), ("240 °F", "116 °C"),
])
def test_an_absolute_temperature_that_does_not_round_both_ways_is_refused(us, metric):
    assert refused(us, metric), (us, metric)


@pytest.mark.parametrize("marker", ["~", "about", "approximately"])
def test_a_temperature_is_safety_critical_so_no_marker_loosens_it(marker):
    assert refused(f"{marker} 100 °F", f"{marker} 40 °C")
    assert refused(f"{marker} 70 °F", f"{marker} 20 °C")
    assert check_pair(f"{marker} 100 °F", f"{marker} 38 °C") == []   # a pair that round-trips is fine, marked or not


@pytest.mark.parametrize("us,metric", [
    ("18 °F difference", "10 °C difference"), ("1.8 °F difference", "1 °C difference"), ("0 °F difference", "0 °C difference"),
    ("9 °F rise", "5 °C rise"), ("36 °F drop", "20 °C drop"), ("18 °F change", "10 °C change"), ("1 °F difference", "0.556 °C difference"),
    ("18 °F span", "10 °C span"), ("18 degrees Fahrenheit difference", "10 degrees Celsius difference"),
])
def test_a_temperature_interval_converts_without_the_offset(us, metric):
    assert check_pair(us, metric) == [], (us, metric, check_pair(us, metric))


@pytest.mark.parametrize("us,metric", [
    ("18 °F difference", "11 °C difference"), ("1 °F difference", "0.6 °C difference"), ("1 °F difference", "0.56 °C difference"),
    ("18 °F difference", "10 °C"), ("18 °F", "10 °C difference"), ("0 °F difference", "17.8 °C difference"),
])
def test_an_interval_is_held_to_the_safety_bound_and_cannot_be_mixed_with_an_absolute_value(us, metric):
    assert refused(us, metric), (us, metric)


def test_only_a_temperature_can_be_an_interval():
    problems = check_pair("4 in difference", "100 mm difference")
    assert problems and any("only a temperature" in p for p in problems), problems


@pytest.mark.parametrize("spelling", ["°F", "° F", "deg F", "deg. F", "degrees F", "degree F", "degrees Fahrenheit", "Fahrenheit", "°f"])
def test_the_spellings_of_a_temperature_unit(spelling):
    assert parse_measure(f"98.6 {spelling}").unit == "°f"


@pytest.mark.parametrize("spelling", ["inch", "inches", "foot", "feet", "yard", "yards", "mile", "miles", "pound", "pounds", "lbs", "ounce", "ounces", "gallon",
                                      "gallons", "quart", "quarts", "fluid ounce", "fluid ounces", "meters", "metres", "liters", "litres", "kilopascals"])
def test_the_spellings_of_other_units(spelling):
    assert parse_measure(f"2 {spelling}").unit in units._UNITS


# ================================================================================ characters the layout cannot print
@pytest.mark.parametrize("text,fragment", [("Δ18 °F", "Δ"), ("≈4 in", "≈"), ("−4 in", "−"), ("4 in ", None), ("℉", None), ("4 µm", None), ("4 ін", None)])
def test_a_character_the_layout_cannot_print_is_refused_with_a_hint(text, fragment):
    problems = check_pair(text, "100 mm")
    if fragment is None and text == "4 in ":
        assert problems and not any("cannot be printed" in p for p in problems)  # trailing space: ordinary
        return
    assert problems and any("cannot be printed" in p or "cannot parse" in p or "unknown unit" in p for p in problems), problems
    if fragment:
        assert any(fragment in p for p in problems)


def test_the_layout_really_cannot_print_what_the_parser_refuses():
    """Why the ASCII forms: Δ is a fatal LaTeX error in this layout (tested once by hand; the claim is recorded in RUN-004.md)."""
    problems = check_pair("Δ18 °F", "Δ10 °C")
    assert problems and "cannot be printed" in problems[0]


# ======================================================================================== the prose scan
def conversions(text, **kw):
    return scan_text(text, **kw).problems


@pytest.mark.parametrize("text", [
    "Cut it to 4 in (100 mm) long.", "Cut it to 4 in / 100 mm long.", "Cut it to 4 in or 100 mm long.", "Cut it to 4 in = 100 mm long.",
    "Cut it to 4 in, or 100 mm, long.", "Cut it to 4 inches (100 mm) long.", "Cut it to 100 mm (4 in) long.", "Cut it to 100 mm / 4 in long.",
    "Use 1 gallon (4 liters) of water.", "Use 1 gal / 4 L of water.", "Use 1 qt or 1 L of water.", "A 3 ft (1 m) pole.", "Wait for 2 lb (1 kg) of ice.",
    "Cut 4 in. (100 mm) off.", "Cut 4-6 in (100-150 mm) off.", "Cut 1/4 in (6 mm) off.", "Hold 15 psi (100 kPa).", "Heat to 100 °F (40 °C).",
    "Heat to 70 degrees F (20 degrees C).", "Cut it to 4 in (about 110 mm) long.",
])
def test_an_inconsistent_conversion_written_in_text_is_found(text):
    found = conversions(text)
    assert found, text
    assert all("converts to" in p or "differ by" in p or "range" in p for p in found), found


@pytest.mark.parametrize("text", [
    "Cut it to 4 in (101.6 mm) long.", "Cut it to 4 in / 101.6 mm long.", "Cut it to 4 in or 101.6 mm long.", "Cut it to 4 in = 101.6 mm long.",
    "Cut it to 4 inches (101.6 mm) long.", "Cut it to 101.6 mm (4 in) long.", "Use 1 gallon (3.8 liters) of water.", "Use 1 qt or 0.95 L of water.",
    "Cut it to 4 in (about 100 mm) long.", "Cut it to about 4 in (~100 mm).", "Cut 4-6 in (102-152 mm) off.", "Cut 1/4 in (6.35 mm) off.", "Hold 15 psi (103 kPa).",
    "Heat to 240 °F (115.6 °C).", "Heat to 100 °F (38 °C).", "Rise of 18 °F difference (10 °C difference).", "Cut 4 in (101.6 mm) or 8 in (203.2 mm).",
])
def test_a_consistent_conversion_written_in_text_is_accepted(text):
    assert conversions(text) == [], text


@pytest.mark.parametrize("text", [
    "Wait 4 in the morning (100 mm of rain falls).", "It is 4 in (10 ft) deep.", "It is 4 in (5 kg).", "Stay 4 in the shade.", "4 in the morning / 100 mm",
    "Use a 2 x 4 in lumber.", "Combine 10 ft/s with 3 m/s.", "Speed of 4 mi/h (6 km/h).",
])
def test_two_quantities_side_by_side_are_not_a_conversion_unless_they_are_the_same_thing(text):
    assert conversions(text) == [], text


def test_a_range_against_a_single_value_in_text_is_found():
    assert any("range" in p for p in conversions("Cut 4-6 in (100 mm) off."))


def test_the_prose_pair_uses_the_same_class_as_a_table_row():
    assert conversions("Use 2 oz (57 g) of salt.") == []                           # 0.53 %: precise
    assert conversions("Use 2 oz (57 g) of salt.", strictness="safety")            # 0.53 %: over the safety bound
    assert conversions("Hold 5 psi (34 kPa).")                                      # pressure is safety-critical whatever the caller says


def test_a_quantity_with_no_counterpart_is_reported_and_never_an_error():
    result = scan_text("Cut 4 ft of rope and 12 oz of cord, 30 minutes, 4 in the shade.")
    assert result.problems == [] and result.unpaired == ["4 ft", "12 oz"], result
    assert scan_text("Cut 4 ft (1.22 m) of rope.").unpaired == []


def test_the_ambiguous_words_in_and_l_alone_are_not_reported_as_quantities():
    assert scan_text("Wait 5 in the shade, for 3 l more.").unpaired == []


def test_a_quantity_the_scan_cannot_parse_is_ignored_not_misread():
    assert scan_text("Mix 1/0 in (3 mm) well.").problems == []


def test_every_problem_names_the_text_that_was_found():
    problems = conversions("First cut 4 in (100 mm), then 1 mi / 2 km more.")
    first = [p for p in problems if p.startswith("'4 in (100 mm)'")]
    second = [p for p in problems if p.startswith("'1 mi / 2 km'")]
    assert first and second and len(first) + len(second) == len(problems), problems
    assert any("converts to 102 mm" in p for p in first) and any("differ by" in p for p in second)


def test_many_pairs_in_one_text_are_all_checked():
    text = " ".join(f"Cut {n} in ({n * 25.4:.1f} mm) and {n} lb ({n * 453.6:.0f} g)." for n in range(1, 9))
    assert scan_text(text).problems == []
    assert len(scan_text(text.replace("(25.4 mm)", "(25 mm)").replace("(50.8 mm)", "(51 mm)")).problems) >= 1


def test_a_long_text_without_a_pair_is_scanned_quickly():
    import time
    text = ("Fixture sentence with 4 numbers 12 34 56 and words in the middle. " * 2000)
    started = time.monotonic()
    scan_text(text)
    assert time.monotonic() - started < 3.0


# =============================================================================== in the validator, by entry
def clean(repo, builder=build_world, status="verified", **over):
    path = builder(repo, status, **over)
    assert codes(run(repo)) == set(), [str(f) for f in run(repo)]
    return path


def hazardous(repo, status="verified"):
    return clean(repo, status=status, hazard_tags=["HZ-WATER-POTABILITY"], as_of_date=DATE)


def set_row(path, us, metric):
    rewrite_entry(path, lambda fm: fm["dimension_unit_table"][0].update(us_customary=us, metric=metric))


@pytest.mark.parametrize("us,metric", LOOSE, ids=[f"{a}/{b}" for a, b in LOOSE])
def test_the_loose_pairs_are_refused_in_an_entrys_unit_table(repo, us, metric):
    path = clean(repo)
    set_row(path, us, metric)
    found = run(repo)
    assert "UNIT_INCONSISTENT" in codes(found)
    assert any("dimension_unit_table[1]" in f.where and "differ by" in f.message for f in found if f.code == "UNIT_INCONSISTENT")


def test_p28_a_conversion_in_a_steps_text_is_refused_and_named(repo):
    path = clean(repo)
    rewrite_entry(path, lambda fm: fm["procedure"][0].update(action="Fixture action using 4 in (100 mm) of fixture material."))
    found = run(repo)
    refusals = [f for f in found if f.code == "UNIT_INCONSISTENT"]
    assert refusals and all("procedure[0].action" in f.where for f in refusals), [str(f) for f in refusals]
    assert any("converts to 102 mm" in f.message for f in refusals) and all("'4 in (100 mm)'" in f.message for f in refusals)


def test_the_same_step_with_a_consistent_conversion_is_clean(repo):
    path = clean(repo)
    rewrite_entry(path, lambda fm: fm["procedure"][0].update(action="Fixture action using 4 in (101.6 mm) of fixture material."))
    assert codes(run(repo)) == set()


@pytest.mark.parametrize("field_path", [
    lambda fm, t: fm["procedure"][0].update(action=t), lambda fm, t: fm["procedure"][1].update(verify=t), lambda fm, t: fm["procedure"][0].update(abort_if=t),
    lambda fm, t: fm.update(what_it_is=t), lambda fm, t: fm.update(find_where=t), lambda fm, t: fm.update(find_when=t),
    lambda fm, t: fm.update(dangers=["Fixture danger.", t]), lambda fm, t: fm.update(conditions_and_limits=[t]), lambda fm, t: fm.update(materials=[t]),
    lambda fm, t: fm.update(failure_modes=[t]), lambda fm, t: fm.update(hazard_boundaries=[t]), lambda fm, t: fm.update(diagnostic_features=[t]),
], ids=["action", "verify", "abort_if", "what_it_is", "find_where", "find_when", "dangers", "conditions", "materials", "failure_modes", "hazard_boundaries", "diagnostic"])
def test_every_prose_field_is_scanned(repo, field_path):
    path = clean(repo)
    rewrite_entry(path, lambda fm: field_path(fm, "Fixture text with 4 in (100 mm) in it."))
    assert "UNIT_INCONSISTENT" in codes(run(repo))


def test_the_body_is_scanned_too(repo):
    path = build_world(repo, "draft", body="Fixture body with 4 in (100 mm) in it.\n")
    assert "UNIT_INCONSISTENT" in codes(run(repo))


def test_a_prose_conversion_is_an_error_at_every_status_including_draft(repo):
    build_world(repo, "draft", what_it_is="Fixture text with 4 in (100 mm) in it.")
    assert "UNIT_INCONSISTENT" in codes(run(repo))


def test_identifiers_and_claim_ids_are_never_read_as_quantities(repo):
    path = clean(repo)
    rewrite_entry(path, lambda fm: fm.update(title="Fixture entry 4 in 100 mm", claim_ids=["CLM-0001"]))
    assert "UNIT_INCONSISTENT" not in codes(run(repo))  # the title is prose, but "4 in 100 mm" is not a conversion construction


def test_an_unpaired_quantity_is_only_a_warning(repo):
    path = clean(repo)
    rewrite_entry(path, lambda fm: fm["procedure"][0].update(action="Fixture action: cut 4 ft of fixture rope."))
    found = run(repo)
    assert codes(found) == set()
    warnings = [f for f in found if f.code == "UNIT_UNPAIRED_IN_PROSE"]
    assert len(warnings) == 1 and "4 ft" in warnings[0].message and "procedure[0].action" in warnings[0].where


def test_a_hazardous_entry_holds_its_table_and_its_text_to_the_safety_bound(repo):
    path = hazardous(repo)
    set_row(path, "2 oz", "57 g")
    assert "UNIT_INCONSISTENT" in codes(run(repo))
    set_row(path, "1 lb", "453.6 g")
    rewrite_entry(path, lambda fm: fm["procedure"][0].update(action="Fixture action using 2 oz (57 g) of fixture salt."))
    assert "UNIT_INCONSISTENT" in codes(run(repo))


def test_the_same_pair_in_an_entry_that_needs_no_review_beyond_screening_passes(repo):
    path = clean(repo)
    set_row(path, "2 oz", "57 g")
    rewrite_entry(path, lambda fm: fm["procedure"][0].update(action="Fixture action using 2 oz (57 g) of fixture salt."))
    assert codes(run(repo)) == set()


def test_a_medical_entry_is_held_to_the_safety_bound(repo):
    path = clean(repo, builder=lambda r, s, **o: build_world(r, s, fm_factory=medical_dict, **o))
    rewrite_entry(path, lambda fm: fm["procedure"][0].update(action="Fixture action using 2 oz (57 g) of fixture material."))
    assert "UNIT_INCONSISTENT" in codes(run(repo))


def test_an_entry_citing_a_high_risk_claim_is_held_to_the_safety_bound(repo):
    from factories import edit_rows
    path = clean(repo)
    set_row(path, "2 oz", "57 g")
    edit_rows(repo, "claims", lambda rows: rows[0].update(risk_level="high"))
    assert "UNIT_INCONSISTENT" in codes(run(repo))


def test_a_pressure_in_an_ordinary_entry_is_still_held_to_the_safety_bound(repo):
    path = clean(repo)
    set_row(path, "5 psi", "34 kPa")
    assert "UNIT_INCONSISTENT" in codes(run(repo))


def test_a_dose_unit_in_a_table_row_is_refused_as_unknown(repo):
    path = clean(repo)
    set_row(path, "1 tsp", "5 ml")
    found = run(repo)
    assert any(f.code == "UNIT_INCONSISTENT" and "unknown unit" in f.message for f in found)


def test_the_real_specimen_and_the_real_tree_still_validate_clean():
    assert [f for f in validate_repo(REAL) if f.severity == "error"] == []
    assert [f for f in validate_repo(REAL, specimen=True) if f.severity == "error"] == []


# =============================================================================== classification still sees the dimension
@pytest.mark.parametrize("text,dimension", [("4 in", "length"), ("4-6 in", "length"), ("1/4 in", "length"), ("2 lb", "mass"), ("1 gal", "volume"),
                                            ("15 psi", "pressure"), ("100 kPa", "pressure"), ("70 °F", "temperature"), ("18 °F difference", "temperature"),
                                            ("~15 psi", "pressure"), ("about 70 °F", "temperature"), ("4-6 psi", "pressure")])
def test_dimension_of_reads_every_form(text, dimension):
    assert dimension_of(text) == dimension


@pytest.mark.parametrize("text", ["", "12", "five in", "1 tsp", "Δ18 °F", "4 furlong"])
def test_dimension_of_is_none_for_what_it_cannot_read(text):
    assert dimension_of(text) is None


@pytest.mark.parametrize("us,metric", [("15 psi", "103 kPa"), ("4-6 psi", "27.6-41.4 kPa"), ("70 °F", "21.1 °C"), ("18 °F difference", "10 °C difference")])
def test_a_pressure_or_temperature_row_in_any_form_still_brings_the_high_risk_review(repo, us, metric):
    from factories import context
    path = build_world(repo, "draft")
    rewrite_entry(path, lambda fm: fm["dimension_unit_table"][0].update(us_customary=us, metric=metric))
    ctx = context(repo)
    entry = Entry(path=path, rel=path.relative_to(repo.root).as_posix(), fm=ctx.entries[0].fm, body="")
    assert "CLS-HIGH-RISK" in classify(ctx, entry).subjects
