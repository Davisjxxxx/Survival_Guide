"""Independent, registered, current, order-aware safety reviews (GA-001, GA-002, FR-002, FR-004, FR-005).

This file replaces tests/test_safety_review_independence.py. Every scenario of its 92 tests is here, restated for the registry model:

  * a row names a REGISTERED reviewer; the owner (`user`) is the registry's owner and satisfies neither class;
  * `domain_expert` is now a registered HUMAN external_sme. RUN-002 also accepted technical_reviewer (decision D13, tests 02 and 04 below);
  * a failure is cleared only by an explicit resolution, never by a later pass (tests 07 and 09 replace the RUN-002 tests that asserted the
    opposite: typed dates and record position deciding, a failure on one topic blocking only that topic, new passes alone restoring
    eligibility). Those RUN-002 tests passed while asserting the defect (FABLE-REVIEW-001 FR-002, FR-003, FR-004).

Each test name starts with the number of the required test it reproduces.
"""
from __future__ import annotations

import pytest

import yaml

from factories import (
    DATE, REAL, ROLE_IDENTITY, add_approval, add_resolution, add_safety, add_safety_pair, append_row, approval_row, build_world, codes, edit_rows,
    medical_dict, register, rewrite_entry, tamper, write_rows,
)
from sfe.classify import load_classification_policy
from sfe.common import load_yaml
from sfe.registry import Repo, load_hazards, load_review_policy
from sfe.validate import validate_repo

TOPICS = [t["id"] for t in load_yaml((REAL / "schemas/hazard_topics.yaml").read_text(encoding="utf-8"))["topics"]]
FAILER_ROLES = ["technical_reviewer", "external_sme", "chatgpt_editorial", "user"]
W, CO, SPARK, LEGAL, FOOD = "HZ-WATER-POTABILITY", "HZ-COMBUSTION-CO", "HZ-IGNITION-SPARK", "HZ-HARVEST-LEGAL", "HZ-FOOD-PRESERVATION"


def run(repo):
    return validate_repo(repo.root)


def tagged(repo, topics, status="approved"):
    """An entry tagged with `topics` and its editorial approval, but NO safety review: the tests record their own."""
    path = build_world(repo, status, hazard_tags=list(topics), as_of_date=DATE)
    write_rows(repo, "safety_audit", [])
    return path


MEDICAL = ["CLS-MEDICAL", "CLS-HIGH-RISK"]  # a medical entry's zone (Z10) is Critical, so the high-risk floor applies as well


def medical(repo, **over):
    path = build_world(repo, "approved", fm_factory=medical_dict, **over)
    write_rows(repo, "safety_audit", [])
    return path


def msgs(found, code, subject=None):
    return [f.message for f in found if f.code == code and (subject is None or f.message.startswith(subject + ":"))]


def passes(repo):
    found = run(repo)
    assert codes(found) == set(), [str(f) for f in found]
    return found


def resolve(repo, failure):
    """The adjudicator clears an adverse row, linking evidence."""
    return add_resolution(repo, "safety_audit", failure["audit_id"])


# ----------------------------------------------------------------------------- 1. user-only
@pytest.mark.parametrize("topic", TOPICS)
def test_01_user_only_audit_fails(repo, topic):
    path = tagged(repo, [topic])
    add_safety(repo, path, [topic], role="user")
    found = run(repo)
    assert "SAFETY_REVIEW_ROLE_MISSING" in codes(found)
    text = " ".join(msgs(found, "SAFETY_REVIEW_ROLE_MISSING", topic))
    assert "domain_expert" in text and "chatgpt_validation" in text, "an owner audit must satisfy NEITHER specialist review"


def test_01_two_user_audits_still_fail(repo):
    path = tagged(repo, [W])
    add_safety(repo, path, [W], role="user", reviewer="Owner A")
    add_safety(repo, path, [W], role="user", reviewer="Owner B")
    assert "SAFETY_REVIEW_ROLE_MISSING" in codes(run(repo))


def test_01_a_user_audit_adds_nothing_to_a_genuine_one_sided_review(repo):
    path = tagged(repo, [CO])
    add_safety(repo, path, [CO], role="external_sme")
    add_safety(repo, path, [CO], role="user")
    found = run(repo)
    assert "SAFETY_REVIEW_ROLE_MISSING" in codes(found)
    assert "chatgpt_validation" in " ".join(msgs(found, "SAFETY_REVIEW_ROLE_MISSING"))


# ------------------------------------------------------------------------ 2. domain expert only
@pytest.mark.parametrize("topic", TOPICS)
def test_02_external_sme_only_audit_fails(repo, topic):
    path = tagged(repo, [topic])
    add_safety(repo, path, [topic], role="external_sme")
    text = " ".join(msgs(run(repo), "SAFETY_REVIEW_ROLE_MISSING", topic))
    assert "chatgpt_validation" in text and "domain_expert" not in text


@pytest.mark.parametrize("topic", TOPICS)
def test_02_a_technical_reviewer_is_not_the_domain_expert(repo, topic):
    """D13. RUN-002 let technical_reviewer fill domain_expert. A domain expert is now a registered human external_sme, so a technical
    reviewer alone leaves BOTH classes missing."""
    path = tagged(repo, [topic])
    add_safety(repo, path, [topic], role="technical_reviewer")
    text = " ".join(msgs(run(repo), "SAFETY_REVIEW_ROLE_MISSING", topic))
    assert "domain_expert" in text and "chatgpt_validation" in text


def test_02_two_domain_experts_are_still_one_review_class(repo):
    path = tagged(repo, [SPARK])
    add_safety(repo, path, [SPARK], role="external_sme", reviewer="Expert A")
    add_safety(repo, path, [SPARK], role="external_sme", reviewer="Expert B")
    assert "chatgpt_validation" in " ".join(msgs(run(repo), "SAFETY_REVIEW_ROLE_MISSING"))


# ----------------------------------------------------------------------------- 3. ChatGPT only
@pytest.mark.parametrize("topic", TOPICS)
def test_03_chatgpt_only_audit_fails(repo, topic):
    path = tagged(repo, [topic])
    add_safety(repo, path, [topic], role="chatgpt_editorial")
    text = " ".join(msgs(run(repo), "SAFETY_REVIEW_ROLE_MISSING", topic))
    assert "domain_expert" in text and "chatgpt_validation" not in text


def test_03_two_chatgpt_validations_never_stand_in_for_the_domain_expert(repo):
    """The brief: ChatGPT editorial review cannot substitute for the required external subject-matter expert, however many there are."""
    path = tagged(repo, [W])
    add_safety(repo, path, [W], role="chatgpt_editorial", reviewer="Fixture ChatGPT Editorial")
    add_safety(repo, path, [W], role="chatgpt_editorial", reviewer="Fixture Second Validator")
    text = " ".join(msgs(run(repo), "SAFETY_REVIEW_ROLE_MISSING", W))
    assert "domain_expert" in text and "chatgpt_validation" not in text


# ------------------------------------------------------------------ 4. two independent reviews pass
@pytest.mark.parametrize("topic", TOPICS)
def test_04_two_valid_independent_reviews_pass(repo, topic):
    path = tagged(repo, [topic])
    add_safety_pair(repo, path, [topic])
    found = passes(repo)
    assert not [f for f in found if f.code.startswith("SAFETY_")]


@pytest.mark.parametrize("topic", TOPICS)
def test_04_a_technical_reviewer_cannot_make_the_pair(repo, topic):
    path = tagged(repo, [topic])
    add_safety_pair(repo, path, [topic], domain_role="technical_reviewer")
    assert "domain_expert" in " ".join(msgs(run(repo), "SAFETY_REVIEW_ROLE_MISSING", topic))


def test_04_row_order_does_not_matter_when_nothing_is_adverse(repo):
    path = tagged(repo, [W])
    add_safety(repo, path, [W], role="chatgpt_editorial", reviewer="Fixture ChatGPT Editorial")
    add_safety(repo, path, [W], role="external_sme", reviewer="Fixture Domain Expert")
    passes(repo)


# ----------------------------------------------------------------- 5. PASS then later FAIL fails
@pytest.mark.parametrize("failer", FAILER_ROLES)
def test_05_earlier_pass_followed_by_later_fail_fails(repo, failer):
    path = tagged(repo, [W])
    add_safety_pair(repo, path, [W])
    passes(repo)  # eligible until the failure is recorded
    add_safety(repo, path, [W], role=failer, decision="fail", reviewer="Late Failer")
    found = run(repo)
    assert "SAFETY_FAILURE_UNRESOLVED" in codes(found)
    text = " ".join(msgs(found, "SAFETY_FAILURE_UNRESOLVED"))
    assert "fail" in text and ROLE_IDENTITY[failer][1] in text


@pytest.mark.parametrize("topic", TOPICS)
def test_05_every_topic_is_blocked_by_a_later_fail(repo, topic):
    path = tagged(repo, [topic])
    add_safety_pair(repo, path, [topic])
    add_safety(repo, path, [topic], role="technical_reviewer", decision="fail")
    assert "SAFETY_FAILURE_UNRESOLVED" in codes(run(repo))


# ------------------------------------------------------------- 6. PASS then CONDITIONAL fails
@pytest.mark.parametrize("failer", FAILER_ROLES)
def test_06_earlier_pass_followed_by_later_conditional_fails(repo, failer):
    path = tagged(repo, [FOOD])
    add_safety_pair(repo, path, [FOOD])
    add_safety(repo, path, [FOOD], role=failer, decision="conditional", reviewer="Late Conditional")
    found = run(repo)
    assert "SAFETY_FAILURE_UNRESOLVED" in codes(found)
    assert "conditional" in " ".join(msgs(found, "SAFETY_FAILURE_UNRESOLVED"))


# ---------------------------------------------- 7. remediation needs a resolution AND new passes
def failed_entry(repo, topic=LEGAL, failer="technical_reviewer"):
    path = tagged(repo, [topic])
    add_safety_pair(repo, path, [topic])
    failure = add_safety(repo, path, [topic], role=failer, decision="fail", reviewer="The Failer")
    return path, topic, failure


def test_07_the_old_passes_do_not_restore_eligibility(repo):
    failed_entry(repo)
    assert "SAFETY_FAILURE_UNRESOLVED" in codes(run(repo))


def test_07_new_passes_alone_do_not_restore_eligibility(repo):
    """Replaces RUN-002's 'two new independent passes restore eligibility': without an explicit resolution the failure stands (FR-004)."""
    path, topic, _ = failed_entry(repo)
    add_safety_pair(repo, path, [topic])
    assert "SAFETY_FAILURE_UNRESOLVED" in codes(run(repo))


def test_07_after_a_resolution_the_old_passes_still_do_not_count(repo):
    path, topic, failure = failed_entry(repo)
    resolve(repo, failure)
    found = run(repo)
    assert "SAFETY_FAILURE_UNRESOLVED" not in codes(found) and "SAFETY_AUDIT_SUPERSEDED" in codes(found)
    text = " ".join(msgs(found, "SAFETY_AUDIT_SUPERSEDED", topic))
    assert "domain_expert" in text and "chatgpt_validation" in text


def test_07_after_a_resolution_one_new_pass_is_not_enough(repo):
    path, topic, failure = failed_entry(repo)
    resolve(repo, failure)
    add_safety(repo, path, [topic], role="external_sme", reviewer="Fixed Expert")
    text = " ".join(msgs(run(repo), "SAFETY_AUDIT_SUPERSEDED", topic))
    assert text and "chatgpt_validation" in text and "domain_expert" not in text.split("needs")[-1]


def test_07_after_a_resolution_the_other_single_new_pass_is_not_enough_either(repo):
    path, topic, failure = failed_entry(repo)
    resolve(repo, failure)
    add_safety(repo, path, [topic], role="chatgpt_editorial", reviewer="Fixed ChatGPT")
    text = " ".join(msgs(run(repo), "SAFETY_AUDIT_SUPERSEDED", topic))
    assert "domain_expert" in text.split("needs")[-1]


def test_07_a_resolution_and_two_new_independent_passes_restore_eligibility(repo):
    path, topic, failure = failed_entry(repo)
    resolve(repo, failure)
    add_safety_pair(repo, path, [topic])
    passes(repo)


def test_07_passes_recorded_before_the_resolution_do_not_count(repo):
    """Reapproval must FOLLOW the resolution: a pair recorded between the failure and its resolution is superseded by the resolution."""
    path, topic, failure = failed_entry(repo)
    add_safety_pair(repo, path, [topic])
    resolve(repo, failure)
    assert "SAFETY_AUDIT_SUPERSEDED" in codes(run(repo))
    add_safety_pair(repo, path, [topic])
    passes(repo)


def test_07_new_passes_by_the_wrong_roles_do_not_restore_eligibility(repo):
    path, topic, failure = failed_entry(repo)
    resolve(repo, failure)
    add_safety(repo, path, [topic], role="user", reviewer="Owner One")
    add_safety(repo, path, [topic], role="user", reviewer="Owner Two")
    assert codes(run(repo)) & {"SAFETY_AUDIT_SUPERSEDED", "SAFETY_REVIEW_ROLE_MISSING"}


def test_07_a_pass_recorded_after_the_failure_does_not_clear_it_whatever_its_date(repo):
    """Replaces 'passes dated before the failure never count even if recorded later': the date no longer decides anything.
    A pair recorded after the failure, under ANY date, leaves it standing; a date that goes backwards is an error of its own."""
    path = tagged(repo, [W])
    add_safety(repo, path, [W], role="external_sme", decision="fail", reviewer="F", reviewed_on="2026-01-20")
    add_safety_pair(repo, path, [W], reviewed_on="2026-01-16")
    found = codes(run(repo))
    assert "SAFETY_FAILURE_UNRESOLVED" in found and "LEDGER_DATE_REGRESSION" in found


def test_07_same_day_passes_recorded_after_a_failure_do_not_clear_it(repo):
    """Replaces 'same-day order is the record order' (a failure followed by same-day passes restored eligibility)."""
    path = tagged(repo, [CO])
    add_safety(repo, path, [CO], role="technical_reviewer", decision="fail", reviewer="F")
    add_safety_pair(repo, path, [CO])
    assert "SAFETY_FAILURE_UNRESOLVED" in codes(run(repo))


def test_07_same_day_failure_recorded_last_blocks(repo):
    path = tagged(repo, [CO])
    add_safety_pair(repo, path, [CO])
    add_safety(repo, path, [CO], role="chatgpt_editorial", decision="fail", reviewer="F")
    assert "SAFETY_FAILURE_UNRESOLVED" in codes(run(repo))


def test_07_a_second_failure_after_remediation_blocks_again(repo):
    path, topic, failure = failed_entry(repo)
    resolve(repo, failure)
    add_safety_pair(repo, path, [topic])
    passes(repo)
    add_safety(repo, path, [topic], role="external_sme", decision="conditional", reviewer="Second Look")
    assert "SAFETY_FAILURE_UNRESOLVED" in codes(run(repo))


# ----------------------------------------------------------------------------- 8. stale hashes
def test_08_a_pair_bound_to_the_wrong_hash_fails(repo):
    path = tagged(repo, [W])
    add_safety_pair(repo, path, [W], package_sha256="0" * 64)
    assert "SAFETY_AUDIT_NOT_PASSING_OR_STALE" in codes(run(repo))


def test_08_editing_the_entry_after_review_makes_both_reviews_stale(repo):
    path = tagged(repo, [W])
    add_safety_pair(repo, path, [W])
    passes(repo)
    rewrite_entry(path, lambda fm: fm.update(title="Fixture entry, edited after review"))
    found = codes(run(repo))
    assert "SAFETY_AUDIT_NOT_PASSING_OR_STALE" in found and "APPROVAL_STALE" in found


def test_08_one_stale_review_leaves_that_role_missing(repo):
    path = tagged(repo, [W])
    add_safety(repo, path, [W], role="external_sme", reviewer="Current Expert")
    add_safety(repo, path, [W], role="chatgpt_editorial", reviewer="Stale ChatGPT", package_sha256="f" * 64)
    text = " ".join(msgs(run(repo), "SAFETY_REVIEW_ROLE_MISSING", W))
    assert "chatgpt_validation" in text and "domain_expert" not in text


def test_08_reviews_of_another_revision_do_not_count(repo):
    path = tagged(repo, [W])
    add_safety_pair(repo, path, [W], revision=2)
    assert "SAFETY_AUDIT_MISSING" in codes(run(repo))


def test_08_a_failure_recorded_against_this_revision_stays_in_force_even_if_bound_to_older_content(repo):
    """Fail closed: after a failure only newer passes for the CURRENT content, after a resolution, may restore eligibility."""
    path = tagged(repo, [W])
    add_safety_pair(repo, path, [W])
    add_safety(repo, path, [W], role="technical_reviewer", decision="fail", reviewer="F", package_sha256="a" * 64)
    assert "SAFETY_FAILURE_UNRESOLVED" in codes(run(repo))


# ------------------------------------------------------------------ 9. multiple hazard topics
def test_09_every_topic_must_be_covered(repo):
    a, b, c = SPARK, CO, W
    path = tagged(repo, [a, b, c])
    add_safety_pair(repo, path, [a, b])
    found = run(repo)
    assert len(msgs(found, "SAFETY_TOPIC_UNCOVERED")) == 1 and c in msgs(found, "SAFETY_TOPIC_UNCOVERED")[0]


def test_09_each_topic_needs_both_roles_not_just_some_rows(repo):
    a, b = SPARK, CO
    path = tagged(repo, [a, b])
    add_safety(repo, path, [a, b], role="external_sme", reviewer="Expert")
    add_safety(repo, path, [a], role="chatgpt_editorial", reviewer="ChatGPT")  # does not cover b
    found = run(repo)
    assert msgs(found, "SAFETY_REVIEW_ROLE_MISSING", b) and not msgs(found, "SAFETY_REVIEW_ROLE_MISSING", a)
    assert "chatgpt_validation" in msgs(found, "SAFETY_REVIEW_ROLE_MISSING", b)[0]


def test_09_one_pair_covering_all_topics_passes(repo):
    topics = [SPARK, CO, W]
    path = tagged(repo, topics)
    add_safety_pair(repo, path, topics)
    passes(repo)


def test_09_separate_pairs_per_topic_also_pass(repo):
    a, b = SPARK, CO
    path = tagged(repo, [a, b])
    add_safety_pair(repo, path, [a])
    add_safety_pair(repo, path, [b])
    passes(repo)


def test_09_a_failure_on_one_topic_blocks_the_whole_entry(repo):
    """Replaces 'a failure on one topic blocks only that topic': a failure blocks the ENTRY (FR-002), so no topic can ride past it."""
    a, b = SPARK, CO
    path = tagged(repo, [a, b])
    add_safety_pair(repo, path, [a, b])
    add_safety(repo, path, [b], role="technical_reviewer", decision="fail", reviewer="F")
    found = run(repo)
    assert "SAFETY_FAILURE_UNRESOLVED" in codes(found)


def test_09_after_a_resolution_every_topic_needs_new_passes(repo):
    """Replaces 'remediating only the failed topic restores eligibility'. The failure stood for the whole entry, so after the resolution
    BOTH topics need passes recorded after it."""
    a, b = SPARK, CO
    path = tagged(repo, [a, b])
    add_safety_pair(repo, path, [a, b])
    failure = add_safety(repo, path, [b], role="technical_reviewer", decision="fail", reviewer="F")
    resolve(repo, failure)
    add_safety_pair(repo, path, [b])
    found = run(repo)
    assert msgs(found, "SAFETY_AUDIT_SUPERSEDED", a) and not msgs(found, "SAFETY_AUDIT_SUPERSEDED", b)
    add_safety_pair(repo, path, [a])
    passes(repo)


def test_09_a_failure_covering_two_topics_blocks_the_entry_and_supersedes_both(repo):
    a, b = SPARK, CO
    path = tagged(repo, [a, b])
    add_safety_pair(repo, path, [a, b])
    failure = add_safety(repo, path, [a, b], role="external_sme", decision="conditional", reviewer="F")
    assert "SAFETY_FAILURE_UNRESOLVED" in codes(run(repo))
    resolve(repo, failure)
    found = run(repo)
    assert msgs(found, "SAFETY_AUDIT_SUPERSEDED", a) and msgs(found, "SAFETY_AUDIT_SUPERSEDED", b)


def test_09_all_six_topics_at_once(repo):
    path = tagged(repo, TOPICS)
    add_safety_pair(repo, path, TOPICS)
    passes(repo)
    # drop ONE topic from the ChatGPT review: exactly that topic must now fail, and only for the ChatGPT class
    victim = TOPICS[3]
    edit_rows(repo, "safety_audit", lambda r: r[1].update(subjects="|".join(t for t in TOPICS if t != victim)))
    found = run(repo)
    assert [m for m in msgs(found, "SAFETY_REVIEW_ROLE_MISSING") if m.startswith(victim + ":")]
    assert not [m for m in msgs(found, "SAFETY_REVIEW_ROLE_MISSING") if not m.startswith(victim + ":")]
    assert all("chatgpt_validation" in m for m in msgs(found, "SAFETY_REVIEW_ROLE_MISSING"))


# ----------------------------------------------------------- 10. medical guidance without tags
def test_10_medical_guidance_without_any_audit_is_missing(repo):
    medical(repo)
    assert "SAFETY_AUDIT_MISSING" in codes(run(repo))


def test_10_a_pair_of_passes_that_lists_no_subject_covers_nothing(repo):
    """RUN-002's medical tests accepted two rows with an empty topic list, because for medical guidance every row counted. A pass covers exactly
    the subjects it lists (FR-001): the same two rows, listing nothing, leave every required subject uncovered."""
    path = build_world(repo, "approved", fm_factory=medical_dict, reviews=False)
    add_approval(repo, path)
    add_safety_pair(repo, path, [])
    found = [f for f in run(repo) if f.code == "SAFETY_TOPIC_UNCOVERED"]
    assert {f.message.split(":")[0] for f in found} == {"CLS-MEDICAL", "CLS-HIGH-RISK"}


def test_10_medical_user_only_audit_fails(repo):
    path = medical(repo)
    add_safety(repo, path, ["CLS-MEDICAL"], role="user")
    found = run(repo)
    text = " ".join(msgs(found, "SAFETY_REVIEW_ROLE_MISSING", "CLS-MEDICAL"))
    assert "domain_expert" in text and "chatgpt_validation" in text


@pytest.mark.parametrize("role,missing", [("external_sme", "chatgpt_validation"), ("chatgpt_editorial", "domain_expert"),
                                          ("technical_reviewer", "domain_expert")])
def test_10_medical_single_role_audit_fails(repo, role, missing):
    path = medical(repo)
    add_safety(repo, path, ["CLS-MEDICAL"], role=role)
    assert missing in " ".join(msgs(run(repo), "SAFETY_REVIEW_ROLE_MISSING", "CLS-MEDICAL"))


def test_10_medical_with_both_independent_reviews_passes(repo):
    path = medical(repo)
    add_safety_pair(repo, path, MEDICAL)
    passes(repo)


def test_10_medical_pass_then_later_fail_fails(repo):
    path = medical(repo)
    add_safety_pair(repo, path, ["CLS-MEDICAL"])
    add_safety(repo, path, ["CLS-MEDICAL"], role="technical_reviewer", decision="fail", reviewer="F")
    assert "SAFETY_FAILURE_UNRESOLVED" in codes(run(repo))


def test_10_medical_remediation_needs_a_resolution_and_both_new_passes(repo):
    path = medical(repo)
    add_safety_pair(repo, path, MEDICAL)
    failure = add_safety(repo, path, MEDICAL, role="chatgpt_editorial", decision="conditional", reviewer="F")
    add_safety(repo, path, MEDICAL, role="chatgpt_editorial", reviewer="New ChatGPT")
    assert "SAFETY_FAILURE_UNRESOLVED" in codes(run(repo)), "a new pass does not clear a conditional"
    resolve(repo, failure)
    add_safety(repo, path, MEDICAL, role="chatgpt_editorial", reviewer="Newer ChatGPT")
    assert "SAFETY_AUDIT_SUPERSEDED" in codes(run(repo))
    add_safety(repo, path, MEDICAL, role="external_sme", reviewer="New Expert")
    passes(repo)


def test_10_medical_stale_hash_fails(repo):
    path = medical(repo)
    add_safety_pair(repo, path, ["CLS-MEDICAL"], package_sha256="0" * 64)
    assert "SAFETY_AUDIT_NOT_PASSING_OR_STALE" in codes(run(repo))


def test_10_medical_with_tags_needs_the_topic_reviews_and_the_medical_review(repo):
    path = medical(repo, hazard_tags=[W], as_of_date=DATE)
    add_safety(repo, path, [W], role="external_sme", reviewer="Expert")
    found = run(repo)
    assert msgs(found, "SAFETY_REVIEW_ROLE_MISSING", W) and msgs(found, "SAFETY_TOPIC_UNCOVERED", "CLS-MEDICAL")
    add_safety(repo, path, [W, *MEDICAL], role="chatgpt_editorial", reviewer="ChatGPT")
    add_safety(repo, path, [W, *MEDICAL], role="external_sme", reviewer="Expert")
    passes(repo)


# --------------------------------------------------------- the ChatGPT editorial APPROVAL ledger too
def test_user_only_approval_never_satisfies_the_chatgpt_editorial_requirement(repo):
    build_world(repo, "approved")
    edit_rows(repo, "approvals", lambda rows: rows[0].update(reviewer_id="REV-0001", capacity="registrar"))
    assert "APPROVAL_NOT_CHATGPT_EDITORIAL" in codes(run(repo))


# --------------------------------------------------------------------------------- determinism
def test_the_verdict_is_deterministic_and_independent_of_run_order(repo):
    path = tagged(repo, [W])
    add_safety_pair(repo, path, [W])
    add_safety(repo, path, [W], role="technical_reviewer", decision="fail", reviewer="F")
    first = [str(f) for f in run(repo)]
    assert first == [str(f) for f in run(repo)]


def test_a_reordered_ledger_is_rejected_not_reinterpreted(repo):
    """Replaces 'rows with different dates give the same verdict in any file order'. File order is not a thing a verdict may depend on:
    a reordered ledger is refused outright (FR-003)."""
    path = tagged(repo, [W])
    add_safety_pair(repo, path, [W])
    add_safety(repo, path, [W], role="technical_reviewer", decision="fail", reviewer="F")
    tamper(repo, "safety_audit", lambda lines: [lines[0]] + lines[:0:-1])
    assert "LEDGER_SEQUENCE_BROKEN" in codes(run(repo))


# ======================================================================== 11. identity and independence (FR-005)
def test_11_an_unregistered_reviewer_does_not_count(repo):
    path = tagged(repo, [W])
    add_safety(repo, path, [W], role="external_sme", reviewer_id="REV-0099")
    add_safety(repo, path, [W], role="chatgpt_editorial")
    found = run(repo)
    assert "REVIEWER_NOT_REGISTERED" in " ".join(msgs(found, "SAFETY_REVIEW_ROLE_MISSING", W))
    assert "domain_expert" in " ".join(msgs(found, "SAFETY_REVIEW_ROLE_MISSING", W))


def test_11_a_capacity_the_registry_never_granted_establishes_nothing(repo):
    """The row says external_sme; the registry says REV-0003 is an AI with chatgpt_editorial only. The row's own words count for nothing."""
    path = tagged(repo, [W])
    add_safety(repo, path, [W], role="external_sme", reviewer_id="REV-0003")
    add_safety(repo, path, [W], role="chatgpt_editorial")
    assert "REVIEWER_CAPACITY_NOT_REGISTERED" in " ".join(msgs(run(repo), "SAFETY_REVIEW_ROLE_MISSING", W))


def test_11_a_model_cannot_claim_the_chatgpt_capacity_of_a_person_or_the_reverse(repo):
    path = tagged(repo, [W])
    add_safety(repo, path, [W], role="chatgpt_editorial", reviewer_id="REV-0004")  # the human expert claims the ChatGPT capacity
    add_safety(repo, path, [W], role="external_sme")
    found = run(repo)
    assert "REVIEWER_CAPACITY_NOT_REGISTERED" in " ".join(msgs(found, "SAFETY_REVIEW_ROLE_MISSING", W))


def test_11_models_labelled_as_a_domain_expert_do_not_make_the_pair(repo):
    """P09: two AI model labels filled both classes at RUN-002. An AI can be registered as a technical_reviewer, but never as the external expert."""
    path = tagged(repo, [W])
    register(repo, "REV-0010", "technical_reviewer", kind="ai_model", name="GPT-6 High", domains=[W], evidence="Fixture model card")
    add_safety(repo, path, [W], role="technical_reviewer", reviewer_id="REV-0010")
    add_safety(repo, path, [W], role="chatgpt_editorial", reviewer="GPT-6 Extra High")
    assert "domain_expert" in " ".join(msgs(run(repo), "SAFETY_REVIEW_ROLE_MISSING", W))


def test_11_one_person_cannot_hold_both_the_human_and_the_chatgpt_capacity(repo):
    """P09b: one identity in both classes. The registry refuses it, and the row that tries is not counted."""
    path = tagged(repo, [W])
    register(repo, "REV-0004", "chatgpt_editorial", kind="human", name="Fixture Domain Expert", domains=["ALL"])
    add_safety(repo, path, [W], role="external_sme", reviewer_id="REV-0004")
    add_safety(repo, path, [W], role="chatgpt_editorial", reviewer_id="REV-0004")
    found = codes(run(repo))
    assert "REGISTRY_KIND_CAPACITY" in found and "SAFETY_REVIEW_ROLE_MISSING" in found


def test_11_two_ids_cannot_share_one_name(repo):
    register(repo, "REV-0010", "external_sme", kind="human", name="fixture domain  expert", domains=[W], evidence="x")
    assert "REGISTRY_NAME_DUPLICATE" in codes(run(repo))


def test_11_a_revoked_reviewer_no_longer_counts_even_for_earlier_reviews(repo):
    path = tagged(repo, [W])
    add_safety_pair(repo, path, [W])
    passes(repo)
    register(repo, "REV-0004", "external_sme", kind="human", name="Fixture Domain Expert", action="revoke", revokes="REG-0004")
    found = run(repo)
    assert "REVIEWER_REVOKED" in " ".join(msgs(found, "SAFETY_REVIEW_ROLE_MISSING", W)), "revocation is retroactive for counting"


def test_11_a_registration_made_after_the_review_does_not_validate_it(repo):
    """Registering a reviewer after the fact must not turn an earlier row into a valid one."""
    path = tagged(repo, [W])
    register(repo, "REV-0010", "external_sme", kind="human", name="Late Registered Expert", domains=[W], evidence="Fixture credential", on="2026-03-01")
    add_safety(repo, path, [W], role="external_sme", reviewer_id="REV-0010")  # recorded on 2026-01-15, before the registration
    add_safety(repo, path, [W], role="chatgpt_editorial")
    assert "REVIEWER_NOT_VALID_ON_DATE" in " ".join(msgs(run(repo), "SAFETY_REVIEW_ROLE_MISSING", W))


def test_11_an_expired_registration_does_not_count(repo):
    path = tagged(repo, [W])
    register(repo, "REV-0010", "external_sme", kind="human", name="Short Term Expert", domains=[W], evidence="Fixture credential", until="2026-01-31")
    add_safety(repo, path, [W], role="external_sme", reviewer_id="REV-0010", reviewed_on="2026-02-15")
    add_safety(repo, path, [W], role="chatgpt_editorial", reviewed_on="2026-02-15")
    assert "REVIEWER_NOT_VALID_ON_DATE" in " ".join(msgs(run(repo), "SAFETY_REVIEW_ROLE_MISSING", W))


def test_11_a_reviewer_outside_their_registered_domains_does_not_count(repo):
    path = tagged(repo, [SPARK])
    register(repo, "REV-0010", "external_sme", kind="human", name="Water Only Expert", domains=[W], evidence="Fixture credential")
    add_safety(repo, path, [SPARK], role="external_sme", reviewer_id="REV-0010")
    add_safety(repo, path, [SPARK], role="chatgpt_editorial")
    assert "REVIEWER_DOMAIN_NOT_COVERED" in " ".join(msgs(run(repo), "SAFETY_REVIEW_ROLE_MISSING", SPARK))


def test_11_a_reviewer_registered_for_the_subject_does_count(repo):
    path = tagged(repo, [SPARK])
    register(repo, "REV-0010", "external_sme", kind="human", name="Ignition Expert", domains=[SPARK], evidence="Fixture credential")
    add_safety(repo, path, [SPARK], role="external_sme", reviewer_id="REV-0010")
    add_safety(repo, path, [SPARK], role="chatgpt_editorial")
    passes(repo)


def test_11_the_author_cannot_review_their_own_entry(repo):
    path = tagged(repo, [W])
    register(repo, "REV-0004", "author", kind="human", name="Fixture Domain Expert")
    rewrite_entry(path, lambda fm: fm.update(authored_by="REV-0004"))
    add_approval(repo, path)  # the entry changed, so approve it again as it now stands
    add_safety_pair(repo, path, [W])
    found = run(repo)
    assert "REVIEWER_IS_AUTHOR" in " ".join(msgs(found, "SAFETY_REVIEW_ROLE_MISSING", W))


def test_11_the_same_identity_cannot_fill_two_classes_of_one_subject(repo):
    """Defence in depth. The policy validation keeps the classes of one subject disjoint, so this can only happen if a class definition
    is changed; the gate still refuses it."""
    path_policy = repo.path("schemas/hazard_topics.yaml")
    data = yaml.safe_load(path_policy.read_text(encoding="utf-8"))
    data["review_policy"]["classes"]["peer_expert"] = {"capacities": ["technical_reviewer"], "kinds": ["human"], "specialty_domains": False}
    for topic in data["topics"]:
        if topic["id"] == W:
            topic["required_reviews"] = ["domain_expert", "chatgpt_validation", "peer_expert"]
    path_policy.write_text(yaml.safe_dump(data, sort_keys=False), encoding="utf-8")
    register(repo, "REV-0004", "technical_reviewer", kind="human", name="Fixture Domain Expert", domains=[W], evidence="Fixture credential")
    path = tagged(repo, [W])
    add_safety(repo, path, [W], role="external_sme")                       # REV-0004 as the domain expert
    add_safety(repo, path, [W], role="technical_reviewer", reviewer="Fixture Domain Expert")  # the SAME REV-0004 as the peer
    add_safety(repo, path, [W], role="chatgpt_editorial")
    assert "SAFETY_REVIEWERS_NOT_DISTINCT" in codes(run(repo))


def test_11_reviews_by_the_same_person_in_two_classes_are_impossible_through_the_registry_alone(repo):
    """The shipped policy: external_sme is human, chatgpt_editorial is an AI model, and an identity has one kind. No registry state lets one
    identity satisfy both classes of a subject."""
    topics, _ = load_hazards(Repo(REAL))
    cls, _ = load_classification_policy(Repo(REAL))
    policy, _ = load_review_policy(Repo(REAL), {**topics, **cls.subjects})
    a, b = policy.classes["domain_expert"], policy.classes["chatgpt_validation"]
    assert not set(a.kinds) & set(b.kinds) and not set(a.capacities) & set(b.capacities)


def test_11_the_registry_is_consulted_for_the_approvals_ledger_as_well(repo):
    path = build_world(repo, "approved", reviews=False)
    append_row(repo, "approvals", approval_row(path, reviewer_id="REV-0099"))  # a perfect row, by an identity that is not registered
    found = run(repo)
    assert "APPROVAL_NOT_CHATGPT_EDITORIAL" in codes(found)
    assert "REVIEWER_NOT_REGISTERED" in " ".join(f.message for f in found if f.code == "APPROVAL_NOT_CHATGPT_EDITORIAL")
