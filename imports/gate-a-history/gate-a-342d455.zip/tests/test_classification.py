"""Derived classification (FR-001): which review subjects an entry requires cannot be lowered by its author.

At RUN-002 the safety gate ran only for an entry that DECLARED a hazard tag or was typed medical_guidance (Fable probes P18, P18b, P46, P47,
P20). These tests pin the replacement. ZONE_EXPECT below is written by hand from the handoff (sections 2 and 6) and the zone registry's
priorities, NOT read from the policy file, so changing the policy file's table is a deliberate act that this file will notice.
"""
from __future__ import annotations

from pathlib import Path

import pytest
import yaml

from factories import (
    DATE, REAL, add_approval, add_asset, add_required_reviews, add_safety, add_safety_pair, append_row, build_world, claim_row, codes, context, edit_rows,
    entry_dict, medical_dict, register, rewrite_entry, source_row, species_dict, write_entry, write_rows,
)
from sfe.classify import SCREENING, classify, load_classification_policy
from sfe.entries import Entry
from sfe.registry import Repo, load_hazards
from sfe.validate import classification_of, validate_repo

W, CO, SPARK, FORAGE, HARVEST, FOOD = ("HZ-WATER-POTABILITY", "HZ-COMBUSTION-CO", "HZ-IGNITION-SPARK", "HZ-FORAGING-ID", "HZ-HARVEST-LEGAL",
                                       "HZ-FOOD-PRESERVATION")
MED, IDENT, HIGH = "CLS-MEDICAL", "CLS-IDENTIFICATION", "CLS-HIGH-RISK"

# Hand-written oracle: the subjects a plain technical_procedure with low-risk claims and neutral text needs in each zone.
ZONE_EXPECT = {
    "Z01": {HIGH}, "Z02": {HIGH}, "Z03": {SPARK, CO, HIGH}, "Z04": {W, HIGH}, "Z05": {FORAGE, IDENT, HIGH}, "Z06": {HARVEST}, "Z07": {HARVEST},
    "Z08": {IDENT}, "Z09": {SCREENING}, "Z10": {MED, HIGH}, "Z11": {HIGH}, "Z12": {HIGH}, "Z13": {CO, W, HIGH}, "Z14": {FOOD, HIGH},
    "Z15": {HIGH}, "Z16": {FORAGE, IDENT},
}
ZONES = sorted(ZONE_EXPECT)


def run(repo):
    return validate_repo(repo.root)


def seeded(repo, **claim_over):
    """A repository with the source and the claim the default fixture entry cites (low-risk, a specification)."""
    append_row(repo, "sources", source_row())
    append_row(repo, "claims", claim_row(**claim_over))
    return repo


def derive(repo, fm, body="Fixture body text.\n"):
    ctx = context(repo)
    entry = Entry(path=Path(f"{fm['id']}.md"), rel=f"content/{fm['zone']}/{fm['id']}.md", fm=fm, body=body)
    return classify(ctx, entry)


def subjects(repo, **over):
    over.setdefault("hazard_tags", [])
    return set(derive(repo, entry_dict(**over)).subjects)


def reason_text(result, subject):
    return " | ".join(result.subjects[subject])


# ================================================================================ the real policy
def test_the_real_policy_loads_and_covers_everything():
    policy, findings = load_classification_policy(Repo(REAL))
    assert findings == [] and policy is not None
    assert set(policy.zones) == set(ZONES)
    assert set(policy.entry_types) == {"general", "species_profile", "technical_procedure", "medical_guidance"}
    assert set(policy.claim_types) == {"procedure_step", "specification", "identification", "legal", "medical", "safety_boundary", "measurement", "other"}
    assert set(policy.risk_levels) == {"critical", "high", "medium", "low"} and set(policy.priority_floor) == {"Critical", "High"}
    assert len(policy.triggers) >= 8


def test_every_subject_the_policy_names_is_defined():
    policy, _ = load_classification_policy(Repo(REAL))
    known = set(load_hazards(Repo(REAL))[0]) | set(policy.subjects)
    named = set()
    for zone in policy.zones.values():
        named |= set(zone["required_subjects"])
    for table in (policy.entry_types, policy.claim_types, policy.risk_levels, policy.priority_floor):
        for value in table.values():
            named |= set(value)
    for trigger in policy.triggers:
        named |= set(trigger.subjects)
    assert named <= known, named - known


# ======================================================================================== by zone
@pytest.mark.parametrize("zone", ZONES)
def test_each_zone_requires_what_the_handoff_and_its_priority_say(repo, zone):
    seeded(repo)
    assert subjects(repo, zone=zone, id=f"{zone}-FIXTURE-001") == ZONE_EXPECT[zone]


def test_every_zone_that_the_handoff_ties_to_a_physical_fact_check_requires_it(repo):
    """Handoff section 6 bullets mapped to zones: fire and ignition, water, combustion, foraging, harvest law, preservation."""
    seeded(repo)
    needs = {"Z03": {SPARK, CO}, "Z04": {W}, "Z05": {FORAGE}, "Z06": {HARVEST}, "Z07": {HARVEST}, "Z13": {CO}, "Z14": {FOOD}, "Z16": {FORAGE}}
    for zone, required in needs.items():
        assert required <= subjects(repo, zone=zone, id=f"{zone}-FIXTURE-001"), zone


def test_every_critical_zone_gets_the_high_risk_floor_whatever_else_applies(repo):
    seeded(repo)
    zones = {z["id"]: z["priority"] for z in yaml.safe_load((REAL / "content/zones.yaml").read_text(encoding="utf-8"))["zones"]}
    for zone, priority in zones.items():
        if priority == "Critical":
            assert HIGH in subjects(repo, zone=zone, id=f"{zone}-FIXTURE-001"), zone


def test_the_reasons_name_their_source(repo):
    seeded(repo)
    result = derive(repo, entry_dict(zone="Z04", id="Z04-FIXTURE-001", hazard_tags=[]))
    assert "zone Z04" in reason_text(result, W)
    assert "zone priority Critical" in reason_text(result, HIGH)


# ================================================================================== by entry type
@pytest.mark.parametrize("entry_type,factory,expected", [
    ("general", entry_dict, {SCREENING}), ("technical_procedure", entry_dict, {SCREENING}),
    ("species_profile", species_dict, {FORAGE, IDENT}), ("medical_guidance", medical_dict, {MED}),
])
def test_each_entry_type_brings_its_subjects(repo, entry_type, factory, expected):
    seeded(repo)
    fm = factory(zone="Z09", id="Z09-FIXTURE-001", hazard_tags=[], claim_ids=["CLM-0001"], field_claims={})  # only what the TYPE brings, no other claim
    if entry_type == "general":
        fm["entry_type"] = "general"
    assert set(derive(repo, fm).subjects) == expected


SPECIES_EMPTY = {"scientific_name": "", "taxonomic_authority": None, "geographic_range": "", "phenology": "", "identification_uncertainty": "",
                 "regulated_or_protected_status": "", "processing_restrictions": "", "positive_identification_warning": "",
                 "expert_identification_criteria": []}
MEDICAL_EMPTY = {"audience_scope": "", "evidence_date": "", "emergency_evacuation_threshold": "", "contraindications": [], "local_emergency_service_guidance": ""}


@pytest.mark.parametrize("factory,empties,expected", [(species_dict, SPECIES_EMPTY, {FORAGE, IDENT}), (medical_dict, MEDICAL_EMPTY, {MED})],
                         ids=["species_profile", "medical_guidance"])
def test_the_entry_type_alone_brings_its_subjects_even_when_every_type_field_is_empty(repo, factory, empties, expected):
    """A species or medical entry whose type fields are still empty (a draft) needs the same reviews: the TYPE decides, not the fields."""
    seeded(repo)
    fm = factory(zone="Z09", id="Z09-FIXTURE-001", hazard_tags=[], claim_ids=["CLM-0001"], field_claims={}, **empties)  # the type alone, no other claim
    assert set(derive(repo, fm).subjects) == expected


# ================================================================================= by claim
@pytest.mark.parametrize("claim_type,expected", [
    ("procedure_step", {SCREENING}), ("specification", {SCREENING}), ("identification", {IDENT}), ("legal", {HIGH}), ("medical", {MED}),
    ("safety_boundary", {HIGH}), ("measurement", {SCREENING}), ("other", {SCREENING}),
])
def test_each_claim_type_brings_its_subjects(repo, claim_type, expected):
    seeded(repo, claim_type=claim_type)
    assert subjects(repo, zone="Z09", id="Z09-FIXTURE-001") == expected


@pytest.mark.parametrize("risk,expected", [("critical", {HIGH}), ("high", {HIGH}), ("medium", {SCREENING}), ("low", {SCREENING})])
def test_each_risk_level_brings_its_subjects(repo, risk, expected):
    """The risk is the claim author's label. It can only ADD review, never remove it: the zone and type rules do not read it."""
    seeded(repo, risk_level=risk)
    assert subjects(repo, zone="Z09", id="Z09-FIXTURE-001") == expected


def test_a_low_risk_label_cannot_lower_what_the_zone_requires(repo):
    seeded(repo, risk_level="low", claim_type="other")
    assert subjects(repo, zone="Z04", id="Z04-FIXTURE-001") == {W, HIGH}


def test_a_claim_in_a_step_or_a_unit_row_counts_as_cited(repo):
    seeded(repo)
    append_row(repo, "claims", claim_row(claim_id="CLM-0002", claim_type="medical"))
    append_row(repo, "claims", claim_row(claim_id="CLM-0003", risk_level="critical"))
    fm = entry_dict(zone="Z09", id="Z09-FIXTURE-001", hazard_tags=[])
    fm["procedure"][0]["claim_ids"] = ["CLM-0001", "CLM-0002"]
    fm["dimension_unit_table"][0]["claim_id"] = "CLM-0003"
    assert set(derive(repo, fm).subjects) == {MED, HIGH}


def test_an_unregistered_claim_has_an_unknown_type_so_it_requires_high_risk_review(repo):
    result = derive(repo, entry_dict(zone="Z09", id="Z09-FIXTURE-001", hazard_tags=[]))
    assert set(result.subjects) == {HIGH} and "not registered" in reason_text(result, HIGH)


# ================================================================================ by the plan
def plan(repo, **o):
    row = {"coverage_id": "COV-0001", "zone_id": "Z09", "topic": "Fixture topic", "entry_type": "technical_procedure", "risk_level": "low",
           "planned_entry_id": "Z09-FIXTURE-001", "hazard_topics": [FORAGE], "source_coverage": "none", "claim_coverage": "none",
           "photo_coverage": "not_applicable", "status": "planned"}
    row.update(o)
    append_row(repo, "coverage", row)


def test_the_coverage_plan_adds_its_hazard_topics(repo):
    """P46: the plan said identification; the entry carried no tag."""
    seeded(repo)
    plan(repo)
    result = derive(repo, entry_dict(zone="Z09", id="Z09-FIXTURE-001", hazard_tags=[]))
    assert set(result.subjects) == {FORAGE} and "coverage plan" in reason_text(result, FORAGE)


def test_the_coverage_plans_risk_rating_adds_high_risk(repo):
    seeded(repo)
    plan(repo, hazard_topics=[], risk_level="critical")
    assert subjects(repo, zone="Z09", id="Z09-FIXTURE-001") == {HIGH}


def test_a_plan_for_another_entry_changes_nothing(repo):
    seeded(repo)
    plan(repo, planned_entry_id="Z09-OTHER-001")
    assert subjects(repo, zone="Z09", id="Z09-FIXTURE-001") == {SCREENING}


def test_changing_the_type_after_planning_is_an_error(repo):
    seeded(repo)
    plan(repo, entry_type="species_profile", hazard_topics=[])
    assert "COVERAGE_ENTRY_TYPE_MISMATCH" in {f.code for f in derive(repo, entry_dict(zone="Z09", id="Z09-FIXTURE-001")).findings}


# ===================================================================== by structure and by text
def test_species_fields_on_any_entry_require_identification_review_and_are_an_error_off_type(repo):
    """P20: approved species text on an entry typed `general` is never printed and skips the species rules."""
    seeded(repo)
    fm = entry_dict(zone="Z09", id="Z09-FIXTURE-001", hazard_tags=[], entry_type="general", scientific_name="Fixture speciesus",
                    positive_identification_warning="Fixture warning")
    result = derive(repo, fm)
    assert {FORAGE, IDENT} <= set(result.subjects)
    assert "ENTRY_FIELD_NOT_FOR_TYPE" in {f.code for f in result.findings}


def test_medical_fields_on_any_entry_require_medical_review_and_are_an_error_off_type(repo):
    seeded(repo)
    fm = entry_dict(zone="Z09", id="Z09-FIXTURE-001", hazard_tags=[], contraindications=["Fixture contraindication"], emergency_evacuation_threshold="Fixture")
    result = derive(repo, fm)
    assert MED in result.subjects and "ENTRY_FIELD_NOT_FOR_TYPE" in {f.code for f in result.findings}


def test_empty_foreign_fields_are_still_misplaced(repo):
    seeded(repo)
    fm = entry_dict(zone="Z09", id="Z09-FIXTURE-001", hazard_tags=[], scientific_name="")
    assert "ENTRY_FIELD_NOT_FOR_TYPE" in {f.code for f in derive(repo, fm).findings}


def test_a_cited_diagnostic_photograph_requires_identification_review(repo):
    seeded(repo)
    add_asset(repo, 1)  # a verified_diagnostic photograph
    assert subjects(repo, zone="Z09", id="Z09-FIXTURE-001", photo_ids=["PHO-0001"]) == {IDENT}


def test_a_supporting_photograph_does_not(repo):
    seeded(repo)
    add_asset(repo, 1, role="supporting_habitat", view="habitat")
    assert subjects(repo, zone="Z09", id="Z09-FIXTURE-001", photo_ids=["PHO-0001"]) == {SCREENING}


@pytest.mark.parametrize("us,metric,expected", [
    ("14.7 psi", "101.4 kPa", {HIGH}), ("50 °F", "10 °C", {HIGH}), ("4 in", "101.6 mm", {SCREENING}), ("2 lb", "907 g", {SCREENING}),
])
def test_pressure_and_temperature_quantities_require_high_risk_review(repo, us, metric, expected):
    seeded(repo)
    fm = entry_dict(zone="Z09", id="Z09-FIXTURE-001", hazard_tags=[])
    fm["dimension_unit_table"] = [{"quantity": "Fixture quantity", "us_customary": us, "metric": metric, "claim_id": "CLM-0001"}]
    assert set(derive(repo, fm).subjects) == expected


TRIGGER_CASES = [
    ("TRG-IGNITION", "a spark", {SPARK}), ("TRG-IGNITION", "a ferro rod", {SPARK}), ("TRG-WATER", "drinking water", {W}),
    ("TRG-WATER", "a pathogen", {W}), ("TRG-COMBUSTION", "a generator", {CO}), ("TRG-COMBUSTION", "carbon monoxide", {CO}),
    ("TRG-FORAGING", "a mushroom", {FORAGE}), ("TRG-FORAGING", "wild plants", {FORAGE}), ("TRG-HARVEST", "hunting", {HARVEST}),
    ("TRG-HARVEST", "a snare", {HARVEST}), ("TRG-PRESERVATION", "canning", {FOOD}), ("TRG-PRESERVATION", "botulism", {FOOD}),
    ("TRG-MEDICAL", "a tourniquet", {MED}), ("TRG-MEDICAL", "hypothermia", {MED}), ("TRG-HIGH-RISK", "a fatal outcome", {HIGH}),
]


@pytest.mark.parametrize("trigger,phrase,expected", TRIGGER_CASES, ids=[f"{t}:{p}" for t, p, _ in TRIGGER_CASES])
def test_keywords_in_the_text_require_their_subject(repo, trigger, phrase, expected):
    seeded(repo)
    result = derive(repo, entry_dict(zone="Z09", id="Z09-FIXTURE-001", hazard_tags=[], what_it_is=f"Fixture text about {phrase}."))
    assert set(result.subjects) == expected and trigger in reason_text(result, next(iter(expected)))


@pytest.mark.parametrize("field", ["title", "what_it_is", "find_where", "find_when", "diagnostic_features", "lookalikes_or_confusions", "materials",
                                   "conditions_and_limits", "dangers", "materials_tools", "environmental_constraints", "failure_modes",
                                   "hazard_boundaries", "inspection_acceptance_criteria", "procedure.action", "procedure.verify",
                                   "procedure.abort_if", "body"])
def test_the_keyword_scan_reads_every_prose_field_and_the_body(repo, field):
    seeded(repo)
    fm = entry_dict(zone="Z09", id="Z09-FIXTURE-001", hazard_tags=[])
    text, body = "Fixture text about a mushroom.", "Fixture body text.\n"
    if field == "body":
        body = text + "\n"
    elif field.startswith("procedure."):
        fm["procedure"][0][field.split(".")[1]] = text
    elif isinstance(fm[field], list):
        fm[field] = [text]
    else:
        fm[field] = text
    assert FORAGE in derive(repo, fm, body).subjects, field


def test_the_keyword_scan_is_case_insensitive_and_whole_word(repo):
    seeded(repo)
    assert FORAGE in derive(repo, entry_dict(zone="Z09", id="Z09-FIXTURE-001", hazard_tags=[], what_it_is="A MUSHROOM here.")).subjects
    assert subjects(repo, zone="Z09", id="Z09-FIXTURE-001", what_it_is="A sparkle and a generous gesture.") == {SCREENING}


def test_identifier_fields_are_not_scanned(repo):
    seeded(repo)
    assert subjects(repo, zone="Z09", id="Z09-FIXTURE-001", region=["mushroom_country"], season=["hunting_season"]) == {SCREENING}


# ================================================================================ tags only add
def test_a_declared_tag_adds_its_subject(repo):
    seeded(repo)
    result = derive(repo, entry_dict(zone="Z09", id="Z09-FIXTURE-001", hazard_tags=[W]))
    assert set(result.subjects) == {W} and reason_text(result, W) == "declared hazard tag"


def test_removing_a_tag_never_lowers_what_derivation_requires(repo):
    seeded(repo)
    with_tag = set(derive(repo, entry_dict(zone="Z04", id="Z04-FIXTURE-001", hazard_tags=[W, CO])).subjects)
    without = set(derive(repo, entry_dict(zone="Z04", id="Z04-FIXTURE-001", hazard_tags=[])).subjects)
    assert without == {W, HIGH} and with_tag == {W, CO, HIGH}, "the tag added CO; dropping it keeps everything derivation requires"


def test_an_unknown_tag_adds_nothing_and_is_reported(repo):
    seeded(repo)
    fm = entry_dict(zone="Z09", id="Z09-FIXTURE-001", hazard_tags=["HZ-NOT-A-TOPIC"])
    assert set(derive(repo, fm).subjects) == {SCREENING}
    write_entry(repo, fm)
    assert "HAZARD_TAG_UNKNOWN" in codes(run(repo))


def test_nothing_applying_means_the_screening_attestation(repo):
    seeded(repo)
    result = derive(repo, entry_dict(zone="Z09", id="Z09-FIXTURE-001", hazard_tags=[]))
    assert result.subjects == {SCREENING: ["no other review subject applies"]}


def test_a_classification_is_never_empty(repo):
    seeded(repo)
    for zone in ZONES:
        assert derive(repo, entry_dict(zone=zone, id=f"{zone}-FIXTURE-001", hazard_tags=[])).subjects


# =========================================================================== fail closed
def test_an_unusable_policy_requires_every_subject_and_is_an_error(repo):
    seeded(repo)
    ctx = context(repo)
    ctx.cls_policy = None
    fm = entry_dict(zone="Z09", id="Z09-FIXTURE-001", hazard_tags=[])
    result = classify(ctx, Entry(Path("x.md"), "x.md", fm, ""))
    assert set(result.subjects) == {s for s in ctx.subjects if s != SCREENING}
    assert [f.code for f in result.findings] == ["CLASSIFICATION_UNKNOWN"]


def test_a_zone_the_policy_does_not_know_requires_every_subject(repo):
    seeded(repo)
    ctx = context(repo)
    del ctx.cls_policy.zones["Z09"]
    result = classify(ctx, Entry(Path("x.md"), "x.md", entry_dict(zone="Z09", id="Z09-FIXTURE-001", hazard_tags=[]), ""))
    assert set(result.subjects) == {s for s in ctx.subjects if s != SCREENING} and "CLASSIFICATION_UNKNOWN" in {f.code for f in result.findings}


def test_a_priority_the_policy_does_not_know_requires_every_subject(repo):
    seeded(repo)
    ctx = context(repo)
    ctx.cls_policy.priority_floor.pop("High")
    result = classify(ctx, Entry(Path("x.md"), "x.md", entry_dict(zone="Z09", id="Z09-FIXTURE-001", hazard_tags=[]), ""))
    assert set(result.subjects) == {s for s in ctx.subjects if s != SCREENING}


# ====================================================================== allowed types and identification
@pytest.mark.parametrize("entry_type,ok", [("medical_guidance", True), ("technical_procedure", False), ("general", False), ("species_profile", False)])
def test_zone_z10_is_medical_guidance_only(repo, entry_type, ok):
    seeded(repo)
    fm = {"medical_guidance": medical_dict, "species_profile": species_dict}.get(entry_type, entry_dict)(zone="Z10", id="Z10-FIXTURE-001", hazard_tags=[])
    fm["entry_type"] = entry_type
    assert ("ENTRY_TYPE_NOT_ALLOWED_IN_ZONE" not in {f.code for f in derive(repo, fm).findings}) is ok


@pytest.mark.parametrize("entry_type,ok", [("species_profile", True), ("technical_procedure", True), ("general", False), ("medical_guidance", False)])
def test_zone_z05_allows_species_profiles_and_procedures_only(repo, entry_type, ok):
    seeded(repo)
    fm = {"medical_guidance": medical_dict, "species_profile": species_dict}.get(entry_type, entry_dict)(zone="Z05", id="Z05-FIXTURE-001", hazard_tags=[],
                                                                                                      diagnostic_features=[], lookalikes_or_confusions=[])
    fm["entry_type"] = entry_type
    assert ("ENTRY_TYPE_NOT_ALLOWED_IN_ZONE" not in {f.code for f in derive(repo, fm).findings}) is ok


@pytest.mark.parametrize("zone", ["Z05", "Z16"])
def test_identification_content_in_an_identification_zone_must_be_a_species_profile(repo, zone):
    seeded(repo)
    for kwargs, flagged in (({"diagnostic_features": ["Fixture feature"], "lookalikes_or_confusions": []}, True),
                            ({"diagnostic_features": [], "lookalikes_or_confusions": ["Fixture lookalike"]}, True),
                            ({"diagnostic_features": [], "lookalikes_or_confusions": []}, False)):
        fm = entry_dict(zone=zone, id=f"{zone}-FIXTURE-001", hazard_tags=[], **kwargs)
        assert ("IDENTIFICATION_CONTENT_REQUIRES_PROFILE_TYPE" in {f.code for f in derive(repo, fm).findings}) is flagged, (zone, kwargs)


def test_a_diagnostic_photograph_in_an_identification_zone_needs_the_profile_type(repo):
    seeded(repo)
    add_asset(repo, 1)
    fm = entry_dict(zone="Z05", id="Z05-FIXTURE-001", hazard_tags=[], diagnostic_features=[], lookalikes_or_confusions=[], photo_ids=["PHO-0001"])
    assert "IDENTIFICATION_CONTENT_REQUIRES_PROFILE_TYPE" in {f.code for f in derive(repo, fm).findings}


def test_other_zones_do_not_impose_the_profile_type(repo):
    seeded(repo)
    fm = entry_dict(zone="Z08", id="Z08-FIXTURE-001", hazard_tags=[])
    assert "IDENTIFICATION_CONTENT_REQUIRES_PROFILE_TYPE" not in {f.code for f in derive(repo, fm).findings}


# ================================================================ the matrix: 16 zones x 4 entry types
FACTORIES = {"general": entry_dict, "technical_procedure": entry_dict, "species_profile": species_dict, "medical_guidance": medical_dict}


def test_no_zone_and_type_combination_requires_less_than_its_zone_alone(repo):
    seeded(repo)
    for zone in ZONES:
        for entry_type, factory in FACTORIES.items():
            fm = factory(zone=zone, id=f"{zone}-FIXTURE-001", hazard_tags=[])
            fm["entry_type"] = entry_type
            result = derive(repo, fm)
            derived = set(result.subjects) - {SCREENING}
            assert derived >= ZONE_EXPECT[zone] - {SCREENING}, (zone, entry_type, derived)
            assert result.subjects, (zone, entry_type)
            assert not (SCREENING in result.subjects and derived), "screening is only for an entry nothing else applies to"
            if entry_type == "species_profile":
                assert {FORAGE, IDENT} <= derived, (zone, entry_type)
            if entry_type == "medical_guidance":
                assert MED in derived, (zone, entry_type)


def test_the_disallowed_combinations_are_exactly_the_policys(repo):
    seeded(repo)
    bad = set()
    for zone in ZONES:
        for entry_type, factory in FACTORIES.items():
            fm = factory(zone=zone, id=f"{zone}-FIXTURE-001", hazard_tags=[], **({"diagnostic_features": [], "lookalikes_or_confusions": []} if zone in ("Z05", "Z16") else {}))
            fm["entry_type"] = entry_type
            if "ENTRY_TYPE_NOT_ALLOWED_IN_ZONE" in {f.code for f in derive(repo, fm).findings}:
                bad.add((zone, entry_type))
    assert bad == {("Z05", "general"), ("Z05", "medical_guidance"), ("Z10", "general"), ("Z10", "technical_procedure"), ("Z10", "species_profile"),
                   ("Z16", "medical_guidance")}


# ==================================================== the bypasses of FABLE-REVIEW-001, end to end
def approved_without_reviews(repo, **kwargs):
    path = build_world(repo, "approved", **kwargs)
    write_rows(repo, "safety_audit", [])
    return path


def test_p18_a_wild_foods_entry_typed_general_cannot_be_published_without_review(repo):
    approved_without_reviews(repo, id="Z05-FIXTURE-001", zone="Z05", entry_type="general", diagnostic_features=[], lookalikes_or_confusions=[])
    assert {"SAFETY_AUDIT_MISSING", "ENTRY_TYPE_NOT_ALLOWED_IN_ZONE"} <= codes(run(repo))


def test_p18_the_same_entry_typed_as_a_procedure_still_needs_the_foraging_review(repo):
    approved_without_reviews(repo, id="Z05-FIXTURE-001", zone="Z05", diagnostic_features=[], lookalikes_or_confusions=[])
    assert "SAFETY_AUDIT_MISSING" in codes(run(repo))


def test_p18_with_every_derived_review_it_passes(repo):
    path = approved_without_reviews(repo, id="Z05-FIXTURE-001", zone="Z05", diagnostic_features=[], lookalikes_or_confusions=[])
    add_required_reviews(repo, path)
    assert codes(run(repo)) == set()


def test_p18b_a_wilderness_medicine_entry_typed_as_a_procedure_cannot_bypass_review(repo):
    approved_without_reviews(repo, id="Z10-FIXTURE-001", zone="Z10")
    assert {"SAFETY_AUDIT_MISSING", "ENTRY_TYPE_NOT_ALLOWED_IN_ZONE"} <= codes(run(repo))


def test_p46_the_coverage_plan_requires_the_review_its_entry_omitted(repo):
    path = approved_without_reviews(repo)
    plan(repo, hazard_topics=[W])
    found = codes(run(repo))
    assert "SAFETY_AUDIT_MISSING" in found and "APPROVAL_STALE" in found, "the classification is part of the package: the plan changed what was approved"
    add_safety_pair(repo, path, [W])
    add_approval(repo, path)
    assert codes(run(repo)) == set()


def test_p47_an_untagged_general_entry_resting_on_a_critical_medical_claim_cannot_be_published_without_review(repo):
    """P47: the claim was typed medical and critical; the entry had no tag and was typed `general`. RUN-002 asked for no review at all."""
    approved_without_reviews(repo, entry_type="general")
    edit_rows(repo, "claims", lambda rows: rows[0].update(claim_type="medical", risk_level="critical"))
    assert "SAFETY_AUDIT_MISSING" in codes(run(repo))


def test_p47_a_claim_that_becomes_critical_after_the_screening_makes_the_screen_insufficient(repo):
    build_world(repo, "approved")
    assert codes(run(repo)) == set()
    edit_rows(repo, "claims", lambda rows: rows[0].update(claim_type="medical", risk_level="critical"))
    found = run(repo)
    uncovered = {f.message.split(":")[0] for f in found if f.code == "SAFETY_TOPIC_UNCOVERED"}
    assert uncovered == {MED, HIGH} and "APPROVAL_STALE" in codes(found)


def test_p20_species_and_medical_fields_on_a_general_entry_are_refused(repo):
    """Even with every review the classification then demands, approved text the layout never prints is an error (FR-011)."""
    build_world(repo, "approved", entry_type="general", scientific_name="Fixture speciesus", contraindications=["Fixture"])
    assert "ENTRY_FIELD_NOT_FOR_TYPE" in codes(run(repo))


def test_untagging_an_approved_entry_cannot_remove_what_its_zone_requires(repo):
    """Tags only add. Removing one changes the entry (so the approval goes stale) but never what its zone, type or claims require."""
    path = build_world(repo, "approved", id="Z04-FIXTURE-001", zone="Z04", hazard_tags=[W])
    assert codes(run(repo)) == set()
    rewrite_entry(path, lambda fm: fm.update(hazard_tags=[]))
    ctx = context(repo)
    assert set(classification_of(ctx, next(e for e in ctx.entries if e.path.name == path.name)).subjects) == {W, HIGH}
    assert "APPROVAL_STALE" in codes(run(repo))
    add_approval(repo, path)
    add_required_reviews(repo, path)
    assert codes(run(repo)) == set()


def test_untagging_where_nothing_else_requires_the_subject_only_changes_the_package(repo):
    """On a zone with no requirement of its own the tag WAS the reason. Removing it makes the approval stale, and the reviewers of the
    new package decide whether the screening is enough; the author alone cannot carry an approval past the change."""
    path = build_world(repo, "approved", hazard_tags=[W], as_of_date=DATE)
    rewrite_entry(path, lambda fm: fm.update(hazard_tags=[]))
    assert "APPROVAL_STALE" in codes(run(repo))


# ========================================================================= the verified rung
def test_a_zone_derived_hazard_needs_danger_boundaries_without_any_tag(repo):
    build_world(repo, "verified", id="Z04-FIXTURE-001", zone="Z04", hazard_tags=[], dangers=[])
    assert "DANGER_BOUNDARY_MISSING" in codes(run(repo))


def test_a_screened_entry_needs_no_danger_boundaries(repo):
    build_world(repo, "verified", dangers=[])
    assert "DANGER_BOUNDARY_MISSING" not in codes(run(repo))


def test_a_harvest_zone_entry_needs_a_region_and_a_date_without_any_tag(repo):
    build_world(repo, "verified", id="Z06-FIXTURE-001", zone="Z06", hazard_tags=[])
    assert "LEGAL_REGION_DATE_MISSING" in codes(run(repo))


def test_a_harvest_zone_entry_with_a_region_and_a_date_passes_that_rule(repo):
    build_world(repo, "verified", id="Z06-FIXTURE-001", zone="Z06", hazard_tags=[], as_of_date=DATE)
    assert "LEGAL_REGION_DATE_MISSING" not in codes(run(repo))


def test_a_foraging_zone_species_profile_needs_expert_criteria_without_any_tag(repo):
    for n, view in enumerate(("whole", "key_feature"), start=1):
        add_asset(repo, n, view=view)
    build_world(repo, "verified", fm_factory=species_dict, hazard_tags=[], expert_identification_criteria=[], photo_ids=["PHO-0001", "PHO-0002"])
    assert "SPECIES_EXPERT_CRITERIA_MISSING" in codes(run(repo))


# ================================================================================= screening
def screened(repo):
    path = build_world(repo, "approved")
    assert codes(run(repo)) == set()
    return path


def test_an_entry_nothing_applies_to_still_needs_an_independent_screen(repo):
    screened(repo)
    write_rows(repo, "safety_audit", [])
    assert "SAFETY_AUDIT_MISSING" in codes(run(repo))


@pytest.mark.parametrize("role,ok", [("technical_reviewer", True), ("external_sme", True), ("chatgpt_editorial", True), ("user", False), ("adjudicator", False),
                                     ("author", False)])
def test_who_may_screen(repo, role, ok):
    path = build_world(repo, "approved")
    write_rows(repo, "safety_audit", [])
    add_safety(repo, path, [SCREENING], role=role)
    assert (codes(run(repo)) == set()) is ok


def test_the_author_cannot_screen_their_own_entry(repo):
    path = build_world(repo, "approved")
    write_rows(repo, "safety_audit", [])
    register(repo, "REV-0005", "author", kind="human", name="Fixture Technical Reviewer")
    rewrite_entry(path, lambda fm: fm.update(authored_by="REV-0005"))
    add_approval(repo, path)
    add_safety(repo, path, [SCREENING], role="technical_reviewer")
    assert "REVIEWER_IS_AUTHOR" in " ".join(f.message for f in run(repo) if f.code == "SAFETY_REVIEW_ROLE_MISSING")


def test_a_screening_review_does_not_cover_any_other_subject(repo):
    path = build_world(repo, "approved", hazard_tags=[W], as_of_date=DATE)
    write_rows(repo, "safety_audit", [])
    add_safety(repo, path, [SCREENING], role="technical_reviewer")
    assert "SAFETY_TOPIC_UNCOVERED" in codes(run(repo))


def test_an_entry_with_a_subject_does_not_need_the_screen(repo):
    path = build_world(repo, "approved", hazard_tags=[W], as_of_date=DATE)
    ctx = context(repo)
    assert SCREENING not in classification_of(ctx, next(e for e in ctx.entries if e.path.name == path.name)).subjects


# ========================================================================= policy validation
def edit_policy(repo, mutate):
    path = repo.path("schemas/classification_policy.yaml")
    data = yaml.safe_load(path.read_text(encoding="utf-8"))
    mutate(data)
    path.write_text(yaml.safe_dump(data, sort_keys=False, allow_unicode=True), encoding="utf-8")


POLICY_CASES = [
    ("a_zone_row_is_missing", lambda d: d["zones"].pop("Z05"), "CLASSIFICATION_POLICY_INCOMPLETE"),
    ("an_entry_type_row_is_missing", lambda d: d["entry_types"].pop("medical_guidance"), "CLASSIFICATION_POLICY_INCOMPLETE"),
    ("a_claim_type_row_is_missing", lambda d: d["claim_types"].pop("legal"), "CLASSIFICATION_POLICY_INCOMPLETE"),
    ("a_risk_row_is_missing", lambda d: d["risk_levels"].pop("critical"), "CLASSIFICATION_POLICY_INCOMPLETE"),
    ("a_priority_row_is_missing", lambda d: d["priority_floor"].pop("Critical"), "CLASSIFICATION_POLICY_INCOMPLETE"),
    ("an_unexpected_zone_row", lambda d: d["zones"].update(Z99=d["zones"]["Z01"]), "CLASSIFICATION_POLICY_INVALID"),
    ("a_zone_names_an_undefined_subject", lambda d: d["zones"]["Z03"].update(required_subjects=["HZ-NOT-A-TOPIC"]), "CLASSIFICATION_POLICY_UNKNOWN_SUBJECT"),
    ("a_type_names_an_undefined_subject", lambda d: d["entry_types"]["general"].update(required_subjects=["CLS-NOPE"]), "CLASSIFICATION_POLICY_UNKNOWN_SUBJECT"),
    ("a_trigger_names_an_undefined_subject", lambda d: d["triggers"][0].update(subjects=["CLS-NOPE"]), "CLASSIFICATION_POLICY_UNKNOWN_SUBJECT"),
    ("the_structure_names_an_undefined_subject", lambda d: d["structure"].update(species_fields=["CLS-NOPE"]), "CLASSIFICATION_POLICY_UNKNOWN_SUBJECT"),
    ("a_zone_allows_no_type", lambda d: d["zones"]["Z01"].update(allowed_types=[]), "CLASSIFICATION_POLICY_INVALID"),
    ("a_zone_allows_an_unknown_type", lambda d: d["zones"]["Z01"].update(allowed_types=["pamphlet"]), "CLASSIFICATION_POLICY_INVALID"),
    ("identification_is_not_a_boolean", lambda d: d["zones"]["Z05"].update(identification="yes"), "CLASSIFICATION_POLICY_INVALID"),
    ("a_trigger_does_not_compile", lambda d: d["triggers"][0].update(pattern="(unclosed"), "CLASSIFICATION_POLICY_TRIGGER"),
    ("a_trigger_id_repeats", lambda d: d["triggers"][1].update(id=d["triggers"][0]["id"]), "CLASSIFICATION_POLICY_INVALID"),
    ("a_trigger_has_no_pattern", lambda d: d["triggers"][0].pop("pattern"), "CLASSIFICATION_POLICY_INVALID"),
    ("the_structure_lacks_units", lambda d: d["structure"].pop("units"), "CLASSIFICATION_POLICY_INVALID"),
    ("the_triggers_are_not_a_list", lambda d: d.update(triggers="none"), "CLASSIFICATION_POLICY_INVALID"),
    ("the_floor_is_not_a_mapping", lambda d: d.update(priority_floor=[]), "CLASSIFICATION_POLICY_INVALID"),
]


@pytest.mark.parametrize("name,mutate,expected", POLICY_CASES, ids=[c[0] for c in POLICY_CASES])
def test_an_incomplete_or_inconsistent_policy_is_rejected_and_approves_nothing(repo, name, mutate, expected):
    build_world(repo, "approved")
    assert codes(run(repo)) == set()
    edit_policy(repo, mutate)
    policy, findings = load_classification_policy(repo)
    assert policy is None and expected in {f.code for f in findings}
    found = codes(run(repo))
    assert expected in found and "SAFETY_POLICY_UNAVAILABLE" in found
