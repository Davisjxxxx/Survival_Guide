"""Usable text in mandatory safety fields (FABLE-REVIEW-001 FR-021, RUN-004).

P27: `abort_if: "N/A"`, `verify: "-"` and `dangers: ["n/a"]` passed the verified rung, because it only tested that a field was not blank. These tests pin
`scripts/sfe/textcheck.py`: what counts as null, placeholder, repeated or content-free text, that no verdict rests on length alone, that EVERY mandatory
field is covered, and the one justified exception (`Not applicable [CLM-id]: <justification>`, on a step's verify or abort_if only).
"""
from __future__ import annotations

import itertools
import random

import pytest

from factories import add_asset, build_world, codes, entry_dict, medical_dict, rewrite_entry, species_dict
from sfe import texgen
from sfe.textcheck import (DANGERS_FLOOR, EXCEPTION_MIN_CONTENT, EXCEPTION_MIN_WORDS, GENERIC, NULL_PHRASES, STEP_FIELDS, STOPWORDS, TYPE_TEXT, assess,
                           justification_problem, parse_not_applicable)
from sfe.validate import validate_repo


def run(repo):
    return validate_repo(repo.root)


def world(repo, kind, status="verified", **over):
    """A clean world of one entry type; returns the entry path. The control for every refusal below."""
    if kind == "technical_procedure":
        path = build_world(repo, status, **over)
    elif kind == "species_profile":
        for n, view in enumerate(("whole", "key_feature"), start=1):
            add_asset(repo, n, view=view)
        path = build_world(repo, status, fm_factory=species_dict, photo_ids=["PHO-0001", "PHO-0002"], **over)
    else:
        path = build_world(repo, status, fm_factory=medical_dict, **over)
    assert codes(run(repo)) == set(), [str(f) for f in run(repo)]
    return path


# ====================================================================================== the verdicts
NULL_LIKE_VARIANTS = [
    "N/A", "n/a", "N/a", "NA", "na", "N.A.", "n.a", "N/A.", "N/A!", "(N/A)", "[n/a]", "'N/A'", '"n/a"', "“N/A”", "- N/A -", "n / a", "N-A",
    "none", "None", "NONE", "None.", "(none)", "nil", "Nil", "null", "NULL", "no", "No.", "nope", "nothing", "Nothing.", "unknown", "Unknown", "unspecified",
    "TBD", "tbd", "TBD.", "T.B.D.", "tba", "TBC", "todo", "TODO", "to do", "pending", "Pending.", "not applicable", "Not Applicable", "NOT APPLICABLE.",
    "Not applicable.", "not available", "not relevant", "not required", "not needed", "not specified", "see above", "See above.", "as above", "same as above",
    "ditto", "etc", "etc.", "and so on", "various", "misc", "no abort condition", "No abort condition.", "no verification needed", "nothing to verify",
    "no danger", "No known hazards.", "no risk", "none known", "None required", "N/A - see above", "N/A: not needed", "N/A, none", "Not applicable: see above",
    "NA — nothing", "TBD: to be added later", "None; n/a", "n/a (none)",
]
NO_LETTERS = ["-", "--", "---", "—", "–", "−", "...", "…", ".", "?", "???", "!!", "*", "**", "()", "[]", "{}", "/", "\\", "_", "~", "- - -", "  -  "]
PLACEHOLDERS = ["[insert abort condition]", "<fill in>", "{{verify}}", "to be added", "To be determined", "fill in", "Fill me in", "insert text here", "coming soon",
                "work in progress", "xxx", "xxxx", "XXXXXX", "lorem ipsum", "Lorem ipsum dolor sit amet", "asdf", "blah", "blah blah", "placeholder", "foobar"]
REPEATED = ["aaaa", "ok ok ok", "stop stop", "n/a n/a n/a", "no no", "go go go go", "check check", "yes yes yes", "wait wait wait",
            "smoke smoke", "smoke smoke smoke", "fire fire", "water water water water", "dry water dry water"]  # the last five repeat a real WORD: only this rule catches them
FILLER = ["ok", "okay", "fine", "good", "safe", "check", "verify", "confirm", "Check it", "Be careful", "Use caution", "Stop if unsafe", "Make sure", "Looks fine",
          "All good", "Everything fine", "It is fine", "As needed", "As appropriate", "If necessary", "See note", "Done", "Ready",
          "a b c d", "x y", "q q r", "Stay safe", "Take care", "Keep going", "Stay careful and keep safe"]  # stray letters and light verbs carry no information
USABLE = [
    "Flame is steady", "Stop if smoke", "Water is clear", "Do not drink", "Danger of fire", "Keep at least 3 ft away", "Leave the room if the alarm sounds",
    "Wait until the surface is dry", "The line stays below knee height", "15 psi", "Call 911", "Burn hazard near the coals", "Stop if the handle cracks",
    "Fixture verify 1.", "Fixture abort 1.", "Fixture danger boundary", "None of the water should be brown", "No leak at the joint",
    "Evacuate if confusion or fever develops", "Temperature stays under 40 °F",
]


@pytest.mark.parametrize("text", NULL_LIKE_VARIANTS)
def test_null_like_text_is_refused(text):
    assert assess(text) is not None, text


@pytest.mark.parametrize("text", NO_LETTERS)
def test_text_with_no_letter_or_digit_is_refused(text):
    assert assess(text) == "NO_LETTERS_OR_DIGITS", text


@pytest.mark.parametrize("text", PLACEHOLDERS)
def test_an_unfilled_placeholder_is_refused(text):
    assert assess(text) in {"PLACEHOLDER", "NULL_LIKE"}, text


@pytest.mark.parametrize("text", REPEATED)
def test_a_repeated_character_or_word_is_refused(text):
    assert assess(text) in {"REPEATED", "NULL_LIKE", "NO_CONTENT"}, text


@pytest.mark.parametrize("text", ["smoke smoke", "smoke smoke smoke", "fire fire", "water water water water", "dry water dry water", "aaaa", "n/a n/a n/a"])
def test_repeating_a_real_word_or_a_run_is_named_as_repetition(text):
    assert assess(text) == "REPEATED", text


@pytest.mark.parametrize("text", FILLER)
def test_generic_filler_is_refused_even_when_it_is_long_enough(text):
    assert assess(text) in {"NO_CONTENT", "TOO_SHORT", "NULL_LIKE"}, text


@pytest.mark.parametrize("text", USABLE)
def test_a_real_statement_is_accepted(text):
    assert assess(text) is None, text


def test_a_blank_or_non_text_value_is_refused():
    for value in ("", "   ", "\n", None, 0, [], {}):
        assert assess(value) == "EMPTY", value


def test_length_alone_decides_nothing_in_either_direction():
    """Short real text passes; long filler does not. The floor is two words, never the only test."""
    assert assess("Stop if smoke") is None and assess("Danger of fire") is None
    long_filler = ["ok " * 40, "n/a " * 40, "check verify confirm ensure make sure " * 6, "x" * 200, "tbd " * 30, "see above " * 20,
                   "be careful and use caution and stay safe and check that everything is fine and good"]
    for text in long_filler:
        assert assess(text) is not None, text[:40]


def test_a_single_word_is_refused_for_a_safety_field_and_allowed_for_a_name():
    assert assess("Smoke") == "TOO_SHORT"
    assert assess("Smoke", minimum_words=1) is None
    assert assess("Quercus", minimum_words=1) is None
    assert assess("ok", minimum_words=1) == "NO_CONTENT"  # the one-word floor of a name does not let filler through


def test_a_number_is_information():
    assert assess("15 psi") is None and assess("120 seconds") is None and assess("pH 7") is None


def test_a_sentence_that_merely_starts_with_a_null_word_is_a_sentence():
    assert assess("None of the water should be brown") is None
    assert assess("No leak at the joint") is None
    assert assess("Nil by mouth until seen") is None


def test_the_word_lists_are_what_they_say():
    assert {"n a", "none", "tbd", "not applicable"} <= NULL_PHRASES
    assert {"ok", "check", "verify", "safe", "careful", "stop", "none", "tbd", "stay"} <= GENERIC
    assert {"smoke", "fire", "water", "leak", "brown", "pressure", "temperature", "boil"}.isdisjoint(GENERIC), "a word that names a thing in the world is never filler"
    assert {"the", "of", "if", "not"} <= STOPWORDS


# ====================================================================================== property tests (seeded)
def decorations(text: str, rng: random.Random) -> str:
    """The same words in a different costume: case, spacing, quotes, brackets, trailing punctuation, dashes."""
    out = rng.choice([text, text.upper(), text.lower(), text.title(), text.swapcase()])
    out = rng.choice(["{}", "({})", "[{}]", "'{}'", '"{}"', "“{}”", "- {} -", "{}.", "{}!", "{}...", "  {}  ", "{} ?", "*{}*", "{}—", "–{}"]).format(out)
    return out


@pytest.mark.parametrize("seed", range(5))
def test_no_costume_makes_a_null_phrase_usable(seed):
    rng = random.Random(seed)
    for phrase in sorted(NULL_PHRASES):
        for _ in range(8):
            text = decorations(phrase, rng)
            assert assess(text) is not None, (phrase, text)


@pytest.mark.parametrize("seed", range(5))
def test_no_costume_makes_a_real_statement_unusable(seed):
    rng = random.Random(seed)
    sentences = [s for s in USABLE if s[0].isalpha() and s not in {"Fixture verify 1.", "Fixture abort 1."}]
    for sentence in sentences:
        for _ in range(8):
            plain = sentence.rstrip(".")
            text = rng.choice([plain, plain.upper(), plain.lower(), plain.capitalize(), f"{plain}.", f"  {plain}  ", f'"{plain}"', f"({plain})"])
            assert assess(text) is None, (sentence, text)


def test_a_real_statement_stays_usable_when_filler_is_added_around_it():
    for sentence in ("Stop if smoke", "Water is clear", "Do not drink"):
        assert assess(f"Check: {sentence}") is None and assess(f"{sentence}. Be careful.") is None


def test_every_pair_of_null_phrases_is_still_null_or_repeated():
    rng = random.Random(7)
    phrases = sorted(p for p in NULL_PHRASES if len(p.split()) <= 3)
    for first, second in rng.sample(list(itertools.product(phrases, phrases)), 400):
        assert assess(f"{first} {second}") is not None, (first, second)


# ================================================================================ wired into the verified rung
def test_p27_is_refused_for_the_stated_reason_field_by_field(repo):
    """P27: a hazard-tagged verified entry with abort_if 'N/A', verify '-' and dangers ['n/a']. The control is the same entry with real text."""
    path = world(repo, "technical_procedure", hazard_tags=["HZ-WATER-POTABILITY"], as_of_date="2026-01-15")

    def fn(fm):
        for step in fm["procedure"]:
            step.update(abort_if="N/A", verify="-")
        fm["dangers"] = ["n/a"]
    rewrite_entry(path, fn)
    found = run(repo)
    refused = [f for f in found if f.code == "FIELD_NOT_USABLE"]
    messages = " | ".join(f.message for f in refused)
    assert "step 1 abort_if" in messages and "step 1 verify" in messages and "dangers[0]" in messages
    assert "NULL_LIKE" in messages and "NO_LETTERS_OR_DIGITS" in messages
    assert len(refused) == 5  # two steps x (verify, abort_if) and the danger


@pytest.mark.parametrize("kind", ["technical_procedure", "species_profile", "medical_guidance"])
def test_every_mandatory_text_field_refuses_filler_and_names_itself(repo, kind):
    """Every field the textcheck table lists, set to 'n/a', is refused and named. Dropping a field from the table would show up here."""
    expected = dict(TYPE_TEXT[kind])
    path = world(repo, kind)
    for field_name in expected:
        probe_repo_value = "n/a"
        rewrite_entry(path, lambda fm, f=field_name: fm.update({f: [probe_repo_value] if isinstance(fm.get(f), list) else probe_repo_value}))
        found = run(repo)
        assert any(x.code == "FIELD_NOT_USABLE" and x.message.startswith(field_name) for x in found), (kind, field_name, [str(x) for x in found])
        # restore this field so only one field is wrong at a time
        rewrite_entry(path, lambda fm, f=field_name: fm.update({f: ["Fixture restored value"] if isinstance(fm.get(f), list) else "Fixture restored value"}))
    assert not any(f.code == "FIELD_NOT_USABLE" for f in run(repo))


@pytest.mark.parametrize("key", sorted(STEP_FIELDS))
def test_every_step_field_refuses_filler(repo, key):
    path = world(repo, "technical_procedure")
    rewrite_entry(path, lambda fm: fm["procedure"][1].update({key: "n/a"}))
    found = [f for f in run(repo) if f.code == "FIELD_NOT_USABLE"]
    assert len(found) == 1 and found[0].message.startswith(f"step 2 {key}"), [str(f) for f in found]


def test_dangers_are_assessed_on_every_entry_that_prints_one(repo):
    path = world(repo, "technical_procedure")
    rewrite_entry(path, lambda fm: fm.update(dangers=["Fixture real danger", "n/a"]))
    found = [f for f in run(repo) if f.code == "FIELD_NOT_USABLE"]
    assert len(found) == 1 and found[0].message.startswith("dangers[1]"), "the second item is named by its index; the first is fine"
    assert DANGERS_FLOOR == 2


def test_a_list_with_a_blank_item_is_refused_by_index(repo):
    path = world(repo, "technical_procedure")
    rewrite_entry(path, lambda fm: fm.update(failure_modes=["Fixture failure mode", ""]))
    found = [f for f in run(repo) if f.code == "FIELD_NOT_USABLE"]
    assert len(found) == 1 and found[0].message.startswith("failure_modes[1]") and "EMPTY" in found[0].message


def test_a_blank_field_is_reported_by_the_older_gate_and_not_twice(repo):
    path = world(repo, "technical_procedure")
    rewrite_entry(path, lambda fm: fm["procedure"][0].update(abort_if=""))
    found = codes(run(repo))
    assert "STEP_INCOMPLETE" in found and "FIELD_NOT_USABLE" not in found


def test_nothing_is_assessed_below_the_verified_rung(repo):
    path = world(repo, "technical_procedure", "researched")
    rewrite_entry(path, lambda fm: (fm["procedure"][0].update(abort_if="N/A", verify="-"), fm.update(dangers=["n/a"])))
    assert "FIELD_NOT_USABLE" not in codes(run(repo))
    rewrite_entry(path, lambda fm: fm.update(status="verified", technical_reviewer="REV-0005"))
    assert "FIELD_NOT_USABLE" in codes(run(repo))


def test_the_older_placeholder_rule_still_applies_beside_the_new_one(repo):
    path = world(repo, "technical_procedure")
    rewrite_entry(path, lambda fm: fm.update(what_it_is="Fixture what text, TBD later."))
    assert "PLACEHOLDER_IN_VERIFIED_CONTENT" in codes(run(repo))


# ================================================================================ the one justified exception
EXCEPTION = "Not applicable [CLM-0001]: this step only observes the water surface"


def na_world(repo, key="abort_if", text=EXCEPTION, **over):
    path = world(repo, "technical_procedure", **over)
    rewrite_entry(path, lambda fm: fm["procedure"][0].update({key: text}))
    return path


@pytest.mark.parametrize("key", ["verify", "abort_if"])
def test_a_justified_exception_is_accepted_in_a_steps_verify_or_abort_if(repo, key):
    na_world(repo, key)
    assert codes(run(repo)) == set(), [str(f) for f in run(repo)]


def test_the_exception_is_accepted_in_a_hazardous_entry_too_with_the_same_justification(repo):
    na_world(repo, hazard_tags=["HZ-WATER-POTABILITY"], as_of_date="2026-01-15")
    assert codes(run(repo)) == set()


def test_the_exception_form_is_exact():
    assert parse_not_applicable(EXCEPTION) == ("CLM-0001", "this step only observes the water surface")
    assert parse_not_applicable("not applicable [clm-0001]: lowercase claim id") is None
    for bad in ("Not applicable: this step only observes the surface", "N/A [CLM-0001]: this step only observes the surface", "Not applicable [CLM-1]: x",
                "Not applicable [CLM-0001] this step only observes the surface", "Not applicable [CLM-0001]:", "Not applicable"):
        assert parse_not_applicable(bad) is None, bad


@pytest.mark.parametrize("text,why", [
    ("Not applicable [CLM-0001]: n/a", "itself not usable"),
    ("Not applicable [CLM-0001]: none needed", "itself not usable"),
    ("Not applicable [CLM-0001]: not needed here at all", "itself not usable"),
    ("Not applicable [CLM-0001]: only observes surface", "5 words"),
    ("Not applicable [CLM-0001]: because I said so", "content words"),
    ("Not applicable [CLM-0001]: see above and check it is fine", "itself not usable"),
], ids=["na", "none-needed", "no-content", "short", "no-reason", "filler"])
def test_a_weak_justification_is_refused(repo, text, why):
    na_world(repo, text=text)
    found = run(repo)
    refused = [f for f in found if f.code == "NOT_APPLICABLE_JUSTIFICATION_WEAK"]
    assert refused and why in refused[0].message, [str(f) for f in found]


def test_the_justification_floor_is_the_one_the_contract_states():
    assert (EXCEPTION_MIN_WORDS, EXCEPTION_MIN_CONTENT) == (5, 3)
    assert justification_problem("this step only observes the water surface") is None


def test_the_exception_needs_a_claim_that_the_same_step_cites(repo):
    path = na_world(repo, text="Not applicable [CLM-0002]: this step only observes the water surface")
    assert "NOT_APPLICABLE_CLAIM_NOT_CITED" in codes(run(repo))
    rewrite_entry(path, lambda fm: fm["procedure"][0].update(claim_ids=["CLM-0001", "CLM-0002"]))
    assert "NOT_APPLICABLE_CLAIM_NOT_CITED" not in codes(run(repo))  # the step now cites it (the claim itself is another gate's business)


def test_the_exception_without_a_claim_is_just_null_text(repo):
    na_world(repo, text="Not applicable: this step only observes the water surface")
    found = run(repo)
    assert any(f.code == "FIELD_NOT_USABLE" and "NULL_LIKE" in f.message for f in found)


@pytest.mark.parametrize("path_fn", [
    lambda fm: fm["procedure"][0].update(action=EXCEPTION),
    lambda fm: fm.update(dangers=[EXCEPTION]),
    lambda fm: fm.update(hazard_boundaries=[EXCEPTION]),
    lambda fm: fm.update(failure_modes=["Fixture failure mode", EXCEPTION]),
], ids=["action", "dangers", "hazard_boundaries", "failure_modes"])
def test_the_exception_is_refused_in_every_other_field(repo, path_fn):
    path = world(repo, "technical_procedure")
    rewrite_entry(path, path_fn)
    assert "NOT_APPLICABLE_NOT_ALLOWED" in codes(run(repo))


@pytest.mark.parametrize("kind,field_name", [("species_profile", "positive_identification_warning"), ("medical_guidance", "contraindications"),
                                             ("medical_guidance", "emergency_evacuation_threshold")])
def test_a_species_or_medical_field_may_never_say_it_does_not_apply(repo, kind, field_name):
    """'No contraindication' is a statement about the world and needs a claim behind it; the exception form is not a way to leave it out."""
    path = world(repo, kind)
    rewrite_entry(path, lambda fm: fm.update({field_name: [EXCEPTION] if isinstance(fm[field_name], list) else EXCEPTION}))
    assert "NOT_APPLICABLE_NOT_ALLOWED" in codes(run(repo))


def test_the_declaration_is_printed_and_part_of_the_reviewed_package(repo):
    fm = entry_dict(procedure=[{"step": 1, "action": "Fixture action.", "verify": EXCEPTION, "abort_if": "Fixture abort.", "claim_ids": ["CLM-0001"]}])
    promised = [text for _, text in texgen.printed_strings(fm, assets={}, sources={}, zone_title="Fixture zone")]
    assert EXCEPTION in promised, "the card prints the declaration, claim id and justification included"
    # An approved world whose first step carries the declaration, with the reviews the reviewers gave it: the control must be clean.
    path = build_world(repo, "approved", procedure=[{"step": 1, "action": "Fixture action 1.", "verify": EXCEPTION, "abort_if": "Fixture abort 1.",
                                                     "claim_ids": ["CLM-0001"]}], claim_ids=["CLM-0001"], dimension_unit_table=[])
    assert codes(run(repo)) == set(), [str(f) for f in run(repo)]
    rewrite_entry(path, lambda f: f["procedure"][0].update(verify=EXCEPTION.replace("water surface", "water level")))
    assert "APPROVAL_STALE" in codes(run(repo)), "the justification is reviewed text: changing it stales the approval"
