"""Cross-document consistency of the three supplied documents (handoff, sprint plan, Excel tracker).

These pin the claims made in PROJECT_AUDIT.md section 3, so the reconciliation cannot silently rot.
"""
from __future__ import annotations

import re
from datetime import date

import openpyxl
import pytest

from factories import REAL

HANDOFF = (REAL / "handoff/SURVIVAL_FIELD_ENCYCLOPEDIA_ASTRA_CLI_HANDOFF.md").read_text(encoding="utf-8")
PLAN_PATH = REAL / "handoff/Survival_Field_Encyclopedia_Master_Sprint_Plan_v1.md"
PLAN = PLAN_PATH.read_text(encoding="utf-8")
WORKBOOK = openpyxl.load_workbook(REAL / "handoff/Survival_Field_Encyclopedia_Sprint_Tracker_v1.xlsx", data_only=True)


def norm(text):
    text = str(text).lower().replace("&", "and").replace("–", "-").replace("—", "-")
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9/+\-\. ]+", " ", text)).strip()


def plan_sprints():
    rows = {}
    for line in PLAN.splitlines():
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if line.startswith("|") and re.fullmatch(r"S\d\d", cells[0]):
            rows[cells[0]] = cells
    return rows


def tracker_sprints():
    return {str(r[0].value): [c.value for c in r] for r in WORKBOOK["Sprints"].iter_rows(min_row=2)}


def test_there_are_sixteen_sprints_in_both_documents():
    assert sorted(plan_sprints()) == sorted(tracker_sprints()) == [f"S{n:02d}" for n in range(16)]


def test_sprint_tables_are_identical_in_plan_and_tracker():
    plan, tracker = plan_sprints(), tracker_sprints()
    for sid in plan:
        p, t = plan[sid], tracker[sid]
        # plan: id, start, finish, work, owner, exit, status.  tracker: id, start, finish, phase, deliverables, responsible, gate, deps, status
        for name, a, b in (("start", p[1], t[1]), ("finish", p[2], t[2]), ("work", p[3], t[4]), ("owner", p[4], t[5]),
                           ("exit", p[5], t[6]), ("status", p[6], t[8])):
            assert norm(a) == norm(b), f"{sid} {name}: plan {a!r} vs tracker {b!r}"


def test_sprints_are_contiguous_fourteen_day_blocks():
    rows = plan_sprints()
    previous_end = None
    for sid in sorted(rows):
        start, end = (date.fromisoformat(rows[sid][i]) for i in (1, 2))
        assert (end - start).days == 13, sid
        if previous_end:
            assert (start - previous_end).days == 1, sid
        previous_end = end


@pytest.mark.parametrize("milestone,sprint", [
    ("Gate A scaffolding target:** 2026-12-13", "S01"), ("Core wilderness beta target:** 2027-02-07", "S05"),
    ("Midwest early-access target:** 2027-04-04", "S09"), ("All-zone alpha target:** 2027-05-30", "S13"),
    ("Full v1.0 engineering target:** 2027-06-27", "S15"),
])
def test_milestones_fall_on_sprint_ends(milestone, sprint):
    assert milestone in PLAN
    assert milestone.rsplit(" ", 1)[1] == plan_sprints()[sprint][2]


def test_gate_a_exists_in_all_three_documents():
    """Gate naming differs elsewhere (PROJECT_AUDIT.md section 3, item 1), but Gate A is common to all three."""
    assert "**Gate A:**" in HANDOFF
    assert "Gate A:" in PLAN and "Gate A0" in PLAN
    gates = {str(r[0].value): [c.value for c in r] for r in WORKBOOK["Review Gates"].iter_rows(min_row=2)}
    assert {"G0", "GA"} <= set(gates)
    assert "specimen" in gates["GA"][2].lower() and "RUN-001" in gates["GA"][2]


def test_the_three_gate_vocabularies_really_do_differ():
    """If someone reconciles the documents, this fails and PROJECT_AUDIT.md item 1 must be updated."""
    plan_labels = set(re.findall(r"Gate ([A-H]\d?)\b", PLAN))
    handoff_labels = set(re.findall(r"\*\*Gate ([A-D])", HANDOFF))
    tracker_labels = {str(r[0].value) for r in WORKBOOK["Review Gates"].iter_rows(min_row=2)}
    assert handoff_labels == {"A", "B", "C"}
    assert "B1" in plan_labels and "H2" in plan_labels
    assert tracker_labels == {"G0", "GA", "GB", "GC", "GD", "GE", "GF", "GG", "GH"}


def test_the_primer_and_blueprint_are_claimed_but_not_supplied():
    """PROJECT_AUDIT.md section 1.3: the evidence the tracker cites is not in the package."""
    evidence = {str(r[0].value): [c.value for c in r] for r in WORKBOOK["Evidence"].iter_rows(min_row=2)}
    named = [evidence[k][1] for k in ("E01", "E02", "E03", "E04")]
    assert all(name.endswith(".pdf") for name in named)
    assert not any((REAL / "handoff" / name).exists() for name in named)
    assert "not supplied" in evidence["E07"][3].lower()
