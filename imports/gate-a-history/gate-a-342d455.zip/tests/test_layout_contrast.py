"""Handoff section 7: strong contrast, and colour is never the only signal. Computed from the colours the layout defines."""
from __future__ import annotations

import re

import pytest

from factories import REAL

STY = (REAL / "layouts/sfe.sty").read_text(encoding="utf-8")
COLORS = {name: hex_ for name, hex_ in re.findall(r"\\definecolor\{(\w+)\}\{HTML\}\{([0-9A-Fa-f]{6})\}", STY)}


def luminance(hex_):
    def channel(value):
        value /= 255
        return value / 12.92 if value <= 0.03928 else ((value + 0.055) / 1.055) ** 2.4
    r, g, b = (int(hex_[i:i + 2], 16) for i in (0, 2, 4))
    return 0.2126 * channel(r) + 0.7152 * channel(g) + 0.0722 * channel(b)


def contrast(a, b):
    hi, lo = sorted((luminance(a), luminance(b)), reverse=True)
    return (hi + 0.05) / (lo + 0.05)


def test_the_layout_defines_a_small_dark_palette():
    assert {"sfeInk", "sfeAccent", "sfeBlue", "sfePanel"} <= set(COLORS)


@pytest.mark.parametrize("name", ["sfeInk", "sfeAccent", "sfeBlue"])
def test_dark_colours_have_aaa_contrast_with_white(name):
    """White text on these bars, and these colours as text on white, must reach WCAG AAA (7:1)."""
    assert contrast(COLORS[name], "FFFFFF") >= 7.0, f"{name}: {contrast(COLORS[name], 'FFFFFF'):.2f}:1"


def test_body_text_on_the_light_panel_has_aaa_contrast():
    assert contrast("111111", COLORS["sfePanel"]) >= 7.0


def test_each_accent_colour_travels_with_a_label_or_shape():
    """Documented rule, spot-checked in the layout source: red marks danger, blue marks sources and illustrations."""
    assert "FAILURE / DANGER" in (REAL / "scripts/sfe/texgen.py").read_text(encoding="utf-8")
    assert "dash pattern" in STY and "ILLUSTRATION" in STY      # illustration: dashed frame + tag, not just blue
    assert r"\hyperlink{sfe:src:#1}{\fcolorbox{sfeBlue}" in STY  # source chip: boxed ID text, not just blue


def test_accent_colours_are_distinguishable_from_ink_only_by_hue_so_they_never_carry_unique_meaning():
    """In grayscale all three are dark (luminance < 0.1), so any meaning carried by hue alone would be lost: none is."""
    assert all(luminance(COLORS[n]) < 0.1 for n in ("sfeInk", "sfeAccent", "sfeBlue"))
