"""The status ladder and approval gates (handoff section 10): every rung has a test that proves it fails closed."""
from __future__ import annotations

import pytest

from factories import (
    LADDER, add_asset, append_row, approval_row, build_world, claim_row, codes, edit_rows, entry_dict, read_rows,
    rewrite_entry, set_zone, source_row, write_entry, write_rows, zone_dir,
)
from sfe.validate import validate_repo


def run(repo):
    return validate_repo(repo.root)


@pytest.mark.parametrize("status", LADDER)
def test_complete_world_passes_at_every_status(repo, status):
    build_world(repo, status)
    findings = run(repo)
    assert codes(findings) == set(), [str(f) for f in findings]


def _claim_unverified(repo, path):
    edit_rows(repo, "claims", lambda rows: rows[0].update(status="UNVERIFIED", verified_by="", verified_on="", evidence_date=""))


def _source_unverified(repo, path):
    edit_rows(repo, "sources", lambda rows: rows[0].update(verification_status="unverified", verified_by="", verified_on=""))


def _claim_other_source(repo, path):
    append_row(repo, "sources", source_row(source_id="SRC-0002"))
    edit_rows(repo, "claims", lambda rows: rows[0].update(source_id="SRC-0002"))


def _benchmark(repo, path):
    edit_rows(repo, "sources", lambda rows: rows[0].update(intended_use="benchmark_only"))


def _withdrawn(repo, path):
    append_row(repo, "approvals", approval_row(path, approval_id="APR-0002", decision="withdrawn", decided_on="2026-02-01"))


def _technical_only(repo, path):
    edit_rows(repo, "approvals", lambda rows: rows[0].update(capacity="technical_reviewer"))


def _drop_approvals(repo, path):
    write_rows(repo, "approvals", [])


def _edit(**changes):
    return lambda repo, path: rewrite_entry(path, lambda fm: fm.update(changes))


def _step(index, **changes):
    def mutate(repo, path):
        def fn(fm):
            fm["procedure"][index].update(changes)
        rewrite_entry(path, fn)
    return mutate


def _renumber(repo, path):
    def fn(fm):
        fm["procedure"][1]["step"] = 3
    rewrite_entry(path, fn)


def _unit(**changes):
    def mutate(repo, path):
        def fn(fm):
            fm["dimension_unit_table"][0].update(changes)
        rewrite_entry(path, fn)
    return mutate


CASES = [
    # name, world status, mutation(repo, entry path), error code that must appear
    ("no_sources", "researched", _edit(source_ids=[]), "SOURCE_IDS_EMPTY"),
    ("unknown_source", "researched", _edit(source_ids=["SRC-0001", "SRC-0099"]), "SOURCE_NOT_REGISTERED"),
    ("step_without_claim", "researched", _step(0, claim_ids=[]), "STEP_WITHOUT_CLAIM"),
    ("unknown_claim", "researched", _step(0, claim_ids=["CLM-0099"]), "CLAIM_NOT_REGISTERED"),
    ("bad_step_numbering", "researched", _renumber, "STEP_NUMBERING"),
    ("claim_source_not_cited", "researched", _claim_other_source, "CLAIM_SOURCE_NOT_CITED"),
    ("benchmark_source_cited", "researched", _benchmark, "BENCHMARK_SOURCE_CITED"),
    ("uncited_specification", "researched", _unit(claim_id=""), "UNCITED_SPECIFICATION"),
    ("claim_not_verified", "verified", _claim_unverified, "CLAIM_NOT_VERIFIED"),
    ("source_not_verified", "verified", _source_unverified, "SOURCE_NOT_VERIFIED"),
    ("no_technical_reviewer", "verified", _edit(technical_reviewer=None), "TECHNICAL_REVIEWER_MISSING"),
    ("step_without_verify", "verified", _step(0, verify=""), "STEP_INCOMPLETE"),
    ("step_without_abort", "verified", _step(1, abort_if="  "), "STEP_INCOMPLETE"),
    ("hazard_without_danger_boundary", "verified", _edit(hazard_tags=["HZ-WATER-POTABILITY"], dangers=[]), "DANGER_BOUNDARY_MISSING"),
    ("placeholder_text", "verified", _edit(what_it_is="TBD later"), "PLACEHOLDER_IN_VERIFIED_CONTENT"),
    ("unverified_marker", "verified", _edit(find_where="still UNVERIFIED"), "PLACEHOLDER_IN_VERIFIED_CONTENT"),
    ("unit_pair_inconsistent", "verified", _unit(metric="100 mm"), "UNIT_INCONSISTENT"),
    ("unit_dimension_mismatch", "verified", _unit(metric="100 kg"), "UNIT_INCONSISTENT"),
    ("procedure_field_empty", "verified", _edit(hazard_boundaries=[]), "PROCEDURE_FIELD_EMPTY"),
    ("legal_without_date", "verified", _edit(hazard_tags=["HZ-HARVEST-LEGAL"]), "LEGAL_REGION_DATE_MISSING"),
    ("no_approval_row", "approved", _drop_approvals, "APPROVAL_MISSING"),
    ("approval_stale_after_edit", "approved", _edit(title="Fixture entry one, edited after approval"), "APPROVAL_STALE"),
    ("approval_withdrawn", "approved", _withdrawn, "APPROVAL_NOT_CURRENT"),
    ("approval_not_chatgpt", "approved", _technical_only, "APPROVAL_NOT_CHATGPT_EDITORIAL"),
    ("no_editorial_reviewer", "approved", _edit(editorial_reviewer=None), "EDITORIAL_REVIEWER_MISSING"),
    ("approved_without_flag", "approved", _edit(approved_by_chatgpt=False), "APPROVED_STATUS_WITHOUT_FLAG"),
    ("flag_below_approved", "verified", _edit(approved_by_chatgpt=True), "APPROVED_FLAG_BELOW_APPROVED"),
    ("unknown_hazard_tag", "draft", _edit(hazard_tags=["HZ-NOT-A-TOPIC"]), "HAZARD_TAG_UNKNOWN"),
]


@pytest.mark.parametrize("name,status,mutate,expected", CASES, ids=[c[0] for c in CASES])
def test_gate_fails_closed(repo, name, status, mutate, expected):
    path = build_world(repo, status)
    mutate(repo, path)
    assert expected in codes(run(repo)), [str(f) for f in run(repo)]


def test_approval_survives_workflow_field_changes(repo):
    """Moving an approved entry to published changes only workflow fields, so the approval must stay valid.
    (The entry has no body: a published entry may not carry one until the layout can print it, tests/test_render_totality.py.)"""
    path = build_world(repo, "approved", body="")
    rewrite_entry(path, lambda fm: fm.update(status="published", revision=1))
    assert codes(run(repo)) == set()


def test_approval_is_bound_to_the_exact_content(repo):
    path = build_world(repo, "approved")
    text = path.read_text(encoding="utf-8")
    path.write_text(text.replace("Fixture body text.", "Fixture body text, quietly rewritten."), encoding="utf-8")
    assert "APPROVAL_STALE" in codes(run(repo))


def test_draft_with_unresolved_references_only_warns(repo):
    write_entry(repo, entry_dict(source_ids=["SRC-0099"], claim_ids=["CLM-0099"]))
    findings = run(repo)
    assert "SOURCE_NOT_REGISTERED" in codes(findings, "warning")
    assert codes(findings) == set()


# ------------------------------------------------------------- structure and parsing
def test_wrong_zone_directory(repo):
    path = build_world(repo, "draft")
    target = repo.path(f"content/{zone_dir(repo, 'Z01')}/{path.name}")
    path.rename(target)
    assert "ENTRY_WRONG_ZONE_DIR" in codes(run(repo))


def test_filename_must_equal_id(repo):
    path = build_world(repo, "draft")
    path.rename(path.with_name("Z09-OTHER-001.md"))
    assert "ENTRY_FILENAME_MISMATCH" in codes(run(repo))


def test_id_prefix_must_match_zone(repo):
    write_entry(repo, entry_dict(id="Z10-FIXTURE-001"))
    assert "ENTRY_ID_ZONE_MISMATCH" in codes(run(repo))


def test_duplicate_ids(repo):
    path = build_world(repo, "draft")
    path.with_name("copy.md").write_bytes(path.read_bytes())
    assert "ENTRY_ID_DUPLICATE" in codes(run(repo))


def test_dummy_marker_never_allowed_in_real_content(repo):
    write_entry(repo, entry_dict(what_it_is="This is DUMMY text."))
    assert "DUMMY_MARKER_IN_REAL_CONTENT" in codes(run(repo))


def test_specimen_flag_cannot_masquerade_in_content(repo):
    write_entry(repo, entry_dict(specimen=True))
    assert "ENTRY_SCHEMA" in codes(run(repo))


@pytest.mark.parametrize("raw,fragment", [
    (b"no front matter at all\n", "front-matter fence"),
    (b"---\nid: a\nid: b\n---\nbody\n", "duplicate key"),
    (b"---\r\nid: a\r\n---\r\nbody\r\n", "carriage returns"),
    (b"---\n- not\n- a mapping\n---\nbody\n", "mapping"),
    (b"---\nid: \xff\xfe\n---\nbody\n", "UTF-8"),
])
def test_unparseable_entries_fail_closed(repo, raw, fragment):
    path = repo.path(f"content/{zone_dir(repo, 'Z09')}/Z09-BROKEN-001.md")
    path.write_bytes(raw)
    findings = [f for f in run(repo) if f.code == "ENTRY_PARSE"]
    assert findings and fragment in findings[0].message


@pytest.mark.parametrize("change", [
    {"status": "published-ish"}, {"id": "Z09-lowercase-001"}, {"revision": 0}, {"unexpected_key": 1},
    {"source_ids": ["SRC-1"]}, {"approved_by_chatgpt": "yes"},
])
def test_entry_schema_rejects_malformed_front_matter(repo, change):
    write_entry(repo, entry_dict(**change))
    assert "ENTRY_SCHEMA" in codes(run(repo))


def test_entry_schema_requires_every_base_field(repo):
    fm = entry_dict()
    del fm["dangers"]
    write_entry(repo, fm)
    assert "ENTRY_SCHEMA" in codes(run(repo))


@pytest.mark.parametrize("entry_type,missing", [
    ("technical_procedure", "hazard_boundaries"), ("species_profile", "positive_identification_warning"),
    ("medical_guidance", "emergency_evacuation_threshold"),
])
def test_type_specific_fields_are_required(repo, entry_type, missing):
    from factories import medical_dict, species_dict
    fm = {"technical_procedure": entry_dict, "species_profile": species_dict, "medical_guidance": medical_dict}[entry_type]()
    del fm[missing]
    write_entry(repo, fm)
    assert "ENTRY_SCHEMA" in codes(run(repo))


# ------------------------------------------------------------------------- zones
def test_zone_complete_requires_entries(repo):
    set_zone(repo, "Z03", status="complete")
    assert "ZONE_COMPLETE_WITHOUT_ENTRIES" in codes(run(repo))


def test_zone_complete_requires_every_entry_published(repo):
    build_world(repo, "approved")
    set_zone(repo, "Z09", status="complete")
    assert "ZONE_COMPLETE_WITH_UNPUBLISHED" in codes(run(repo))


def test_zone_complete_requires_closed_coverage(repo):
    build_world(repo, "published")
    set_zone(repo, "Z09", status="complete")
    append_row(repo, "coverage", {"coverage_id": "COV-0001", "zone_id": "Z09", "topic": "Fixture topic", "entry_type": "general",
                                  "risk_level": "low", "status": "planned", "source_coverage": "none", "claim_coverage": "none",
                                  "photo_coverage": "not_applicable"})
    assert "ZONE_COMPLETE_COVERAGE_OPEN" in codes(run(repo))


def test_zone_complete_is_allowed_with_evidence(repo):
    build_world(repo, "published")
    set_zone(repo, "Z09", status="complete")
    assert codes(run(repo)) == set()


def test_approved_cards_must_match_entries(repo):
    build_world(repo, "approved")
    set_zone(repo, "Z09", approved_cards=0)
    assert "ZONE_APPROVED_COUNT" in codes(run(repo))


def test_zone_registry_must_have_sixteen_zones(repo):
    set_zone(repo, "Z16")  # no-op edit to normalise formatting
    import yaml
    path = repo.path("content/zones.yaml")
    data = yaml.safe_load(path.read_text(encoding="utf-8"))
    data["zones"].pop()
    path.write_text(yaml.safe_dump(data, sort_keys=False, allow_unicode=True), encoding="utf-8")
    assert "ZONES_SCHEMA" in codes(run(repo))


def test_zone_dir_must_start_with_zone_id(repo):
    set_zone(repo, "Z02", dir="Z03_shelter")
    assert "ZONES_DIR_PREFIX" in codes(run(repo))


def test_unregistered_directory_in_content_warns(repo):
    repo.path("content/Z99_extra").mkdir()
    assert "CONTENT_UNEXPECTED_PATH" in codes(run(repo), "warning")
