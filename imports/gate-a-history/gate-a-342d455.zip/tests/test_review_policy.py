"""The review policy and the classification subjects: validated, fail-closed, and not configurable below the handoff section 6 standard.

RUN-003: a review class is defined by REGISTRY capacities and kinds (schemas/hazard_topics.yaml, review_policy.classes), and medical guidance
is one of the classification subjects (schemas/classification_policy.yaml). Every weakening case RUN-002 rejected is still rejected here.
The RUN-002 "same reviewer NAME in both classes" warning is superseded: the registry refuses one name under two ids
(tests/test_reviewer_registry.py) and the gate refuses one identity filling two classes (tests/test_review_independence.py).
"""
from __future__ import annotations

import pytest
import yaml

from factories import REAL, build_world, codes, medical_dict
from sfe.classify import load_classification_policy
from sfe.registry import MINIMUM_REVIEW_CLASSES, NON_REVIEWER_CAPACITIES, Repo, load_hazards, load_review_policy
from sfe.validate import validate_repo


def edit_yaml(repo, rel, mutate):
    path = repo.path(rel)
    data = yaml.safe_load(path.read_text(encoding="utf-8"))
    mutate(data)
    path.write_text(yaml.safe_dump(data, sort_keys=False, allow_unicode=True), encoding="utf-8")


def edit_policy(repo, mutate):
    edit_yaml(repo, "schemas/hazard_topics.yaml", mutate)


def edit_classification(repo, mutate):
    edit_yaml(repo, "schemas/classification_policy.yaml", mutate)


def load(repo):
    topics, _ = load_hazards(repo)
    cls, cls_findings = load_classification_policy(repo)
    subjects = {**topics, **(cls.subjects if cls else {})}
    policy, findings = load_review_policy(repo, subjects)
    return policy, cls, cls_findings + findings, subjects


def test_the_real_policy_is_valid_and_exactly_the_documented_one():
    policy, cls, findings, _ = load(Repo(REAL))
    assert findings == [] and policy is not None and cls is not None
    assert {n: (c.capacities, c.kinds, c.specialty_domains) for n, c in policy.classes.items()} == {
        "domain_expert": (("external_sme",), ("human",), True),
        "chatgpt_validation": (("chatgpt_editorial",), ("ai_model",), False),
        "independent_screen": (("technical_reviewer", "external_sme", "chatgpt_editorial"), ("human", "ai_model"), False),
        "image_reviewer": (("technical_reviewer", "external_sme"), ("human", "ai_model"), False),
    }
    assert policy.minimum == ("domain_expert", "chatgpt_validation") == MINIMUM_REVIEW_CLASSES


def test_the_owner_and_the_author_satisfy_no_review_class():
    policy, *_ = load(Repo(REAL))
    for cls in policy.classes.values():
        assert not set(cls.capacities) & NON_REVIEWER_CAPACITIES, cls.name
        assert "owner" not in cls.kinds, cls.name


def test_no_capacity_satisfies_two_classes_of_one_subject():
    """One row has one capacity, so a capacity in two classes of one subject would let one row satisfy two independent reviews."""
    policy, _, _, subjects = load(Repo(REAL))
    for subject_id, subject in subjects.items():
        seen: dict[str, str] = {}
        for name in subject["required_reviews"]:
            for capacity in policy.classes[name].capacities:
                assert seen.setdefault(capacity, name) == name, f"{subject_id}: {capacity} satisfies {seen[capacity]} and {name}"


def test_every_topic_and_classification_subject_keeps_both_minimum_classes_except_screening():
    _, _, _, subjects = load(Repo(REAL))
    assert set(subjects) >= {"HZ-IGNITION-SPARK", "CLS-MEDICAL", "CLS-IDENTIFICATION", "CLS-HIGH-RISK", "CLS-SCREENING"}
    for subject_id, subject in subjects.items():
        if subject_id == "CLS-SCREENING":
            assert subject["required_reviews"] == ["independent_screen"]
        else:
            assert set(MINIMUM_REVIEW_CLASSES) <= set(subject["required_reviews"]), subject_id


def classes(d):
    return d["review_policy"]["classes"]


CASES = [
    # name, which file, mutation, error code that must appear
    ("owner_capacity_in_a_class", "hazard", lambda d: classes(d)["domain_expert"]["capacities"].append("registrar"), "REVIEW_POLICY_USER_ROLE"),
    ("adjudicator_capacity_in_a_class", "hazard", lambda d: classes(d)["chatgpt_validation"]["capacities"].append("adjudicator"), "REVIEW_POLICY_USER_ROLE"),
    ("author_capacity_in_a_class", "hazard", lambda d: classes(d)["domain_expert"]["capacities"].append("author"), "REVIEW_POLICY_USER_ROLE"),
    ("owner_kind_in_a_class", "hazard", lambda d: classes(d)["domain_expert"]["kinds"].append("owner"), "REVIEW_POLICY_USER_ROLE"),
    ("one_capacity_in_two_classes", "hazard", lambda d: classes(d)["domain_expert"]["capacities"].append("chatgpt_editorial"), "REVIEW_POLICY_ROLE_OVERLAP"),
    ("unknown_capacity", "hazard", lambda d: classes(d)["domain_expert"]["capacities"].append("intern"), "REVIEW_POLICY_ROLE_UNKNOWN"),
    ("unknown_kind", "hazard", lambda d: classes(d)["domain_expert"]["kinds"].append("robot"), "REVIEW_POLICY_ROLE_UNKNOWN"),
    ("chatgpt_class_removed", "hazard", lambda d: classes(d).pop("chatgpt_validation"), "REVIEW_POLICY_STANDARD"),
    ("domain_class_removed", "hazard", lambda d: classes(d).pop("domain_expert"), "REVIEW_POLICY_STANDARD"),
    ("class_without_capacities", "hazard", lambda d: classes(d)["domain_expert"].update(capacities=[]), "REVIEW_POLICY_CLASSES"),
    ("class_without_kinds", "hazard", lambda d: classes(d)["domain_expert"].update(kinds=[]), "REVIEW_POLICY_CLASSES"),
    ("specialty_flag_not_boolean", "hazard", lambda d: classes(d)["domain_expert"].update(specialty_domains="yes"), "REVIEW_POLICY_CLASSES"),
    ("no_classes", "hazard", lambda d: d["review_policy"].pop("classes"), "REVIEW_POLICY_CLASSES"),
    ("no_policy_section", "hazard", lambda d: d.pop("review_policy"), "REVIEW_POLICY_MISSING"),
    ("minimum_classes_weakened", "hazard", lambda d: d["review_policy"].update(minimum_classes=["domain_expert"]), "REVIEW_POLICY_STANDARD"),
    ("topic_requires_unknown_class", "hazard", lambda d: d["topics"][0].update(required_reviews=["domain_expert", "chatgpt_validation", "alchemist"]),
     "HAZARD_REVIEW_CLASS_UNKNOWN"),
    ("topic_drops_chatgpt_validation", "hazard", lambda d: d["topics"][2].update(required_reviews=["domain_expert"]), "HAZARD_REVIEW_STANDARD"),
    ("topic_drops_domain_expert", "hazard", lambda d: d["topics"][3].update(required_reviews=["chatgpt_validation"]), "HAZARD_REVIEW_STANDARD"),
    ("medical_drops_chatgpt_validation", "classification", lambda d: d["subjects"]["CLS-MEDICAL"].update(required_reviews=["domain_expert"]),
     "HAZARD_REVIEW_STANDARD"),
    ("medical_drops_domain_expert", "classification", lambda d: d["subjects"]["CLS-MEDICAL"].update(required_reviews=["chatgpt_validation"]),
     "HAZARD_REVIEW_STANDARD"),
    ("identification_drops_a_class", "classification", lambda d: d["subjects"]["CLS-IDENTIFICATION"].update(required_reviews=["domain_expert"]),
     "HAZARD_REVIEW_STANDARD"),
    ("high_risk_drops_a_class", "classification", lambda d: d["subjects"]["CLS-HIGH-RISK"].update(required_reviews=["chatgpt_validation"]),
     "HAZARD_REVIEW_STANDARD"),
    ("medical_requires_nothing", "classification", lambda d: d["subjects"]["CLS-MEDICAL"].update(required_reviews=[]), "CLASSIFICATION_POLICY_INVALID"),
    ("medical_requires_unknown_class", "classification",
     lambda d: d["subjects"]["CLS-MEDICAL"].update(required_reviews=["domain_expert", "chatgpt_validation", "x"]), "HAZARD_REVIEW_CLASS_UNKNOWN"),
    ("screening_requires_nothing", "classification", lambda d: d["subjects"]["CLS-SCREENING"].update(required_reviews=[]), "CLASSIFICATION_POLICY_INVALID"),
    ("screening_requires_unknown_class", "classification", lambda d: d["subjects"]["CLS-SCREENING"].update(required_reviews=["alchemist"]),
     "HAZARD_REVIEW_CLASS_UNKNOWN"),
    ("subject_without_checklist", "classification", lambda d: d["subjects"]["CLS-MEDICAL"].pop("reviewer_must_confirm"), "CLASSIFICATION_POLICY_INVALID"),
    ("subject_with_a_bad_id", "classification", lambda d: d["subjects"].update({"medical": d["subjects"].pop("CLS-MEDICAL")}), "CLASSIFICATION_POLICY_INVALID"),
    ("no_subjects", "classification", lambda d: d.update(subjects="none"), "CLASSIFICATION_POLICY_INVALID"),
]
IDS_OF_CASES = [c[0] for c in CASES]


def mutate_case(repo, which, mutate):
    (edit_policy if which == "hazard" else edit_classification)(repo, mutate)


@pytest.mark.parametrize("name,which,mutate,expected", CASES, ids=IDS_OF_CASES)
def test_a_weakened_policy_is_rejected(repo, name, which, mutate, expected):
    mutate_case(repo, which, mutate)
    policy, cls, findings, _ = load(repo)
    assert policy is None or cls is None, "a weakened policy must not load"
    assert expected in {f.code for f in findings}
    assert expected in codes(validate_repo(repo.root)), "the weakened policy must also fail the repository validation"


@pytest.mark.parametrize("name,which,mutate,expected", CASES, ids=IDS_OF_CASES)
def test_an_invalid_policy_cannot_be_used_to_approve_anything(repo, name, which, mutate, expected):
    """Fail closed: even a perfect pair of reviews cannot approve a hazardous entry while either policy is invalid."""
    build_world(repo, "approved", hazard_tags=["HZ-WATER-POTABILITY"], as_of_date="2026-01-15")
    assert codes(validate_repo(repo.root)) == set()  # valid policy: eligible
    mutate_case(repo, which, mutate)
    assert "SAFETY_POLICY_UNAVAILABLE" in codes(validate_repo(repo.root))


def test_a_missing_classification_policy_approves_nothing(repo):
    build_world(repo, "approved")
    repo.path("schemas/classification_policy.yaml").unlink()
    found = codes(validate_repo(repo.root))
    assert {"CLASSIFICATION_POLICY_MISSING", "SAFETY_POLICY_UNAVAILABLE"} <= found


def test_a_classification_policy_that_is_not_yaml_approves_nothing(repo):
    build_world(repo, "approved")
    repo.path("schemas/classification_policy.yaml").write_text("subjects: [unclosed\n", encoding="utf-8")
    assert {"CLASSIFICATION_POLICY_INVALID", "SAFETY_POLICY_UNAVAILABLE"} <= codes(validate_repo(repo.root))


def test_removing_a_subject_the_policy_still_references_fails_closed(repo):
    """Dropping CLS-MEDICAL while the entry-type and zone rows still name it must not silently skip its review."""
    build_world(repo, "approved", fm_factory=medical_dict)
    assert codes(validate_repo(repo.root)) == set()
    edit_classification(repo, lambda d: d["subjects"].pop("CLS-MEDICAL"))
    found = codes(validate_repo(repo.root))
    assert {"CLASSIFICATION_POLICY_UNKNOWN_SUBJECT", "SAFETY_POLICY_UNAVAILABLE"} <= found


def test_a_required_subject_defined_nowhere_is_refused_by_the_gate_itself(repo):
    """Defence in depth: even if a subject vanished after the policy loaded, the gate reports it instead of skipping it."""
    from sfe.validate import build_context, run_gates
    build_world(repo, "approved")
    ctx, _ = build_context(repo.root)
    del ctx.subjects["CLS-SCREENING"]
    assert "SAFETY_SUBJECT_UNDEFINED" in {f.code for f in run_gates(ctx) if f.severity == "error"}
