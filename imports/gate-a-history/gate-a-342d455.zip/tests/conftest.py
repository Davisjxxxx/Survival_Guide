from __future__ import annotations

from pathlib import Path

import pytest

from factories import REAL, make_repo
from sfe.registry import Repo


@pytest.fixture
def repo(tmp_path: Path) -> Repo:
    """A throwaway scaffolded repository."""
    return make_repo(tmp_path)


@pytest.fixture(scope="session")
def real_repo() -> Repo:
    return Repo(REAL)
