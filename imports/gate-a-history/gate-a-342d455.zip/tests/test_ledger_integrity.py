"""Ledgers are append-only, sequence-ordered and hash-chained (FR-003, FR-022).

Fable probes P03a, P03b, P08b, P08c, P11a, P11b and P24 showed that a typed date, a file position or a deleted row could change a
verdict. These tests pin the replacement: sequence orders events, the chain makes edits detectable, dates are real calendar dates that
may not decrease, and in a Git checkout history may only be appended to.
"""
from __future__ import annotations

import csv
import itertools
import subprocess

import pytest

from factories import (
    make_repo,
    DATE, append_row, claim_row, codes, entry_dict, medical_dict, read_rows, register, seed_registry, source_row, tamper, write_entry,
    write_rows,
)
from sfe.common import parse_csv_bytes, read_csv, valid_calendar_date
from sfe.ledger import GENESIS, LedgerError, LedgerSpec, chain_value, check_history, check_ledger, ledger_head, seal_ledger
from sfe.validate import validate_repo


@pytest.fixture
def repo(tmp_path):
    """These tests build their own registry: start from an empty one."""
    return make_repo(tmp_path, registry=False)


SPEC = LedgerSpec("t", "when")
HEADER = ["sequence", "label", "note", "when", "chain_sha256"]
ROWS = [("a", "first", "2026-01-10"), ("b", "second", "2026-01-11"), ("c", "third", "2026-01-12"), ("d", "fourth", "2026-01-13"),
        ("e", "fifth", "2026-01-14")]


def write_ledger(path, rows):
    with path.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.writer(fh, lineterminator="\n")
        writer.writerow(HEADER)
        for label, note, when in rows:
            writer.writerow(["", label, note, when, ""])


def sealed(tmp_path, rows=ROWS):
    path = tmp_path / "t.csv"
    write_ledger(path, rows)
    seal_ledger(path)
    return path


def check_text(text):
    header, rows = parse_csv_bytes(text.encode("utf-8"))
    return check_ledger("t.csv", header, rows, SPEC)


def check(path):
    return check_text(path.read_text(encoding="utf-8"))


def kinds(findings):
    return [f.code for f in findings]


# -------------------------------------------------------------------------------------- the chain
def test_chain_value_depends_on_the_predecessor_and_on_every_cell():
    cells = ["1", "a", "x", "2026-01-10"]
    base = chain_value(GENESIS, cells)
    assert len(base) == 64 and base == chain_value(GENESIS, list(cells))
    assert chain_value("1" * 64, cells) != base
    for index in range(len(cells)):
        changed = list(cells)
        changed[index] += "!"
        assert chain_value(GENESIS, changed) != base, f"cell {index} is not covered by the chain"


def test_sealing_assigns_sequence_and_chain_in_order(tmp_path):
    path = tmp_path / "t.csv"
    write_ledger(path, ROWS)
    assert seal_ledger(path) == [1, 2, 3, 4, 5]
    header, rows = read_csv(path)
    assert [r["sequence"] for r in rows] == ["1", "2", "3", "4", "5"]
    previous = GENESIS
    for row in rows:
        previous = chain_value(previous, [row[c] for c in header if c != "chain_sha256"])
        assert row["chain_sha256"] == previous
    assert check(path) == []
    assert ledger_head(header, rows) == previous


def test_the_head_of_an_empty_ledger_is_genesis():
    assert ledger_head(HEADER, []) == GENESIS


def test_sealing_is_idempotent_and_never_rewrites_sealed_bytes(tmp_path):
    path = sealed(tmp_path, ROWS[:3])
    before = path.read_bytes()
    assert seal_ledger(path) == []
    assert path.read_bytes() == before
    with path.open("a", encoding="utf-8", newline="") as fh:
        fh.write(",d,fourth,2026-01-13,\n")
    assert seal_ledger(path) == [4]
    assert path.read_bytes().startswith(before), "the sealed prefix must stay byte for byte identical"
    assert check(path) == []


def test_sealing_handles_quoted_commas_quotes_and_embedded_newlines(tmp_path):
    path = tmp_path / "t.csv"
    write_ledger(path, [("a", 'one, two "quoted"', "2026-01-10"), ("b", "line one\nline two", "2026-01-11")])
    seal_ledger(path)
    first = path.read_bytes()
    with path.open("a", encoding="utf-8", newline="") as fh:
        fh.write(",c,plain,2026-01-12,\n")
    assert seal_ledger(path) == [3]
    assert path.read_bytes().startswith(first)
    assert check(path) == []
    assert read_csv(path)[1][1]["note"] == "line one\nline two"


def test_sealing_a_header_only_ledger_changes_nothing(tmp_path):
    path = tmp_path / "t.csv"
    write_ledger(path, [])
    before = path.read_bytes()
    assert seal_ledger(path) == [] and path.read_bytes() == before


def test_seal_refuses_a_sealed_row_after_an_unsealed_one(tmp_path):
    path = sealed(tmp_path, ROWS[:3])
    lines = path.read_text(encoding="utf-8").split("\n")
    parts = lines[2].split(",")
    parts[0], parts[-1] = "", ""
    lines[2] = ",".join(parts)
    path.write_text("\n".join(lines), encoding="utf-8")
    with pytest.raises(LedgerError, match="sealed but an earlier row is not"):
        seal_ledger(path)


def test_seal_refuses_a_row_with_only_one_machine_column(tmp_path):
    path = sealed(tmp_path, ROWS[:2])
    lines = path.read_text(encoding="utf-8").split("\n")
    parts = lines[2].split(",")
    parts[-1] = ""
    lines[2] = ",".join(parts)
    path.write_text("\n".join(lines), encoding="utf-8")
    with pytest.raises(LedgerError, match="only one of"):
        seal_ledger(path)


def test_seal_refuses_to_seal_over_an_edited_row(tmp_path):
    path = sealed(tmp_path, ROWS[:3])
    path.write_text(path.read_text(encoding="utf-8").replace("second", "SECOND"), encoding="utf-8")
    with pytest.raises(LedgerError, match="does not match its chain hash"):
        seal_ledger(path)


def test_seal_refuses_a_wrong_sequence(tmp_path):
    path = sealed(tmp_path, ROWS[:2])
    path.write_text(path.read_text(encoding="utf-8").replace("\n1,a,", "\n7,a,", 1), encoding="utf-8")
    with pytest.raises(LedgerError, match="sequence '7'"):
        seal_ledger(path)


def test_seal_needs_the_machine_columns(tmp_path):
    path = tmp_path / "t.csv"
    path.write_text("label,note\na,b\n", encoding="utf-8")
    with pytest.raises(LedgerError, match="lacks"):
        seal_ledger(path)


def test_seal_reports_a_malformed_file_as_a_ledger_error(tmp_path):
    path = tmp_path / "t.csv"
    path.write_bytes(b"\xef\xbb\xbfsequence,label\n")
    with pytest.raises(LedgerError, match="BOM"):
        seal_ledger(path)


# ----------------------------------------------------------------------------------- tamper detection
# Each function receives the header line followed by the data lines (no trailing blank) and returns the tampered lines.
def edit_a_cell(lines):
    lines[2] = lines[2].replace("second", "SECOND")
    return lines


def delete_a_middle_row(lines):
    del lines[3]
    return lines


def delete_the_first_row(lines):
    del lines[1]
    return lines


def insert_a_row(lines):
    lines.insert(3, "9,x,inserted,2026-01-11," + "0" * 64)
    return lines


def insert_and_renumber(lines):
    """A careful editor: the inserted row and every later row get consecutive sequence numbers. Only the chain can betray it."""
    lines.insert(3, "3,x,inserted,2026-01-11," + "0" * 64)
    for index in range(4, len(lines)):
        parts = lines[index].split(",")
        parts[0] = str(index)
        lines[index] = ",".join(parts)
    return lines


def swap_two_rows(lines):
    lines[2], lines[3] = lines[3], lines[2]
    return lines


def sort_like_a_spreadsheet(lines):
    return [lines[0]] + sorted(lines[1:], key=lambda line: line.split(",")[1], reverse=True)


def forge_a_chain_value(lines):
    parts = lines[3].split(",")
    parts[-1] = "f" * 64
    lines[3] = ",".join(parts)
    return lines


TAMPER = [
    ("edit_a_cell", edit_a_cell, "LEDGER_CHAIN_BROKEN"),
    ("delete_a_middle_row", delete_a_middle_row, "LEDGER_SEQUENCE_BROKEN"),
    ("delete_the_first_row", delete_the_first_row, "LEDGER_SEQUENCE_BROKEN"),
    ("insert_a_row", insert_a_row, "LEDGER_SEQUENCE_BROKEN"),
    ("insert_and_renumber", insert_and_renumber, "LEDGER_CHAIN_BROKEN"),
    ("swap_two_rows", swap_two_rows, "LEDGER_SEQUENCE_BROKEN"),
    ("sort_like_a_spreadsheet", sort_like_a_spreadsheet, "LEDGER_SEQUENCE_BROKEN"),
    ("forge_a_chain_value", forge_a_chain_value, "LEDGER_CHAIN_BROKEN"),
]


def data_lines(path):
    return path.read_text(encoding="utf-8").rstrip("\n").split("\n")


@pytest.mark.parametrize("name,fn,expected", TAMPER, ids=[t[0] for t in TAMPER])
def test_any_edit_deletion_insertion_or_reordering_is_detected(tmp_path, name, fn, expected):
    found = kinds(check_text("\n".join(fn(data_lines(sealed(tmp_path)))) + "\n"))
    breaks = [code for code in found if code in ("LEDGER_CHAIN_BROKEN", "LEDGER_SEQUENCE_BROKEN", "LEDGER_UNSEALED")]
    assert breaks == [expected], "exactly one break is reported (the FIRST); later rows cannot be trusted. A date regression may accompany it."


def test_every_reordering_of_five_rows_is_detected(tmp_path):
    lines = data_lines(sealed(tmp_path))
    header, body = lines[0], lines[1:6]
    for order in itertools.permutations(range(5)):
        if order == (0, 1, 2, 3, 4):
            continue
        text = "\n".join([header] + [body[i] for i in order]) + "\n"
        assert check_text(text), f"reordering {order} went undetected"


def test_an_unsealed_row_is_reported_and_stops_the_chain_check(tmp_path):
    path = sealed(tmp_path, ROWS[:2])
    with path.open("a", encoding="utf-8", newline="") as fh:
        fh.write(",c,third,2026-01-12,\n,d,fourth,2026-01-13,\n")
    assert kinds(check(path)) == ["LEDGER_UNSEALED", "LEDGER_UNSEALED"]


def test_truncating_the_tail_is_invisible_to_the_file_alone(tmp_path):
    """The documented residual: only Git history (check_history) can see that the LAST rows were removed."""
    path = sealed(tmp_path)
    path.write_text("\n".join(data_lines(path)[:4]) + "\n", encoding="utf-8")
    assert check(path) == []


def test_a_cell_containing_a_reserved_control_character_is_rejected(tmp_path):
    path = sealed(tmp_path, [("a", "bad\x1fcell", "2026-01-10")])
    assert kinds(check(path)) == ["LEDGER_CELL_FORBIDDEN_CHAR"]


# ------------------------------------------------------------------------------------------- dates
def rows_dated(*dates):
    return [(f"r{i}", "n", d) for i, d in enumerate(dates, start=1)]


def test_dates_may_repeat_but_never_decrease(tmp_path):
    assert check(sealed(tmp_path, rows_dated("2026-01-10", "2026-01-10", "2026-01-11"))) == []


def test_a_date_that_decreases_is_reported_on_exactly_that_row(tmp_path):
    found = check(sealed(tmp_path, rows_dated("2026-01-10", "2026-01-12", "2026-01-11", "2026-01-12")))
    assert kinds(found) == ["LEDGER_DATE_REGRESSION"] and found[0].where.endswith("row 3")


def test_a_mistyped_future_year_is_caught_by_the_row_after_it(tmp_path):
    """P03a: passes dated 2099 followed by a failure dated 2026. The typo cannot silently outrank later records."""
    found = check(sealed(tmp_path, rows_dated("2099-01-01", "2026-11-17", "2026-11-17")))
    assert kinds(found) == ["LEDGER_DATE_REGRESSION"] and found[0].where.endswith("row 2")


def test_a_date_that_is_not_on_the_calendar_is_not_compared_here(tmp_path):
    assert check(sealed(tmp_path, rows_dated("2026-01-10", "2026-02-31", "2026-01-11"))) == [], "DATE_INVALID is reported by the register loader"


@pytest.mark.parametrize("text,ok", [
    ("2026", True), ("2026-04", True), ("2026-04-30", True), ("2024-02-29", True), ("0001-01-01", True),
    ("2026-02-29", False), ("2026-02-31", False), ("2026-04-31", False), ("2026-13-01", False), ("2026-00-10", False), ("2026-01-00", False),
    ("2026-13-45", False), ("0000-01-01", False), ("0000", False), ("2026-1-5", False), ("26-01-01", False), ("", False),
    ("2026-01-01T00:00", False), (" 2026-01-01", False), ("2026-01-01 ", False),
])
def test_calendar_validation(text, ok):
    assert valid_calendar_date(text) is ok


# --------------------------------------------------------------- the same rules inside the repository
def run(repo):
    return validate_repo(repo.root)


def append_unsealed(repo, **cells):
    columns = repo.columns("reviewers")
    row = {"registration_id": "REG-0099", "action": "register", "reviewer_id": "REV-0099", "display_name": "Fixture Unsealed", "kind": "ai_model",
           "capacity": "author", "domains": "", "registered_by": "REV-0001", "registered_on": DATE}
    row.update(cells)
    with repo.path("reviews/reviewers.csv").open("a", encoding="utf-8", newline="") as fh:
        csv.writer(fh, lineterminator="\n").writerow([row.get(c, "") for c in columns])


def test_a_sealed_registry_validates(repo):
    seed_registry(repo)
    assert codes(run(repo)) == set()


def test_an_unsealed_registry_row_is_an_error_and_carries_no_authority(repo):
    seed_registry(repo)
    append_unsealed(repo)
    found = run(repo)
    assert "LEDGER_UNSEALED" in codes(found)
    assert not [f for f in found if f.code == "ROW_SCHEMA"], "an unsealed row is reported once, not also as a schema error"


def registry_edit(lines):
    lines[2] = lines[2].replace("Fixture Author", "Fixture Authorx")
    return lines


def registry_delete_middle(lines):
    del lines[3]
    return lines


def registry_delete_first(lines):
    del lines[1]
    return lines


def registry_swap(lines):
    lines[2], lines[3] = lines[3], lines[2]
    return lines


def registry_reverse(lines):
    return [lines[0]] + lines[:0:-1]


REGISTRY_TAMPER = [
    ("edit_a_cell", registry_edit, "LEDGER_CHAIN_BROKEN"),
    ("delete_a_middle_row", registry_delete_middle, "LEDGER_SEQUENCE_BROKEN"),
    ("delete_the_bootstrap_row", registry_delete_first, "LEDGER_SEQUENCE_BROKEN"),
    ("swap_two_rows", registry_swap, "LEDGER_SEQUENCE_BROKEN"),
    ("reverse_the_file", registry_reverse, "LEDGER_SEQUENCE_BROKEN"),
]


@pytest.mark.parametrize("name,fn,expected", REGISTRY_TAMPER, ids=[t[0] for t in REGISTRY_TAMPER])
def test_tampering_with_the_registry_file_fails_validation(repo, name, fn, expected):
    seed_registry(repo)
    tamper(repo, "reviewers", fn)
    assert expected in codes(run(repo))


def test_a_registry_date_that_is_not_on_the_calendar_is_rejected(repo):
    seed_registry(repo)
    register(repo, "REV-0007", "author", kind="human", name="Fixture Person", on="2026-02-31")
    assert "DATE_INVALID" in codes(run(repo))


def test_a_registry_date_that_goes_backwards_is_rejected(repo):
    seed_registry(repo)
    register(repo, "REV-0007", "author", kind="human", name="Fixture Person", on="2025-12-31")
    assert "LEDGER_DATE_REGRESSION" in codes(run(repo))


@pytest.mark.parametrize("column,value", [("retrieved_on", "2026-13-45"), ("verified_on", "2026-02-30")])
def test_source_dates_must_be_real(repo, column, value):
    append_row(repo, "sources", source_row(**{column: value}))
    assert "DATE_INVALID" in codes(run(repo))


def test_claim_dates_must_be_real(repo):
    append_row(repo, "sources", source_row())
    append_row(repo, "claims", claim_row(evidence_date="2026-02-30"))
    assert "DATE_INVALID" in codes(run(repo))


@pytest.mark.parametrize("value,ok", [("2026", True), ("2026-04", True), ("2026-04-30", True), ("2026-04-31", False), ("2026-00", False)])
def test_asset_observation_dates_allow_year_or_month_but_must_be_real(repo, value, ok):
    from factories import add_asset
    add_asset(repo, 1, date_observed=value)
    assert ("DATE_INVALID" not in codes(run(repo))) is ok


def test_entry_dates_must_be_real(repo):
    """P24: an as_of_date of 2026-13-45 satisfied the pattern and was accepted."""
    write_entry(repo, entry_dict(as_of_date="2026-13-45"))
    assert "DATE_INVALID" in codes(run(repo))
    write_entry(repo, medical_dict(evidence_date="2026-02-31"))
    assert "DATE_INVALID" in codes(run(repo))


# -------------------------------------------------------------------------------------- Git history
def git(repo, *args):
    return subprocess.run(["git", "-c", "user.name=Fixture", "-c", "user.email=fixture@example.invalid", "-c", "commit.gpgsign=false",
                           "-C", str(repo.root), *args], capture_output=True, text=True, check=True)


def commit(repo, message="step"):
    git(repo, "add", "-A")
    git(repo, "commit", "-q", "-m", message)


@pytest.fixture
def versioned(repo):
    git(repo, "init", "-q", "-b", "main")
    seed_registry(repo)
    commit(repo, "seed")
    return repo


def history(repo):
    return [f for f in run(repo) if f.code.startswith("LEDGER_HISTORY")]


def test_an_append_only_history_is_clean(versioned):
    register(versioned, "REV-0007", "author", kind="human", name="Fixture Person")
    assert history(versioned) == []  # uncommitted append
    commit(versioned, "append")
    register(versioned, "REV-0008", "author", kind="human", name="Fixture Other")
    commit(versioned, "append again")
    assert history(versioned) == []


def test_a_rewritten_row_is_caught_even_when_the_chain_was_recomputed(versioned):
    """The chain alone cannot stop someone who recomputes it; Git history does."""
    rows = read_rows(versioned, "reviewers")
    rows[1]["display_name"] = "Fixture Renamed"
    write_rows(versioned, "reviewers", rows)  # re-sealed: internally consistent
    found = run(versioned)
    assert "LEDGER_CHAIN_BROKEN" not in codes(found) and "LEDGER_SEQUENCE_BROKEN" not in codes(found)
    assert "LEDGER_HISTORY_REWRITTEN" in codes(found)
    assert "row 2" in next(f.message for f in found if f.code == "LEDGER_HISTORY_REWRITTEN")


def test_a_committed_rewrite_stays_reported(versioned):
    rows = read_rows(versioned, "reviewers")
    rows[1]["display_name"] = "Fixture Renamed"
    write_rows(versioned, "reviewers", rows)
    commit(versioned, "rewrite")
    assert "LEDGER_HISTORY_REWRITTEN" in codes(run(versioned))


def test_a_repository_with_no_commits_yet_has_no_history_to_violate(repo):
    """Found while porting probe P08c: `git init` followed by validation was reported as an unreadable history, which would block a first commit."""
    git(repo, "init", "-q", "-b", "main")
    assert history(repo) == []
    assert codes(run(repo)) == set()
    commit(repo, "first commit")
    assert history(repo) == []


def test_removing_the_last_rows_is_caught_by_git_history(versioned):
    """The tail truncation the file alone cannot see (P08c, in its last-row form)."""
    rows = read_rows(versioned, "reviewers")
    write_rows(versioned, "reviewers", rows[:-1])
    assert codes(run(versioned)) >= {"LEDGER_HISTORY_REWRITTEN"}


def test_a_ledger_that_held_rows_cannot_change_its_columns(versioned):
    path = versioned.path("reviews/reviewers.csv")
    path.write_text(path.read_text(encoding="utf-8").replace("sequence,", "seq,", 1), encoding="utf-8")
    assert "LEDGER_HISTORY_MIGRATION_UNATTESTED" in {f.code for f in check_history(versioned.root, "reviews/reviewers.csv")}


def test_an_empty_ledger_may_change_its_columns(repo):
    git(repo, "init", "-q", "-b", "main")
    commit(repo, "header only")
    path = repo.path("reviews/reviewers.csv")
    path.write_text(path.read_text(encoding="utf-8").replace("sequence,", "seq,", 1), encoding="utf-8")
    assert check_history(repo.root, "reviews/reviewers.csv") == []


def test_deleting_a_ledger_that_held_rows_is_reported(versioned):
    versioned.path("reviews/reviewers.csv").unlink()
    assert "LEDGER_HISTORY_DELETED" in {f.code for f in check_history(versioned.root, "reviews/reviewers.csv")}


def test_outside_git_the_history_check_says_so_instead_of_passing_silently(repo):
    seed_registry(repo)
    notes = [f for f in run(repo) if f.code == "LEDGER_HISTORY_UNVERIFIED"]
    assert notes and all(f.severity == "info" for f in notes), "a note, never an error and never silence"
    assert codes(run(repo)) == set()


def test_the_real_repository_history_is_verified_when_it_is_a_checkout(real_repo):
    found = [f for f in validate_repo(real_repo.root) if f.code.startswith("LEDGER_HISTORY")]
    assert [f for f in found if f.severity == "error"] == []
