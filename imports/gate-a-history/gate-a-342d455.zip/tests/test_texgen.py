"""LaTeX generation: escaping, optional-argument traps, fail-closed rendering, and the log gate."""
from __future__ import annotations

import re

import pytest

from factories import entry_dict, medical_dict, species_dict
from sfe.pdfbuild import parse_latex_log
from sfe.texgen import ITEM, RenderError, _table_body, cmd, env, plain, render_document, render_entry, tex_escape

HOSTILE = [
    r"\input{/etc/passwd}", r"\immediate\write18{touch /tmp/pwned}", "100% $5 & #1 _x_ {a} ~ ^ `q`", "\\\\",
    r"\def\a{b}\a", r"\catcode`\%=12 %", "} \\end{document} {", r"\verb|x|", "\\csname relax\\endcsname",
]
_SAFE = [r"\textbackslash{}", r"\{", r"\}", r"\$", r"\&", r"\#", r"\textasciicircum{}", r"\_", r"\textasciitilde{}", r"\%", r"\textasciigrave{}"]


def residual(escaped: str) -> str:
    for sequence in _SAFE:
        escaped = escaped.replace(sequence, "")
    return escaped


@pytest.mark.parametrize("text", HOSTILE)
def test_no_active_tex_character_survives_escaping(text):
    assert not re.search(r"[\\{}$&#^_~%`]", residual(tex_escape(text)))


@pytest.mark.parametrize("text", ["plain words", "Quoted 'text' and \"more\"", "En–dash — em dash ° × ·", "[brackets] and *stars*", "a--b"])
def test_ordinary_text_passes_through(text):
    assert tex_escape(text) == text


def test_whitespace_is_collapsed():
    assert tex_escape("  a \t b\n\n c  ") == "a b c"


@pytest.mark.parametrize("bad", ["a\x00b", "a\x1bb", "\x07"])
def test_control_characters_are_rejected_not_passed_through(bad):
    with pytest.raises(RenderError):
        tex_escape(bad)


def test_plain_strips_every_tex_token():
    assert plain(r"Evil \input{x} $y$ %z") == "Evil inputx y z"
    assert plain("A — B · C") == "A B C"


def test_cmd_and_env_build_balanced_groups():
    assert cmd("foo", "a", "b") == r"\foo{a}{b}"
    assert cmd("foo", "a", opt="0") == r"\foo[0]{a}"
    assert env("box", "body", "x", "y") == r"\begin{box}{x}{y}body\end{box}"


def test_table_rules_never_follow_a_relax():
    body = _table_body(["A", "B"], ["x & y", "[DUMMY] & z"])
    assert r"\midrule\relax " in body
    assert r"\tabularnewline\relax [DUMMY]" in body            # data rows are guarded against a leading '['
    assert r"\relax\midrule" not in body and r"\relax\bottomrule" not in body  # a rule must follow a row end directly
    assert body.endswith(r"\tabularnewline\bottomrule")


def _render(fm, *, proof=True, assets=None, sources=None, repo_root=None):
    from pathlib import Path
    return render_entry(fm, assets=assets or {}, sources=sources or {}, zone_title="Fixture zone", proof=proof,
                        repo_root=repo_root or Path("."))


def test_bracket_leading_text_cannot_become_an_item_label():
    tex = _render(entry_dict(materials=["[x] first", "*star second"])).tex
    assert ITEM + "[x] first" in tex and ITEM + "*star second" in tex
    assert r"\item [" not in tex and r"\item[" not in tex.replace(r"\item[\textbf", "")


def test_sections_appear_in_the_standard_order():
    tex = _render(entry_dict()).tex
    keys = re.findall(r"\\sfeAnchor(?:\[\d\])?\{[^}]*\}\{(\w+)\}", tex)
    expected = ["top", "what", "where", "when", "identify", "materials", "units", "steps", "check", "danger", "regional", "sources"]
    assert keys == expected


def test_every_icon_has_a_text_label_in_the_layout():
    sty = open("layouts/sfe.sty", encoding="utf-8").read()
    for name in ("find", "identify", "use", "check", "avoid", "caution", "source"):
        assert rf"\sfe@icon@{name}" in sty
    assert "icons assist; the text label is always printed" in sty


@pytest.mark.parametrize("factory", [species_dict, medical_dict])
def test_unimplemented_entry_types_refuse_to_render(factory):
    with pytest.raises(RenderError, match="not implemented"):
        _render(factory())


def test_release_never_renders_a_placeholder_where_an_image_should_be():
    asset = {"asset_id": "PHO-0001", "asset_kind": "photo", "local_path": "assets/original_photos/PHO-0001.png",
             "license_status": "approved", "role": "verified_diagnostic", "view": "whole", "license": "L", "caption": "c", "alt_text": "a"}
    fm = entry_dict(photo_ids=["PHO-0001"])
    assert r"\sfeSlotPhoto" in _render(fm, proof=True, assets={"PHO-0001": asset}).tex
    with pytest.raises(RenderError, match="placeholder"):
        _render(fm, proof=False, assets={"PHO-0001": asset})


def test_unknown_asset_is_an_error():
    with pytest.raises(RenderError, match="not in the asset manifest"):
        _render(entry_dict(photo_ids=["PHO-0099"]))


def test_document_metadata_cannot_carry_tex_tokens():
    tex = render_document("body", paper="letterpaper", proof=True, title=r"Evil \input{x}", author="A", subject="S", keywords="K",
                          footer_left=r"left \input{y}", footer_right="r", version="0.1.0")
    title_line = next(line for line in tex.splitlines() if line.startswith(r"\def\sfePdfTitle"))
    assert "\\input" not in title_line
    footer_line = next(line for line in tex.splitlines() if line.startswith(r"\def\sfeFooterLeft"))
    assert r"\textbackslash{}input" in footer_line


# ------------------------------------------------------------------------- the log gate
def codes(findings, severity="error"):
    return {f.code for f in findings if f.severity == severity}


@pytest.mark.parametrize("line,code", [
    ("Overfull \\hbox (12.3pt too wide) in paragraph at lines 5--6", "LAYOUT_OVERFLOW"),
    ("Overfull \\vbox (4.0pt too high) has occurred while \\output is active", "LAYOUT_OVERFLOW"),
    ("LaTeX Warning: Reference `foo' on page 1 undefined on input line 3.", "UNDEFINED_REFERENCE"),
    ("LaTeX Warning: Label(s) may have changed. Rerun to get cross-references right.", "LABELS_UNSTABLE"),
    ("Package hyperref Warning: Token not allowed in a PDF string (Unicode):", "BOOKMARK_TOKEN"),
    ("Missing character: There is no ✓ in font TeXGyreHeros-Regular!", "MISSING_GLYPH"),
    ("LaTeX Font Warning: Font shape `T1/qhv/m/n' undefined", "FONT_SUBSTITUTED"),
    ("pdfTeX warning (dest): name{sfe:src:X} has been referenced but does not exist, replaced by a fixed one", "LINK_TARGET_MISSING"),
])
def test_log_problems_are_errors(line, code):
    assert code in codes(parse_latex_log(line + "\n", "log"))


def test_underfull_boxes_are_ignored():
    assert parse_latex_log("Underfull \\hbox (badness 10000) in paragraph at lines 1--2\n", "log") == []


def test_unknown_warnings_are_reported_but_not_fatal():
    found = parse_latex_log("Package foo Warning: something odd happened.\n", "log")
    assert codes(found) == set() and codes(found, "warning") == {"LATEX_WARNING"}


def test_a_claimed_error_is_not_double_reported_as_a_warning():
    found = parse_latex_log("LaTeX Warning: Reference `foo' on page 1 undefined on input line 3.\n", "log")
    assert codes(found, "warning") == set()
