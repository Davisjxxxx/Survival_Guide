"""FR-017: preserve withdrawal after consecutive interrupted state changes.

These are state-machine tests with synthetic staged artifacts, not PDF builds.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from sfe import release as rel
from sfe.common import sha256_file
from sfe.registry import Repo


def _stage(dist: Path, edition_id: str) -> Path:
    staged = dist / rel.STAGING / f"{edition_id}-stage"
    (staged / "zones").mkdir(parents=True)
    pdf = staged / "zones/Z09.pdf"
    manifest = staged / "zones/Z09.build.json"
    pdf.write_bytes(f"synthetic state-machine fixture: {edition_id}".encode())
    manifest.write_text(json.dumps({"edition_id": edition_id}) + "\n", encoding="utf-8")
    edition = {
        "schema": 1, "edition_id": edition_id, "entries": [],
        "ledger_state": {}, "policy_sha256": {},
        "artifacts": [{
            "zone": "Z09", "pdf": "zones/Z09.pdf", "pdf_sha256": sha256_file(pdf),
            "manifest": "zones/Z09.build.json", "manifest_sha256": sha256_file(manifest),
        }],
    }
    (staged / rel.EDITION_FILE).write_bytes(rel.edition_bytes(edition))
    return staged


def _crash_at(target: str):
    def crash(step: str) -> None:
        if step == target:
            raise RuntimeError(f"injected crash at {target}")
    return crash


def _tree_bytes(root: Path) -> dict[str, bytes]:
    return {str(path.relative_to(root)): path.read_bytes()
            for path in root.rglob("*") if path.is_file()}


@pytest.mark.parametrize("prior_active", [False, True], ids=["empty-log", "prior-edition"])
@pytest.mark.parametrize("by,event", [("withdraw", "withdraw"), ("reconcile", "auto_withdraw")])
@pytest.mark.parametrize("interrupt_withdrawal", [False, True], ids=["completed-control", "interrupted"])
def test_recovery_keeps_withdrawal_when_promotion_was_never_logged(
    tmp_path: Path, monkeypatch, prior_active: bool, by: str, event: str,
    interrupt_withdrawal: bool,
):
    dist = tmp_path / "dist"
    withdrawn_id = "ED-" + "a" * 16
    next_id = "ED-" + "b" * 16
    reason = "Safety review found an error that requires withdrawing this edition."
    if prior_active:
        previous_id = "ED-" + "c" * 16
        rel.promote(dist, _stage(dist, previous_id), previous_id)

    # The pointer advances to A, but A has no promotion row in the log.
    monkeypatch.setattr(rel, "_FAULT", _crash_at("after_pointer"))
    with pytest.raises(RuntimeError, match="injected crash at after_pointer"):
        rel.promote(dist, _stage(dist, withdrawn_id), withdrawn_id)
    monkeypatch.setattr(rel, "_FAULT", None)
    pointer, problems = rel.read_pointer(dist)
    assert not problems and pointer is not None and pointer.state == "active"
    assert pointer.edition_id == withdrawn_id
    assert all(row["edition_id"] != withdrawn_id for row in rel.read_log(dist)[0])
    archive = dist / rel.EDITIONS / withdrawn_id
    archived_bytes = _tree_bytes(archive)

    # A completed withdrawal is the passing control. The adverse case loses
    # the withdrawal log append as well as the earlier promotion log append.
    if interrupt_withdrawal:
        monkeypatch.setattr(rel, "_FAULT", _crash_at("after_withdraw_pointer"))
        with pytest.raises(RuntimeError, match="injected crash at after_withdraw_pointer"):
            rel.withdraw(dist, reason, by=by)
        monkeypatch.setattr(rel, "_FAULT", None)
    else:
        rel.withdraw(dist, reason, by=by)
    withdrawn_pointer, problems = rel.read_pointer(dist)
    assert not problems and withdrawn_pointer is not None
    assert withdrawn_pointer.state == "withdrawn" and withdrawn_pointer.edition_id == withdrawn_id

    rel.recover(dist)
    rows, problems = rel.read_log(dist)
    assert not problems
    tombstones = [row for row in rows if row["edition_id"] == withdrawn_id
                  and row["event"] in ("withdraw", "auto_withdraw")]
    assert len(tombstones) == 1, "recovery must preserve a durable withdrawal record"
    assert tombstones[0]["event"] == event and tombstones[0]["reason"] == reason
    assert rel.read_pointer(dist) == (withdrawn_pointer, [])

    # Repeated recovery neither duplicates nor changes the withdrawal evidence.
    recovered_log = (dist / rel.LOG).read_bytes()
    for _ in range(2):
        assert rel.recover(dist) == []
        assert (dist / rel.LOG).read_bytes() == recovered_log
        assert rel.read_pointer(dist) == (withdrawn_pointer, [])
    assert _tree_bytes(archive) == archived_bytes

    # A prior edition can remain the last logged promotion when A's promotion
    # was interrupted. Verification and reconciliation still honor the
    # authoritative withdrawn pointer; neither selects that older edition.
    repo = Repo(tmp_path / "unused-repo")  # Withdrawn-state checks need no content repository.
    verification = rel.verify_active(repo, dist)
    assert verification.state == "withdrawn" and not verification.ok
    assert verification.pointer == withdrawn_pointer
    assert rel.reconcile(repo, dist) == []
    assert (dist / rel.LOG).read_bytes() == recovered_log
    assert rel.read_pointer(dist) == (withdrawn_pointer, [])

    # A different edition is allowed. Replacing the withdrawn pointer must
    # not erase A's prohibition: A's unchanged archived bytes remain refused.
    rel.promote(dist, _stage(dist, next_id), next_id)
    with pytest.raises(rel.ReleaseStateError, match="EDITION_WITHDRAWN"):
        rel.promote(dist, _stage(dist, withdrawn_id), withdrawn_id)
    pointer, problems = rel.read_pointer(dist)
    assert not problems and pointer is not None
    assert pointer.state == "active" and pointer.edition_id == next_id
    assert _tree_bytes(archive) == archived_bytes
