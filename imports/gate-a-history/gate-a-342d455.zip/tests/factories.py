"""Fixture factories. Every test builds a throwaway repository under tmp_path; nothing touches the real tree.

All fixture text is deliberately neutral ("Fixture ...") so it carries no survival meaning and cannot be
mistaken for content. Fixture rows live only in temporary directories, never in the real registers.
"""
from __future__ import annotations

import csv
import hashlib
import shutil
from pathlib import Path
from typing import Any, Callable

import yaml
from PIL import Image

from sfe import package as package_mod
from sfe.common import load_yaml, sha256_file
from sfe.entries import claim_ids_of, content_sha256, parse_entry
from sfe.ledger import LedgerError, create_pin, seal_ledger
from sfe.registry import LEDGERS, REGISTERS, Repo, load_zones, scaffold
from sfe.validate import build_context, package_of, required_subjects

REAL = Path(__file__).resolve().parents[1]
DATE = "2026-01-15"
SOURCE_COPY_SHA256 = hashlib.sha256(b"fixture source copy").hexdigest()  # the hash of a retrieved copy kept outside the repository
LADDER = ["draft", "researched", "verified", "approved", "published"]
ENTRY_CLAIM_TYPE = {"species_profile": "identification", "medical_guidance": "medical"}  # the type of CLM-0001 in a world of that entry type


# ----------------------------------------------------------------------- repo
def make_repo(tmp_path: Path, *, registry: bool = True) -> Repo:
    """A minimal repository: real schemas, layouts and zone registry, scaffolded empty, with the standard fixture reviewer registry."""
    for rel in ("schemas", "layouts"):
        shutil.copytree(REAL / rel, tmp_path / rel)
    (tmp_path / "content").mkdir()
    shutil.copyfile(REAL / "content/zones.yaml", tmp_path / "content/zones.yaml")
    repo = Repo(tmp_path)
    scaffold(repo)
    if registry:
        seed_registry(repo)
    return repo


def zone_dir(repo: Repo, zone_id: str) -> str:
    zones, _ = load_zones(repo)
    return next(z["dir"] for z in zones if z["id"] == zone_id)


# ------------------------------------------------------------------------ CSV
def _cell(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, list):
        return "|".join(str(v) for v in value)
    return str(value)


def read_rows(repo: Repo, name: str) -> list[dict[str, str]]:
    with repo.path(REGISTERS[name][0]).open(encoding="utf-8", newline="") as fh:
        return list(csv.DictReader(fh))


def write_rows(repo: Repo, name: str, rows: list[dict[str, Any]]) -> None:
    """Write a register. A LEDGER is rebuilt as if it had been honestly appended: sequence and chain are recomputed for every row,
    whatever the rows carried. Tests that need a tampered ledger write the raw file themselves (see tamper())."""
    cols = repo.columns(name)
    path = repo.path(REGISTERS[name][0])
    machine = {"sequence", "chain_sha256"} if name in LEDGERS else set()
    with path.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.writer(fh, lineterminator="\n")
        writer.writerow(cols)
        for row in rows:
            writer.writerow(["" if c in machine else _cell(row.get(c)) for c in cols])
    if name in LEDGERS:
        seal_ledger(path)


def append_row(repo: Repo, name: str, row: dict[str, Any]) -> None:
    write_rows(repo, name, read_rows(repo, name) + [row])


def edit_rows(repo: Repo, name: str, fn: Callable[[list[dict[str, Any]]], None]) -> None:
    rows = read_rows(repo, name)
    fn(rows)
    write_rows(repo, name, rows)


# --------------------------------------------------------------------- rows
def source_row(**o: Any) -> dict[str, Any]:
    row = {
        "source_id": "SRC-0001", "document_title": "Fixture source", "issuing_body_author": "Fixture Agency",
        "edition_date": "2020", "url_or_local_origin": "https://fixture-agency.gov/doc", "source_type": "government",
        "access_usage_rights": "Fixture terms", "revision_date": "2021-01-01", "reliability_notes": "Fixture notes",
        "sections_pages_relevant": "p. 1", "intended_use": "claim_source", "provenance_class": "primary_publisher",
        "rights_status": "permitted", "verification_status": "verified", "verified_by": "Fixture Reviewer", "verified_on": DATE,
        "retrieved_on": DATE, "local_sha256": SOURCE_COPY_SHA256,
    }
    row.update(o)
    return row


def claim_row(**o: Any) -> dict[str, Any]:
    row = {
        "claim_id": "CLM-0001", "claim_text": "Fixture claim text.", "claim_type": "specification", "risk_level": "low",
        "source_id": "SRC-0001", "source_locator": "p. 1", "evidence_date": DATE, "status": "verified",
        "verified_by": "Fixture Reviewer", "verified_on": DATE,
    }
    row.update(o)
    return row


def entry_dict(**o: Any) -> dict[str, Any]:
    step = lambda n: {"step": n, "action": f"Fixture action {n}.", "verify": f"Fixture verify {n}.",  # noqa: E731
                      "abort_if": f"Fixture abort {n}.", "claim_ids": ["CLM-0001"]}
    fm: dict[str, Any] = {
        "entry_type": "technical_procedure", "id": "Z09-FIXTURE-001", "zone": "Z09", "title": "Fixture entry one",
        "status": "draft", "region": ["fixture_region"], "season": ["year_round"],
        "what_it_is": "Fixture what text.", "find_where": "Fixture where text.", "find_when": "Fixture when text.",
        "diagnostic_features": ["Fixture feature"], "lookalikes_or_confusions": ["Fixture lookalike"],
        "materials": ["Fixture material"], "procedure": [step(1), step(2)],
        "conditions_and_limits": ["Fixture limit"], "dangers": ["Fixture danger boundary"],
        "source_ids": ["SRC-0001"], "claim_ids": ["CLM-0001"], "photo_ids": [], "illustration_ids": [], "hazard_tags": [],
        "authored_by": "REV-0002", "technical_reviewer": None, "editorial_reviewer": None, "approved_by_chatgpt": False, "revision": 1,
        "materials_tools": ["Fixture tool"],
        "dimension_unit_table": [{"quantity": "Fixture length", "us_customary": "4 in", "metric": "101.6 mm", "claim_id": "CLM-0001"}],
        "environmental_constraints": ["Fixture constraint"], "inspection_acceptance_criteria": ["Fixture criterion"],
        "failure_modes": ["Fixture failure mode"], "hazard_boundaries": ["Fixture hazard boundary"],
    }
    fm.update(o)
    return fm


def species_dict(**o: Any) -> dict[str, Any]:
    fm = entry_dict(entry_type="species_profile", id="Z05-FIXTURE-001", zone="Z05", procedure=[], claim_ids=["CLM-0001", "CLM-0002"],
                    hazard_tags=["HZ-FORAGING-ID"],
                    # FR-008: every safety-bearing field is bound to a claim of the type the claim policy accepts for it
                    field_claims={"diagnostic_features": ["CLM-0001"], "lookalikes_or_confusions": ["CLM-0001"], "identification_uncertainty": ["CLM-0001"],
                                  "positive_identification_warning": ["CLM-0001"], "expert_identification_criteria": ["CLM-0001"],
                                  "processing_restrictions": ["CLM-0002"], "regulated_or_protected_status": ["CLM-0002"], "dangers": ["CLM-0002"]})
    for key in ("materials_tools", "dimension_unit_table", "environmental_constraints", "inspection_acceptance_criteria",
                "failure_modes", "hazard_boundaries"):
        del fm[key]
    fm.update({
        "taxon_id": "TAX-0001", "scientific_name": "Fixture speciesus", "taxonomic_authority": None, "geographic_range": "Fixture range",
        "phenology": "Fixture phenology", "identification_uncertainty": "Fixture uncertainty",
        "regulated_or_protected_status": "Fixture status", "processing_restrictions": "Fixture restrictions",
        "positive_identification_warning": "Fixture warning", "expert_identification_criteria": ["Fixture expert criterion"],
    })
    fm.update(o)
    return fm


def write_entry(repo: Repo, fm: dict[str, Any], body: str = "Fixture body text.\n") -> Path:
    path = repo.path(f"content/{zone_dir(repo, fm['zone'])}/{fm['id']}.md")
    path.write_text("---\n" + yaml.safe_dump(fm, sort_keys=False, allow_unicode=True) + "---\n" + body, encoding="utf-8", newline="\n")
    return path


def entry_hash(path: Path) -> str:
    fm, body = parse_entry(path.read_bytes())
    return content_sha256(fm, body)


# ---------------------------------------------------------- packets, approvals and reviews (RUN-003)
def context(repo: Repo) -> Any:
    """A fresh validation context for the repo as it stands (no gates are run)."""
    ctx, _ = build_context(repo.root)
    return ctx


def entry_in(ctx: Any, path: Path) -> Any:
    return next(e for e in ctx.entries if e.path.name == path.name)


def packet_for(repo: Repo, path: Path) -> dict[str, Any]:
    """Store the review packet of the entry AS IT STANDS and return the three columns a decision cites: digest, packet path, packet hash."""
    ctx = context(repo)
    _subjects, package, digest = package_of(ctx, entry_in(ctx, path))
    rel, sha = package_mod.write_packet(repo.root, package, digest)
    return {"package_sha256": digest, "packet_path": rel, "packet_sha256": sha}


def approval_row(path: Path, **o: Any) -> dict[str, Any]:
    """An editorial approval of the entry as it stands: bound to its package digest, with its packet stored."""
    fm, _ = parse_entry(path.read_bytes())
    row = {"approval_id": "APR-0001", "entry_id": fm["id"], "revision": fm["revision"], **packet_for(Repo(path.parents[2]), path),
           "decision": "approved", "reviewer_id": "REV-0003", "capacity": "chatgpt_editorial", "decided_on": DATE}
    row.update(o)
    if row["decision"] in ("rejected", "withdrawn"):
        row.setdefault("notes", "Fixture finding.")
    return row


def safety_row(path: Path, topics: list[str], **o: Any) -> dict[str, Any]:
    fm, _ = parse_entry(path.read_bytes())
    row = {"audit_id": "SAF-0001", "entry_id": fm["id"], "revision": fm["revision"], **packet_for(Repo(path.parents[2]), path),
           "subjects": topics, "decision": "pass", "reviewer_id": "REV-0004", "capacity": "external_sme", "reviewed_on": DATE}
    row.update(o)
    if row["decision"] in ("fail", "conditional"):
        row.setdefault("notes", "Fixture finding.")
    return row


ROLE_IDENTITY = {"external_sme": ("REV-0004", "external_sme"), "technical_reviewer": ("REV-0005", "technical_reviewer"),
                 "chatgpt_editorial": ("REV-0003", "chatgpt_editorial"), "adjudicator": ("REV-0006", "adjudicator"),
                 "user": ("REV-0001", "registrar"), "author": ("REV-0002", "author")}
ROLE_KIND = {"external_sme": "human", "technical_reviewer": "human", "chatgpt_editorial": "ai_model", "adjudicator": "human",
             "user": "owner", "author": "ai_model"}


def reviewer_for(repo: Repo, role: str, name: str | None = None) -> tuple[str, str]:
    """(registry id, capacity) for a fixture role. With a name, that person or model is registered on first use (an identity per name)."""
    default_id, capacity = ROLE_IDENTITY[role]
    if name is None:
        return default_id, capacity
    rows = read_rows(repo, "reviewers")
    wanted = " ".join(name.lower().split())
    domains = ["ALL"] if capacity == "chatgpt_editorial" else (ALL_DOMAINS if capacity in ("external_sme", "technical_reviewer") else [])
    evidence = "Fixture credential" if capacity in ("external_sme", "technical_reviewer", "adjudicator") else None
    for row in rows:
        if " ".join(row["display_name"].lower().split()) == wanted:
            if not any(r["reviewer_id"] == row["reviewer_id"] and r["capacity"] == capacity and r["action"] == "register" for r in rows):
                register(repo, row["reviewer_id"], capacity, kind=row["kind"], name=row["display_name"], domains=domains, evidence=evidence)
            return row["reviewer_id"], capacity
    new_id = f"REV-{max(int(r['reviewer_id'].split('-')[1]) for r in rows) + 1:04d}"
    register(repo, new_id, capacity, kind=ROLE_KIND[role], name=name, domains=domains, evidence=evidence)
    return new_id, capacity


def add_approval(repo: Repo, path: Path, **o: Any) -> dict[str, Any]:
    row = approval_row(path, approval_id=f"APR-{len(read_rows(repo, 'approvals')) + 1:04d}", **o)
    append_row(repo, "approvals", row)
    return row


def add_safety(repo: Repo, path: Path, topics: list[str], *, role: str = "external_sme", decision: str = "pass", reviewed_on: str = DATE,
               reviewer: str | None = None, **o: Any) -> dict[str, Any]:
    """Append ONE safety-audit row by a registered fixture reviewer, bound to the entry as it stands; returns the row."""
    reviewer_id, capacity = reviewer_for(repo, role, reviewer)
    fields = {"audit_id": f"SAF-{len(read_rows(repo, 'safety_audit')) + 1:04d}", "reviewer_id": reviewer_id, "capacity": capacity,
              "decision": decision, "reviewed_on": reviewed_on}
    fields.update(o)  # a test may override any column, the reviewer id included
    row = safety_row(path, topics, **fields)
    append_row(repo, "safety_audit", row)
    return row


def add_safety_pair(repo: Repo, path: Path, topics: list[str], *, reviewed_on: str = DATE, domain_role: str = "external_sme",
                    **o: Any) -> list[dict[str, Any]]:
    """The standard pair of independent reviews: a registered human domain expert and ChatGPT validation."""
    return [
        add_safety(repo, path, topics, role=domain_role, reviewed_on=reviewed_on, reviewer="Fixture Domain Expert", **o),
        add_safety(repo, path, topics, role="chatgpt_editorial", reviewed_on=reviewed_on, reviewer="Fixture ChatGPT Editorial", **o),
    ]


def add_required_reviews(repo: Repo, path: Path, *, reviewed_on: str = DATE) -> None:
    """Give an entry every review its classification requires (screening: one independent screen; any other subject: the pair)."""
    ctx = context(repo)
    subjects = required_subjects(ctx, entry_in(ctx, path))
    pair = [subject for subject in subjects if subject != "CLS-SCREENING"]
    if "CLS-SCREENING" in subjects:
        add_safety(repo, path, ["CLS-SCREENING"], role="technical_reviewer", reviewed_on=reviewed_on, reviewer="Fixture Technical Reviewer")
    if pair:
        add_safety_pair(repo, path, pair, reviewed_on=reviewed_on)


LEDGER_IDS = {"approvals": ("approval_id", "APR", "decided_on"), "safety_audit": ("audit_id", "SAF", "reviewed_on"),
              "image_audit": ("audit_id", "IMG", "reviewed_on")}


def add_resolution(repo: Repo, ledger: str, target_id: str, *, by: Any = "adjudicator", name: str | None = None, kind: str = "cleared",
                   on: str = DATE, evidence_text: str = "Fixture reviewer reply.", **o: Any) -> dict[str, Any]:
    """Append a resolution row that clears (or voids) `target_id`, linking a stored evidence file. `by` is a fixture role or (id, capacity)."""
    id_col, prefix, date_col = LEDGER_IDS[ledger]
    number = len(read_rows(repo, ledger)) + 1
    reviewer_id, capacity = by if isinstance(by, tuple) else reviewer_for(repo, by, name)
    rel = f"reviews/evidence/{prefix}-{number:04d}.txt"
    evidence = repo.path(rel)
    evidence.parent.mkdir(parents=True, exist_ok=True)
    evidence.write_text(evidence_text, encoding="utf-8")
    row = {id_col: f"{prefix}-{number:04d}", "decision": "resolution", "reviewer_id": reviewer_id, "capacity": capacity, date_col: on,
           "resolves_id": target_id, "resolution_kind": kind, "evidence_path": rel, "evidence_sha256": sha256_file(evidence),
           "notes": "Fixture reason."}
    row.update(o)
    append_row(repo, ledger, row)
    return row


# --------------------------------------------------------------------- assets
def make_png(path: Path, size: tuple[int, int] = (40, 30), color: tuple[int, int, int] = (200, 200, 200)) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    Image.new("RGB", size, color).save(path, format="PNG")


def asset_row(n: int = 1, *, kind: str = "photo", **o: Any) -> dict[str, Any]:
    prefix, folder = ("PHO", "original_photos") if kind == "photo" else ("ILL", "diagrams")
    row = {
        "asset_id": f"{prefix}-{n:04d}", "asset_kind": kind, "local_path": f"assets/{folder}/{prefix}-{n:04d}.png",
        "subject_common_name": "Fixture subject", "taxon_id": None, "specimen_id": None,
        "generation_method": "camera_photo" if kind == "photo" else "vector_drawing",
        "role": "verified_diagnostic" if kind == "photo" else "schematic_illustration",
        "view": "whole" if kind == "photo" else None, "provenance_url": "https://fixture-agency.gov/photo",
        "organization": "Fixture Agency", "credited_photographer": "Fixture Photographer", "license": "CC-BY-4.0",
        "license_status": "approved", "permission_reference": None, "allowed_derivatives": "resize and crop",
        "rights_evidence_path": None, "rights_evidence_sha256": None, "rights_granted": [],
        "acquired_on": DATE, "reviewer": "Fixture Image Reviewer", "review_status": "approved", "reviewed_on": DATE,
        "caption": f"Fixture caption {n}.", "alt_text": f"Fixture alt text {n}.",
        "overlay_label": "ILLUSTRATION — NOT FOR SPECIES IDENTIFICATION" if kind != "photo" else None,
    }
    row.update(o)
    return row


AUTO: Any = object()  # "supply the identification evidence this asset needs"; pass None to leave it out on purpose


def taxon_row(n: int = 1, **o: Any) -> dict[str, Any]:
    row = {"taxon_id": f"TAX-{n:04d}", "scientific_name": "Fixture speciesus" if n == 1 else f"Fixture alius {n}", "name_authority": "Fixture nomenclature 2026",
           "kind": "plant", "risk_tier": "A", "notes": None}
    row.update(o)
    return row


def specimen_row(n: int = 1, **o: Any) -> dict[str, Any]:
    """A complete, valid specimen record: determined by the fixture domain expert from the physical specimen (the strictest basis)."""
    row = {"specimen_id": f"SPM-{n:04d}", "taxon_id": "TAX-0001", "observer": "Fixture Observer", "observed_on": DATE, "locality": "Fixture locality",
           "habitat": "Fixture habitat", "determination_basis": "physical_examination", "determined_by": "REV-0004", "determined_on": DATE,
           "voucher_reference": None, "notes": None}
    row.update(o)
    return row


def add_taxon(repo: Repo, n: int = 1, **o: Any) -> dict[str, Any]:
    """Append taxon n unless it is already registered (so a world can ask for it more than once)."""
    row = taxon_row(n, **o)
    if not any(r["taxon_id"] == row["taxon_id"] for r in read_rows(repo, "taxa")):
        append_row(repo, "taxa", row)
    return row


def add_specimen(repo: Repo, n: int = 1, **o: Any) -> dict[str, Any]:
    """Append specimen n unless it is already recorded; its taxon is registered too."""
    row = specimen_row(n, **o)
    add_taxon(repo, int(row["taxon_id"].split("-")[1]))
    if not any(r["specimen_id"] == row["specimen_id"] for r in read_rows(repo, "specimens")):
        append_row(repo, "specimens", row)
    return row


def add_asset(repo: Repo, n: int = 1, *, kind: str = "photo", audited: bool = True, write_file: bool = True, taxon: Any = AUTO, specimen: Any = AUTO,
              rights_evidence: Any = AUTO, **o: Any) -> dict[str, Any]:
    """Create the file, hash it, write rights evidence when approved, append the manifest row and (optionally) a passing image audit.

    A real diagnostic photograph needs the evidence behind it, so by default one is given: a taxon (a look-alike view gets a different taxon,
    TAX-0002) and a complete specimen record determined by the fixture domain expert. `taxon=None`, `specimen=None` or `rights_evidence=None` leaves it out."""
    row = asset_row(n, kind=kind, **o)
    evidence = row["role"] == "verified_diagnostic" and row["generation_method"] in ("camera_photo", "scan")
    if taxon is AUTO:
        taxon = ("TAX-0002" if row.get("view") == "look_alike" else "TAX-0001") if evidence else None
    if specimen is AUTO:
        specimen = f"SPM-{n:04d}" if evidence else None
    if taxon:
        add_taxon(repo, int(taxon.split("-")[1]))
    if specimen:
        add_specimen(repo, int(specimen.split("-")[1]), taxon_id=taxon or "TAX-0001")
    row["taxon_id"], row["specimen_id"] = taxon, specimen
    if rights_evidence is AUTO and row["license_status"] == "approved" and "rights_evidence_path" not in o and "rights_evidence_sha256" not in o:
        ev_rel = f"assets/rights/{row['asset_id']}.txt"
        ev_file = repo.path(ev_rel)
        ev_file.parent.mkdir(parents=True, exist_ok=True)
        ev_file.write_text(f"Fixture rights evidence for {row['asset_id']} ({row.get('license')}).\n", encoding="utf-8")
        row["rights_evidence_path"] = ev_rel
        row["rights_evidence_sha256"] = sha256_file(ev_file)
    if write_file and row.get("local_path"):
        # two catalogue rows must never share a file (ASSET_DUPLICATE_BYTES): the colour differs by kind and by n
        make_png(repo.path(row["local_path"]), color=(180 + n, 180, 180) if kind == "photo" else (180, 180 + n, 180))
        row.setdefault("sha256", None)
        if not o.get("sha256"):
            row["sha256"] = sha256_file(repo.path(row["local_path"]))
    append_row(repo, "assets", row)
    if audited and row.get("sha256"):
        add_image_audit(repo, row["asset_id"])
    return row


def record_digest(repo: Repo, asset_id: str) -> str:
    ctx = context(repo)
    return package_mod.asset_record_digest(asset_id, assets=ctx.assets, taxa=ctx.taxa, specimens=ctx.specimens, repo_root=repo.root)


def add_image_audit(repo: Repo, asset_id: str, **o: Any) -> dict[str, Any]:
    """A passing image audit by the fixture domain expert, bound to the file hash and the record digest as they stand."""
    asset = next(r for r in read_rows(repo, "assets") if r["asset_id"] == asset_id)
    row = {"audit_id": f"IMG-{len(read_rows(repo, 'image_audit')) + 1:04d}", "asset_id": asset_id, "asset_sha256": asset["sha256"],
           "record_sha256": record_digest(repo, asset_id), "provenance_checked": True, "license_checked": True,
           "identification_checked": True, "caption_alt_checked": True, "decision": "pass", "reviewer_id": "REV-0004",
           "capacity": "external_sme", "reviewed_on": DATE}
    row.update(o)
    if row["decision"] in ("fail", "conditional"):
        row.setdefault("notes", "Fixture finding.")
    append_row(repo, "image_audit", row)
    return row


# ---------------------------------------------------------------------- worlds
def build_world(repo: Repo, status: str = "published", *, fm_factory: Callable[..., dict[str, Any]] = entry_dict, body: str | None = None,
                reviews: bool = True, **over: Any) -> Path:
    """Register everything an entry needs to pass every gate up to `status`; returns the entry path.

    From `approved` on that includes the editorial approval and every independent review the entry's classification requires,
    all by registered fixture reviewers and bound to the entry as it stands. `reviews=False` builds the entry without them."""
    rank = LADDER.index(status)
    fm = fm_factory(status=status, **over)
    if rank >= 2:
        fm["technical_reviewer"] = "REV-0005"
    if rank >= 3:
        fm["editorial_reviewer"] = "REV-0003"
        fm["approved_by_chatgpt"] = True
    verified = rank >= 2
    append_row(repo, "sources", source_row(verification_status="verified" if verified else "unverified",
                                           verified_by="Fixture Reviewer" if verified else None, verified_on=DATE if verified else None))
    state = dict(status="verified" if verified else "UNVERIFIED", verified_by="Fixture Reviewer" if verified else None,
                 verified_on=DATE if verified else None, evidence_date=DATE if verified else None)
    # FR-008: the claim a species profile or medical entry rests on has the type its claim policy needs (identification, medical)
    append_row(repo, "claims", claim_row(claim_type=ENTRY_CLAIM_TYPE.get(fm["entry_type"], "specification"), **state))
    if "CLM-0002" in claim_ids_of(fm):
        append_row(repo, "claims", claim_row(claim_id="CLM-0002", claim_type="legal", **state))
    if body is None:  # a published entry has no body: the layout has no section for one (PUBLISHED_BODY_NOT_RENDERED)
        body = "" if status == "published" else "Fixture body text.\n"
    if fm.get("taxon_id"):
        add_taxon(repo, int(fm["taxon_id"].split("-")[1]))
    path = write_entry(repo, fm, body)
    set_zone(repo, fm["zone"], status="in_drafting", approved_cards=1 if rank >= 3 else 0)
    if rank >= 3 and reviews:
        add_approval(repo, path)
        add_required_reviews(repo, path)
    return path


def codes(findings: Any, severity: str = "error") -> set[str]:
    return {f.code for f in findings if f.severity == severity}


# ------------------------------------------------------------------ more helpers
def medical_dict(**o: Any) -> dict[str, Any]:
    fm = entry_dict(entry_type="medical_guidance", id="Z10-FIXTURE-001", zone="Z10")
    for key in ("materials_tools", "dimension_unit_table", "environmental_constraints", "inspection_acceptance_criteria",
                "failure_modes", "hazard_boundaries"):
        del fm[key]
    fm.update({"audience_scope": "Fixture audience", "evidence_date": DATE, "emergency_evacuation_threshold": "Fixture threshold",
               "contraindications": ["Fixture contraindication"], "local_emergency_service_guidance": "Fixture guidance",
               "field_claims": {"audience_scope": ["CLM-0001"], "emergency_evacuation_threshold": ["CLM-0001"], "contraindications": ["CLM-0001"],
                                "local_emergency_service_guidance": ["CLM-0001"], "dangers": ["CLM-0001"]}})
    fm.update(o)
    return fm


def set_zone(repo: Repo, zone_id: str, **fields: Any) -> None:
    """Edit one zone in the temporary repo's content/zones.yaml."""
    path = repo.path("content/zones.yaml")
    data = yaml.safe_load(path.read_text(encoding="utf-8"))
    for zone in data["zones"]:
        if zone["id"] == zone_id:
            zone.update(fields)
    path.write_text(yaml.safe_dump(data, sort_keys=False, allow_unicode=True), encoding="utf-8", newline="\n")


def rewrite_entry(path: Path, fn: Callable[[dict[str, Any]], None]) -> None:
    """Apply `fn` to an entry's front matter and write it back, keeping the body."""
    fm, body = parse_entry(path.read_bytes())
    fn(fm)
    path.write_text("---\n" + yaml.safe_dump(fm, sort_keys=False, allow_unicode=True) + "---\n" + body, encoding="utf-8", newline="\n")


# ------------------------------------------------------------------ reviewer registry (FR-005)
HZ_TOPICS = [t["id"] for t in load_yaml((REAL / "schemas/hazard_topics.yaml").read_text(encoding="utf-8"))["topics"]]
CLS_SUBJECTS = ["CLS-HIGH-RISK", "CLS-IDENTIFICATION", "CLS-MEDICAL", "CLS-SCREENING"]
ID_GROUPS = ["ID-PLANT", "ID-FUNGUS", "ID-LICHEN", "ID-MINERAL", "ID-ROCK", "ID-MATERIAL"]
ALL_DOMAINS = HZ_TOPICS + CLS_SUBJECTS + ID_GROUPS


def register(repo: Repo, reviewer_id: str, capacity: str, *, kind: str, name: str, domains: Any = (), evidence: str | None = None,
             by: str = "REV-0001", on: str = DATE, until: str | None = None, action: str = "register",
             revokes: str | None = None, notes: str | None = None) -> dict[str, Any]:
    """Append one registry event (the ledger is re-sealed). Fixture people and models only."""
    row = {"registration_id": f"REG-{len(read_rows(repo, 'reviewers')) + 1:04d}", "action": action, "reviewer_id": reviewer_id,
           "display_name": name, "kind": kind, "capacity": capacity, "domains": list(domains), "qualification_evidence": evidence,
           "registered_by": by, "revokes_registration_id": revokes, "registered_on": on, "valid_until": until, "notes": notes}
    append_row(repo, "reviewers", row)
    return row


def seed_registry(repo: Repo) -> None:
    """The standard fixture registry: an owner, an author, ChatGPT validation, a human domain expert, a technical reviewer, an adjudicator."""
    register(repo, "REV-0001", "registrar", kind="owner", name="Fixture Owner", by="REV-0001")
    register(repo, "REV-0002", "author", kind="ai_model", name="Fixture Author")
    register(repo, "REV-0003", "chatgpt_editorial", kind="ai_model", name="Fixture ChatGPT Editorial", domains=["ALL"], evidence="Fixture model card")
    register(repo, "REV-0004", "external_sme", kind="human", name="Fixture Domain Expert", domains=ALL_DOMAINS, evidence="Fixture credential")
    register(repo, "REV-0005", "technical_reviewer", kind="human", name="Fixture Technical Reviewer", domains=ALL_DOMAINS, evidence="Fixture credential")
    register(repo, "REV-0006", "adjudicator", kind="human", name="Fixture Adjudicator", evidence="Fixture appointment")


def pin_for(repo: Repo) -> str:
    """Create an external continuity pin for the repository's current verified ledgers (FR-003)."""
    return create_pin(repo)


def tamper(repo: Repo, name: str, fn: Callable[[list[str]], list[str]]) -> None:
    """Edit the RAW lines of a register file without re-sealing: the way a person with a text editor or a spreadsheet would."""
    path = repo.path(REGISTERS[name][0])
    lines = path.read_text(encoding="utf-8").split("\n")
    trailing = lines[-1] == ""
    body = lines[:-1] if trailing else lines
    out = fn(body)
    path.write_text("\n".join(out) + ("\n" if trailing else ""), encoding="utf-8", newline="")
