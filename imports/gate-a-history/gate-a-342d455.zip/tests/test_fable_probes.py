"""Regression: every FABLE-REVIEW-001 probe that RUN-003 claims to close stays closed (probes ported in tests/fable_probes.py).

A probe is refused only if the validator blocks it FOR THE STATED REASON and the valid world it started from was itself clean. The probes
that RUN-003 does not close (FINDING_REMEDIATION_MATRIX.md section 4) are measured by `python tests/fable_probes.py` and reported in RUN-003.md;
they are deliberately not asserted here, so that no test pins an open hole in place.
"""
from __future__ import annotations

import pytest

import fable_probes as FP

# The 59 probes of FABLE-REVIEW-001 (evidence/probes.py, probes2.py, probes3.py).
REVIEW_PROBES = {
    "P01", "P02", "P03a", "P03b", "P04", "P05", "P06", "P07", "P08a", "P08b", "P08c", "P09", "P36", "P52", "P53", "P10a", "P10b", "P11a", "P11b", "P24",
    "P12", "P13", "P14", "P15", "P16", "P17", "P32", "P34", "P18", "P19a", "P19b", "P21", "P22a", "P22b", "P49", "P47", "P46", "P27", "P28", "P29", "P23",
    "P20", "P25", "P26", "P09b", "P18b", "P13b", "P60", "P70", "P71", "P72", "P73", "P80", "P81", "P90", "P91", "P92", "P93", "P94",
}
IN_SCOPE = [p for p in FP.PROBES if p.scope == "in"]
OUT_OF_SCOPE = [p for p in FP.PROBES if p.scope == "out"]


def test_every_probe_of_the_review_has_a_counterpart_and_none_is_invented():
    ids = [p.pid for p in FP.PROBES]
    assert len(ids) == len(set(ids)) == len(REVIEW_PROBES) == 59
    assert set(ids) == REVIEW_PROBES


def test_every_probe_names_its_finding_and_every_open_one_says_so():
    for p in FP.PROBES:
        assert p.finding, p.pid
        if p.scope == "out":
            assert "open" in p.finding or p.finding.startswith("("), f"{p.pid}: an out-of-scope probe must say what stays open, or that it only measures"
        else:
            assert "open" not in p.finding, f"{p.pid} is in scope but its finding says it is open"


def test_the_split_between_closed_and_open_is_the_one_the_run_record_states():
    assert len(IN_SCOPE) == 50 and len(OUT_OF_SCOPE) == 9
    assert {p.pid for p in OUT_OF_SCOPE} == {"P26", "P29", "P70", "P71", "P73", "P80", "P81", "P91", "P94"}


@pytest.mark.parametrize("probe", IN_SCOPE, ids=lambda p: p.pid)
def test_the_counterexample_is_refused_for_the_stated_reason(probe, tmp_path):
    result = probe.fn(FP.Kit(tmp_path))
    assert result.verdict == "BLOCKED", f"{probe.pid} ({probe.title}) is accepted again: {result.info}"
    missing = set(probe.expect) - set(result.errors)
    assert not missing, f"{probe.pid} is blocked, but not for {sorted(missing)}: it was refused with {result.errors}"
    if probe.expect_any:
        assert set(probe.expect_any) & set(result.errors), f"{probe.pid} is blocked, but for none of {probe.expect_any}: {result.errors}"
    for text in probe.expect_text:
        assert any(text in message for message in result.messages), f"{probe.pid} is blocked, but nothing says {text!r}: {result.messages}"
    if not probe.no_control:
        assert result.control == [], f"{probe.pid}: the valid world it starts from is not clean ({result.control}), so the refusal proves nothing"


@pytest.mark.parametrize("probe", [p for p in OUT_OF_SCOPE if not p.slow], ids=lambda p: p.pid)
def test_the_open_probes_still_run(probe, tmp_path):
    """Smoke only: an open probe must keep building its scenario, so the run record can keep measuring it. Its verdict is not asserted."""
    result = probe.fn(FP.Kit(tmp_path))
    assert result.verdict in {"ELIGIBLE", "BLOCKED", "INFO"}


def test_p08c_tail_truncation_is_caught_in_git_and_by_external_pin_in_bare_export(tmp_path):
    """Replaces RUN-003's `test_the_p08c_residual_is_stated_not_hidden`: tail truncation in a bare export is now caught by an external
    continuity pin (LEDGER_PIN_TRUNCATED), and without a pin release fails closed (LEDGER_PIN_REQUIRED) while validate warns."""
    p08c = next(p for p in FP.PROBES if p.pid == "P08c")
    result = p08c.fn(FP.Kit(tmp_path))
    assert result.verdict == "BLOCKED" and result.info["blocked_while_recorded"] is True
    assert "LEDGER_PIN_TRUNCATED" in result.info["outside_git_with_pin"]
    assert "LEDGER_CONTINUITY_UNANCHORED" in result.info["outside_git_unpinned_validate_warnings"]
    assert "LEDGER_PIN_REQUIRED" in result.info["outside_git_unpinned_release_errors"]
