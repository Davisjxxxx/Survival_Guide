"""The epstopdf message "Shell escape feature is not enabled".

Cause: epstopdf-base warns at LOAD time whenever shell escape is off, whether or not any EPS file exists; newer graphics drivers load it.
Handling, in three layers, none of which enables shell escape or waives warning validation in general:
  1. remove the cause: the driver's documented opt-out (\\DoNotLoadEpstopdf) is the first line of every generated main.tex;
  2. make it irrelevant by construction: the renderer accepts PNG, JPEG and PDF only, so no EPS can ever be part of a build;
  3. classify the exact message as a NOTE (never an error, never silent) only when both facts hold in that build.
"""
from __future__ import annotations

import shutil
import subprocess

import pytest

from factories import REAL, entry_dict
from sfe import cli
from sfe.common import Finding, note
from sfe.pdfbuild import build_proof, load_build_config, parse_latex_log, run_latex
from sfe.registry import Repo
from sfe.texgen import RENDERABLE_IMAGE_TYPES, RenderError, render_document, render_entry

LINE = "Package epstopdf Warning: Shell escape feature is not enabled.\n"
NOTE = "TOOLCHAIN_NOTE_EPSTOPDF_SHELL_ESCAPE"


def kinds(findings):
    return [(f.severity, f.code) for f in findings]


has_epstopdf = shutil.which("kpsewhich") is not None and subprocess.run(["kpsewhich", "epstopdf-base.sty"], capture_output=True, text=True).stdout.strip() != ""


@pytest.mark.skipif(not has_epstopdf, reason="epstopdf-base.sty is not installed")
def test_the_real_warning_from_the_real_package_is_reproduced_on_the_pinned_toolchain(tmp_path):
    """Loading pdftexcmds first defines \\pdf@shellescape, which is what makes the real epstopdf-base emit its real warning under --no-shell-escape."""
    (tmp_path / "main.tex").write_text(
        "\\documentclass{article}\\usepackage{graphicx}\\usepackage{pdftexcmds}\\usepackage{epstopdf-base}\\begin{document}x\\end{document}\n", encoding="utf-8")
    pdf, log, _ = run_latex(tmp_path, epoch=1794787200)
    assert LINE.strip() in log and pdf.exists(), "the build still succeeds: the message is a warning, not an error"
    assert kinds(parse_latex_log(log, "log")) == [("info", NOTE)]
    assert kinds(parse_latex_log(log, "log", graphics_inputs=["img/figure.eps"])) == [("warning", "LATEX_WARNING")]


def test_the_note_is_exact_match_and_guarded():
    assert kinds(parse_latex_log(LINE, "log")) == [("info", NOTE)]
    assert kinds(parse_latex_log("Package epstopdf-base Warning: Shell escape feature is not enabled.\n", "log")) == [("info", NOTE)]
    assert kinds(parse_latex_log("Package epstopdf Warning: Shell escape feature is not enabled. on input line 7.\n", "log")) == [("info", NOTE)]


@pytest.mark.parametrize("log", [
    "Package foo Warning: Shell escape feature is not enabled.\n",                                    # another package
    "Package epstopdf Warning: Shell escape feature is not enabled. Conversion failed\n",             # extra text: not the known message
    "Package epstopdf Warning: Drivers other than `pdftex' and `luatex' are not supported.\n",        # another epstopdf warning
    "Package epstopdf Warning: No graphics package `graphic{s,x}' loaded.\n",
    "LaTeX Warning: Shell escape feature is not enabled.\n",
    "Package epstopdf Info: Source file: <figure.eps>\n" + LINE,                                      # conversion was attempted: not benign
    LINE + "(epstopdf) Output file: <figure-eps-converted-to.pdf>\n",
])
def test_nothing_else_is_waived(log):
    assert NOTE not in {f.code for f in parse_latex_log(log, "log")}
    assert any(f.severity == "warning" for f in parse_latex_log(log, "log")), "it must remain a visible warning"


@pytest.mark.parametrize("name", ["img/a.eps", "img/a.EPS", "figure.ps"])
def test_an_eps_or_ps_graphic_in_the_build_makes_the_message_a_real_warning(name):
    assert kinds(parse_latex_log(LINE, "log", graphics_inputs=[name])) == [("warning", "LATEX_WARNING")]


def test_the_waiver_is_a_note_never_an_error_and_never_silent():
    finding = parse_latex_log(LINE, "log")[0]
    assert isinstance(finding, Finding) and finding.severity == "info" and "epstopdf" in finding.message and "EPS" in finding.message


def test_other_log_problems_are_still_errors_next_to_the_note():
    log = LINE + "Overfull \\hbox (9.0pt too wide) in paragraph at lines 3--4\n"
    assert sorted(kinds(parse_latex_log(log, "log"))) == [("error", "LAYOUT_OVERFLOW"), ("info", NOTE)]


# ------------------------------------------------------------------------------ layer 1: the opt-out
def test_the_documented_opt_out_is_the_first_line_before_documentclass():
    tex = render_document("body", paper="letterpaper", proof=True, title="T", author="A", subject="S", keywords="K",
                          footer_left="L", footer_right="R", version="0.1.0")
    lines = tex.splitlines()
    assert lines[0] == r"\newcommand{\DoNotLoadEpstopdf}{}"
    assert lines.index(r"\documentclass[10pt]{article}") == 1


def test_the_opt_out_keeps_epstopdf_out_of_the_log(tmp_path):
    (tmp_path / "main.tex").write_text("\\newcommand{\\DoNotLoadEpstopdf}{}\\documentclass{article}\\usepackage{graphicx}\\begin{document}x\\end{document}\n", encoding="utf-8")
    _, log, _ = run_latex(tmp_path, epoch=1794787200)
    assert "epstopdf" not in log.lower()


# ------------------------------------------------------------------------------ layer 2: EPS cannot occur
def _asset(suffix):
    return {"asset_id": "PHO-0001", "asset_kind": "photo", "local_path": f"assets/original_photos/PHO-0001{suffix}", "license_status": "approved",
            "role": "decorative_only", "view": None, "license": "L", "caption": "c", "alt_text": "a"}


@pytest.mark.parametrize("suffix", [".eps", ".EPS", ".ps", ".tif", ".tiff", ".bmp", ".gif", ".svg"])
def test_the_renderer_refuses_image_types_that_need_conversion(tmp_path, suffix):
    asset = _asset(suffix)
    (tmp_path / asset["local_path"]).parent.mkdir(parents=True)
    (tmp_path / asset["local_path"]).write_bytes(b"x")
    with pytest.raises(RenderError, match="cannot be rendered"):
        render_entry(entry_dict(photo_ids=["PHO-0001"]), assets={"PHO-0001": asset}, sources={}, zone_title="Z", proof=False, repo_root=tmp_path)


@pytest.mark.parametrize("suffix", [".png", ".jpg", ".jpeg", ".pdf", ".PNG"])
def test_the_renderer_accepts_the_directly_supported_types(tmp_path, suffix):
    asset = _asset(suffix)
    (tmp_path / asset["local_path"]).parent.mkdir(parents=True)
    (tmp_path / asset["local_path"]).write_bytes(b"x")
    rendered = render_entry(entry_dict(photo_ids=["PHO-0001"]), assets={"PHO-0001": asset}, sources={}, zone_title="Z", proof=False, repo_root=tmp_path)
    assert list(rendered.files) == [f"img/PHO-0001{suffix.lower()}"]


def test_the_accepted_image_types_are_exactly_png_jpeg_and_pdf():
    assert RENDERABLE_IMAGE_TYPES == (".png", ".jpg", ".jpeg", ".pdf")


# ------------------------------------------------------------ shell escape stays off, validation is not disabled
def test_shell_escape_is_never_enabled_in_any_flag_or_environment(tmp_path, monkeypatch):
    calls = []

    class Done:
        returncode, stdout, stderr = 0, "", ""

    monkeypatch.setattr("sfe.pdfbuild.subprocess.run", lambda command, **kw: calls.append((command, kw)) or Done())
    run_latex(tmp_path, epoch=1794787200)
    command, kwargs = calls[0]
    assert "--no-shell-escape" in command
    assert not {"-shell-escape", "--shell-escape", "-enable-write18", "--enable-write18", "-enable-pipes"} & set(command)
    assert kwargs["env"]["openout_any"] == "p" and kwargs["env"]["openin_any"] == "p"


def test_the_note_flows_through_a_whole_build_without_failing_it_and_without_hiding_other_warnings(tmp_path, monkeypatch):
    import sfe.pdfbuild as pdfbuild
    real = pdfbuild.run_latex
    state = {"extra": ""}

    def with_messages(workdir, **kwargs):
        pdf, log, runs = real(workdir, **kwargs)
        return pdf, log + LINE + state["extra"], runs

    monkeypatch.setattr(pdfbuild, "run_latex", with_messages)
    first = build_proof(Repo(REAL), out_dir=tmp_path / "a", previews=False)
    assert first.ok and NOTE in {f.code for f in first.findings if f.severity == "info"}
    import json
    manifest = json.loads(first.manifest.read_text(encoding="utf-8"))
    assert manifest["qa"]["notes"] == [NOTE] and manifest["qa"]["warnings"] == ["PDF_UNTAGGED"] and manifest["qa"]["errors"] == 0

    state["extra"] = "Package foo Warning: something else entirely.\n"
    second = build_proof(Repo(REAL), out_dir=tmp_path / "b", previews=False)
    assert second.ok
    assert "LATEX_WARNING" in {f.code for f in second.findings if f.severity == "warning"}, "an unrelated warning must still be reported"
    assert first.sha256 == second.sha256, "the log gate never changes the PDF"


def test_notes_are_counted_separately_and_never_fail_a_run(capsys):
    findings = [Finding("error", "E", "w", "m"), Finding("warning", "W", "w", "m"), note("N", "w", "m")]
    assert cli._print_findings(findings) == (1, 1, 1)
    assert cli._counts(1, 1, 1) == "1 error(s), 1 warning(s), 1 note(s)"
    assert cli._counts(0, 0, 0) == "0 error(s), 0 warning(s)", "the summary format is unchanged when there are no notes"
    assert "INFO" in capsys.readouterr().out
