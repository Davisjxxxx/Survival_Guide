"""'Preserve all handoff documents and previous records': hashes recorded before any work began must still match."""
from __future__ import annotations

import hashlib
import shutil
import subprocess

import pytest

from factories import REAL

PRESERVED = REAL / "PRESERVED_FILES.sha256"
EXPECTED = {
    "BASELINE_AUDIT_20261116.md",
    "handoff/README_INSTALL.md",
    "handoff/SHA256SUMS.txt",
    "handoff/SURVIVAL_FIELD_ENCYCLOPEDIA_ASTRA_CLI_HANDOFF.md",
    "handoff/Survival_Field_Encyclopedia_Master_Sprint_Plan_v1.md",
    "handoff/Survival_Field_Encyclopedia_Sprint_Tracker_v1.xlsx",
}


def parse(path):
    pairs = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        digest, name = line.split("  ", 1)
        pairs[name] = digest
    return pairs


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def test_manifest_lists_exactly_the_preserved_files():
    assert set(parse(PRESERVED)) == EXPECTED


def test_preserved_files_match_hashes_recorded_before_work_began():
    for name, digest in parse(PRESERVED).items():
        assert sha(REAL / name) == digest, f"{name} was modified"


def test_supplied_package_checksums_verify():
    sums = parse(REAL / "handoff/SHA256SUMS.txt")
    assert len(sums) == 3
    for name, digest in sums.items():
        assert sha(REAL / "handoff" / name) == digest, name


def test_gitattributes_stops_git_rewriting_preserved_files():
    text = (REAL / ".gitattributes").read_text(encoding="utf-8")
    assert "handoff/** -text" in text and "BASELINE_AUDIT_20261116.md -text" in text


needs_git = pytest.mark.skipif(not (REAL / ".git").exists() or shutil.which("git") is None, reason="not a git checkout")


@needs_git
def test_preserved_files_equal_their_first_committed_version():
    """Compares the working file with the blob from the commit that first added it (the verbatim import)."""
    for name in EXPECTED:
        first = subprocess.run(["git", "log", "--diff-filter=A", "--format=%H", "--", name], cwd=REAL,
                               capture_output=True, text=True, check=True).stdout.split()[-1]
        blob = subprocess.run(["git", "show", f"{first}:{name}"], cwd=REAL, capture_output=True, check=True).stdout
        assert blob == (REAL / name).read_bytes(), f"{name} differs from the version first committed in {first[:8]}"
