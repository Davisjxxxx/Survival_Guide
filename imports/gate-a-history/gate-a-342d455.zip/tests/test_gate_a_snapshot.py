"""Gate A baseline guard: no content, no research, no photographs, no approvals exist yet.

These tests encode the Gate A promise ("do not invent research, photos, or approvals; do not declare any zone complete").
They are deliberately a snapshot: when real packs arrive at Gate B, update or retire them in that sprint's change,
never silently. Run only these with:  pytest -m gate_a_snapshot
"""
from __future__ import annotations

import pytest

from factories import REAL
from sfe.registry import REGISTERS, load_zones

pytestmark = pytest.mark.gate_a_snapshot


def test_no_entry_files_exist(real_repo):
    zones, _ = load_zones(real_repo)
    for zone in zones:
        files = sorted(p.name for p in real_repo.path(f"content/{zone['dir']}").iterdir())
        assert files == ["README.md"], f"{zone['dir']} holds {files}"


@pytest.mark.parametrize("name", list(REGISTERS))
def test_every_register_is_header_only(real_repo, name):
    lines = real_repo.path(REGISTERS[name][0]).read_text(encoding="utf-8").splitlines()
    assert len(lines) == 1, f"{REGISTERS[name][0]} holds {len(lines) - 1} row(s); nothing may be invented before Gate B"


def test_no_approvals_audits_or_reviews_were_recorded(real_repo):
    for name in ("approvals", "image_audit", "safety_audit"):
        assert len(real_repo.path(REGISTERS[name][0]).read_text(encoding="utf-8").splitlines()) == 1


def test_asset_directories_hold_only_placeholders(real_repo):
    for rel in ("assets/original_photos", "assets/diagrams", "assets/rejected_unverified", "assets/rights"):
        assert sorted(p.name for p in real_repo.path(rel).iterdir()) == [".gitkeep"], rel


def test_release_directories_are_empty(real_repo):
    for rel in ("dist/zones", "dist/complete"):
        assert sorted(p.name for p in real_repo.path(rel).iterdir()) == [".gitkeep"], rel


def test_proofs_hold_only_the_labelled_specimen(real_repo):
    names = sorted(p.relative_to(real_repo.root).as_posix() for p in real_repo.path("proofs").rglob("*") if p.is_file())
    assert names == [
        "proofs/SPECIMEN_LAYOUT_PROOF.build.json", "proofs/SPECIMEN_LAYOUT_PROOF.pdf",
        "proofs/previews/SPECIMEN_LAYOUT_PROOF_color.png", "proofs/previews/SPECIMEN_LAYOUT_PROOF_gray.png",
    ]


def test_specimen_registers_use_only_dummy_ids():
    for rel, key in (("layouts/specimen/specimen_sources.csv", "DUMMY-SRC-"), ("layouts/specimen/specimen_claims.csv", "DUMMY-CLM-"),
                     ("layouts/specimen/specimen_assets.csv", "DUMMY-")):
        rows = (REAL / rel).read_text(encoding="utf-8").splitlines()[1:]
        assert rows and all(row.startswith(key) for row in rows), rel


def test_the_specimen_names_no_reviewer_and_claims_no_approval():
    text = (REAL / "layouts/specimen/specimen_entry.md").read_text(encoding="utf-8")
    assert "technical_reviewer: null" in text and "editorial_reviewer: null" in text
    assert "approved_by_chatgpt: false" in text and "status: draft" in text


def test_no_main_branch_and_no_remote():
    import shutil
    import subprocess
    if not (REAL / ".git").exists() or shutil.which("git") is None:
        pytest.skip("not a git checkout")
    branches = subprocess.run(["git", "branch", "--format=%(refname:short)"], cwd=REAL, capture_output=True, text=True, check=True).stdout.split()
    assert "main" not in branches and "master" not in branches, "nothing may be committed to main before authorization"
    remotes = subprocess.run(["git", "remote"], cwd=REAL, capture_output=True, text=True, check=True).stdout.split()
    assert remotes == [], "no remote may be configured at Gate A"
