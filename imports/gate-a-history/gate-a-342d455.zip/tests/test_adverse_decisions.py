"""Adverse decisions are authoritative (FR-002, FR-003, FR-004).

At RUN-002 a recorded failure blocked only when it named a topic the entry was tagged with, for the same revision, and was not outranked by a
typed date or a later pass (Fable probes P04, P05, P06, P07, P08, P10, P52, P53). These tests pin the replacement: an unresolved fail or
conditional (or a rejected or withdrawn approval) blocks the whole entry whatever it names, and only an explicit, evidence-linked
resolution by an authorised actor clears it, after which the passes must be recorded again.
"""
from __future__ import annotations

import itertools

import pytest

from factories import (
    DATE, add_approval, add_asset, add_image_audit, add_resolution, add_safety, add_safety_pair, append_row, build_world, codes, edit_rows,
    read_rows, register, rewrite_entry, tamper, write_rows,
)
from sfe.validate import validate_repo

W, CO = "HZ-WATER-POTABILITY", "HZ-COMBUSTION-CO"
SAFETY_ADVERSE = ["fail", "conditional"]


def run(repo):
    return validate_repo(repo.root)


def eligible(repo, topics=(W,), **over):
    """An approved entry with its approval and both independent reviews: eligible. The baseline of every test below."""
    path = build_world(repo, "approved", hazard_tags=list(topics), as_of_date=DATE, **over)
    found = run(repo)
    assert codes(found) == set(), [str(f) for f in found]
    return path


def first(repo, ledger, decision):
    return next(r for r in read_rows(repo, ledger) if r["decision"] == decision)


# ============================================================ A. a failure blocks the whole entry (FR-002)
@pytest.mark.parametrize("decision", SAFETY_ADVERSE)
def test_a_failure_with_no_subjects_blocks(repo, decision):
    """P04: the reviewer left topics_reviewed empty. RUN-002 ignored the failure."""
    path = eligible(repo)
    add_safety(repo, path, [], role="external_sme", decision=decision, reviewer="Reporter")
    assert "SAFETY_FAILURE_UNRESOLVED" in codes(run(repo))


@pytest.mark.parametrize("decision", SAFETY_ADVERSE)
def test_a_failure_naming_a_hazard_the_entry_is_not_classified_with_blocks_and_says_so(repo, decision):
    """P05: the reviewer found a hazard the author did not tag. The failure must stand AND the missing classification must be named."""
    path = eligible(repo)
    add_safety(repo, path, [CO], role="external_sme", decision=decision, reviewer="Reporter")
    found = run(repo)
    assert {"SAFETY_FAILURE_UNRESOLVED", "SAFETY_FAILURE_REPORTS_UNCLASSIFIED_HAZARD"} <= codes(found)
    assert CO in next(f.message for f in found if f.code == "SAFETY_FAILURE_REPORTS_UNCLASSIFIED_HAZARD")


@pytest.mark.parametrize("decision", SAFETY_ADVERSE)
def test_a_failure_on_an_entry_with_no_hazard_class_blocks(repo, decision):
    """P06: an entry whose only subject is the screening attestation. RUN-002 never read safety rows for it."""
    path = build_world(repo, "approved")
    assert codes(run(repo)) == set()
    add_safety(repo, path, [], role="technical_reviewer", decision=decision, reviewer="Reporter")
    assert "SAFETY_FAILURE_UNRESOLVED" in codes(run(repo))


@pytest.mark.parametrize("decision", SAFETY_ADVERSE)
def test_a_failure_bound_to_another_revision_blocks(repo, decision):
    """P52: the failure carries revision 2 while the entry is at revision 1."""
    path = eligible(repo)
    add_safety(repo, path, [W], role="external_sme", decision=decision, reviewer="Reporter", revision=2)
    assert "SAFETY_FAILURE_UNRESOLVED" in codes(run(repo))


@pytest.mark.parametrize("decision", SAFETY_ADVERSE)
def test_a_failure_bound_to_other_content_blocks(repo, decision):
    path = eligible(repo)
    add_safety(repo, path, [W], role="external_sme", decision=decision, reviewer="Reporter", package_sha256="a" * 64)
    assert "SAFETY_FAILURE_UNRESOLVED" in codes(run(repo))


@pytest.mark.parametrize("reviewer_id", ["REV-0099", "REV-0001", "REV-0003"])
def test_a_failure_blocks_whoever_records_it(repo, reviewer_id):
    """Identity decides whether a PASS counts. A failure blocks even from an identity the registry does not know: it is cheap to record and
    never silently discarded."""
    path = eligible(repo)
    add_safety(repo, path, [W], role="external_sme", decision="fail", reviewer_id=reviewer_id, capacity="adjudicator")
    assert "SAFETY_FAILURE_UNRESOLVED" in codes(run(repo))


def test_a_failure_does_not_need_a_packet_a_hash_or_a_subject(repo):
    eligible(repo)
    append_row(repo, "safety_audit", {"audit_id": "SAF-0099", "entry_id": "Z09-FIXTURE-001", "revision": 1, "decision": "fail",
                                      "reviewer_id": "REV-0004", "capacity": "external_sme", "reviewed_on": DATE, "notes": "Found a problem."})
    assert "SAFETY_FAILURE_UNRESOLVED" in codes(run(repo))


def test_a_failure_blocks_a_published_entry_and_the_release(repo, tmp_path):
    from sfe.pdfbuild import build_release
    path = build_world(repo, "published", hazard_tags=[W], as_of_date=DATE)
    assert codes(run(repo)) == set()
    add_safety(repo, path, [W], role="external_sme", decision="fail", reviewer="Reporter")
    assert "SAFETY_FAILURE_UNRESOLVED" in codes(run(repo))
    result = build_release(repo, out_root=tmp_path / "out")
    assert not result.ok and "SAFETY_FAILURE_UNRESOLVED" in codes(result.findings) and not (tmp_path / "out").exists()


def test_a_failure_does_not_block_an_entry_that_has_not_reached_approval(repo):
    """The approval and publication gates are where reviews are required; work in progress is not blocked by a note about it."""
    path = build_world(repo, "verified")
    add_safety(repo, path, [], role="external_sme", decision="fail", reviewer="Reporter")
    assert codes(run(repo)) == set()


def test_each_unresolved_failure_is_reported_separately(repo):
    path = eligible(repo)
    add_safety(repo, path, [W], role="external_sme", decision="fail", reviewer="One")
    add_safety(repo, path, [W], role="technical_reviewer", decision="conditional", reviewer="Two")
    assert len([f for f in run(repo) if f.code == "SAFETY_FAILURE_UNRESOLVED"]) == 2


def test_clearing_one_failure_leaves_the_other_standing(repo):
    path = eligible(repo)
    one = add_safety(repo, path, [W], role="external_sme", decision="fail", reviewer="One")
    add_safety(repo, path, [W], role="technical_reviewer", decision="conditional", reviewer="Two")
    add_resolution(repo, "safety_audit", one["audit_id"])
    left = [f for f in run(repo) if f.code == "SAFETY_FAILURE_UNRESOLVED"]
    assert len(left) == 1 and "conditional" in left[0].message


# ================================================================ B. orphans and references (P53)
@pytest.mark.parametrize("ledger,decision", [("safety_audit", "fail"), ("safety_audit", "pass"), ("approvals", "withdrawn"), ("approvals", "approved")])
def test_a_row_for_an_entry_that_does_not_exist_is_an_error(repo, ledger, decision):
    """P53: a one-character typo in the entry id. RUN-002 dropped the row silently, so a failure could vanish."""
    path = eligible(repo)
    if ledger == "safety_audit":
        add_safety(repo, path, [W], role="external_sme", decision=decision, reviewer="Reporter", entry_id="Z09-FIXTURF-001")
    else:
        add_approval(repo, path, decision=decision, entry_id="Z09-FIXTURF-001")
    assert "LEDGER_ROW_ORPHAN" in codes(run(repo))


def test_an_image_audit_for_an_asset_that_does_not_exist_is_an_error(repo):
    add_asset(repo, 1)  # with its passing audit
    edit_rows(repo, "image_audit", lambda rows: rows[0].update(asset_id="PHO-0999"))
    assert "LEDGER_ROW_ORPHAN" in codes(run(repo))


def test_an_orphan_row_can_be_retired_by_voiding_it(repo):
    path = eligible(repo)
    orphan = add_safety(repo, path, [W], role="external_sme", decision="fail", reviewer="Reporter", entry_id="Z09-FIXTURF-001")
    assert "LEDGER_ROW_ORPHAN" in codes(run(repo))
    add_resolution(repo, "safety_audit", orphan["audit_id"], by="adjudicator", kind="void")
    assert codes(run(repo)) == set()


def test_a_resolution_must_name_an_existing_row(repo):
    path = eligible(repo)
    add_safety(repo, path, [W], role="external_sme", decision="fail", reviewer="Reporter")
    add_resolution(repo, "safety_audit", "SAF-0777")
    found = codes(run(repo))
    assert "RESOLUTION_TARGET_UNKNOWN" in found and "SAFETY_FAILURE_UNRESOLVED" in found


def test_a_resolution_cannot_name_a_row_recorded_after_it(repo):
    path = eligible(repo)
    number = len(read_rows(repo, "safety_audit"))
    add_resolution(repo, "safety_audit", f"SAF-{number + 2:04d}")
    add_safety(repo, path, [W], role="external_sme", decision="fail", reviewer="Reporter")
    found = codes(run(repo))
    assert "RESOLUTION_TARGET_NOT_EARLIER" in found and "SAFETY_FAILURE_UNRESOLVED" in found


def test_a_pass_is_not_cleared_only_voided(repo):
    eligible(repo)
    target = first(repo, "safety_audit", "pass")
    add_resolution(repo, "safety_audit", target["audit_id"], kind="cleared")
    assert "RESOLUTION_TARGET_NOT_ADVERSE" in codes(run(repo))


def test_a_resolution_cannot_be_resolved(repo):
    path = eligible(repo)
    failure = add_safety(repo, path, [W], role="external_sme", decision="fail", reviewer="Reporter")
    resolution = add_resolution(repo, "safety_audit", failure["audit_id"])
    add_resolution(repo, "safety_audit", resolution["audit_id"], kind="void")
    assert "RESOLUTION_TARGET_IS_RESOLUTION" in codes(run(repo))


def test_a_failure_cannot_be_resolved_twice(repo):
    path = eligible(repo)
    failure = add_safety(repo, path, [W], role="external_sme", decision="fail", reviewer="Reporter")
    add_resolution(repo, "safety_audit", failure["audit_id"])
    add_resolution(repo, "safety_audit", failure["audit_id"])
    assert "RESOLUTION_DUPLICATE" in codes(run(repo))


def test_a_resolution_that_names_another_entry_is_rejected(repo):
    path = eligible(repo)
    failure = add_safety(repo, path, [W], role="external_sme", decision="fail", reviewer="Reporter")
    add_resolution(repo, "safety_audit", failure["audit_id"], entry_id="Z09-OTHER-001")
    found = codes(run(repo))
    assert "RESOLUTION_ENTITY_MISMATCH" in found and "SAFETY_FAILURE_UNRESOLVED" in found


# ======================================================== C. a resolution needs evidence and authority (FR-004)
def blocked_entry(repo):
    path = eligible(repo)
    failure = add_safety(repo, path, [W], role="external_sme", decision="fail", reviewer="Reporter")
    return path, failure


@pytest.mark.parametrize("override", [
    {"evidence_sha256": "0" * 64},
    {"evidence_path": "reviews/evidence/does-not-exist.txt"},
    {"evidence_path": "assets/original_photos/x.txt"},
    {"evidence_path": "../outside.txt"},
])
def test_a_resolution_with_bad_evidence_does_not_clear_the_failure(repo, override):
    path, failure = blocked_entry(repo)
    add_resolution(repo, "safety_audit", failure["audit_id"], **override)
    found = codes(run(repo))
    assert "RESOLUTION_EVIDENCE_INVALID" in found and "SAFETY_FAILURE_UNRESOLVED" in found


def test_a_resolution_without_evidence_columns_is_a_schema_error_and_does_not_clear(repo):
    path, failure = blocked_entry(repo)
    add_resolution(repo, "safety_audit", failure["audit_id"], evidence_path=None, evidence_sha256=None)
    found = codes(run(repo))
    assert "ROW_SCHEMA" in found and "SAFETY_FAILURE_UNRESOLVED" in found


def test_a_resolution_without_a_reason_is_a_schema_error(repo):
    path, failure = blocked_entry(repo)
    add_resolution(repo, "safety_audit", failure["audit_id"], notes=None)
    assert "ROW_SCHEMA" in codes(run(repo))


def test_the_evidence_file_is_bound_by_hash_so_editing_it_later_breaks_the_resolution(repo):
    path, failure = blocked_entry(repo)
    resolution = add_resolution(repo, "safety_audit", failure["audit_id"])
    add_safety_pair(repo, path, [W])
    assert codes(run(repo)) == set()
    repo.path(resolution["evidence_path"]).write_text("rewritten after the fact", encoding="utf-8")
    found = codes(run(repo))
    assert "RESOLUTION_EVIDENCE_INVALID" in found and "SAFETY_FAILURE_UNRESOLVED" in found


def test_the_reviewer_who_recorded_a_failure_can_clear_it(repo):
    path, failure = blocked_entry(repo)
    add_resolution(repo, "safety_audit", failure["audit_id"], by=(failure["reviewer_id"], failure["capacity"]))
    assert "SAFETY_FAILURE_UNRESOLVED" not in codes(run(repo))


def test_a_registered_adjudicator_can_clear_any_failure(repo):
    path, failure = blocked_entry(repo)
    add_resolution(repo, "safety_audit", failure["audit_id"], by="adjudicator")
    assert "SAFETY_FAILURE_UNRESOLVED" not in codes(run(repo))


@pytest.mark.parametrize("by", ["technical_reviewer", "chatgpt_editorial", "user"])
def test_nobody_else_can_clear_a_failure(repo, by):
    """P07 / P10: a different reviewer, ChatGPT, or even the owner cannot make another reviewer's failure go away."""
    path, failure = blocked_entry(repo)
    add_resolution(repo, "safety_audit", failure["audit_id"], by=by, name="Someone Else")
    found = codes(run(repo))
    assert "RESOLUTION_UNAUTHORIZED" in found and "SAFETY_FAILURE_UNRESOLVED" in found


def test_an_unregistered_identity_cannot_clear_a_failure(repo):
    path, failure = blocked_entry(repo)
    add_resolution(repo, "safety_audit", failure["audit_id"], by=("REV-0099", "adjudicator"))
    found = codes(run(repo))
    assert "RESOLUTION_UNAUTHORIZED" in found and "SAFETY_FAILURE_UNRESOLVED" in found


def test_the_entrys_author_cannot_clear_a_failure_about_their_own_entry(repo):
    path, failure = blocked_entry(repo)
    register(repo, "REV-0006", "author", kind="human", name="Fixture Adjudicator")
    rewrite_entry(path, lambda fm: fm.update(authored_by="REV-0006"))
    add_resolution(repo, "safety_audit", failure["audit_id"], by="adjudicator")
    found = run(repo)
    assert any(f.code == "RESOLUTION_UNAUTHORIZED" and "author" in f.message for f in found)
    assert "SAFETY_FAILURE_UNRESOLVED" in codes(found)


def test_a_revoked_adjudicator_cannot_clear_a_failure(repo):
    path, failure = blocked_entry(repo)
    register(repo, "REV-0006", "adjudicator", kind="human", name="Fixture Adjudicator", action="revoke", revokes="REG-0006")
    add_resolution(repo, "safety_audit", failure["audit_id"], by="adjudicator")
    assert "RESOLUTION_UNAUTHORIZED" in codes(run(repo))


def test_only_an_adjudicator_or_the_registrar_can_void_a_row(repo):
    path, failure = blocked_entry(repo)
    add_resolution(repo, "safety_audit", failure["audit_id"], by=(failure["reviewer_id"], failure["capacity"]), kind="void")
    assert "RESOLUTION_UNAUTHORIZED" in codes(run(repo)), "the reviewer who recorded it may clear it, not void it"


@pytest.mark.parametrize("by", ["adjudicator", "user"])
def test_an_adjudicator_or_the_registrar_can_void_a_failure_entered_in_error(repo, by):
    path, failure = blocked_entry(repo)
    add_resolution(repo, "safety_audit", failure["audit_id"], by=by, kind="void")
    found = codes(run(repo))
    assert "SAFETY_FAILURE_UNRESOLVED" not in found and "RESOLUTION_UNAUTHORIZED" not in found


def test_voiding_a_failure_still_requires_the_work_to_be_redone(repo):
    """Voiding an adverse row is a resolution too: the passes recorded before it no longer count."""
    path, failure = blocked_entry(repo)
    add_resolution(repo, "safety_audit", failure["audit_id"], by="adjudicator", kind="void")
    assert "SAFETY_AUDIT_SUPERSEDED" in codes(run(repo))
    add_safety_pair(repo, path, [W])
    assert codes(run(repo)) == set()


def test_voiding_a_pass_removes_it_without_moving_the_barrier(repo):
    path = eligible(repo)
    chatgpt = [r for r in read_rows(repo, "safety_audit") if r["reviewer_id"] == "REV-0003"][0]
    add_resolution(repo, "safety_audit", chatgpt["audit_id"], by="adjudicator", kind="void")
    found = run(repo)
    assert "SAFETY_REVIEW_ROLE_MISSING" in codes(found) and "SAFETY_AUDIT_SUPERSEDED" not in codes(found)
    add_safety(repo, path, [W], role="chatgpt_editorial")
    assert codes(run(repo)) == set()


# ============================================================ D. the approvals ledger (P10, P11)
def approved(repo):
    path = eligible(repo)
    return path, first(repo, "approvals", "approved")


@pytest.mark.parametrize("decision", ["rejected", "withdrawn"])
def test_an_adverse_approval_decision_blocks(repo, decision):
    path, _ = approved(repo)
    add_approval(repo, path, decision=decision)
    assert "APPROVAL_NOT_CURRENT" in codes(run(repo))


def test_p10a_a_withdrawal_by_chatgpt_is_not_overridden_by_another_role_approving_later(repo):
    path, _ = approved(repo)
    add_approval(repo, path, decision="withdrawn")
    add_approval(repo, path, reviewer_id="REV-0005", capacity="technical_reviewer")
    assert "APPROVAL_NOT_CURRENT" in codes(run(repo))


def test_p10b_an_sme_rejection_is_not_overridden_by_the_owner_approving_later(repo):
    path, _ = approved(repo)
    add_approval(repo, path, decision="rejected", reviewer_id="REV-0004", capacity="external_sme")
    add_approval(repo, path, reviewer_id="REV-0001", capacity="registrar")
    assert "APPROVAL_NOT_CURRENT" in codes(run(repo))


def test_a_new_editorial_approval_alone_does_not_clear_a_withdrawal(repo):
    path, _ = approved(repo)
    add_approval(repo, path, decision="withdrawn")
    add_approval(repo, path)
    assert "APPROVAL_NOT_CURRENT" in codes(run(repo))


def test_after_a_resolution_the_earlier_approval_no_longer_counts(repo):
    path, _ = approved(repo)
    withdrawal = add_approval(repo, path, decision="withdrawn")
    add_resolution(repo, "approvals", withdrawal["approval_id"], by=(withdrawal["reviewer_id"], withdrawal["capacity"]))
    found = run(repo)
    assert "APPROVAL_NOT_CURRENT" in codes(found) and any("before the latest adverse" in f.message for f in found if f.code == "APPROVAL_NOT_CURRENT")


def test_a_resolution_and_a_new_editorial_approval_restore_the_entry(repo):
    path, _ = approved(repo)
    withdrawal = add_approval(repo, path, decision="withdrawn")
    add_resolution(repo, "approvals", withdrawal["approval_id"], by="adjudicator")
    add_approval(repo, path)
    assert codes(run(repo)) == set()


def test_an_approval_recorded_before_the_resolution_does_not_count(repo):
    path, _ = approved(repo)
    withdrawal = add_approval(repo, path, decision="withdrawn")
    add_approval(repo, path)
    add_resolution(repo, "approvals", withdrawal["approval_id"], by="adjudicator")
    assert "APPROVAL_NOT_CURRENT" in codes(run(repo))
    add_approval(repo, path)
    assert codes(run(repo)) == set()


def test_an_adverse_approval_for_another_revision_still_blocks(repo):
    path, _ = approved(repo)
    add_approval(repo, path, decision="withdrawn", revision=2)
    assert "APPROVAL_NOT_CURRENT" in codes(run(repo))


def test_p11_a_date_cannot_rescue_an_approval(repo):
    """P11a: an approval dated 2099 followed by a withdrawal. The withdrawal is recorded later, so it stands; the date that goes backwards is
    reported on its own."""
    path, _ = approved(repo)
    edit_rows(repo, "approvals", lambda rows: rows[0].update(decided_on="2099-01-01"))
    add_approval(repo, path, decision="withdrawn", decided_on="2026-11-17")
    found = codes(run(repo))
    assert "APPROVAL_NOT_CURRENT" in found and "LEDGER_DATE_REGRESSION" in found


def test_p11b_a_withdrawal_dated_before_the_approval_still_blocks(repo):
    path, _ = approved(repo)
    add_approval(repo, path, decision="withdrawn", decided_on="2026-01-14")
    found = codes(run(repo))
    assert "APPROVAL_NOT_CURRENT" in found and "LEDGER_DATE_REGRESSION" in found


# ============================================================================ E. the image ledger
def with_photo(repo):
    add_asset(repo, 1, role="supporting_habitat", view="habitat")
    add_asset(repo, 2, role="supporting_habitat", view="habitat")
    path = build_world(repo, "approved", photo_ids=["PHO-0001"])
    assert codes(run(repo)) == set()
    return path


@pytest.mark.parametrize("decision", SAFETY_ADVERSE)
def test_an_unresolved_image_failure_blocks_every_entry_that_cites_the_image(repo, decision):
    with_photo(repo)
    add_image_audit(repo, "PHO-0001", decision=decision, reviewer_id="REV-0005", capacity="technical_reviewer")
    assert "IMAGE_AUDIT_FAILURE_UNRESOLVED" in codes(run(repo))


def test_an_image_failure_does_not_block_entries_that_cite_other_images(repo):
    with_photo(repo)
    add_image_audit(repo, "PHO-0002", decision="fail")
    assert codes(run(repo)) == set()


def test_an_image_failure_is_cleared_by_a_resolution_and_a_fresh_audit(repo):
    with_photo(repo)
    failure = add_image_audit(repo, "PHO-0001", decision="fail")
    add_resolution(repo, "image_audit", failure["audit_id"], by="adjudicator")
    assert "IMAGE_AUDIT_NOT_PASSING" in codes(run(repo)), "the earlier pass no longer counts"
    add_image_audit(repo, "PHO-0001")
    assert codes(run(repo)) == set()


def test_a_fresh_image_audit_alone_does_not_clear_an_image_failure(repo):
    with_photo(repo)
    add_image_audit(repo, "PHO-0001", decision="fail")
    add_image_audit(repo, "PHO-0001")
    assert "IMAGE_AUDIT_FAILURE_UNRESOLVED" in codes(run(repo))


# ===================================================================== F. metamorphic properties
def test_appending_any_adverse_safety_row_never_leaves_the_entry_eligible(repo):
    path = eligible(repo)
    base = read_rows(repo, "safety_audit")
    cases = itertools.product(SAFETY_ADVERSE, ["REV-0004", "REV-0099", "REV-0001"], [[], [W], [CO]], [1, 2], [None, "0" * 64])
    count = 0
    for decision, reviewer, subjects, revision, digest in cases:
        extra = {"package_sha256": digest} if digest else {}
        add_safety(repo, path, subjects, role="external_sme", decision=decision, reviewer_id=reviewer, revision=revision, **extra)
        assert "SAFETY_FAILURE_UNRESOLVED" in codes(run(repo)), (decision, reviewer, subjects, revision, digest)
        write_rows(repo, "safety_audit", base)
        count += 1
    assert count == 72
    assert codes(run(repo)) == set(), "the baseline is eligible again once the extra row is gone"


def test_appending_any_adverse_approval_row_never_leaves_the_entry_eligible(repo):
    path, _ = approved(repo)
    base = read_rows(repo, "approvals")
    for decision, reviewer, revision in itertools.product(["rejected", "withdrawn"], [("REV-0003", "chatgpt_editorial"), ("REV-0004", "external_sme"),
                                                                                      ("REV-0099", "chatgpt_editorial")], [1, 2]):
        add_approval(repo, path, decision=decision, reviewer_id=reviewer[0], capacity=reviewer[1], revision=revision)
        assert "APPROVAL_NOT_CURRENT" in codes(run(repo)), (decision, reviewer, revision)
        write_rows(repo, "approvals", base)


def test_appending_passes_never_unblocks_a_blocked_entry(repo):
    path, failure = blocked_entry(repo)
    for role, name in itertools.product(["external_sme", "chatgpt_editorial", "technical_reviewer", "user"], ["Fixture Domain Expert", "Another One"]):
        add_safety(repo, path, [W], role=role, reviewer=name)
        add_approval(repo, path)
        assert "SAFETY_FAILURE_UNRESOLVED" in codes(run(repo)), (role, name)


def test_no_unauthorised_resolution_ever_unblocks_an_entry(repo):
    path, failure = blocked_entry(repo)
    attempts = [("technical_reviewer", "cleared"), ("chatgpt_editorial", "cleared"), ("user", "cleared"), ("technical_reviewer", "void"),
                ("chatgpt_editorial", "void"), (("REV-0099", "adjudicator"), "cleared"), (("REV-0099", "registrar"), "void")]
    for by, kind in attempts:
        add_resolution(repo, "safety_audit", failure["audit_id"], by=by, kind=kind, name="Nobody Special")
        assert "SAFETY_FAILURE_UNRESOLVED" in codes(run(repo)), (by, kind)


def test_every_reordering_of_the_review_ledger_is_refused_not_reinterpreted(repo):
    """P08b: the same rows in another file order gave another verdict. Now any reordering is an error, whatever the verdict would have been."""
    path = eligible(repo)
    add_safety(repo, path, [W], role="external_sme", decision="fail", reviewer="Reporter")
    add_resolution(repo, "safety_audit", read_rows(repo, "safety_audit")[-1]["audit_id"])
    original = (repo.path("reviews/safety-audit.csv")).read_text(encoding="utf-8").rstrip("\n").split("\n")
    header, body = original[0], original[1:]
    assert len(body) == 4  # the pair, the failure, its resolution
    for order in itertools.permutations(range(len(body))):
        if order == tuple(range(len(body))):
            continue
        tamper(repo, "safety_audit", lambda lines, order=order: [header] + [body[i] for i in order])
        assert codes(run(repo)) & {"LEDGER_SEQUENCE_BROKEN", "LEDGER_CHAIN_BROKEN"}, order
    tamper(repo, "safety_audit", lambda lines: original)
    assert "SAFETY_FAILURE_UNRESOLVED" not in codes(run(repo))


def test_p08c_deleting_the_failing_row_in_the_middle_is_detected(repo):
    path = eligible(repo)
    add_safety(repo, path, [W], role="external_sme", decision="fail", reviewer="Reporter")
    add_safety_pair(repo, path, [W])
    tamper(repo, "safety_audit", lambda lines: lines[:3] + lines[4:])  # remove the failure (row 3), keep the rest
    found = codes(run(repo))
    assert found & {"LEDGER_SEQUENCE_BROKEN", "LEDGER_CHAIN_BROKEN"}
