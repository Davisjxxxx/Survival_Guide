"""Handoff section 6: the physical fact checks "must be gate tests". Each hazard topic gets the full set of gate tests.

RUN-003: a review row now names a registered reviewer and a review SUBJECT. Medical guidance is the subject CLS-MEDICAL, so a pair of rows
that lists some other topic is no longer taken for a medical review (Fable probe P36).
"""
from __future__ import annotations

import pytest

from factories import REAL, add_safety, add_safety_pair, build_world, codes, medical_dict, rewrite_entry, write_rows
from sfe.common import load_yaml
from sfe.validate import validate_repo

TOPICS = load_yaml((REAL / "schemas/hazard_topics.yaml").read_text(encoding="utf-8"))["topics"]
IDS = [t["id"] for t in TOPICS]


def run(repo):
    return validate_repo(repo.root)


def approved_with(repo, topic, **over):
    """An approved entry tagged with `topic` and its editorial approval, but NO safety review at all."""
    path = build_world(repo, "approved", hazard_tags=[topic], as_of_date="2026-01-15", **over)
    write_rows(repo, "safety_audit", [])
    return path


def test_registry_covers_exactly_the_six_handoff_checks():
    assert len(TOPICS) == 6
    assert [t["handoff_ref"] for t in TOPICS] == [f"section 6, bullet {n}" for n in range(1, 7)]
    for topic in TOPICS:
        assert topic["reviewer_must_confirm"], topic["id"]
        assert {"domain_expert", "chatgpt_validation"} <= set(topic["required_reviews"]), topic["id"]
    by_id = {t["id"]: t for t in TOPICS}
    assert "CDC/EPA" in by_id["HZ-WATER-POTABILITY"]["authority_requirement"]
    assert "USDA/NCHFP" in by_id["HZ-FOOD-PRESERVATION"]["authority_requirement"]
    assert by_id["HZ-HARVEST-LEGAL"]["requires_region_and_as_of_date"] is True


@pytest.mark.parametrize("topic", IDS)
def test_tagged_entry_cannot_be_approved_without_a_safety_audit(repo, topic):
    approved_with(repo, topic)
    assert "SAFETY_AUDIT_MISSING" in codes(run(repo))


@pytest.mark.parametrize("topic", IDS)
def test_audit_of_a_different_topic_is_not_enough(repo, topic):
    path = approved_with(repo, topic)
    other = next(t for t in IDS if t != topic)
    add_safety_pair(repo, path, [other])
    assert "SAFETY_TOPIC_UNCOVERED" in codes(run(repo))


@pytest.mark.parametrize("topic", IDS)
def test_stale_audit_does_not_count(repo, topic):
    path = approved_with(repo, topic)
    add_safety_pair(repo, path, [topic], package_sha256="0" * 64)
    assert "SAFETY_AUDIT_NOT_PASSING_OR_STALE" in codes(run(repo))


@pytest.mark.parametrize("decision", ["fail", "conditional"])
@pytest.mark.parametrize("topic", IDS)
def test_non_passing_audit_does_not_count(repo, topic, decision):
    """RUN-002 reported SAFETY_AUDIT_NOT_PASSING_OR_STALE. Now an adverse decision is stronger than 'not a pass': it blocks the entry
    until a resolution row clears it, and it never counts as coverage of the topic."""
    path = approved_with(repo, topic)
    add_safety(repo, path, [topic], decision=decision)
    found = codes(run(repo))
    assert "SAFETY_FAILURE_UNRESOLVED" in found and "SAFETY_TOPIC_UNCOVERED" in found


@pytest.mark.parametrize("topic", IDS)
def test_covered_entry_passes(repo, topic):
    path = approved_with(repo, topic)
    add_safety_pair(repo, path, [topic])
    assert codes(run(repo)) == set()


@pytest.mark.parametrize("topic", IDS)
def test_tagged_entry_needs_danger_boundaries_to_be_verified(repo, topic):
    build_world(repo, "verified", hazard_tags=[topic], as_of_date="2026-01-15", dangers=[])
    assert "DANGER_BOUNDARY_MISSING" in codes(run(repo))


def test_audit_must_cover_every_tag(repo):
    path = build_world(repo, "approved", hazard_tags=["HZ-IGNITION-SPARK", "HZ-COMBUSTION-CO"], as_of_date="2026-01-15")
    write_rows(repo, "safety_audit", [])
    add_safety_pair(repo, path, ["HZ-IGNITION-SPARK"])
    findings = [f for f in run(repo) if f.code == "SAFETY_TOPIC_UNCOVERED"]
    assert len(findings) == 1 and "HZ-COMBUSTION-CO" in findings[0].message


def test_editing_the_entry_invalidates_the_audit(repo):
    path = approved_with(repo, "HZ-WATER-POTABILITY")
    add_safety_pair(repo, path, ["HZ-WATER-POTABILITY"])
    assert codes(run(repo)) == set()
    rewrite_entry(path, lambda fm: fm.update(what_it_is="Fixture what text, changed."))
    assert {"SAFETY_AUDIT_NOT_PASSING_OR_STALE", "APPROVAL_STALE"} <= codes(run(repo))


# ---------------------------------------------------------------------------- medical
def medical_without_reviews(repo, **over):
    path = build_world(repo, "approved", fm_factory=medical_dict, **over)
    write_rows(repo, "safety_audit", [])
    return path


def test_medical_entries_need_a_safety_audit_even_without_tags(repo):
    medical_without_reviews(repo)
    assert "SAFETY_AUDIT_MISSING" in codes(run(repo))


MEDICAL = ["CLS-MEDICAL", "CLS-HIGH-RISK"]  # a medical entry's zone (Z10) is Critical, so the high-risk floor applies as well


def test_medical_entry_with_audit_passes(repo):
    path = medical_without_reviews(repo)
    add_safety_pair(repo, path, MEDICAL)
    assert codes(run(repo)) == set()


def test_a_pair_that_lists_no_medical_subject_is_not_a_medical_review(repo):
    """P36: RUN-002 took ANY rows for a medical entry as its medical review, including rows that listed a single unrelated topic."""
    path = medical_without_reviews(repo)
    add_safety_pair(repo, path, ["HZ-WATER-POTABILITY"])
    found = run(repo)
    assert "SAFETY_TOPIC_UNCOVERED" in codes(found)
    assert any(f.code == "SAFETY_TOPIC_UNCOVERED" and f.message.startswith("CLS-MEDICAL:") for f in found)


@pytest.mark.parametrize("field", ["audience_scope", "evidence_date", "emergency_evacuation_threshold", "local_emergency_service_guidance"])
def test_medical_fields_required_to_verify(repo, field):
    build_world(repo, "verified", fm_factory=medical_dict, **{field: ""})
    assert "MEDICAL_FIELD_EMPTY" in codes(run(repo))


def test_medical_contraindications_required_to_verify(repo):
    build_world(repo, "verified", fm_factory=medical_dict, contraindications=[])
    assert "MEDICAL_FIELD_EMPTY" in codes(run(repo))
