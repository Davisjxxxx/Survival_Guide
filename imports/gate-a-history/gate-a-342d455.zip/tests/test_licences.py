"""Controlled licence vocabulary, rights evidence, and quarantine boundaries (finding FR-015, probe P90).

Verifies:
- Approved assets must carry a licence from schemas/licenses.yaml permitting reuse, modify, crop, redistribute, and commercial (D22);
- Restrictive licences (All rights reserved, CC BY-NC, CC BY-ND, CC BY-NC-ND, Fair use) are rejected with LICENSE_INCOMPATIBLE;
- Unknown licences outside the vocabulary are rejected with LICENSE_UNKNOWN;
- Bare ambiguous terms remain rejected with LICENSE_AMBIGUOUS;
- allowed_derivatives="none" / "unknown" is rejected (LICENSE_DERIVATIVES_FORBIDDEN);
- LicenseRef-Permission requires permission_reference and all required operations in rights_granted;
- Every approved asset requires a rights evidence file under assets/rights/ matching rights_evidence_sha256 (and changing it stales approvals);
- Uncatalogued files in quarantine or unexpected files under assets/ are rejected;
- An invalid or weakened schemas/licenses.yaml fails closed (LICENSE_POLICY_INVALID, LICENSE_POLICY_UNAVAILABLE);
- Nothing infers photograph authenticity (generation_method stays an attested field).
"""
from __future__ import annotations

import pytest

from factories import add_asset, build_world, codes, edit_rows, make_png, make_repo
from sfe.assets import load_license_policy
from sfe.common import sha256_file
from sfe.validate import validate_repo


def run(repo):
    return validate_repo(repo.root)


@pytest.mark.parametrize("lic", [
    "CC0-1.0", "CC0 1.0", "Public-Domain-Mark-1.0", "US-Gov-PD (17 USC 105)", "US-Gov-PD",
    "CC-BY-4.0", "CC BY 4.0", "CC-BY-3.0", "CC-BY-SA-4.0", "CC-BY-SA-3.0", "LicenseRef-Project-Original",
])
def test_compatible_vocabulary_licences_pass(repo, lic):
    add_asset(repo, 1, license=lic)
    assert codes(run(repo)) == set(), [str(f) for f in run(repo)]


@pytest.mark.parametrize("lic,missing_op", [
    ("CC-BY-NC-4.0", "commercial"),
    ("CC BY-NC 4.0", "commercial"),
    ("CC-BY-NC-SA-4.0", "commercial"),
    ("CC-BY-ND-4.0", "modify"),
    ("CC-BY-NC-ND-4.0", "crop"),
    ("CC BY-NC-ND 4.0", "commercial"),
    ("All rights reserved", "reuse"),
    ("All-Rights-Reserved", "redistribute"),
    ("Fair use", "redistribute"),
    ("Fair-Use", "modify"),
])
def test_restrictive_and_incompatible_licences_are_rejected_with_reason(repo, lic, missing_op):
    add_asset(repo, 1, license=lic)
    findings = run(repo)
    assert "LICENSE_INCOMPATIBLE" in codes(findings)
    msgs = [f.message for f in findings if f.code == "LICENSE_INCOMPATIBLE"]
    assert any(missing_op in m for m in msgs), msgs


@pytest.mark.parametrize("lic", ["Copyright Fixture Publisher", "Fixture-License-1.0", "MIT", "GPL-3.0", "Custom-Unreviewed"])
def test_unknown_licence_outside_vocabulary_is_rejected(repo, lic):
    add_asset(repo, 1, license=lic)
    assert "LICENSE_UNKNOWN" in codes(run(repo))


@pytest.mark.parametrize("deriv", ["none", "None", "NO", "unknown", "prohibited", "no derivatives", "n/a"])
def test_forbidden_derivatives_text_is_rejected(repo, deriv):
    add_asset(repo, 1, license="CC-BY-4.0", allowed_derivatives=deriv)
    assert "LICENSE_DERIVATIVES_FORBIDDEN" in codes(run(repo))


def test_permission_based_licence_requires_all_operations_and_reference(repo):
    all_ops = ["reuse", "modify", "crop", "redistribute", "commercial"]
    add_asset(repo, 1, license="LicenseRef-Permission", permission_reference="Written grant 2026-01-15, Owner",
              rights_granted=all_ops)
    assert codes(run(repo)) == set(), [str(f) for f in run(repo)]

    # Missing any single required operation fails with LICENSE_RIGHTS_INCOMPLETE
    for op in all_ops:
        edit_rows(repo, "assets", lambda rows, op=op: rows[0].update(rights_granted="|".join(o for o in all_ops if o != op)))
        findings = run(repo)
        assert "LICENSE_RIGHTS_INCOMPLETE" in codes(findings), op
        assert any(op in f.message for f in findings if f.code == "LICENSE_RIGHTS_INCOMPLETE")

    # Missing permission_reference also fails
    edit_rows(repo, "assets", lambda rows: rows[0].update(rights_granted="|".join(all_ops), permission_reference=""))
    assert "LICENSE_RIGHTS_INCOMPLETE" in codes(run(repo))


def test_rights_evidence_file_is_mandatory_and_hash_checked_and_bound_to_approval(repo):
    add_asset(repo, 1, role="supporting_habitat", view="habitat")
    build_world(repo, "approved", photo_ids=["PHO-0001"])
    assert codes(run(repo)) == set()

    # Modifying the rights evidence file fails both hash check AND stales approval + image audit
    ev = repo.path("assets/rights/PHO-0001.txt")
    orig = ev.read_bytes()
    ev.write_bytes(orig + b"tampered\n")
    found = codes(run(repo))
    assert {"RIGHTS_EVIDENCE_HASH_MISMATCH", "APPROVAL_STALE", "IMAGE_AUDIT_STALE"} <= found

    # Deleting the rights evidence file fails RIGHTS_EVIDENCE_MISSING
    ev.unlink()
    assert "RIGHTS_EVIDENCE_MISSING" in codes(run(repo))

    # Restore
    ev.write_bytes(orig)
    assert codes(run(repo)) == set()


def test_rights_evidence_must_live_under_assets_rights(repo):
    other = repo.path("reviews/evidence/outside.txt")
    other.parent.mkdir(parents=True, exist_ok=True)
    other.write_text("Fixture evidence outside assets/rights.\n", encoding="utf-8")
    add_asset(repo, 1, rights_evidence_path="reviews/evidence/outside.txt", rights_evidence_sha256=sha256_file(other))
    assert "RIGHTS_EVIDENCE_PATH_INVALID" in codes(run(repo))


def test_missing_rights_evidence_columns_rejected_for_approved_asset(repo):
    add_asset(repo, 1, rights_evidence=None)
    found = codes(run(repo))
    assert {"ROW_SCHEMA", "RIGHTS_EVIDENCE_MISSING"} <= found


def test_quarantine_and_assets_directory_hygiene(repo):
    # Uncatalogued file sitting in assets/rejected_unverified/ is reported
    make_png(repo.path("assets/rejected_unverified/stray.png"))
    assert "QUARANTINE_UNCATALOGUED_FILE" in codes(run(repo))
    repo.path("assets/rejected_unverified/stray.png").unlink()

    # Unexpected file or directory directly under assets/ is reported
    make_png(repo.path("assets/rogue.png"))
    assert "ASSET_DIRECTORY_UNEXPECTED" in codes(run(repo))
    repo.path("assets/rogue.png").unlink()
    assert codes(run(repo)) == set()


def test_invalid_or_weakened_license_policy_fails_closed(tmp_path):
    # 1. Missing schemas/licenses.yaml refuses approved assets
    r1 = make_repo(tmp_path / "missing")
    add_asset(r1, 1)
    r1.path("schemas/licenses.yaml").unlink()
    found = codes(run(r1))
    assert {"LICENSE_POLICY_INVALID", "LICENSE_POLICY_UNAVAILABLE"} <= found

    # 2. Policy that drops a floor operation (modify) is rejected
    r2 = make_repo(tmp_path / "floor")
    add_asset(r2, 1)
    pol_path = r2.path("schemas/licenses.yaml")
    pol_path.write_text(pol_path.read_text(encoding="utf-8").replace("modify, ", ""), encoding="utf-8")
    policy, findings = load_license_policy(r2)
    assert policy is None and "LICENSE_POLICY_INVALID" in codes(findings)
    assert {"LICENSE_POLICY_INVALID", "LICENSE_POLICY_UNAVAILABLE"} <= codes(run(r2))
