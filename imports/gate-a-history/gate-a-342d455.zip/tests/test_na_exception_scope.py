"""The structured FR-021 exception belongs only in step verify/abort_if.

These independent field cases pin the contract's scope without importing the
implementation's list of assessed fields. Ordinary optional text keeps its
existing rules; quoting the declaration does not declare non-applicability.
"""
from __future__ import annotations

import pytest

from factories import build_world, codes, rewrite_entry
from sfe.validate import validate_repo


EXCEPTION = "Not applicable [CLM-0001]: this step only observes the water surface"


def clean_world(repo, status="verified"):
    path = build_world(repo, status)
    findings = validate_repo(repo.root)
    assert codes(findings) == set(), [str(f) for f in findings]
    return path


@pytest.mark.parametrize("field_name,is_list", [
    ("title", False),
    ("what_it_is", False),
    ("conditions_and_limits", True),
    ("diagnostic_features", True),
    ("materials_tools", True),
    ("hazard_boundaries", True),
])
def test_exact_declaration_is_refused_in_other_printed_fields(repo, field_name, is_list):
    path = clean_world(repo)
    # Put it after an ordinary item so checking only the first item cannot pass.
    value = ["Fixture text", EXCEPTION] if is_list else EXCEPTION
    rewrite_entry(path, lambda fm: fm.update({field_name: value}))
    refusals = [f for f in validate_repo(repo.root) if f.code == "NOT_APPLICABLE_NOT_ALLOWED"]
    location = f"{field_name}[1]" if is_list else field_name
    assert len(refusals) == 1 and location in refusals[0].message, [str(f) for f in refusals]


def test_exact_declaration_is_refused_in_a_nested_printed_table_label(repo):
    path = clean_world(repo)
    rewrite_entry(path, lambda fm: fm["dimension_unit_table"][0].update(quantity=EXCEPTION))
    refusals = [f for f in validate_repo(repo.root) if f.code == "NOT_APPLICABLE_NOT_ALLOWED"]
    assert len(refusals) == 1 and "dimension_unit_table[0].quantity" in refusals[0].message


def test_step_action_still_refuses_the_declaration_once(repo):
    path = clean_world(repo)
    rewrite_entry(path, lambda fm: fm["procedure"][0].update(action=EXCEPTION))
    refusals = [f for f in validate_repo(repo.root) if f.code == "NOT_APPLICABLE_NOT_ALLOWED"]
    assert len(refusals) == 1 and "step 1 action" in refusals[0].message


@pytest.mark.parametrize("field_name", ["verify", "abort_if"])
def test_valid_step_exception_remains_accepted(repo, field_name):
    path = clean_world(repo)
    rewrite_entry(path, lambda fm: fm["procedure"][0].update({field_name: EXCEPTION}))
    findings = validate_repo(repo.root)
    assert codes(findings) == set(), [str(f) for f in findings]


@pytest.mark.parametrize("field_name,is_list", [("what_it_is", False), ("conditions_and_limits", True)])
@pytest.mark.parametrize("text", [
    "Fixture",  # no new word floor for ordinary optional text
    '"' + EXCEPTION + '"',  # quoted declaration, not the declaration itself
    "The label quotes " + EXCEPTION,
    "The words Not applicable identify the exception rule.",
])
def test_ordinary_short_text_and_mentions_keep_existing_behavior(repo, field_name, is_list, text):
    path = clean_world(repo)
    rewrite_entry(path, lambda fm: fm.update({field_name: [text] if is_list else text}))
    findings = validate_repo(repo.root)
    assert codes(findings) == set(), [str(f) for f in findings]


@pytest.mark.parametrize("status", ["draft", "researched"])
def test_exception_scope_check_still_starts_at_verified(repo, status):
    path = clean_world(repo, status)
    rewrite_entry(path, lambda fm: fm.update(what_it_is=EXCEPTION))
    findings = validate_repo(repo.root)
    assert codes(findings) == set(), [str(f) for f in findings]
