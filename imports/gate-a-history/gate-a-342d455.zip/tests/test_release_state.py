"""Release state: active-release manifest, immutable archive, atomic promotion, withdrawal,
validation against current approvals and hashes, and crash/restart recovery (finding FR-017, probe P25).
"""
from __future__ import annotations

import json
import os
import stat
from pathlib import Path

import pytest

from factories import (
    DATE, add_approval, add_asset, add_required_reviews, add_safety, build_world, codes, edit_rows, entry_dict,
    make_repo, pin_for, rewrite_entry, set_zone, write_entry,
)
from sfe import pdfbuild, release as rel
from sfe.cli import main as cli_main
from sfe.common import sha256_file
from sfe.ledger import GENESIS


def published_world(tmp_path: Path, **over):
    repo = make_repo(tmp_path)
    add_asset(repo, 1)
    path = build_world(repo, "published", photo_ids=["PHO-0001"], **over)
    return repo, path


def second_revision(repo, path: Path, **over):
    """Bump the entry to revision 2 with new text, fresh approval and required reviews."""
    rewrite_entry(path, lambda fm: fm.update(revision=2, what_it_is="Fixture updated revision two text.", **over))
    add_approval(repo, path, decided_on="2026-02-01")
    add_required_reviews(repo, path, reviewed_on="2026-02-01")


def cli(capsys, *args: str) -> tuple[int, str]:
    code = cli_main(list(args))
    cap = capsys.readouterr()
    return code, cap.out + cap.err


def _make_fake_staged(dist: Path, edition_id: str, payload: bytes = b"fixture-pdf-bytes") -> Path:
    """Create a staged edition directory under dist/.staging without running pdfLaTeX (for fast state-machine tests)."""
    base = dist / rel.STAGING
    base.mkdir(parents=True, exist_ok=True)
    staged = base / f"{edition_id}-stage"
    (staged / "zones").mkdir(parents=True)
    pdf = staged / "zones/Z09_tools_construction.pdf"
    man = staged / "zones/Z09_tools_construction.build.json"
    pdf.write_bytes(payload)
    man.write_text(json.dumps({"edition_id": edition_id}) + "\n", encoding="utf-8")
    edition = {
        "schema": 1, "edition_id": edition_id, "entries": [], "ledger_state": {}, "policy_sha256": {},
        "artifacts": [{"zone": "Z09", "pdf": "zones/Z09_tools_construction.pdf", "pdf_sha256": sha256_file(pdf),
                       "manifest": "zones/Z09_tools_construction.build.json", "manifest_sha256": sha256_file(man)}],
    }
    (staged / rel.EDITION_FILE).write_bytes(rel.edition_bytes(edition))
    return staged


# ============================================================================== fast state-machine unit tests
def test_pointer_validation_rejects_malformed_and_missing_fields(tmp_path):
    dist = tmp_path / "dist"
    dist.mkdir()
    assert rel.read_pointer(dist) == (None, [])

    (dist / rel.POINTER).write_text("{not json", encoding="utf-8")
    ptr, problems = rel.read_pointer(dist)
    assert ptr is None and "RELEASE_POINTER_INVALID" in codes(problems)

    bad_cases = [
        {"schema": 1, "state": "active"},  # missing keys
        {"schema": 2, "state": "active", "edition_id": "ED-" + "a" * 16, "edition_manifest_sha256": "b" * 64, "generation": 1, "reason": None, "by": "release"},
        {"schema": 1, "state": "current", "edition_id": "ED-" + "a" * 16, "edition_manifest_sha256": "b" * 64, "generation": 1, "reason": None, "by": "release"},
        {"schema": 1, "state": "active", "edition_id": "BAD-ID", "edition_manifest_sha256": "b" * 64, "generation": 1, "reason": None, "by": "release"},
        {"schema": 1, "state": "active", "edition_id": "ED-" + "a" * 16, "edition_manifest_sha256": "short", "generation": 1, "reason": None, "by": "release"},
        {"schema": 1, "state": "active", "edition_id": "ED-" + "a" * 16, "edition_manifest_sha256": "b" * 64, "generation": 0, "reason": None, "by": "release"},
        {"schema": 1, "state": "active", "edition_id": "ED-" + "a" * 16, "edition_manifest_sha256": "b" * 64, "generation": True, "reason": None, "by": "release"},
        {"schema": 1, "state": "active", "edition_id": "ED-" + "a" * 16, "edition_manifest_sha256": "b" * 64, "generation": 1, "reason": None, "by": "other"},
        {"schema": 1, "state": "withdrawn", "edition_id": "ED-" + "a" * 16, "edition_manifest_sha256": "b" * 64, "generation": 2, "reason": "   ", "by": "withdraw"},
    ]
    for payload in bad_cases:
        (dist / rel.POINTER).write_text(json.dumps(payload), encoding="utf-8")
        ptr, problems = rel.read_pointer(dist)
        assert ptr is None and "RELEASE_POINTER_INVALID" in codes(problems), payload


def test_log_is_hash_chained_and_tamper_evident(tmp_path):
    dist = tmp_path / "dist"
    dist.mkdir()
    r1 = rel.append_log(dist, "promote", "ED-" + "1" * 16, detail="gen 1")
    r2 = rel.append_log(dist, "withdraw", "ED-" + "1" * 16, reason="Safety review found an error")
    rows, problems = rel.read_log(dist)
    assert problems == [] and len(rows) == 2 and r1["sequence"] == "1" and r2["sequence"] == "2"

    # Editing row 1 breaks the chain and refuses further appends
    log_path = dist / rel.LOG
    text = log_path.read_text(encoding="utf-8")
    log_path.write_text(text.replace("gen 1", "gen 9"), encoding="utf-8")
    _, problems = rel.read_log(dist)
    assert "RELEASE_LOG_INVALID" in codes(problems)
    with pytest.raises(rel.ReleaseStateError, match="damaged"):
        rel.append_log(dist, "recover", None, detail="nope")


def test_archive_is_immutable_and_refuses_conflicting_edition(tmp_path):
    dist = tmp_path / "dist"
    ed = "ED-" + "a" * 16
    promo = rel.promote(dist, _make_fake_staged(dist, ed, b"bytes-v1"), ed)
    assert promo.changed is True
    archived_pdf = promo.directory / "zones/Z09_tools_construction.pdf"
    assert (archived_pdf.stat().st_mode & 0o222) == 0, "archived files must be read-only"

    # Re-promoting identical bytes is idempotent (changed=False)
    promo2 = rel.promote(dist, _make_fake_staged(dist, ed, b"bytes-v1"), ed)
    assert promo2.changed is False

    # Re-promoting DIFFERENT bytes under the same edition id is refused (EDITION_CONFLICT) and never overwrites
    with pytest.raises(rel.ReleaseStateError, match="EDITION_CONFLICT"):
        rel.promote(dist, _make_fake_staged(dist, ed, b"tampered-bytes"), ed)
    assert archived_pdf.read_bytes() == b"bytes-v1"


def test_withdraw_requires_usable_reason_and_preserves_archive(tmp_path):
    dist = tmp_path / "dist"
    ed = "ED-" + "b" * 16
    promo = rel.promote(dist, _make_fake_staged(dist, ed), ed)
    for bad in ("", "N/A", "none", "ok", "bad"):
        with pytest.raises(rel.ReleaseStateError, match="reason"):
            rel.withdraw(dist, bad)
    pointer = rel.withdraw(dist, "Specialist safety audit identified an error in zone nine.")
    assert pointer.state == "withdrawn" and pointer.edition_id == ed and pointer.generation == 2
    assert (promo.directory / rel.EDITION_FILE).is_file(), "withdrawing must never delete archived evidence"
    rows, problems = rel.read_log(dist)
    assert not problems and [r["event"] for r in rows] == ["promote", "withdraw"]
    # Withdrawing when already withdrawn refuses
    with pytest.raises(rel.ReleaseStateError, match="no active release"):
        rel.withdraw(dist, "Attempting a second withdrawal of an already withdrawn edition.")


@pytest.mark.parametrize("step", ["before_archive", "after_archive", "after_pointer_tmp", "after_pointer", "mid_log"])
def test_interrupted_promotion_at_every_step_recovers_without_losing_evidence(tmp_path, monkeypatch, step):
    """Inject a simulated crash at each named step of promotion; verify recover() repairs state cleanly and preserves evidence."""
    dist = tmp_path / "dist"
    ed1 = "ED-" + "1" * 16
    ed2 = "ED-" + "2" * 16
    if step == "mid_log":
        # mid_log only runs when superseding a prior active edition
        rel.promote(dist, _make_fake_staged(dist, ed1, b"v1"), ed1)

    target_ed = ed2 if step == "mid_log" else ed1
    staged = _make_fake_staged(dist, target_ed, b"v2" if step == "mid_log" else b"v1")

    def boom(current_step: str) -> None:
        if current_step == step:
            raise RuntimeError(f"simulated crash at {step}")

    monkeypatch.setattr(rel, "_FAULT", boom)
    with pytest.raises(RuntimeError, match=step):
        rel.promote(dist, staged, target_ed)
    monkeypatch.setattr(rel, "_FAULT", None)

    actions = rel.recover(dist)
    assert actions, f"recover should have repaired the crash at {step}"
    rows, log_problems = rel.read_log(dist)
    assert log_problems == []
    pointer, ptr_problems = rel.read_pointer(dist)
    assert ptr_problems == []

    if step == "before_archive":
        assert pointer is None
        quarantined_files = [p for p in (dist / rel.QUARANTINE).rglob("*") if p.is_file()]
        assert any(p.name == rel.EDITION_FILE for p in quarantined_files), "leftover staging files must be quarantined, not deleted"
    elif step == "after_archive":
        assert pointer is None
        assert (dist / rel.EDITIONS / target_ed / rel.EDITION_FILE).is_file()
        assert any(r["event"] == "recover" and r["edition_id"] == target_ed for r in rows)
    elif step == "after_pointer_tmp":
        assert pointer is None
        assert not (dist / (rel.POINTER + ".tmp")).exists()
        assert (dist / rel.EDITIONS / target_ed / rel.EDITION_FILE).is_file()
    elif step in ("after_pointer", "mid_log"):
        assert pointer is not None and pointer.state == "active" and pointer.edition_id == target_ed
        assert rel._log_active(rows) == target_ed
        if step == "mid_log":
            assert any(r["event"] == "supersede" and r["edition_id"] == ed1 for r in rows)
            assert any(r["event"] == "promote" and r["edition_id"] == ed2 for r in rows)
            assert (dist / rel.EDITIONS / ed1 / rel.EDITION_FILE).is_file()

    # Running recover a second time is a no-op; re-promoting target_ed completes cleanly
    assert rel.recover(dist) == []
    resumed = rel.promote(dist, _make_fake_staged(dist, target_ed, b"v2" if step == "mid_log" else b"v1"), target_ed)
    assert resumed.edition_id == target_ed
    assert rel.read_pointer(dist)[0].state == "active"  # type: ignore[union-attr]
    assert rel.read_log(dist)[1] == []


def test_interrupted_withdrawal_and_partial_log_row_recover(tmp_path, monkeypatch):
    dist = tmp_path / "dist"
    ed = "ED-" + "c" * 16
    rel.promote(dist, _make_fake_staged(dist, ed), ed)

    def boom(step: str) -> None:
        if step == "after_withdraw_pointer":
            raise RuntimeError("crash after withdraw pointer")

    monkeypatch.setattr(rel, "_FAULT", boom)
    with pytest.raises(RuntimeError, match="withdraw pointer"):
        rel.withdraw(dist, "Approval withdrawn after a specialist safety review.")
    monkeypatch.setattr(rel, "_FAULT", None)

    # Simulate a half-written trailing line in RELEASE_LOG.csv as well
    with (dist / rel.LOG).open("ab") as fh:
        fh.write(b"2,withdraw,ED-cccc")

    actions = rel.recover(dist)
    assert len(actions) >= 2
    assert list((dist / rel.QUARANTINE).rglob("RELEASE_LOG.partial-row")), "partial log row must be preserved in quarantine"
    rows, problems = rel.read_log(dist)
    assert problems == [] and [r["event"] for r in rows] == ["promote", "withdraw"]
    assert rel._log_active(rows) is None
    pointer, ptr_problems = rel.read_pointer(dist)
    assert ptr_problems == [] and pointer is not None and pointer.state == "withdrawn" and pointer.edition_id == ed


def test_recovery_reconcile_and_repromote_cannot_reactivate_a_withdrawn_edition(tmp_path, monkeypatch):
    """Once an edition is withdrawn, recover(), reconcile(), interrupted subsequent promotion, and bare promote() cannot reactivate it."""
    repo = make_repo(tmp_path / "repo")
    dist = tmp_path / "dist"
    ed1 = "ED-" + "d" * 16
    ed2 = "ED-" + "e" * 16
    rel.promote(dist, _make_fake_staged(dist, ed1, b"v1"), ed1)
    rel.withdraw(dist, "Specialist review identified an error requiring withdrawal.")

    # 1. Repeated recover() and reconcile() keep the edition withdrawn
    assert rel.recover(dist) == []
    assert rel.reconcile(repo, dist) == []
    assert rel.read_pointer(dist)[0].state == "withdrawn"  # type: ignore[union-attr]

    # 2. A subsequent promotion of ed2 that crashes before replacing the pointer leaves ed1 withdrawn after recover()
    for step in ("before_archive", "after_archive", "after_pointer_tmp"):
        staged2 = _make_fake_staged(dist, ed2, b"v2")

        def boom(current: str, target_step: str = step) -> None:
            if current == target_step:
                raise RuntimeError(f"crash at {target_step}")

        monkeypatch.setattr(rel, "_FAULT", boom)
        with pytest.raises(RuntimeError, match=step):
            rel.promote(dist, staged2, ed2)
        monkeypatch.setattr(rel, "_FAULT", None)
        rel.recover(dist)
        ptr, problems = rel.read_pointer(dist)
        assert not problems and ptr is not None and ptr.state == "withdrawn" and ptr.edition_id == ed1

    # 3. Re-promoting the withdrawn edition id itself is refused (EDITION_WITHDRAWN)
    with pytest.raises(rel.ReleaseStateError, match="EDITION_WITHDRAWN"):
        rel.promote(dist, _make_fake_staged(dist, ed1, b"v1"), ed1)
    assert rel.read_pointer(dist)[0].state == "withdrawn"  # type: ignore[union-attr]

    # 4. A genuinely new edition id CAN still be promoted after withdrawal
    promo2 = rel.promote(dist, _make_fake_staged(dist, ed2, b"v2"), ed2)
    assert promo2.changed is True and promo2.edition_id == ed2
    assert rel.read_pointer(dist)[0].state == "active"  # type: ignore[union-attr]


def test_lock_refuses_concurrent_release_process(tmp_path):
    dist = tmp_path / "dist"
    with rel.locked(dist):
        with pytest.raises(rel.ReleaseStateError, match="holds"):
            with rel.locked(dist):
                pass


def test_legacy_flat_output_is_quarantined_never_deleted(tmp_path):
    repo = make_repo(tmp_path / "repo")
    dist = tmp_path / "dist"
    legacy_pdf = dist / "zones/Z09_tools_construction.pdf"
    legacy_pdf.parent.mkdir(parents=True)
    legacy_pdf.write_bytes(b"%PDF-1.4 legacy")
    (dist / "zones/.gitkeep").write_text("", encoding="utf-8")

    assert rel.has_state(dist) is True
    actions = rel.reconcile(repo, dist)
    assert actions and not legacy_pdf.exists()
    assert (dist / "zones/.gitkeep").is_file(), ".gitkeep must stay in place"
    quarantined = list((dist / rel.QUARANTINE).rglob("Z09_tools_construction.pdf"))
    assert len(quarantined) == 1 and quarantined[0].read_bytes() == b"%PDF-1.4 legacy"
    rows, problems = rel.read_log(dist)
    assert not problems and rows[-1]["event"] == "quarantine"


# ============================================================================== end-to-end release builds (slow)
@pytest.mark.slow
def test_p25_withdrawal_invalidates_active_release_and_preserves_archive(tmp_path):
    repo, path = published_world(tmp_path / "repo")
    dist = tmp_path / "dist"
    pin1 = pin_for(repo)
    first = pdfbuild.build_release(repo, out_root=dist, pin=pin1)
    assert first.ok and first.edition_id and first.state == "active"
    assert rel.verify_active(repo, dist, pin=pin1).ok is True
    archived_pdf = first.pdfs[0]
    archived_sha = sha256_file(archived_pdf)

    # Withdraw approval -> verify fails, reconcile/release auto-withdraws pointer, archive stays intact
    add_approval(repo, path, decision="withdrawn", decided_on="2026-03-01")
    pin2 = pin_for(repo)
    check = rel.verify_active(repo, dist, pin=pin2)
    assert not check.ok and "RELEASE_TREE_INVALID" in codes(check.findings)

    second = pdfbuild.build_release(repo, out_root=dist, pin=pin2)
    assert not second.ok and "APPROVAL_NOT_CURRENT" in codes(second.findings)
    assert second.state == "withdrawn" and second.edition_id == first.edition_id
    pointer, problems = rel.read_pointer(dist)
    assert not problems and pointer is not None and pointer.state == "withdrawn" and pointer.reason
    assert not [p for p in dist.rglob("*.pdf") if "editions/" not in p.relative_to(dist).as_posix()]
    assert archived_pdf.is_file() and sha256_file(archived_pdf) == archived_sha
    assert rel.verify_active(repo, dist, pin=pin2).ok is False
    rows, log_problems = rel.read_log(dist)
    assert not log_problems and [r["event"] for r in rows] == ["promote", "auto_withdraw"]


@pytest.mark.slow
def test_release_supersedes_previous_edition_and_preserves_both_in_archive(tmp_path):
    repo, path = published_world(tmp_path / "repo")
    dist = tmp_path / "dist"
    pin1 = pin_for(repo)
    first = pdfbuild.build_release(repo, out_root=dist, pin=pin1)
    assert first.ok and first.edition_id

    # Building the exact same tree again is idempotent: same edition id, byte-identical, no extra log row
    again = pdfbuild.build_release(repo, out_root=dist, pin=pin1)
    assert again.ok and again.edition_id == first.edition_id
    assert sha256_file(again.pdfs[0]) == sha256_file(first.pdfs[0])
    assert len(rel.read_log(dist)[0]) == 1

    # Revision 2 -> new edition id, supersedes first, both editions preserved intact
    second_revision(repo, path)
    pin2 = pin_for(repo)
    second = pdfbuild.build_release(repo, out_root=dist, pin=pin2)
    assert second.ok and second.edition_id and second.edition_id != first.edition_id
    assert (dist / rel.EDITIONS / first.edition_id / rel.EDITION_FILE).is_file()
    assert (dist / rel.EDITIONS / second.edition_id / rel.EDITION_FILE).is_file()
    rows, problems = rel.read_log(dist)
    assert not problems and [r["event"] for r in rows] == ["promote", "supersede", "promote"]
    assert rel.verify_active(repo, dist, pin=pin2).ok is True


@pytest.mark.slow
def test_verify_catches_package_change_policy_change_archive_tamper_and_ledger_rewind(tmp_path):
    repo, path = published_world(tmp_path / "repo")
    dist = tmp_path / "dist"
    pin = pin_for(repo)
    built = pdfbuild.build_release(repo, out_root=dist, pin=pin)
    assert built.ok and built.edition_id
    assert rel.verify_active(repo, dist, pin=pin).ok is True

    # 1. An error in an UNRELATED draft entry does NOT invalidate the active edition
    bad_other = write_entry(repo, entry_dict(id="Z09-FIXTURE-099", status="verified", claim_ids=["CLM-9999"]))
    assert rel.verify_active(repo, dist, pin=pin).ok is True
    bad_other.unlink()

    # 2. Mutating a cited claim invalidates the active release (package digest changed + stale approval)
    edit_rows(repo, "claims", lambda rows: rows[0].update(claim_text="Fixture mutated claim text."))
    v_claim = rel.verify_active(repo, dist, pin=pin)
    assert not v_claim.ok and {"RELEASE_ENTRY_CHANGED", "RELEASE_TREE_INVALID"} <= codes(v_claim.findings)
    edit_rows(repo, "claims", lambda rows: rows[0].update(claim_text="Fixture claim text."))
    assert rel.verify_active(repo, dist, pin=pin).ok is True

    # 3. Changing a policy file invalidates the active release
    unit_policy = repo.path("schemas/unit_policy.yaml")
    orig_policy = unit_policy.read_bytes()
    unit_policy.write_text(orig_policy.decode("utf-8") + "\n# comment\n", encoding="utf-8")
    v_pol = rel.verify_active(repo, dist, pin=pin)
    assert not v_pol.ok and "RELEASE_POLICY_CHANGED" in codes(v_pol.findings)
    unit_policy.write_bytes(orig_policy)
    assert rel.verify_active(repo, dist, pin=pin).ok is True

    # 4. Rewinding a ledger invalidates the active release
    approvals_path = repo.path("reviews/approvals.csv")
    orig_approvals = approvals_path.read_bytes()
    approvals_path.write_text(orig_approvals.decode("utf-8").splitlines()[0] + "\n", encoding="utf-8")
    v_led = rel.verify_active(repo, dist, pin=pin)
    assert not v_led.ok and "RELEASE_LEDGER_NOT_EXTENDED" in codes(v_led.findings)
    approvals_path.write_bytes(orig_approvals)
    assert rel.verify_active(repo, dist, pin=pin).ok is True

    # 5. Tampering with an archived PDF invalidates the active release
    pdf = built.pdfs[0]
    pdf.chmod(0o644)
    orig_pdf = pdf.read_bytes()
    pdf.write_bytes(orig_pdf + b"X")
    v_art = rel.verify_active(repo, dist, pin=pin)
    assert not v_art.ok and "RELEASE_EDITION_MODIFIED" in codes(v_art.findings)
    pdf.write_bytes(orig_pdf)
    pdf.chmod(0o444)
    assert rel.verify_active(repo, dist, pin=pin).ok is True

    # 6. A legacy flat PDF placed in dist/zones/ fails verify_active with RELEASE_LEGACY_OUTPUT
    stray = dist / "zones/Z09_tools_construction.pdf"
    stray.parent.mkdir(parents=True, exist_ok=True)
    stray.write_bytes(b"%PDF-1.4 stray")
    v_leg = rel.verify_active(repo, dist, pin=pin)
    assert not v_leg.ok and "RELEASE_LEGACY_OUTPUT" in codes(v_leg.findings)
    stray.unlink()
    assert rel.verify_active(repo, dist, pin=pin).ok is True


@pytest.mark.slow
def test_restart_recovery_after_crash_during_build_release(tmp_path, monkeypatch):
    """Crash mid-promotion during build_release, then run build_release again: recovery runs automatically and the release succeeds."""
    repo, _ = published_world(tmp_path / "repo")
    dist = tmp_path / "dist"
    pin = pin_for(repo)

    def crash(step: str) -> None:
        if step == "after_pointer":
            raise RuntimeError("power lost right after pointer replace")

    monkeypatch.setattr(rel, "_FAULT", crash)
    with pytest.raises(RuntimeError, match="power lost"):
        pdfbuild.build_release(repo, out_root=dist, pin=pin)
    monkeypatch.setattr(rel, "_FAULT", None)

    # Restart: next release reconciles the missing log entry and completes cleanly
    recovered = pdfbuild.build_release(repo, out_root=dist, pin=pin)
    assert recovered.ok and recovered.edition_id and recovered.actions
    assert rel.verify_active(repo, dist, pin=pin).ok is True
    rows, problems = rel.read_log(dist)
    assert not problems and [r["event"] for r in rows] == ["promote"]


@pytest.mark.slow
def test_zone_losing_its_last_published_entry_is_superseded_not_left_in_place(tmp_path):
    """RT-115: Edition 1 publishes Z09 and Z02. When Z02's entry is demoted to approved, Edition 2 supersedes Edition 1 and holds only Z09."""
    repo, _ = published_world(tmp_path / "repo")
    fm2 = entry_dict(id="Z02-FIXTURE-001", zone="Z02", status="published", technical_reviewer="REV-0005",
                     editorial_reviewer="REV-0003", approved_by_chatgpt=True)
    path2 = write_entry(repo, fm2, "")
    set_zone(repo, "Z02", status="in_drafting", approved_cards=1)
    add_approval(repo, path2)
    add_required_reviews(repo, path2)
    dist = tmp_path / "dist"
    pin = pin_for(repo)
    ed1 = pdfbuild.build_release(repo, out_root=dist, pin=pin)
    assert ed1.ok and len(ed1.pdfs) == 2

    # Demote Z02 entry to approved (leaving only Z09 published)
    rewrite_entry(path2, lambda fm: fm.update(status="approved"))
    ed2 = pdfbuild.build_release(repo, out_root=dist, pin=pin)
    assert ed2.ok and ed2.edition_id != ed1.edition_id and len(ed2.pdfs) == 1
    assert [p.name for p in ed2.pdfs] == ["Z09_tools_construction.pdf"]
    assert not (dist / rel.EDITIONS / ed2.edition_id / "zones/Z02_shelter.pdf").exists()
    assert (dist / rel.EDITIONS / ed1.edition_id / "zones/Z02_shelter.pdf").is_file(), "old edition stays in archive"
    assert rel.verify_active(repo, dist, pin=pin).ok is True


@pytest.mark.slow
def test_cli_release_lifecycle(tmp_path, capsys):
    repo, path = published_world(tmp_path / "repo")
    dist = tmp_path / "dist"
    pin = pin_for(repo)

    code, out = cli(capsys, "--root", str(repo.root), "release", "status", "--out-dir", str(dist))
    assert code == 0 and "none" in out

    code, out = cli(capsys, "--root", str(repo.root), "release", "--out-dir", str(dist), "--pin", pin)
    assert code == 0 and "release: OK" in out and "ED-" in out

    code, out = cli(capsys, "--root", str(repo.root), "release", "verify", "--out-dir", str(dist), "--pin", pin)
    assert code == 0 and "OK" in out and "state=active" in out

    code, out = cli(capsys, "--root", str(repo.root), "release", "withdraw", "--out-dir", str(dist), "--reason", "N/A")
    assert code == 1 and "reason" in out

    code, out = cli(capsys, "--root", str(repo.root), "release", "withdraw", "--out-dir", str(dist),
                    "--reason", "Withdrawn by owner after safety review found an issue.")
    assert code == 0 and "withdrawn" in out

    code, out = cli(capsys, "--root", str(repo.root), "release", "verify", "--out-dir", str(dist), "--pin", pin)
    assert code == 1 and "state=withdrawn" in out

    code, out = cli(capsys, "--root", str(repo.root), "release", "status", "--out-dir", str(dist))
    assert code == 0 and "withdrawn" in out
