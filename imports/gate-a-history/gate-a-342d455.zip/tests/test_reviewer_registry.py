"""The reviewer registry is the only source of reviewer authority (FR-005).

A ledger row used to say who reviewed it and in which role, and the gate believed the row. These tests pin what replaces that: an
owner-rooted, append-only registry in which every row is attested, each identity has one kind for ever, and a row that breaks a rule
is reported and grants nothing. All people and models here are fixtures.
"""
from __future__ import annotations

import pytest

from factories import make_repo, ALL_DOMAINS, DATE, codes, register, seed_registry
from sfe.registry import load_register
from sfe.reviewers import KIND_RULES, Registry, load_registry
from sfe.validate import validate_repo


@pytest.fixture
def repo(tmp_path):
    """These tests build their own registry: start from an empty one."""
    return make_repo(tmp_path, registry=False)


KIND_FOR = {"registrar": "owner", "adjudicator": "human", "external_sme": "human", "chatgpt_editorial": "ai_model",
            "technical_reviewer": "human", "author": "ai_model"}


def registry_of(repo) -> Registry:
    rows, _ = load_register(repo, "reviewers")
    return load_registry(rows, "reviews/reviewers.csv")


def found(repo) -> set[str]:
    return {f.code for f in registry_of(repo).findings}


def args_for(capacity, kind=None):
    domains = ["HZ-WATER-POTABILITY"] if capacity in ("technical_reviewer", "external_sme") else (["ALL"] if capacity == "chatgpt_editorial" else [])
    evidence = "Fixture credential" if capacity in ("technical_reviewer", "external_sme", "adjudicator") else None
    return {"kind": kind or KIND_FOR[capacity], "domains": domains, "evidence": evidence}


def granted(repo, reviewer_id, capacity, on=None):
    return registry_of(repo).lookup(reviewer_id, capacity, on)[0] is not None


# --------------------------------------------------------------------------------------- bootstrap
def test_an_empty_registry_is_valid_and_registers_nobody(repo):
    assert found(repo) == set() and codes(validate_repo(repo.root)) == set()
    assert registry_of(repo).lookup("REV-0001", "registrar")[1][0] == "REVIEWER_NOT_REGISTERED"


def test_the_fixture_registry_is_valid(repo):
    seed_registry(repo)
    assert found(repo) == set()
    reg = registry_of(repo)
    assert reg.kind_of("REV-0004") == "human" and reg.name_of("REV-0003") == "Fixture ChatGPT Editorial"
    assert reg.kind_of("REV-9999") is None and reg.name_of(None) is None


@pytest.mark.parametrize("label,kwargs", [
    ("not_a_registrar", dict(capacity="author", kind="ai_model", by="REV-0001")),
    ("registrar_but_not_owner", dict(capacity="registrar", kind="human", by="REV-0001")),
    ("attested_by_someone_else", dict(capacity="registrar", kind="owner", by="REV-0007")),
    ("a_revocation", dict(capacity="registrar", kind="owner", by="REV-0001", action="revoke", revokes="REG-0001")),
], ids=lambda case: case if isinstance(case, str) else "")
def test_the_first_row_must_be_the_owner_bootstrap(repo, label, kwargs):
    kwargs = dict(kwargs)
    capacity = kwargs.pop("capacity")
    register(repo, "REV-0001", capacity, name="Fixture Owner", **kwargs)
    assert "REGISTRY_BOOTSTRAP_INVALID" in found(repo)
    assert not granted(repo, "REV-0001", capacity), "a broken bootstrap grants nothing"


def test_only_the_first_row_may_attest_itself(repo):
    seed_registry(repo)
    register(repo, "REV-0009", "registrar", kind="owner", name="Fixture Impostor", by="REV-0009")
    assert "REGISTRY_REGISTRAR_REQUIRED" in found(repo)
    assert not granted(repo, "REV-0009", "registrar")


# -------------------------------------------------------------------------------------- attestation
@pytest.mark.parametrize("attester", ["REV-0002", "REV-0003", "REV-0004", "REV-0005", "REV-0006", "REV-4242"])
def test_only_a_registrar_can_attest_a_registration(repo, attester):
    seed_registry(repo)
    register(repo, "REV-0009", "author", kind="human", name="Fixture Subject", by=attester)
    assert "REGISTRY_REGISTRAR_REQUIRED" in found(repo)
    assert not granted(repo, "REV-0009", "author")


def test_a_second_registrar_can_be_appointed_and_then_attests(repo):
    seed_registry(repo)
    register(repo, "REV-0010", "registrar", kind="owner", name="Fixture Second Owner")
    register(repo, "REV-0011", "author", kind="human", name="Fixture Subject", by="REV-0010")
    assert found(repo) == set() and granted(repo, "REV-0011", "author")


def test_a_revoked_registrar_can_no_longer_attest(repo):
    seed_registry(repo)
    register(repo, "REV-0010", "registrar", kind="owner", name="Fixture Second Owner")
    register(repo, "REV-0001", "registrar", kind="owner", name="Fixture Owner", by="REV-0010", action="revoke", revokes="REG-0001")
    assert found(repo) == set()
    register(repo, "REV-0011", "author", kind="human", name="Fixture Subject", by="REV-0001")
    assert "REGISTRY_REGISTRAR_REQUIRED" in found(repo) and not granted(repo, "REV-0011", "author")


def test_the_last_registrar_cannot_be_revoked(repo):
    seed_registry(repo)
    register(repo, "REV-0001", "registrar", kind="owner", name="Fixture Owner", action="revoke", revokes="REG-0001")
    assert "REGISTRY_LAST_REGISTRAR" in found(repo)
    assert granted(repo, "REV-0001", "registrar"), "the refused revocation must not take effect"


# ------------------------------------------------------------------------------- kind and capacity
KIND_CASES = [(capacity, kind, kind in allowed) for capacity, allowed in KIND_RULES.items() for kind in ("human", "ai_model", "owner")]


@pytest.mark.parametrize("capacity,kind,ok", KIND_CASES, ids=[f"{c}-{k}" for c, k, _ in KIND_CASES])
def test_a_capacity_can_only_be_held_by_the_right_kind(repo, capacity, kind, ok):
    seed_registry(repo)
    register(repo, "REV-0009", capacity, name="Fixture Subject", **args_for(capacity, kind))
    assert ("REGISTRY_KIND_CAPACITY" not in found(repo)) is ok
    assert granted(repo, "REV-0009", capacity) is ok


def test_chatgpt_editorial_is_never_a_human_and_an_external_sme_is_never_a_model(repo):
    seed_registry(repo)
    register(repo, "REV-0009", "external_sme", name="Fixture Model Posing As Expert", **args_for("external_sme", "ai_model"))
    register(repo, "REV-0010", "chatgpt_editorial", name="Fixture Person Posing As ChatGPT", **args_for("chatgpt_editorial", "human"))
    assert not granted(repo, "REV-0009", "external_sme") and not granted(repo, "REV-0010", "chatgpt_editorial")


# ------------------------------------------------------------------------ evidence and domains
@pytest.mark.parametrize("capacity", ["external_sme", "technical_reviewer", "adjudicator"])
@pytest.mark.parametrize("evidence", [None, "", "   "])
def test_a_specialist_needs_qualification_evidence(repo, capacity, evidence):
    seed_registry(repo)
    args = args_for(capacity)
    args["evidence"] = evidence
    register(repo, "REV-0009", capacity, name="Fixture Subject", **args)
    assert "REGISTRY_EVIDENCE_MISSING" in found(repo) and not granted(repo, "REV-0009", capacity)


@pytest.mark.parametrize("capacity", ["external_sme", "technical_reviewer", "chatgpt_editorial"])
def test_these_capacities_must_name_the_subjects_they_speak_for(repo, capacity):
    seed_registry(repo)
    args = args_for(capacity)
    args["domains"] = []
    register(repo, "REV-0009", capacity, name="Fixture Subject", **args)
    assert "REGISTRY_DOMAINS_INVALID" in found(repo) and not granted(repo, "REV-0009", capacity)


@pytest.mark.parametrize("capacity", ["registrar", "author", "adjudicator"])
def test_these_capacities_carry_no_domains(repo, capacity):
    seed_registry(repo)
    args = args_for(capacity)
    args["domains"] = ["HZ-WATER-POTABILITY"]
    register(repo, "REV-0009", capacity, name="Fixture Subject", **args)
    assert "REGISTRY_DOMAINS_INVALID" in found(repo)


@pytest.mark.parametrize("capacity,ok", [("chatgpt_editorial", True), ("external_sme", False), ("technical_reviewer", False)])
def test_all_is_a_domain_only_for_chatgpt_editorial(repo, capacity, ok):
    seed_registry(repo)
    args = args_for(capacity)
    args["domains"] = ["ALL"]
    register(repo, "REV-0009", capacity, name="Fixture Subject", **args)
    assert ("REGISTRY_DOMAINS_INVALID" not in found(repo)) is ok


@pytest.mark.parametrize("token", ["water", "HZ-lower", "XX-WATER", "HZ-", "ALL ", "hz-water-potability"])
def test_domain_tokens_must_look_like_subjects(repo, token):
    seed_registry(repo)
    args = args_for("external_sme")
    args["domains"] = [token]
    register(repo, "REV-0009", "external_sme", name="Fixture Subject", **args)
    assert "ROW_SCHEMA" in codes(validate_repo(repo.root))


# ------------------------------------------------------------------------------------------ identity
def test_one_id_cannot_be_two_kinds(repo):
    seed_registry(repo)
    register(repo, "REV-0004", "chatgpt_editorial", name="Fixture Domain Expert", **args_for("chatgpt_editorial", "ai_model"))
    assert "REGISTRY_IDENTITY_CONFLICT" in found(repo)
    assert not granted(repo, "REV-0004", "chatgpt_editorial"), "a human cannot become ChatGPT by adding a row"


def test_one_id_cannot_change_its_name(repo):
    seed_registry(repo)
    register(repo, "REV-0004", "adjudicator", kind="human", name="Fixture Someone Else", evidence="Fixture appointment")
    assert "REGISTRY_IDENTITY_CONFLICT" in found(repo)


@pytest.mark.parametrize("name", ["Fixture Domain Expert", "fixture domain expert", "  Fixture   Domain  Expert ", "FIXTURE DOMAIN EXPERT"])
def test_one_name_cannot_belong_to_two_ids(repo, name):
    """P09b: one person in both required classes. Under two ids with one name, the independence rules would be meaningless."""
    seed_registry(repo)
    register(repo, "REV-0009", "author", kind="human", name=name)
    assert "REGISTRY_NAME_DUPLICATE" in found(repo) and not granted(repo, "REV-0009", "author")


def test_one_identity_may_hold_two_capacities_consistently(repo):
    seed_registry(repo)
    register(repo, "REV-0004", "technical_reviewer", kind="human", name="Fixture Domain Expert", domains=["HZ-WATER-POTABILITY"], evidence="Fixture credential")
    assert found(repo) == set()
    assert granted(repo, "REV-0004", "external_sme") and granted(repo, "REV-0004", "technical_reviewer")


def test_a_capacity_cannot_be_registered_twice_while_active(repo):
    seed_registry(repo)
    register(repo, "REV-0004", "external_sme", kind="human", name="Fixture Domain Expert", domains=["HZ-WATER-POTABILITY"], evidence="Fixture credential")
    assert "REGISTRY_DUPLICATE_REGISTRATION" in found(repo)


def test_a_capacity_can_be_registered_again_after_it_was_revoked(repo):
    seed_registry(repo)
    register(repo, "REV-0004", "external_sme", kind="human", name="Fixture Domain Expert", domains=ALL_DOMAINS, evidence="Fixture credential",
             action="revoke", revokes="REG-0004")
    register(repo, "REV-0004", "external_sme", kind="human", name="Fixture Domain Expert", domains=["HZ-WATER-POTABILITY"], evidence="Fixture requalified")
    assert found(repo) == set() and granted(repo, "REV-0004", "external_sme")


# ------------------------------------------------------------------------------------------ revoke
def revoke(repo, target="REG-0004", **over):
    args = dict(reviewer_id="REV-0004", capacity="external_sme", kind="human", name="Fixture Domain Expert", action="revoke", revokes=target)
    args.update(over)
    return register(repo, args.pop("reviewer_id"), args.pop("capacity"), **args)


def test_a_revocation_ends_the_registration_for_every_date(repo):
    seed_registry(repo)
    assert granted(repo, "REV-0004", "external_sme", DATE)
    revoke(repo, on="2026-03-01")
    reg = registry_of(repo)
    assert found(repo) == set()
    for day in ("2026-01-15", "2026-02-01", "2026-03-01", "2026-04-01"):
        assert reg.lookup("REV-0004", "external_sme", day)[1][0] == "REVIEWER_REVOKED", "revocation is retroactive for counting"


@pytest.mark.parametrize("label,kwargs", [
    ("unknown_target", dict(target="REG-4242")),
    ("target_is_not_a_registration_of_this_identity", dict(target="REG-0003")),
    ("wrong_capacity", dict(capacity="technical_reviewer", evidence="Fixture credential")),
    ("wrong_kind", dict(kind="ai_model")),
], ids=lambda case: case if isinstance(case, str) else "")
def test_a_revocation_must_repeat_the_identity_it_revokes(repo, label, kwargs):
    seed_registry(repo)
    revoke(repo, **kwargs)
    assert "REGISTRY_REVOKE_INVALID" in found(repo)
    assert granted(repo, "REV-0004", "external_sme"), "an invalid revocation takes no effect"


def test_a_registration_cannot_be_revoked_twice(repo):
    seed_registry(repo)
    revoke(repo)
    revoke(repo)
    assert "REGISTRY_REVOKE_INVALID" in found(repo)


def test_only_a_registrar_can_revoke(repo):
    seed_registry(repo)
    revoke(repo, by="REV-0004")
    assert "REGISTRY_REGISTRAR_REQUIRED" in found(repo) and granted(repo, "REV-0004", "external_sme")


def test_a_register_row_cannot_carry_a_revocation_target(repo):
    seed_registry(repo)
    register(repo, "REV-0009", "author", kind="human", name="Fixture Subject", revokes="REG-0004")
    assert "REGISTRY_REVOKE_INVALID" in found(repo) and not granted(repo, "REV-0009", "author")


# --------------------------------------------------------------------------------- the lookup
def test_lookup_explains_every_refusal(repo):
    seed_registry(repo)
    register(repo, "REV-0009", "external_sme", kind="human", name="Fixture Windowed", domains=["HZ-WATER-POTABILITY"], evidence="e",
             on="2026-02-01", until="2026-02-28")
    reg = registry_of(repo)
    assert reg.lookup(None, "author")[1][0] == "REVIEWER_NOT_REGISTERED"
    assert reg.lookup("REV-4242", "author")[1][0] == "REVIEWER_NOT_REGISTERED"
    assert reg.lookup("REV-0002", "external_sme")[1][0] == "REVIEWER_CAPACITY_NOT_REGISTERED"
    assert reg.lookup("REV-0002", None)[1][0] == "REVIEWER_CAPACITY_NOT_REGISTERED"
    assert reg.lookup("REV-0009", "external_sme", "2026-01-31")[1][0] == "REVIEWER_NOT_VALID_ON_DATE"
    assert reg.lookup("REV-0009", "external_sme", "2026-03-01")[1][0] == "REVIEWER_NOT_VALID_ON_DATE"


def test_the_validity_window_includes_both_end_days(repo):
    seed_registry(repo)
    register(repo, "REV-0009", "external_sme", kind="human", name="Fixture Windowed", domains=["HZ-WATER-POTABILITY"], evidence="e",
             on="2026-02-01", until="2026-02-28")
    reg = registry_of(repo)
    for day in ("2026-02-01", "2026-02-14", "2026-02-28"):
        assert reg.lookup("REV-0009", "external_sme", day)[0] is not None, day
    assert reg.lookup("REV-0009", "external_sme", None)[0] is not None, "no date, no window (used for entry fields)"


def test_valid_until_cannot_precede_the_registration(repo):
    seed_registry(repo)
    register(repo, "REV-0009", "external_sme", kind="human", name="Fixture Windowed", domains=["HZ-WATER-POTABILITY"], evidence="e", until="2026-01-01")
    assert "REGISTRY_VALIDITY_INVALID" in found(repo)


def test_a_renewed_registration_replaces_the_revoked_one_in_lookups(repo):
    seed_registry(repo)
    revoke(repo, on="2026-02-01")
    renewed = register(repo, "REV-0004", "external_sme", kind="human", name="Fixture Domain Expert", domains=["HZ-WATER-POTABILITY"],
                       evidence="Fixture requalified", on="2026-02-02")
    assert found(repo) == set()
    reg = registry_of(repo).lookup("REV-0004", "external_sme", "2026-02-03")[0]
    assert reg.registration_id == renewed["registration_id"] and reg.domains == frozenset({"HZ-WATER-POTABILITY"})
    earlier, why = registry_of(repo).lookup("REV-0004", "external_sme", "2026-01-20")
    assert earlier is None and why[0] == "REVIEWER_NOT_VALID_ON_DATE", \
        "the revoked registration never counts again, and the renewed one counts only from its own start"


# ----------------------------------------------------------------------- the registry in validation
def test_registry_errors_reach_the_repository_validation(repo):
    seed_registry(repo)
    register(repo, "REV-0009", "author", kind="human", name="Fixture Subject", by="REV-0002")
    assert "REGISTRY_REGISTRAR_REQUIRED" in codes(validate_repo(repo.root))


@pytest.mark.parametrize("column,value", [("kind", "robot"), ("capacity", "approver"), ("action", "update"), ("reviewer_id", "REV-1"),
                                          ("registration_id", "reg-0001")])
def test_the_registry_schema_rejects_malformed_values(repo, column, value):
    from factories import edit_rows
    seed_registry(repo)
    edit_rows(repo, "reviewers", lambda rows: rows[1].update({column: value}))
    assert "ROW_SCHEMA" in codes(validate_repo(repo.root))


def test_a_revoke_row_must_name_its_target(repo):
    from factories import edit_rows
    seed_registry(repo)
    revoke(repo)
    edit_rows(repo, "reviewers", lambda rows: rows[-1].update(revokes_registration_id=""))
    assert "ROW_SCHEMA" in codes(validate_repo(repo.root))
