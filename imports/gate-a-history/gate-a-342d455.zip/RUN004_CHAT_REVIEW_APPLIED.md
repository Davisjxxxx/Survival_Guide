# RUN-004 Chat Review Bounded Fixes — Application Record

- **Date applied:** 2026-11-21 (America/Chicago)
- **Repository:** `/home/jd/Survival_Guide`
- **Base branch / commit (preserved unchanged):** `gate-a/remediation-3` at `bd409f87b51efcfd1492125999beae790b3ce66f`
- **New branch:** `gate-a/review-fixes-1`
- **Gate A status:** **BLOCKED** (not approved by this application)
- **Content publication status:** **NOT AUTHORIZED**
- **Owner decisions:** All pending (`D1`–`D9`, `D13`–`D23`); no decisions, waivers, reviewer registrations, tags, remotes, pushes, or `main` branch creation were performed.

---

## 1. Package & Patch Integrity Verification

- **Source archive (outside repository):** `/home/jd/Downloads/Survival_Guide_RUN004_Chat_Review_20261120.zip`
- **Source archive SHA-256:** `6e07f863e31525aaf0a52a48425a09132598ecbc38362478ac95122d1d3d5027`
- **Extraction directory (outside repository):** `/home/jd/Survival_Guide_RUN004_Chat_Review_20261120/Survival_Guide_RUN004_Chat_Review_20261120`
- **Base submission archive referenced by manifest:** `RUN004_GateA_Review_bd409f8.zip` (`fae4161586f106aef84c3ba740103d73ce6a717b80db91c8c3adb0408854167f`)
- **Package `SHA256SUMS.txt` check:** All 31 listed files verified `OK` via `sha256sum -c SHA256SUMS.txt`.
- **Patch file (`RUN004_Bounded_Fixes_bd409f8.patch`) SHA-256:** `09b3fdd918398de4acd052940ccd6d54a0c2ff89559b05127112d7f9a5fbc995` (matches `APPLY_WITH_NEON.txt` and `PATCH_MANIFEST.json`).

### Base vs. Post-Apply File Hashes (`PATCH_MANIFEST.json`)

| Path | Kind | Base SHA-256 (`bd409f8`) | Post-Apply SHA-256 (verified against manifest) |
| --- | --- | --- | --- |
| `scripts/sfe/release.py` | modify | `e625af0d7ef6da8295ec356b8b4cc5d8d3c9fff5817211920dc5e28a1be77ecf` | `2a67b6bb411c8e608a1da805c1a69119597931e4bd1b77508d92500b4cf231db` |
| `scripts/sfe/textcheck.py` | modify | `f501db45665bd95e8d5c07b392c39ef33b14cc00a94b39981120dacec35b6847` | `0892f3bff6957972fe79193f7d816906031e3519e39e17604a4803818a970944` |
| `tests/test_na_exception_scope.py` | add | *(absent)* | `20bfdd348304d1a33c5d5c0853026c3e354eb73f02a4e9ab950a0105efddbc7c` |
| `tests/test_release_withdrawal_recovery.py` | add | *(absent)* | `d19b4f16ae0acb1b19f8fc95a15651c0962dc001f93fd79d51a5e48f7db96449` |

Summary of the two bounded fixes applied:
- **R1 (FR-017):** `scripts/sfe/release.py` (`recover()`) now appends a durable `withdraw` / `auto_withdraw` log row for a valid `withdrawn` pointer whenever no withdrawal row exists for that edition, without requiring an earlier matching `promote` row. Prevents loss of withdrawal prohibition after two consecutive interrupted operations (promotion + withdrawal), verified by 8 new cases in `tests/test_release_withdrawal_recovery.py`.
- **R2 (FR-021):** `scripts/sfe/textcheck.py` (`check_entry()`) now walks non-assessed front-matter strings and refuses exact `Not applicable [CLM-id]: <justification>` declarations outside permitted step `verify` / `abort_if` fields with `NOT_APPLICABLE_NOT_ALLOWED`, without imposing new word floors or rejecting quoted/ordinary mentions, verified by 20 new cases in `tests/test_na_exception_scope.py`.

No other implementation, schema, historical run record, or contract file was modified.

---

## 2. Exact Commands & Verification Results

### Package & Patch Verification Commands

```bash
sha256sum /home/jd/Downloads/Survival_Guide_RUN004_Chat_Review_20261120.zip
(cd /home/jd/Survival_Guide_RUN004_Chat_Review_20261120/Survival_Guide_RUN004_Chat_Review_20261120 && sha256sum -c SHA256SUMS.txt)
git -C /home/jd/Survival_Guide apply --check --stat /home/jd/Survival_Guide_RUN004_Chat_Review_20261120/Survival_Guide_RUN004_Chat_Review_20261120/RUN004_Bounded_Fixes_bd409f8.patch
```

### Branch Creation & Patch Application Commands

```bash
cd /home/jd/Survival_Guide
sha256sum scripts/sfe/release.py scripts/sfe/textcheck.py
git checkout -b gate-a/review-fixes-1 bd409f87b51efcfd1492125999beae790b3ce66f
git apply --check /home/jd/Survival_Guide_RUN004_Chat_Review_20261120/Survival_Guide_RUN004_Chat_Review_20261120/RUN004_Bounded_Fixes_bd409f8.patch
git apply /home/jd/Survival_Guide_RUN004_Chat_Review_20261120/Survival_Guide_RUN004_Chat_Review_20261120/RUN004_Bounded_Fixes_bd409f8.patch
sha256sum scripts/sfe/release.py scripts/sfe/textcheck.py tests/test_na_exception_scope.py tests/test_release_withdrawal_recovery.py
```

### Full Check Command (Existing Local Python/TeX Toolchain)

```bash
cd /home/jd/Survival_Guide && python3 --version && pdflatex --version | head -n 1 && make check
```

### Observed Real Results on the Patched Candidate (`gate-a/review-fixes-1`)

- **Runtime environment:** `Python 3.13.0`, `pdfTeX 3.141592653-2.6-1.40.25 (TeX Live 2023/Debian)`
- **Exit code:** `0`
- **Preservation (`make verify-preserved`):**
  - `sha256sum -c PRESERVED_FILES.sha256`: 6/6 `OK` (`BASELINE_AUDIT_20261116.md`, `handoff/README_INSTALL.md`, `handoff/SHA256SUMS.txt`, `handoff/SURVIVAL_FIELD_ENCYCLOPEDIA_ASTRA_CLI_HANDOFF.md`, `handoff/Survival_Field_Encyclopedia_Master_Sprint_Plan_v1.md`, `handoff/Survival_Field_Encyclopedia_Sprint_Tracker_v1.xlsx`)
  - `cd handoff && sha256sum -c SHA256SUMS.txt`: 3/3 `OK`
- **Repository validation (`python3 -m sfe validate`):** `validate[content]: 0 error(s), 0 warning(s)`
- **Specimen validation (`python3 -m sfe validate --specimen`):** `validate[specimen]: 0 error(s), 0 warning(s)`
- **Full pytest suite (`python3 -m pytest -q`):** **`2168 passed in 102.25s (0:01:42)`** (0 failed, 0 skipped, 0 deselected; includes all 28 new regression cases automatically on top of the prior 2140 suite)
- **Specimen proof build (`python3 -m sfe proof`):**
  - `proof[letter]: OK (0 error(s), 1 warning(s))`
  - Expected warning: `WARNING PDF_UNTAGGED SPECIMEN_LAYOUT_PROOF.pdf: PDF is not tagged: accessibility tagging is unavailable with TeX Live 2023 pdfLaTeX (open decision, see BUILD_PLAN.md)`
  - Output PDF: `proofs/SPECIMEN_LAYOUT_PROOF.pdf`
  - SHA-256: `e8ee7b1641baa8e9148de5a531dc36315a65446b0acaccc54c6d1c69100c330a` (unchanged relative to `bd409f8`)
- **Reproducibility check (`python3 -m sfe repro`):**
  - `repro: REPRODUCIBLE`
  - `build A sha256`: `e8ee7b1641baa8e9148de5a531dc36315a65446b0acaccc54c6d1c69100c330a`
  - `build B sha256`: `e8ee7b1641baa8e9148de5a531dc36315a65446b0acaccc54c6d1c69100c330a`
  - `manifests identical: True`

---

## 3. FR-019 Wording Qualification

Per the independent RUN-004 review (`RUN004_Chat_Review_20261120.txt`), the precise behavior of unit validation under FR-019 is qualified as follows (no unit policy was modified by this patch):

- **Explicit unit pairs / dimension tables:** Unknown units are refused.
- **Prose scanner:** Unsupported prose units are **not** recognized or conversion-validated.
- **Medical dosages:** No medical dosage policy or tolerance is defined.
- **Rounding direction:** Minimum/maximum directional rounding (`RT-103`) remains deferred and unimplemented; retain specialist/manual review of unsupported prose quantities and directional safety bounds.

---

## 4. Open Deferrals & Recorded Limits (Unchanged / Still Open)

Applying R1 and R2 resolves only those two bounded contract defects and **does not** close broader findings in full or waive explicit deferrals:

- **P26 / FR-018 (source-link duplicate destinations & log-parser miss):** Explicitly excluded from the RUN-004 contract; remains **OPEN**. Requires an explicit owner disposition (narrow duplicate-source-target/log-parser repair vs. accepted limitation with deadline before multi-entry release).
- **P29 / FR-016 (stale legal/harvest dates & broad jurisdiction):** Explicitly excluded from RUN-004; remains **OPEN** before releasing affected legal/harvest guidance.
- **P91 / FR-013 (photo provenance authenticity):** Explicitly excluded from RUN-004; validator checks declared provenance and does not detect synthetic imagery or replace human audit records; remains **OPEN**.
- **P70 / FR-020 (overlong safety panel layout capacity):** Validator accepts overlong text while release build fails closed on overflow/missing text; later layout-capacity work (multi-page/body/species layout) remains **OPEN**.
- **FR-003 (ledger continuity pin):** Unsigned external pin custody, checkpoint-only coverage, and manual renewal after each batch remain recorded limits (`D23`).
- **FR-008 (claim completeness):** Per-item claim binding remains partial/open beyond RUN-004 scope (`D17`).
- **FR-014 & FR-015 (image handling & licensing):** Metadata stripping and the world-writable-bit check do not constitute archival access control or photo authenticity proof (`D21`, `D22`, `FR-026`); fuller attribution/credits remain partial/open.
- **FR-017 (release state):** Printed edition IDs inside PDF content and errata/recall workflows remain partial/open (`D20`).

Historical records (`RUN-001.md`, `RUN-002.md`, `RUN-003.md`, `RUN-004.md`, `RUN004_REVIEW_RECONCILIATION.md`, `FINDING_REMEDIATION_MATRIX.md`, `BUILD_PLAN.md`, `GOVERNANCE.md`) are preserved untouched; no prior counts or contract texts were rewritten.

---

## 5. Proposed Owner Decision Deadlines (All Decisions Remain PENDING)

The following grouping is carried from `decision_deadlines.txt` as a **proposal only** — it records the deadline ambiguity between `RUN-004.md` (which groups `D1`–`D9`, `D13`–`D23` and future layouts together before S02) and `BUILD_PLAN.md` (which assigns staggered milestones). **No decision is approved, decided, or waived here.**

| Decision / Item | Owner Choice | Proposed Required-Before Milestone | Recorded Residual / Limit | Status |
| --- | --- | --- | --- | --- |
| Gate A engineering review | *(pending owner)* | Gate A now | Reviews final commit, reconciliation, and dummy tooling proof only (not reader-book quality) | **PENDING** |
| `D1` (PDF accessibility tagging) | *(pending owner)* | Gate A now (limited proof decision) / later tagged output before publication | TeX Live 2023 `pdfLaTeX` emits untagged PDF (`PDF_UNTAGGED`) | **PENDING** |
| `D2`, `D4`–`D7` (schemas, dirs, gate vocab, coverage list, no fake entries) | *(pending owner)* | Gate A now | Structural baseline choices per `BUILD_PLAN.md` | **PENDING** |
| `D3` aligned with `D19` (conversion policy) | *(pending owner)* | Gate A alignment / confirm `D19` before S02 approvals | Do not approve old round-trip-only policy as full rule; unsupported prose units unvalidated; no dosage policy; `RT-103` deferred | **PENDING** |
| `D9` aligned with `D14` (hazard scope / classification) | *(pending owner)* | Gate A alignment / confirm `D14` before S02 | Align hazard classes with classification table | **PENDING** |
| `P26` / `FR-018` disposition (duplicate source targets) | *(pending owner)* | Gate A disposition (repair or explicit deadline before multi-entry release) | Excluded from RUN-004; Gate A mentions source links | **PENDING** |
| `D8` (create `main` / merge) | *(pending owner)* | Separate owner action after Gate A review | Must not be executed automatically | **PENDING** |
| `D13`, `D16` (registered human specialists & registrar/reviewer roster) | *(pending owner)* | Before first real approvals (S02) | Empty registry blocks approvals; do not invent identities | **PENDING** |
| `D14`, `D17` (entry classification & claim policy) | *(pending owner)* | Before S02 ingestion | Per-item claim binding remains partial | **PENDING** |
| `D18`, `D19` (usable-text exceptions & numeric tolerances) | *(pending owner)* | Before S02 / first real approvals using them | Manual check for min/max direction (`RT-103`) and unsupported prose units | **PENDING** |
| `D23` (external ledger-pin custody & renewal) | *(pending owner)* | Before relying on real approval-ledger continuity (S02) | Unsigned checkpoint; requires independent custody and per-batch renewal | **PENDING** |
| `D15` (qualified specialist taxa/views), `D21` (original archive/access & derivative recipe), `D22` (distribution/licence policy) | *(pending owner)* | Before diagnostic imagery / S06 | Current checks are not confidential archival ACLs or authenticity proof (`FR-013`, `FR-026`) | **PENDING** |
| `D20` (withdrawal authority, retention, release-log backup) | *(pending owner)* | Before beta / publication | Printed edition IDs and errata/recall workflows remain partial | **PENDING** |
| Future layout / release features (`S03` body/multi-page, `S06` species/plates, `S13` combined ref, `S15` attribution/packaging, `P29`/`FR-016` freshness, `P70`/`FR-020` overflow) | *(pending owner)* | Respectively before affected release gates / publication | Content publication remains **NOT AUTHORIZED** | **PENDING** |
