# Changelog

## Unreleased: Gate A remediation 3 (branch `gate-a/remediation-3`), RUN-004: safety and release-integrity remediation

Changed (independent adversarial review `FABLE-REVIEW-001`; Gate A is NOT approved; no content may be published). Evidence: `RUN-004.md`, `FINDING_REMEDIATION_MATRIX.md` (sections 9–15)
- **FR-008** `schemas/claim_policy.yaml` and `scripts/sfe/evidence.py`: minimum claim counts (hard floor of 1 claim in code), required claim types per entry type (`identification` for species profiles, `medical` for medical guidance), medical claims on every medical procedure step, optional `field_claims` binding every non-empty safety-bearing field to backing claims of accepted types, and text-trigger claim requirements across entry types (P19a, P19b closed).
- **FR-021** `scripts/sfe/textcheck.py`: layered usable-text validation for mandatory safety and verification fields at `verified` and above (rejects null-like tokens, placeholders, repetition, content-free filler); adds one explicit, printed, claim-bound exception `Not applicable [CLM-id]: <justification>` for step `verify` / `abort_if` only (P27 closed).
- **FR-019** `schemas/unit_policy.yaml` and rewritten `scripts/sfe/units.py`: documented numeric equivalence policy (precise 1%, explicit approximate 5%, safety-critical 0.5% with ceilings in code), fractions, ranges, temperature intervals (`"18 °F difference"`), careful zero/temperature offset handling, and inline prose conversion scanning (`A (B)`, `A / B`, `A or B`, `A = B`) across all text fields; no medical dosage tolerances invented (P23, P28 closed).
- **FR-017** `scripts/sfe/release.py`, `pdfbuild.py`, `cli.py`: explicit `ACTIVE_RELEASE.json` manifest, immutable read-only `dist/editions/<ED-id>/` archive, atomic promotion, append-only hash-chained `RELEASE_LOG.csv`, active-release validation (`release verify`), manual and automatic withdrawal (`release withdraw`, `release reconcile`), legacy flat-output quarantine, and crash/restart recovery (`release recover`) without deleting audit evidence (P25 closed).
- **FR-014, FR-015** `scripts/sfe/derive.py`, `schemas/licenses.yaml`, `schemas/asset.schema.json`, `scripts/sfe/assets.py`: deterministic EXIF/GPS/XMP/IPTC/comment/PNG-text-stripped publication derivatives with orientation transpose and ICC preservation, read-only originals with access-control checks (`ASSET_PERMISSIONS_TOO_OPEN`), post-build PDF byte + `pdfimages -all` verification (`IMAGE_METADATA_IN_PDF`, `ORIGINAL_PUBLISHED`), controlled licence vocabulary checking reuse/modify/crop/redistribute/commercial rights, verified rights evidence under `assets/rights/` bound to the approval package digest, and quarantine/directory hygiene (P72, P90 closed).
- **FR-003 (residual)** `scripts/sfe/ledger.py`, `validate.py`, `release.py`, `pdfbuild.py`, `cli.py`: external continuity checkpoint (`python -m sfe ledger pin`, `--pin` / `SFE_LEDGER_PIN`, refused if stored inside the repo) detecting bare-export tail truncation (`LEDGER_PIN_TRUNCATED`) and prefix rewrites (`LEDGER_PIN_REWRITTEN`); fails closed without an anchor once ledgers hold rows (`LEDGER_PIN_REQUIRED` on release/verify; `LEDGER_CONTINUITY_UNANCHORED` warning / `--strict` error on validate; P08c bare-export closed).

Added
- 785 new tests (1353 to 2138) across `test_claim_completeness`, `test_usable_text`, `test_unit_equivalence`, `test_release_state`, `test_image_publication`, `test_licences`, `test_ledger_pin`; 97 new sabotage experiments (`S81`–`S177`, all detected).
- Specimen proof rebuilt for schema updates (`schemas/entry.schema.json`, `schemas/asset.schema.json`, `layouts/specimen/specimen_assets.csv`).

Not done, by instruction: no S02 ingestion, no publication, no approval of Gate A, no `main`, no remote, no push, no fabricated specialist review.

## Unreleased: Gate A remediation 2 (branch `gate-a/remediation-2`), RUN-003: the approval and publication trust model

Changed (independent adversarial review `FABLE-REVIEW-001`; Gate A is NOT approved; no content may be published). Evidence: `RUN-003.md`, `FINDING_REMEDIATION_MATRIX.md`
- **FR-001** Required review subjects are DERIVED from zone, zone priority, entry type, cited claims, coverage plan, structure and text; declared `hazard_tags` only add. Nothing applying means an independent
  screening review. Unknown classifications and an unusable policy require every subject and are errors. Zones have allowed entry types; species and medical fields on another type are errors.
- **FR-002, FR-003, FR-004** Ledgers are append-only, sequence-ordered and hash-chained; precedence is by sequence, never by a typed date; calendar-impossible dates are errors; an unresolved failure blocks the whole
  entry or asset until an explicit, evidence-linked resolution; orphan and conflicting references are errors; in a Git checkout every commit must only append.
- **FR-005, FR-006** `reviews/reviewers.csv`: an owner-rooted registry of identities, kinds, capacities, domains and validity windows. Review classes are defined by registry capacity and kind. `domain_expert` is a registered
  human `external_sme` (D13). A ChatGPT editorial review never substitutes for an external specialist. Entries name a registered author, technical reviewer and editorial reviewer.
- **FR-009, FR-010, FR-029** Approvals and reviews bind to a package digest (entry, classification, full claim and source rows, image rows, actual file hashes, taxon and specimen rows, checklist digests); the
  reviewer's packet is stored and cited by path and SHA-256. A verified source needs an edition, a retrieval date, a hash and known provenance; background and rights-rejected sources cannot back a claim.
- **FR-011** Renderer totality: a non-empty field the layout does not print is refused; a published entry may not carry body text; after each build every promised string is looked up in the PDF text layer
  (`RENDER_FIELD_MISSING`). Release manifests record package digests, ledger heads, policy digests and the approved material known not to be printed.
- **FR-012** Identification evidence: taxon and specimen registers, taxon and specimen links on photographs, one catalogue row per file (hash taken from the file), species plate rules (two distinct target views
  from distinct files, look-alikes never count), determiner authority, one profile per taxon, organism-group domains for identification reviews. An AI illustration needs its label even with blank subject fields.

Added
- Commands `python -m sfe packet` and `python -m sfe ledger seal`; modules `ledger`, `reviewers`, `package`, `classify`, `identification`; schemas `reviewer`, `taxon`, `specimen`, `classification_policy.yaml`.
- 742 tests (611 to 1353) and the 59 probes of the review ported to the new model (`tests/fable_probes.py`); 80 sabotage experiments, each breaking one safeguard in a scratch copy, all detected (`tests/sabotage.py`).
- A fix found while porting probe P08c: a repository with no commits yet is no longer reported as an unreadable ledger history.

Breaking (no data exists to migrate; every register is header-only)
- Ledger columns changed (`reviewer_id` and `capacity` replace `approver`, `reviewer` and the `*_role` columns; `package_sha256` replaces `content_sha256`; `subjects` replaces `topics_reviewed`); entries need
  `authored_by`; `review_policy.class_roles` became `review_policy.classes`; the `sources` schema gained conditional requirements for verified sources and the `assets` and `entries` schemas gained fields. Column-by-column notes: `RUN-003.md` section 7.

Not done, by instruction: no S02 ingestion, no publication, no approval of Gate A, no `main`, no remote, no push, no fabricated approval or specialist.

## Unreleased: Gate A remediation 1 (branch `gate-a/remediation-1`), RUN-002

Fixed (independent review findings; Gate A is NOT approved)
- **GA-001** The safety-audit gate now requires, for each hazard topic and for medical guidance as a whole, a current passing review from BOTH required
  classes: a domain expert (`technical_reviewer` or `external_sme`) and ChatGPT validation (`chatgpt_editorial`). A `user` row never satisfies either.
  The role-to-class policy lives in `schemas/hazard_topics.yaml` (`review_policy`), is validated on every run, and fails closed.
- **GA-002** Deterministic audit precedence: the latest `fail` or `conditional` row (ordered by review date, then record order) supersedes earlier passes
  for that topic; only new passes from every required class restore eligibility. Every topic is evaluated separately.
- Reviews stay bound to the entry revision and content SHA-256.

Added
- Warning `SAFETY_REVIEWERS_NOT_DISTINCT` (same reviewer name in both classes; `--strict` fails on it).
- Toolchain: the documented opt-out for the `epstopdf` shell-escape message, an EPS-proof image-type guard, and one narrow, guarded NOTE classification
  for that exact message. Shell escape stays off; no warning validation is waived in general.
- 162 tests (92 reproductions of the findings, 37 policy, 33 toolchain). Five existing tests that asserted acceptance from a single audit row were
  corrected to supply the two independent reviews.

Unchanged: the submitted baseline (`gate-a-submission`), `handoff/`, the baseline audit, and the dummy specimen proof (byte-identical).

## Unreleased: Gate A scaffold (sprints S00/S01), RUN-001, 2026-11-16

Added
- 16-zone structure (`content/zones.yaml`, `content/Z01_…` to `Z16_…`), generated zone READMEs, `python -m sfe scaffold`.
- JSON Schemas for entries, sources, claims, photo/illustration manifest, approvals, image audits, safety audits, zones and coverage;
  header-only registers; entry templates (general, species, technical procedure, medical).
- Validation and approval gates (status ladder, content-hash-bound approvals, hazard-topic safety audits, image audits), image
  provenance and licensing checks, strict US customary / metric round-trip checking.
- Reproducible pdfLaTeX pipeline (`layouts/sfe.sty`, `scripts/sfe/pdfbuild.py`, `qa.py`) with a fixed build epoch, log gate, poppler QA and
  a build manifest; fail-closed `release` command.
- `proofs/SPECIMEN_LAYOUT_PROOF.pdf`: one clearly labelled dummy specimen (Letter), with manifest, colour and grayscale previews.
- 449 automated tests on throwaway fixture repositories.
- `PROJECT_AUDIT.md`, `BUILD_PLAN.md`, `RUN-001.md`, `GOVERNANCE.md`, `README.md`, `RUN-LOG.md`.

Preserved unchanged: `BASELINE_AUDIT_20261116.md`, everything in `handoff/` (see `PRESERVED_FILES.sha256`).

Not done by design: no survival content, no research, no photographs, no approvals, no zone marked complete, no remote, no push, no
publication.
