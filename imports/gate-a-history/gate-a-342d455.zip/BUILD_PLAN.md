# Build plan

Scope: the production engineering for the Survival Field Encyclopedia (handoff section 11, item 2). It records the toolchain decisions, the
dependencies, the build and test commands, the architecture, and what the Gate A reviewer must decide. It says nothing about content.

## 1. Toolchain decisions

| # | Decision | Choice | Evidence and alternatives |
|---|---|---|---|
| T1 | Typesetting engine | **pdfLaTeX**, TeX Live 2023 (Debian) | A spike built the same page twice in different directories, with different file times and time zones: byte-identical. **LuaLaTeX was tried first and failed**: `module 'luaotfload-main' not found` (the `texlive-luatex` package is not installed). Chrome headless writes a creation date and ID that cannot be fixed. `reportlab`, `weasyprint`, `typst`, `pandoc` and `qpdf` are not installed. Nothing was installed from the network. |
| T2 | Fonts | **TeX Gyre Heros** (text) and **TeX Gyre Cursor** (identifiers), Type 1, from the TeX tree | All fonts are embedded in the PDF (checked). Their file hashes are recorded in every build manifest, so font drift is visible. |
| T3 | Reproducibility | `SOURCE_DATE_EPOCH` fixed in `layouts/build.yaml` (`1794787200`), `FORCE_SOURCE_DATE=1`, `TZ=UTC`, fixed job name, no wall clock anywhere | `make repro` builds twice in unrelated directories and compares SHA-256 and manifests. The epoch is a pipeline setting changed deliberately per release. |
| T4 | Hardening | `--no-shell-escape`, `openin_any=p`, `openout_any=p`, every field passed through a strict escaper | Tests prove a hostile string is printed literally and executes nothing, shell escape is off, and TeX cannot read `/etc/passwd`. A test pins the flags themselves. |
| T5 | PDF QA | **poppler only** (`pdfinfo`, `pdffonts`, `pdftotext -bbox`, `pdftohtml -xml`, `pdftoppm`), run as separate processes | One apt package. PyMuPDF is installed but is AGPL and was not made a dependency. |
| T6 | Structural objects | Written uncompressed (`\pdfobjcompresslevel=0`) | Language, links and viewer preferences can then be audited with plain tools. Streams stay compressed. Cost: a slightly larger file. |
| T7 | Entry format | YAML front matter plus Markdown body, strict loader | Strict: duplicate keys are errors, only `true`/`false` are booleans, dates stay strings. |
| T8 | Registers | CSV (UTF-8, LF, no BOM), column order = schema property order | One source of truth for shape and header. Lists use `\|`. |
| T9 | Gates | Python 3.13, JSON Schema 2020-12 for shape, Python for cross-references and the ladder | Fail closed everywhere: an unparseable file, an unknown id or a stale approval is an error. |
| T10 | Toolchain notes | One documented, guarded allowance: the exact `epstopdf` message "Shell escape feature is not enabled" becomes a **note** (printed, recorded in the manifest, never failing) | Removed at its cause by the graphics driver's documented opt-out (`\DoNotLoadEpstopdf`, first line of every generated `main.tex`); EPS cannot be rendered at all (PNG, JPEG, PDF only); shell escape stays off. Any other warning, including a changed or extended `epstopdf` message, stays a visible warning. See `RUN-002.md`. |

Honest consequences of T1: text is Latin only (T1 encoding with UTF-8 input: fine for English and accented Latin names, no OpenType
features), and **PDFs are untagged** (`Tagged: no`): TeX Live 2023 has no kernel-level tagging. See decision D1.

## 2. Dependencies

Nothing was installed for this project. All of it was already present.

| Kind | Item | Version tested |
|---|---|---|
| System | pdfTeX (`texlive-latex-base`, `-recommended`, `-extra`, `-fonts-recommended`, `-pictures`, `tex-gyre`) | 3.141592653-2.6-1.40.25 (TeX Live 2023/Debian) |
| System | poppler-utils | 26.01.0 |
| System | git, make | 2.43.0, GNU make |
| Python 3.13.0 | PyYAML, jsonschema, Pillow | 6.0.2, 4.19.1, 11.2.1 |
| Python (tests only) | openpyxl, pytest | 3.1.5, 8.2.2 |

## 3. Commands

| Command | Does |
|---|---|
| `make check` | integrity, content gates, specimen gates, all tests, proof build, reproducibility proof |
| `make verify-preserved` | `sha256sum -c` on `PRESERVED_FILES.sha256` and `handoff/SHA256SUMS.txt` |
| `make validate` / `make validate-specimen` | every gate on `content/` and the registers / on the labelled specimen |
| `make test` | the full test suite (`pytest -m gate_a_snapshot` runs only the Gate A baseline guards) |
| `make proof` | rebuild `proofs/SPECIMEN_LAYOUT_PROOF.pdf`, its manifest and previews |
| `make repro` | prove byte-reproducibility |
| `make release` | zone PDFs from `published` entries only into `dist/editions/<ED-id>/` with `ACTIVE_RELEASE.json` and `RELEASE_LOG.csv`. **It must refuse at Gate A.** |
| `python -m sfe release [status\|verify\|withdraw\|reconcile\|recover]` | inspect, verify against current approvals/hashes, withdraw with a usable reason, reconcile/quarantine legacy files, or recover interrupted promotion state |
| `python -m sfe scaffold` | create missing zone directories, generated READMEs and header-only registers; never overwrites hand edits |
| `python -m sfe hash-entry FILE` | print the content hash of an entry's text part (approvals no longer bind to this; they bind to the package digest) |
| `python -m sfe packet ENTRY_ID [--write]` | build the review packet of an entry: what a reviewer is shown and the package digest every decision binds to; `--write` stores it under `reviews/packets/` (never overwrites a different packet) |
| `python -m sfe ledger seal [NAME ...]` | assign `sequence` and `chain_sha256` to rows someone appended to a ledger; sealed rows are never touched |
| `python -m sfe ledger pin [--write PATH]` | verify all ledgers and emit an external `sfe-pin-v1` continuity checkpoint (must be kept outside the repository; passed via `--pin` or `SFE_LEDGER_PIN`) |
| `PYTHONPATH=scripts:tests python3 tests/fable_probes.py TMPDIR [ID ...]` | run the 59 ported Fable probes and print the verdict table |
| `python3 tests/sabotage.py SCRATCH_DIR [ID ...]` | the sensitivity harness: break one safeguard at a time in a scratch copy and require the tests to fail (177 experiments: S01–S80 from RUN-003, S81–S177 from RUN-004) |
| `python -m sfe proof --profile a4` | A4 variant (tested; not committed) |

All commands run with `PYTHONPATH=scripts` (the Makefile sets it).

## 4. Architecture

```
content/*.md + research/*.csv + assets/*.csv + reviews/*.csv + schemas/ + content/zones.yaml
          │
          ▼  validate (scripts/sfe/validate.py, assets.py, units.py, evidence.py, textcheck.py)    any error stops here
 status ladder · cross-references · claim completeness (claim_policy.yaml) · usable safety text (textcheck.py) · unit equivalence
 (table + prose, unit_policy.yaml) · derived classification (classify.py) · reviewer registry & hash-chained ledgers + external
 ledger pin (reviewers.py, ledger.py) · adverse decisions & resolutions · package-bound approvals & reviews (package.py, reviews.py) ·
 identification evidence (identification.py) · controlled licence vocabulary & rights evidence (licenses.yaml) · quarantine hygiene
          │
          ▼  derive.py: deterministic EXIF/GPS/XMP/IPTC/comment/text-stripped publication derivatives (originals read-only, never copied)
          ▼  texgen.py: strict escape + layouts/sfe.sty                      unsupported entry types and unprinted fields refuse to render
 main.tex  ──►  pdflatex (fixed epoch, no shell escape) until aux/out are stable
          │
          ▼  log gate: overflow, undefined reference, dead link target, missing glyph, font substitution = errors
          ▼  qa.py + derive.py: pages, size, title, date, language, fonts embedded, required text, section order, margins,
          │         bookmarks, links/destinations, PDF byte + pdfimages -all metadata check (IMAGE_METADATA_IN_PDF)
          ▼  text-layer check: every string the layout promises is looked up in the PDF (pdftotext -raw)  ──  a miss is RENDER_FIELD_MISSING
          ▼  release.py: atomic promotion into immutable dist/editions/<ED-id>/ (read-only), ACTIVE_RELEASE.json pointer,
          │         hash-chained RELEASE_LOG.csv, crash recovery & auto-withdrawal on invalidation (or proofs/ for specimen)
```

The specimen uses its own registers under `layouts/specimen/` (all ids `DUMMY-…`) so the real registers stay untouched. `release` reads only the
real tree and writes nothing unless every gate passes and at least one entry is `published`.

## 5. Repository layout against handoff section 8

The workspace root `/home/jd/Survival_Guide` plays the role of `survival-field-encyclopedia/`. Everything in the handoff layout exists.
Additions: `schemas/` (machine-readable contracts), `templates/medical_guidance.md` (handoff section 3 gives medical entries their own fields),
`layouts/specimen/`, `PRESERVED_FILES.sha256`, `PROJECT_AUDIT.md`, `BUILD_PLAN.md`, `RUN-001.md`, `GOVERNANCE.md`, `Makefile`, `scripts/sfe/`.
RUN-003 added: `reviews/reviewers.csv` (the registry), `reviews/packets/` and `reviews/evidence/`, `research/taxa.csv`, `assets/specimens.csv`,
`schemas/classification_policy.yaml`, `scripts/sfe/{ledger,reviewers,package,classify,identification}.py`, `RUN-003.md`, `FINDING_REMEDIATION_MATRIX.md`.
RUN-004 added: `schemas/{claim_policy,unit_policy,licenses}.yaml`, `assets/rights/`, `scripts/sfe/{evidence,textcheck,release,derive}.py`, `RUN-004.md`.

## 6. Schema fields added beyond handoff section 3 (for review)

`entry_type` (selects the species, procedure or medical field sets the handoff describes) · `claim_ids` and per-step `claim_ids` (traceability, section 5) ·
per-step `abort_if` (the "error/abort condition", section 10) · `hazard_tags` (section 6 gates) · `as_of_date` (region/legal date stamps) ·
`dimension_unit_table` rows with `claim_id` (US and metric, section 7) · `expert_identification_criteria` ("additional expert criteria", section 10) ·
`specimen` (marks the dummy). Register columns beyond the mandatory ones are listed in each schema's description.
RUN-003 added: entry `authored_by` (a registry id, required from `researched`) and `taxon_id` (species profiles only); asset `taxon_id` and `specimen_id`; the `taxa`, `specimens` and
`reviewers` registers; ledger columns `sequence`, `chain_sha256`, `package_sha256`, `reviewer_id`, `capacity`, `resolves_id`, `resolution_kind`, `packet_*` and `evidence_*` in place of
`content_sha256`, `approver`, `reviewer`, `*_role` and `topics_reviewed`; verified sources need `retrieved_on` and `local_sha256`. Column-by-column migration notes: `RUN-003.md` section 7.
RUN-004 added: optional entry `field_claims` (mapping safety-bearing fields to backing claim ids); asset `rights_evidence_path`, `rights_evidence_sha256` (required when approved) and `rights_granted` (required for `LicenseRef-Permission`). Column-by-column migration notes: `RUN-004.md` section 7.

## 7. Tests

2138 tests (about 1.7 minutes), all on throwaway repositories with neutral "Fixture" text, so no test puts survival content on disk.

| Suite | Proves |
|---|---|
| `test_validation_gates`, `test_hazard_gates`, `test_species_gates` | every rung of the ladder, every handoff-section-6 topic, the species-plate rules, stale approvals and audits |
| `test_claim_completeness`, `test_usable_text` | minimum claims and claim types per entry type, `field_claims` binding, trigger-driven claims (FR-008); non-placeholder safety text and justified `Not applicable [CLM-id]: ...` exception (FR-021) |
| `test_unit_equivalence`, `test_units` | numeric equivalence policy (1% / 5% / 0.5%), fractions, ranges, temperature intervals, prose conversions, property and boundary tests (FR-019) |
| `test_release_state` | active-release manifest, immutable read-only edition archive, atomic promotion, withdrawal/auto-withdrawal, zone removal, crash/fault points, restart recovery, CLI lifecycle (FR-017) |
| `test_image_publication`, `test_licences`, `test_assets` | EXIF/GPS/metadata stripping, orientation transpose, ICC preservation, PDF byte & `pdfimages -all` checks, original access control (FR-014); controlled licence vocabulary, rights evidence, quarantine hygiene (FR-015) |
| `test_ledger_integrity`, `test_ledger_pin`, `test_reviewer_registry` | sequence and chain, calendar and monotonic dates, Git history, external continuity pinning and bare-export truncation detection (FR-003); registry bootstrap, attestation, kinds, capacities, validity, revocation |
| `test_classification`, `test_review_independence`, `test_review_policy`, `test_adverse_decisions` | derived review subjects, capacity-based classes, independence, absorbing failures, resolutions and voids |
| `test_package_binding`, `test_render_totality`, `test_identification_evidence` | package digest and stored packets; renderer totality and PDF text-layer check; taxon, specimen, determiner, plate and duplicate-file rules |
| `test_fable_probes` | the 50 probes of the independent review closed across RUN-003 and RUN-004, each refused for the stated reason from a clean world |
| `test_registers`, `test_zones`, `test_handoff_consistency`, `test_schemas` | source/claim strictness, CSV strictness, structure matching handoff documents, schema/template/hash invariants |
| `test_texgen`, `test_layout_contrast`, `test_pdf_pipeline`, `test_toolchain_compat` | escaping, log gate, QA gates, reproducibility, release pipeline with real images, hardening, contrast ratios, `epstopdf` note |
| `test_preservation`, `test_gate_a_snapshot`, `test_cli` | supplied files unchanged; no content, research, photo or approval exists; fail-closed `release` |

Sensitivity is checked by **sabotage**: break one safeguard at a time in a scratch copy and require the tests to fail (`RUN-002.md`: 10; `RUN-003.md`: 80, S01–S80; `RUN-004.md`: 97 more, S81–S177, reproducible with `tests/sabotage.py`). A safeguard whose removal leaves the suite green was never tested.

## 8. Known limitations (stated plainly)

1. **The gates check evidence and consistency, never truth.** A verified claim is only as good as its reviewer.
2. **Approvals and reviews are attestations in CSV ledgers.** Since RUN-003 they are append-only, sequence-ordered and hash-chained, and only registered identities count, but there is still no cryptographic
   signing: a chain proves the file is internally consistent, not who wrote it, and an editor who recomputes the chain is caught only by Git history.
3. **Image rights are checked as metadata only.** Whether a license is legally sufficient, or a photograph shows the stated species, stays a human review.
4. **No network access was used or implemented.** Online link checking and source retrieval are not built.
5. **Real photographs are untested.** Image embedding was tested with synthetic PNGs; real JPEG and colour-profile handling is unproven.
6. **Layouts exist only for `general` and `technical_procedure`.** Species and medical entries refuse to render (fail closed) until their layouts exist.
7. **Not built yet:** body-text rendering, multi-page flow polish, table of contents, glossary, indexes, cross-references, combined PDF, phone profile, EPUB/HTML, tagged PDF.
8. **Reproducibility holds per toolchain.** Another TeX Live or poppler version may differ; manifests record versions, and the byte-comparison test skips (with the reason) when the toolchain differs.
9. **Reviewer identity is the owner's attestation.** The registry decides who may do what, and a class is defined by registry capacity and kind, never by a typed role; but the registry cannot prove that a
   registered person is who it says, nor that a registered specialist is qualified (a qualification is an evidence reference). Superseded decision D10.
10. **Image audits are gated** by the same registry (RUN-003; resolves OBS-1 and D11): all four checks true, a registered reviewer of the right class and domain, bound to the file hash and the record digest.
11. **Ledger continuity outside Git relies on an external pin (RUN-004).** A hash chain alone cannot detect tail truncation. `python -m sfe ledger pin` emits an external `sfe-pin-v1` anchor kept outside the repository; `release` and `release verify` fail closed (`LEDGER_PIN_REQUIRED`) without one once ledgers hold rows. Rows appended after a pin are unprotected until the owner pins again, and the pin is unsigned (D23).
12. **The classification table is an engineering initial version** (D14). The mechanism is engineering; which zone, claim type or keyword brings which review is a policy decision for ChatGPT and the owner. The keyword triggers are a safety net that a paraphrase evades.
13. **Identification:** hashing detects identical bytes only (no near-duplicate detection); nothing claims that automated analysis establishes what an organism is; the taxon risk tier is a register cell no specialist has attested (D15); the
    plate minimum (two distinct target views from two files) is an engineering reading of a proposed standard, not a specialist's count.
14. **Approved material the layout does not print:** image alt text (release), the claim id of a unit-table row, the `field_claims` mapping (ids are printed in the Claim ids line), and body text (refused for published entries). Each is recorded in every release manifest (`known_unrendered`).
15. **Open findings** of the independent review still open after RUN-004 (FR-013, 016, 018, 020, 023, 024, 025, 026, 027, 028 and the stated residuals of FR-008, FR-009, FR-012, FR-015, FR-017, FR-022) are listed with their evidence in `RUN-004.md` section 9 and `FINDING_REMEDIATION_MATRIX.md` section 15.

## 9. Decisions requested at Gate A

| # | Decision | Recommendation |
|---|---|---|
| D1 | **Accessibility and engine.** PDFs are untagged. Accept for proofs, or approve a spike for tagged output (TeX Live 2025+ kernel tagging, or Typst/WeasyPrint)? Needs an install, so it needs the owner's authorization. | Accept for Gate A; run the spike before S13, with the accessibility gate (tracker `GH`) as the deadline. |
| D2 | Schema additions in §6. | Approve. |
| D3 | **Unit policy:** US and metric values must round-trip in both directions at their displayed precision (`4 in / 100 mm` fails; `4 in / 102 mm` passes). | Approve; relax only by explicit rule. |
| D4 | Directory names for Z02–Z15 (the handoff names only Z01 and Z16). | Approve, or supply names. |
| D5 | **Gate naming:** pick one vocabulary from the three in `PROJECT_AUDIT.md` §3. | Adopt the plan's A0…H2 and update the handoff and tracker. |
| D6 | Which coverage list is authoritative: handoff §2 or the tracker's "Required subtopics". | Handoff §2, with the tracker as a planning aid. |
| D7 | Per-zone "placeholder entries": the gates forbid dummy markers in `content/`. Still wanted? | No; the specimen and templates suffice. |
| D8 | Merge: `gate-a/scaffold` has no `main` to merge into. Creating `main` needs the owner's authorization. | Owner decides after review. |
| D9 | Hazard topics: the six of section 6 plus "every medical entry". Any others to gate? | Approve; ChatGPT may extend the list. |
| D10 | Same reviewer name in both required review classes: warning (now) or error? | **Superseded by RUN-003.** Identity is now a registry id with one kind for ever; a human and an AI model cannot be one identity, duplicate names and conflicting identities are errors, and one identity never fills two classes for one subject. |
| D11 | Image audits accept any reviewer role (OBS-1). Require a ChatGPT editorial or domain-expert audit, as for safety reviews? | **Done in RUN-003**: image audits name a registered reviewer and capacity, need all four checks true and bind to the file hash and the record digest; a diagnostic photograph needs a registered human domain expert holding the organism group's domain. |
| D12 | Precedence after a failure: a failing or conditional audit by ANY role supersedes the earlier passes of BOTH review classes, so both need new passes. A more lenient reading (only the failing class must re-pass) is possible. | **Superseded by RUN-003** (stricter): an unresolved failure blocks until an explicit, evidence-linked resolution row clears it, and passes recorded before the latest adverse row or resolution never count. |
| D13 | `domain_expert` now means a registered **human `external_sme`**. RUN-002 also accepted a `technical_reviewer`. | Keep: a technical reviewer is not a domain specialist, and ChatGPT's editorial review can never stand in for one. The cost: every hazard or classification subject beyond screening needs a registered human specialist before anything can be approved. |
| D14 | `schemas/classification_policy.yaml` (zone rows, allowed types, claim and risk mappings, keyword triggers) is an engineering initial version that errs towards more review. Which zone, claim type or keyword brings which review is a policy decision. | ChatGPT and the owner confirm or amend the table before S02; it is validated on every run, so an amendment is a reviewed diff. |
| D15 | Identification model parameters: the taxon `risk_tier` (A, B, C; any fungus is A) and the specimen `determination_basis` (voucher, physical examination, photographs; photographs alone are not enough for tier A) are an engineering reading of the review's proposed `SPECIES_IDENTIFICATION_STANDARD.md`, which is not adopted; the plate minimum is two distinct target views from two files, not the standard's three captures from two specimens. | A qualified specialist sets the tiers, bases and counts per organism group; until then the tier is an unattested register cell. |
| D16 | Registry bootstrap and attestation: the first row is the owner's and self-attests; every later row is attested by a registrar; a specialist's qualification is an evidence reference that the build cannot verify. | The owner decides who is registered, in which capacity and for which domains, and keeps the registry's Git history reviewed. No registration is created by the build. |
| D17 | Claim policy (`schemas/claim_policy.yaml`): minimum claims, required claim types per entry type, and which safety-bearing fields require which claim types in `field_claims` (FR-008). | Confirm or amend before S02; hard floor of 1 claim stays in code. |
| D18 | Usable-text rule and the sole `Not applicable [CLM-id]: <justification>` exception for step `verify` / `abort_if` (FR-021). | Approve; reviewer judgement still evaluates adequacy. |
| D19 | Unit equivalence policy (`schemas/unit_policy.yaml`: precise 1 %, approximate 5 %, safety 0.5 %) and what counts as safety-critical (FR-019). No medical dosage tolerances are defined. | Confirm or tighten; ceilings (5 / 10 / 2 %) stay in code. |
| D20 | Release custody: who may withdraw an active release, edition retention policy, and where `RELEASE_LOG.csv` is backed up (it lives under git-ignored `dist/`, FR-017). | Owner defines custody and backup before any beta release. |
| D21 | Original photograph storage, read permissions, and the publication derivative recipe (`strip-metadata-reencode-v1`, FR-014 / FR-026). | Owner decides long-term original archive location before S06. |
| D22 | Controlled licence vocabulary (`schemas/licenses.yaml`) and distribution model: currently requires `commercial` use (refusing CC BY-NC licences, FR-015). | Owner confirms commercial vs non-commercial distribution before S06. |
| D23 | External ledger pin custody and cadence (`python -m sfe ledger pin`, kept outside the repo, FR-003). | Owner defines where the external pin is stored and renews it after each ledger batch. |

## 10. Proposed engineering next steps (proposals, not commitments; no content)

- **S02:** a pack-ingest command that validates a ChatGPT pack into the registers; authority-source checks for the water and preservation topics.
- **S03:** body-text rendering, multi-page cards, phone profile; a 12-card pilot layout review.
- **S04:** diagram pipeline from approved specifications only.
- **S06:** species and plate layout, rights-audit report, photo ingest with ICC handling.
- **S13:** table of contents, glossary, indexes, cross-references, combined PDF, coverage report that names incomplete subjects.
- **S15:** print and mobile profiles, accessibility, attribution ledger, release package.
