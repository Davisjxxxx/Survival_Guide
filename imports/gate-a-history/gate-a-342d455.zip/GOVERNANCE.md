# Governance

Source of authority: `handoff/SURVIVAL_FIELD_ENCYCLOPEDIA_ASTRA_CLI_HANDOFF.md` (the handoff) and
`handoff/Survival_Field_Encyclopedia_Master_Sprint_Plan_v1.md` (the plan). Where this file restates them it cites the section.
Where it adds an engineering rule it says so. Rules marked **[gate]** are enforced by code and tested; the rest are procedure.

## Roles (handoff section 0)

| Role | Owns | Never |
|---|---|---|
| ChatGPT (GPT-6 High / Extra High) | Research, claims, source evaluation, wording, species and photo decisions, content approval, final safety sign-off | |
| Build tooling and its operator | Structure, schemas, validation, build automation, asset cataloguing, provenance checks, PDF production, tests, Git records | Invent claims, write safety-critical advice, rewrite approved text, treat an unreviewed AI identification as authoritative |
| Qualified specialists | Positive identification of high-risk fungi and plants, medical, trade and food-preservation review | Be replaced by an AI |
| Owner | Priorities, every gate decision, real-world tests, any publication, merge to `main`, any remote or deployment | |

The ChatGPT research is the editorial source of truth. The build is an implementation artifact, not a scientific authority.

**Authority in a ledger comes only from the reviewer registry** (`reviews/reviewers.csv`, below), never from what a row says about its own author.
A typed name or role string establishes nothing. The registry is the owner's attestation: the first row is the owner's, and every later registration
is attested by an identity the owner made a registrar. The build cannot prove that a registered person is who the registry says; that is the owner's
act, reviewable in Git.

## Non-negotiable rules (handoff sections 0, 4, 5, 6)

1. Never invent survival claims or fill a gap with plausible text. Missing research becomes a `NEEDS_CHAT_RESEARCH` card in `research/unresolved-research.md`.
2. Never substitute a plausible diagram for a verified one. Original diagrams come only from approved briefs. **[gate]** AI-generated images are never photographs and never identification evidence; generated or schematic images of a subject carry `ILLUSTRATION — NOT FOR SPECIES IDENTIFICATION`.
3. Never silently rewrite approved text. **[gate]** An approval is bound to one revision and one **package digest**: the entry and everything its text rests on (the full rows of the
   claims and sources it cites, its images and their files, the specimen and taxon records behind them, and the review checklists). Any later change to any of it makes the approval stale
   and the entry fails closed; a change to something the entry does not rest on changes nothing.
4. Never copy copyrighted text, figures or distinctive structure from commercial guides. Comparator titles are benchmarks only. **[gate]** `benchmark_only` sources can never back a claim.
5. Never treat a PDF as authorised because a third-party site offers it. **[gate]** A mirrored or unknown-provenance source cannot be `permitted` without a recorded permission.
6. Never assume an image is public domain. **[gate]** A bare "free" or "public domain" is rejected as a license; each image needs a specific license or permission, a credit, a recorded human review and a file hash.
7. Photographs alone never establish edibility or identity. **[gate]** A species plate needs at least two distinct views of the profile's own taxon, from two different files, one of them
   `whole` or `key_feature`; each photograph rests on a specimen record whose determination a registered human specialist made; an explicit uncertainty statement and a look-alike review are
   required, and hard-to-identify groups need expert criteria (see Identification evidence).
8. The author never decides what needs review, who may review it, or what a review covers. **[gate]** Required reviews are derived from the zone, the entry type, the claims, the plan and the text
   (declared tags only add); reviewer authority comes from the registry; a review covers exactly the package it was shown; the renderer prints every approved field or the build fails.

## The status ladder **[gate]**

Each status includes every one below it. Nothing advances without the recorded evidence.

| Status | Needs |
|---|---|
| `draft` | Well-formed shape. Ids that are present should resolve (warning only). |
| `researched` | At least one registered source; minimum claim count and required claim types by entry type (`schemas/claim_policy.yaml`: every entry cites at least 1 claim; `technical_procedure` has at least 1 step; `species_profile` cites an `identification` claim; `medical_guidance` cites a `medical` claim and every medical step cites a `medical` claim; non-empty safety-bearing fields are bound in `field_claims`; edibility/identification/medical text triggers require matching claims); every procedure step carries claim ids that resolve; every claim rests on a source the entry lists (and the registers never let a `benchmark_only`, `background` or rights-`rejected` source back a claim); a registered author (`authored_by`). |
| `verified` | All claims and sources `verified`, and each verified source is identifiable (a known edition and revision date, a retrieval date, the hash of the copy that was read, known provenance); a registered technical reviewer who is not the author; every step has an action, a verification check and an abort condition; every mandatory safety and verification field carries usable text (`scripts/sfe/textcheck.py`, not `"N/A"`, `"-"`, or placeholders — only step `verify`/`abort_if` may use `Not applicable [CLM-id]: <justification>` citing a step claim with a substantive justification); entries whose derived subjects go beyond the screening attestation state danger boundaries; type-specific fields (species, procedure, medical) present; unit pairs in tables and prose satisfy the numeric equivalence policy (`schemas/unit_policy.yaml`: 1% precise, 5% explicitly approximate, 0.5% safety-critical; no invented medical dosage tolerances); no placeholder text; cited images carry a compatible licence from `schemas/licenses.yaml`, verified rights evidence under `assets/rights/`, and non-world-writable original permissions; a species profile meets the identification evidence rules. |
| `approved` | A registered editorial reviewer holding the `chatgpt_editorial` capacity; `approved_by_chatgpt: true`; a current editorial approval row in `reviews/approvals.csv` bound to the package digest, with its stored review packet; for **every subject the entry requires** (see Which reviews an entry needs) the independent reviews that subject's definition asks for, each bound to the same digest and sequenced after any adverse decision or resolution; no unresolved adverse decision on the entry or on any cited image; a passing image audit for every cited image (all four checks true, bound to the file hash and the record digest). |
| `published` | As `approved`; every cited image reviewed, captioned and with alt text; **no body text**, because the layout has no section for it yet and the page would drop what was approved. Release builds include **only** `published` entries, require an external ledger continuity pin once any ledger has rows, embed only metadata-stripped derivatives (`scripts/sfe/derive.py`) verified against both PDF bytes and `pdfimages -all`, verify every approved field in the PDF text layer, and promote atomically into an immutable edition archive (`dist/editions/<ED-id>/`) tracked by `ACTIVE_RELEASE.json` and `RELEASE_LOG.csv` (refusing when nothing is published and auto-withdrawing invalidated active editions). |

Zones: `complete` is allowed only when the zone has entries, every one is `published` and no coverage row for it is open.
`approved_cards` must equal the number of approved or published entries.

## Which reviews an entry needs **[gate]**

The author does not choose. `scripts/sfe/classify.py` derives the **review subjects** an entry requires as the union of everything below that applies to it, per
`schemas/classification_policy.yaml` (an engineering initial version, **pending the owner's and ChatGPT's confirmation**, decision D14):

- the zone's own subjects, and the zone-priority floor (every Critical zone needs `CLS-HIGH-RISK`);
- the entry type's subjects (a species profile brings `HZ-FORAGING-ID` and `CLS-IDENTIFICATION`; medical guidance brings `CLS-MEDICAL`);
- the type and risk level of every claim the entry cites;
- the hazard topics and entry type recorded in the coverage plan;
- structural content: species or medical fields, a cited diagnostic photograph, pressure or temperature units;
- keywords in the text (a safety net only: a paraphrase evades it, so nothing depends on it alone);
- the declared `hazard_tags`, which **only add**. Nothing an author writes removes a subject.

When nothing applies, the entry still needs an independent **screening** review (`CLS-SCREENING`): that no hazard class applies is a decision somebody other than the author must attest.
An unknown zone, entry type, claim classification or priority, or an unusable policy, requires **every** subject and is an error. A zone lists its `allowed_types` (zone Z10 takes only
`medical_guidance`; Z05 only `species_profile` or `technical_procedure`), identification content in an identification zone must be a `species_profile`, and species or medical fields on another
type are an error. The six physical fact checks of handoff section 6 (`schemas/hazard_topics.yaml`) and the four classification subjects are all review subjects, each with a checklist the reviewer
confirms. A checklist is a review aid, never publishable text.

## Who may review: the registry **[gate]**

`reviews/reviewers.csv` is an append-only, hash-chained **event log** that says who may author, review, adjudicate and register.

- The first row is the owner's bootstrap (kind `owner`, capacity `registrar`, attested by itself). Every later row is attested by an identity holding an active `registrar` capacity.
- An identity has one **kind** for ever (`human`, `ai_model`, `owner`) and may hold several **capacities**: `author`, `chatgpt_editorial`, `technical_reviewer`, `external_sme`, `adjudicator`, `registrar`.
  A capacity is open only to certain kinds (an `external_sme` must be human; `chatgpt_editorial` must be an AI model), names the **domains** the holder may speak for (review subjects and the
  identification kinds `ID-PLANT`, `ID-FUNGUS`, ...), carries a validity window, and for specialists a reference to the qualification evidence.
- A revocation is retroactive for counting. Conflicting identities, duplicate names and unknown domains are errors, and a row that breaks a rule is granted nothing.
- A **review class** is defined by registry capacity and kind, never by a typed role: `domain_expert` is a registered **human** `external_sme` (decision D13: RUN-002 also accepted a
  `technical_reviewer`); `chatgpt_validation` is a registered AI `chatgpt_editorial`; `independent_screen` is a registered reviewer other than the author; `image_reviewer` audits non-diagnostic images.
  The owner, an adjudicator and the entry's author never satisfy a class, a reviewer never reviews their own entry, and one identity never fills two classes for one subject.
  The minimum classes cannot be configured away: if the policy is invalid, no review is accepted at all.
- A ChatGPT editorial review is an editorial validation. It can never stand in for the external domain expert a subject requires.

## Ledgers **[gate]**

`reviews/approvals.csv`, `reviews/safety-audit.csv`, `reviews/image-audit.csv` and the registry are **append-only, sequence-ordered and hash-chained**: each row carries its sequence number and
`chain_sha256 = SHA-256(previous chain value, this row)`. `python -m sfe ledger seal` assigns both to appended rows and never touches sealed ones. A typed date never decides what came
first: **precedence is by sequence**, and a date that goes backwards is an error. Calendar-impossible dates are errors. A reordered, edited or inserted row breaks the chain at its first
point (`LEDGER_SEQUENCE_BROKEN`, `LEDGER_CHAIN_BROKEN`). In a Git checkout every commit must only append to the previous one (`LEDGER_HISTORY_REWRITTEN`). Because a hash chain alone cannot
detect tail truncation in a bare archive, `python -m sfe ledger pin` emits an external `sfe-pin-v1` continuity checkpoint kept **outside** the repository (pin files inside the repo are refused,
`LEDGER_PIN_INSIDE_REPO`): `release` and `release verify` fail closed (`LEDGER_PIN_REQUIRED`) once any ledger has rows and no external pin is supplied (`--pin` or `SFE_LEDGER_PIN`), and `validate`
warns (`LEDGER_CONTINUITY_UNANCHORED`, an error under `--strict`). Any truncation or prefix rewrite relative to the pin is refused (`LEDGER_PIN_TRUNCATED`, `LEDGER_PIN_REWRITTEN`).

## Adverse decisions **[gate]**

An unresolved `fail` or `conditional` review (a `rejected` or `withdrawn` approval, a failing image audit) **blocks the whole entry, or every entry that cites the image**, whichever subject it
names, whatever revision or hash it carries and whoever recorded it. A later pass does not clear it. Only an explicit **resolution** row clears it, and a resolution must cite an earlier adverse row
of the same entry or asset, an evidence file under `reviews/evidence/` (path and SHA-256 are checked) and a reason. It is recorded by the original reviewer or a registered adjudicator
(`cleared`), or voided by an adjudicator or registrar (`void`, for an orphaned or mistaken row), and **never by the entry's author**. Passes recorded before the latest adverse row or
resolution no longer count, so remediation needs new passes. A row that names an entry or asset that does not exist is an orphan and an error.

## What a review is bound to: the package **[gate]**

An approval or review binds to the **package digest** (`scripts/sfe/package.py`): a canonical JSON closure of the entry front matter, revision and normalised body; the classification (subjects,
reasons and the digest of each subject's definition); the full row of every claim and source it cites; and every cited image's manifest row, its **actual file hash** and its taxon and specimen
rows. `python -m sfe packet ENTRY_ID --write` stores exactly what a reviewer is shown under `reviews/packets/`; a decision cites the packet by path and SHA-256, and the gate re-derives the digest
and compares. A change to the checklist a reviewer confirmed makes earlier reviews stale. Nothing proves that the reviewer read the packet; the packet proves what they were shown.

## Identification evidence **[gate]**

A photograph that claims to identify something rests on a chain of records, each part of the package: a **taxon** (`research/taxa.csv`: accepted name, kind, risk tier), a **specimen**
(`assets/specimens.csv`: observer, date, locality, habitat, and a determination by a registered human `external_sme` who holds the domain `ID-<KIND>`, on a stated basis), the photograph (its
`taxon_id` and `specimen_id`), and the species profile (`taxon_id`; one profile per taxon). The determiner is never the photographer and never the author who cites the image; a tier A taxon
(any fungus is tier A) needs a voucher or a physical examination, not photographs alone. One catalogue row per file, the hash taken **from the file**. A look-alike view must name a different
taxon and never counts toward the minimum. An identification review, and an image audit of a diagnostic photograph, need a reviewer registered for the kind of every taxon shown. AI-generated
imagery is never identification evidence and never a photograph of a specimen. **Stated limits:** hashing detects identical bytes only (re-encoded or cropped copies are not detected); nothing
here claims that automated analysis establishes what an organism is; the risk tier is a register cell that no specialist has yet attested (decision D15).

## What the build proves, and what it does not

The gates prove that the records are complete, consistent, current and sequenced, that each decision was made by someone the owner registered for it, and that what a reviewer saw is what is
published. They do **not** prove that a claim is true, that a registered person is who the registry says, that a reviewer read the packet, that a photograph shows what its determination says, or
that the classification table is what ChatGPT and the owner would choose. Passing tests are evidence of tested behaviour, not of release readiness.

## Change control

- Approved text changes only through a new `revision`, a new approval and a shown diff (handoff section 12).
- Research arrives as ChatGPT-approved packs (files or pasted text). Register sources and claims first, then entries, then run `make check`.
- Reviews, approvals, resolutions and determinations are attestations supplied by registered people and models. The tooling never creates a reviewer, a registration, a review row, an approval, a
  resolution or a determination, and the build never writes a ledger row (`ledger seal` only chains rows that someone else appended).
- Registering a reviewer is an owner act. A specialist's registration names the subjects and identification kinds they may speak for and cites the evidence of their qualification.

## Git and release authority

- Work happens on feature branches. `main` does not exist yet and must not be created or committed to without the owner's explicit authorization.
- No remote, push, deployment, upload or release without the owner's explicit authorization.
- `handoff/` and `BASELINE_AUDIT_20261116.md` are preserved byte-for-byte; `PRESERVED_FILES.sha256` and `tests/test_preservation.py` enforce it.
- Ledgers are append-only in Git as well as in the file (see Ledgers). Do not rewrite, reorder or squash a commit that touched `reviews/`.
- Do not initialise or change any other project.
