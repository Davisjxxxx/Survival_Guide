# Changelog

## Unreleased: Gate A scaffold (sprints S00/S01), RUN-001, 2026-11-16

Added
- 16-zone structure (`content/zones.yaml`, `content/Z01_…` to `Z16_…`), generated zone READMEs, `python -m sfe scaffold`.
- JSON Schemas for entries, sources, claims, photo/illustration manifest, approvals, image audits, safety audits, zones and coverage;
  header-only registers; entry templates (general, species, technical procedure, medical).
- Validation and approval gates (status ladder, content-hash-bound approvals, hazard-topic safety audits, image audits), image
  provenance and licensing checks, strict US customary / metric round-trip checking.
- Reproducible pdfLaTeX pipeline (`layouts/sfe.sty`, `scripts/sfe/pdfbuild.py`, `qa.py`) with a fixed build epoch, log gate, poppler QA and
  a build manifest; fail-closed `release` command.
- `proofs/SPECIMEN_LAYOUT_PROOF.pdf`: one clearly labelled dummy specimen (Letter), with manifest, colour and grayscale previews.
- 449 automated tests on throwaway fixture repositories.
- `PROJECT_AUDIT.md`, `BUILD_PLAN.md`, `RUN-001.md`, `GOVERNANCE.md`, `README.md`, `RUN-LOG.md`.

Preserved unchanged: `BASELINE_AUDIT_20261116.md`, everything in `handoff/` (see `PRESERVED_FILES.sha256`).

Not done by design: no survival content, no research, no photographs, no approvals, no zone marked complete, no remote, no push, no
publication.
