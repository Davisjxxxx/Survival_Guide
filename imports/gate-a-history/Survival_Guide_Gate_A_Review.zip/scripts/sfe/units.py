"""US customary <-> metric round-trip consistency (handoff section 7).

Policy (a decision flagged for Gate A review): a pair is consistent only if it
round-trips in BOTH directions. Converting the US value to metric and rounding to the
metric value's displayed decimals must give exactly the metric value shown, and
converting the metric value to US and rounding to the US decimals must give exactly
the US value shown. So "4 in / 101.6 mm" and "4 in / 102 mm" pass, while "4 in / 100 mm"
and "3.9 in / 100 mm" fail. Arithmetic uses exact decimals (all factors are exact by
definition), so there is no floating-point edge. This checks internal consistency
only; it says nothing about whether the quantity itself is right.
"""
from __future__ import annotations

import re
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation, getcontext

getcontext().prec = 40

# unit -> (dimension, factor to the SI base unit as an exact decimal string, system)
_UNITS: dict[str, tuple[str, str, str]] = {
    "mm": ("length", "0.001", "metric"), "cm": ("length", "0.01", "metric"),
    "m": ("length", "1", "metric"), "km": ("length", "1000", "metric"),
    "in": ("length", "0.0254", "us"), "ft": ("length", "0.3048", "us"),
    "yd": ("length", "0.9144", "us"), "mi": ("length", "1609.344", "us"),
    "g": ("mass", "0.001", "metric"), "kg": ("mass", "1", "metric"),
    "oz": ("mass", "0.028349523125", "us"), "lb": ("mass", "0.45359237", "us"),
    "ml": ("volume", "0.000001", "metric"), "l": ("volume", "0.001", "metric"),
    "fl oz": ("volume", "0.0000295735295625", "us"), "qt": ("volume", "0.000946352946", "us"),
    "gal": ("volume", "0.003785411784", "us"),
    "kpa": ("pressure", "1000", "metric"), "psi": ("pressure", "6894.757293168", "us"),
}
_TEMPERATURE = {"°c": "metric", "°f": "us"}
_KELVIN_OFFSET = Decimal("273.15")
_QUANTITY = re.compile(r"^\s*(-?\d+(?:\.\d+)?)\s*([^\d\s].*?)\s*$")


class UnitError(ValueError):
    """Raised when a quantity string cannot be parsed or its unit is unknown."""


def parse_quantity(text: str) -> tuple[Decimal, int, str]:
    """Return (value, displayed decimals, normalised unit)."""
    match = _QUANTITY.match(text)
    if not match:
        raise UnitError(f"cannot parse quantity {text!r}")
    number, unit = match.group(1), re.sub(r"\s+", " ", match.group(2).strip().lower())
    try:
        value = Decimal(number)
    except InvalidOperation as exc:
        raise UnitError(f"cannot parse number in {text!r}") from exc
    if unit not in _UNITS and unit not in _TEMPERATURE:
        raise UnitError(f"unknown unit {unit!r} in {text!r}")
    return value, max(0, -value.as_tuple().exponent), unit  # type: ignore[operator]


def _to_si(value: Decimal, unit: str) -> Decimal:
    if unit == "°c":
        return value + _KELVIN_OFFSET
    if unit == "°f":
        return (value - 32) * 5 / 9 + _KELVIN_OFFSET
    return value * Decimal(_UNITS[unit][1])


def _from_si(si: Decimal, unit: str) -> Decimal:
    if unit == "°c":
        return si - _KELVIN_OFFSET
    if unit == "°f":
        return (si - _KELVIN_OFFSET) * 9 / 5 + 32
    return si / Decimal(_UNITS[unit][1])


def _round(value: Decimal, decimals: int) -> Decimal:
    return value.quantize(Decimal(1).scaleb(-decimals), rounding=ROUND_HALF_UP)


def _dimension(unit: str) -> str:
    return "temperature" if unit in _TEMPERATURE else _UNITS[unit][0]


def _system(unit: str) -> str:
    return _TEMPERATURE[unit] if unit in _TEMPERATURE else _UNITS[unit][2]


def check_pair(us_text: str, metric_text: str) -> list[str]:
    """Return a list of problems (empty when the pair round-trips in both directions)."""
    try:
        us_val, us_dec, us_unit = parse_quantity(us_text)
        me_val, me_dec, me_unit = parse_quantity(metric_text)
    except UnitError as exc:
        return [str(exc)]
    problems: list[str] = []
    if _system(us_unit) != "us":
        problems.append(f"{us_text!r} is not a US customary unit")
    if _system(me_unit) != "metric":
        problems.append(f"{metric_text!r} is not a metric unit")
    if _dimension(us_unit) != _dimension(me_unit):
        problems.append(f"dimension mismatch: {us_text!r} is {_dimension(us_unit)}, {metric_text!r} is {_dimension(me_unit)}")
    if problems:
        return problems
    forward = _round(_from_si(_to_si(us_val, us_unit), me_unit), me_dec)
    backward = _round(_from_si(_to_si(me_val, me_unit), us_unit), us_dec)
    if forward != me_val:
        problems.append(f"{us_text!r} converts to {forward:f} {me_unit}, not {metric_text!r}")
    if backward != us_val:
        problems.append(f"{metric_text!r} converts to {backward:f} {us_unit}, not {us_text!r}")
    return problems
