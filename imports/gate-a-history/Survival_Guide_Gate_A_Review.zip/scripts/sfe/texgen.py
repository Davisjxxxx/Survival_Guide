"""Entry -> LaTeX. Layout lives in layouts/sfe.sty; this module only fills it.

Safety properties:
  * every value passes through tex_escape(), so entry text can never inject TeX commands;
  * unsupported entry types raise RenderError (fail closed): a layout that silently drops a
    mandatory field (for example a species profile's positive-identification warning) is worse
    than no page at all;
  * a release build never renders a placeholder where an approved image should be.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from .assets import REQUIRED_LABEL

SUPPORTED_TYPES = ("general", "technical_procedure")
# \item followed by text starting with "[" would read it as an optional label; \relax prevents that.
ITEM = r"\item\relax "
_ESCAPES = {
    "\\": r"\textbackslash{}", "{": r"\{", "}": r"\}", "$": r"\$", "&": r"\&", "#": r"\#",
    "^": r"\textasciicircum{}", "_": r"\_", "~": r"\textasciitilde{}", "%": r"\%", "`": r"\textasciigrave{}",
}


class RenderError(ValueError):
    """Raised when an entry cannot be rendered safely."""


def tex_escape(text: str) -> str:
    """Escape arbitrary text for LaTeX. Control characters are rejected, never passed through."""
    collapsed = re.sub(r"[ \t\r\n]+", " ", text.strip())
    if any(ord(ch) < 32 for ch in collapsed):
        raise RenderError("control character in text")
    return "".join(_ESCAPES.get(ch, ch) for ch in collapsed)


def plain(text: str) -> str:
    """ASCII-safe text for PDF metadata and bookmark titles (no TeX tokens survive)."""
    return re.sub(r"\s+", " ", re.sub(r"[^A-Za-z0-9 .,:;()/\-\[\]]", "", text)).strip()


def cmd(name: str, *args: str, opt: str | None = None) -> str:
    head = "\\" + name + (f"[{opt}]" if opt is not None else "")
    return head + "".join("{" + arg + "}" for arg in args)


def env(name: str, body: str, *args: str) -> str:
    return "\\begin{" + name + "}" + "".join("{" + a + "}" for a in args) + body + "\\end{" + name + "}"


def _bullets(values: list[str]) -> str:
    kept = [v for v in values if v.strip()]
    if not kept:
        return r"\textendash{}"
    return env("itemize", "".join(ITEM + tex_escape(v) for v in kept))


def _label_list(pairs: list[tuple[str, str]]) -> str:
    kept = [(label, text) for label, text in pairs if text.strip()]
    if not kept:
        return r"\textendash{}"
    return env("sfeitems", "".join(r"\item[\textbf{" + tex_escape(label) + "}] " + tex_escape(text) for label, text in kept))


def _table_body(header: list[str], rows: list[str]) -> str:
    """booktabs table body. `header` cells and `rows` (each a full row of already-escaped cells joined by &) are
    LaTeX-safe. \\relax separates data rows so a cell that starts with '[' or '*' is never read as an optional
    argument of the row terminator; it is deliberately absent before \\midrule and \\bottomrule, which must follow a
    row end directly."""
    head = " & ".join(r"\textbf{" + cell + "}" for cell in header)
    return (r"\toprule " + head + r"\tabularnewline\midrule\relax "
            + (r"\tabularnewline\relax ").join(rows) + r"\tabularnewline\bottomrule")


@dataclass
class Rendered:
    tex: str
    files: dict[str, Path] = field(default_factory=dict)  # build-dir relative name -> source file
    stats: dict[str, int] = field(default_factory=dict)


def _asset_line(asset: dict[str, Any], proof: bool) -> str:
    parts = [asset["asset_id"], asset["role"].replace("_", " ")]
    if asset.get("view"):
        parts.append(f"view {asset['view']}")
    parts.append(f"license {asset.get('license') or asset['license_status']}")
    credit = asset.get("credited_photographer") or asset.get("organization")
    if credit:
        parts.append(f"credit {credit}")
    if asset.get("provenance_url"):
        parts.append(urlparse(asset["provenance_url"]).hostname or "")
    text = tex_escape(" · ".join(p for p in parts if p))
    caption = tex_escape(asset.get("caption") or "")
    block = r"\textbf{" + text + "}"
    detail = [caption] if caption else []
    if proof and asset.get("alt_text"):
        detail.append(r"\textit{ALT: " + tex_escape(asset["alt_text"]) + "}")
    if detail:
        block += r"\par " + " · ".join(detail)
    return block


def _image_blocks(fm: dict[str, Any], assets: dict[str, dict[str, Any]], *, kind: str, proof: bool,
                  repo_root: Path, files: dict[str, Path]) -> str:
    ids = fm["photo_ids"] if kind == "photo" else fm["illustration_ids"]
    height = ("3.0cm" if len(ids) <= 1 else "2.2cm") if kind == "photo" else "2.4cm"
    blocks: list[str] = []
    for aid in ids:
        asset = assets.get(aid)
        if asset is None:
            raise RenderError(f"{aid} is not in the asset manifest")
        has_file = bool(asset.get("local_path")) and asset["license_status"] == "approved" and (repo_root / asset["local_path"]).is_file()
        label = tex_escape(asset.get("overlay_label") or ("ILLUSTRATION" if kind != "photo" else ""))
        if has_file:
            name = f"img/{aid}{Path(asset['local_path']).suffix.lower()}"
            files[name] = repo_root / asset["local_path"]
            blocks.append(cmd("sfeSlotImage", name, height) if kind == "photo" else cmd("sfeSlotIllusImage", name, height, label))
        elif proof:
            blocks.append(cmd("sfeSlotPhoto", height) if kind == "photo" else cmd("sfeSlotIllus", height, label))
        else:
            raise RenderError(f"{aid}: no approved image file; a release build never renders a placeholder")
        blocks.append(cmd("sfeAssetLine", _asset_line(asset, proof)))
    return "".join(blocks)


def render_entry(fm: dict[str, Any], *, assets: dict[str, dict[str, Any]], sources: dict[str, dict[str, Any]],
                 zone_title: str, proof: bool, repo_root: Path, proof_note: str = "") -> Rendered:
    if fm["entry_type"] not in SUPPORTED_TYPES:
        raise RenderError(f"layout for entry_type {fm['entry_type']!r} is not implemented yet (planned for a later sprint); refusing to render it incompletely")
    eid, steps = fm["id"], fm["procedure"]
    files: dict[str, Path] = {}
    zone_label = "ZXX · SPECIMEN (not a real zone)" if fm.get("specimen") else f"{fm['zone']} · {zone_title}"
    out: list[str] = [
        cmd("sfeAnchor", eid, "top", "Entry: " + plain(fm["title"]), opt="0"),
        cmd("sfeEntryHeader", tex_escape(eid), tex_escape(zone_label), tex_escape(fm["status"].upper()), str(fm["revision"]), tex_escape(fm["title"])),
    ]

    left = (
        cmd("sfeAnchor", eid, "what", "WHAT") + env("sfepanel", r"\textbf{WHAT}\quad " + tex_escape(fm["what_it_is"]))
        + cmd("sfeAnchor", eid, "where", "WHERE") + env("sfesec", tex_escape(fm["find_where"]), "find", "WHERE")
        + cmd("sfeAnchor", eid, "when", "WHEN") + env("sfesec", tex_escape(fm["find_when"]), "find", "WHEN")
    )
    out.append(cmd("sfecols", left, _image_blocks(fm, assets, kind="photo", proof=proof, repo_root=repo_root, files=files)))

    identify = (
        cmd("sfeAnchor", eid, "identify", "IDENTIFY")
        + env("sfesec", _bullets(fm["diagnostic_features"]) + r"\par\textbf{Look-alikes and confusions:}" + _bullets(fm["lookalikes_or_confusions"]), "identify", "IDENTIFY")
    )
    out.append(cmd("sfecols", identify, _image_blocks(fm, assets, kind="illustration", proof=proof, repo_root=repo_root, files=files)))

    tools = fm.get("materials_tools", [])
    materials = cmd("sfeAnchor", eid, "materials", "MATERIALS") + env(
        "sfesec", _bullets(fm["materials"]) + (r"\par\textbf{Tools:}" + _bullets(tools) if tools else ""), "none", "MATERIALS")
    rows = fm.get("dimension_unit_table", [])
    if rows:
        body = [" & ".join((tex_escape(r["quantity"]), tex_escape(r["us_customary"]), tex_escape(r["metric"]))) for r in rows]
        table = env("tabularx", _table_body(["Quantity", "US customary", "Metric"], body), r"\linewidth", "Yll")
        units = cmd("sfeAnchor", eid, "units", "DIMENSIONS") + env("sfesec", r"{\footnotesize " + table + "}", "none", "DIMENSIONS — US CUSTOMARY | METRIC")
    else:
        units = ""
    out.append(cmd("sfecols", materials, units))

    step_items = "".join(ITEM + tex_escape(s["action"]) for s in steps)
    out.append(cmd("sfeAnchor", eid, "steps", "STEPS") + env("sfesec", env("sfeenum", step_items) if steps else r"\textendash{}", "use", "STEPS"))

    check = _label_list([(f"Step {s['step']}", s["verify"]) for s in steps])
    criteria = fm.get("inspection_acceptance_criteria", [])
    if criteria:
        check += r"\par\textbf{Acceptance criteria:}" + _bullets(criteria)
    danger = (
        r"\textbf{\textcolor{sfeAccent}{\sfeicon[sfeAccent]{avoid}\ AVOID}} --- abort if:" + _label_list([(f"Step {s['step']}", s["abort_if"]) for s in steps])
        + r"\par\textbf{\textcolor{sfeAccent}{\sfeicon[sfeAccent]{caution}\ CAUTION}} --- danger boundaries:" + _bullets(fm["dangers"] + fm.get("hazard_boundaries", []))
    )
    modes = fm.get("failure_modes", [])
    if modes:
        danger += r"\par\textbf{Failure modes:}" + _bullets(modes)
    out.append(cmd("sfehalves", cmd("sfeAnchor", eid, "check", "CHECK") + env("sfesec", check, "check", "CHECK"),
                   cmd("sfeAnchor", eid, "danger", "FAILURE / DANGER") + env("sfewarn", danger, "caution", "FAILURE / DANGER")))

    stamp = f"as of {fm['as_of_date']}" if fm.get("as_of_date") else ""
    regional = (
        r"\textbf{Region:} " + tex_escape(", ".join(fm["region"]) or "—") + r"\quad\textbf{Season:} " + tex_escape(", ".join(fm["season"]) or "—")
        + (r"\quad\textbf{Legal/regional status:} " + tex_escape(stamp) if stamp else "")
        + r"\par" + _bullets(fm["conditions_and_limits"])
        + (r"\par\textbf{Environmental constraints:}" + _bullets(fm["environmental_constraints"]) if fm.get("environmental_constraints") else "")
    )
    regional_box = cmd("sfeAnchor", eid, "regional", "REGIONAL / LEGAL LIMITATIONS") + env("sfesec", regional, "none", "REGIONAL / LEGAL LIMITATIONS")

    cited = [sources[s] for s in fm["source_ids"] if s in sources]
    chips = r"\ ".join(cmd("sfeSrcLink", tex_escape(s["source_id"])) for s in cited) or r"\textendash{}"
    claim_ids = tex_escape(", ".join(sorted({c for step in steps for c in step["claim_ids"]} | set(fm["claim_ids"]))) or "—")
    sources_body = r"\textbf{Sources:} " + chips + r"\quad\textbf{Claim ids:} {\ttfamily\footnotesize " + claim_ids + "}"
    sources_box = cmd("sfeAnchor", eid, "sources", "SOURCES") + env("sfesec", sources_body, "source", "SOURCES")
    out.append(cmd("sfehalves", regional_box, sources_box))

    if cited:
        legend = [cmd("sfeLegendRow", tex_escape(s["source_id"]), tex_escape(s["document_title"]), tex_escape(s["rights_status"]),
                      tex_escape(s["verification_status"]), tex_escape(s["intended_use"])) for s in cited]
        out.append(r"{\scriptsize\textbf{SOURCE LEGEND (condensed)}\par"
                   + env("tabularx", _table_body(["ID", "Title", "Rights", "Verification", "Use"], legend), r"\linewidth", "lYlll") + "}")
    if proof_note:
        out.append(env("sfepanel", r"\scriptsize\textbf{PROOF CHECKS (generated by the pipeline):} " + tex_escape(proof_note)))
    out.append(r"\vspace{2pt}\sfeIconKey")
    stats = {"sources": len(cited), "assets": len(fm["photo_ids"]) + len(fm["illustration_ids"]), "steps": len(steps), "unit_pairs": len(rows)}
    return Rendered("\n".join(out), files, stats)


def render_document(body: str, *, paper: str, proof: bool, title: str, author: str, subject: str, keywords: str,
                    footer_left: str, footer_right: str, version: str, banner: str = "") -> str:
    head = [
        r"\documentclass[10pt]{article}",
        rf"\def\sfePaper{{{paper}}}",
        rf"\def\sfeProof{{{1 if proof else 0}}}",
        rf"\def\sfeVersion{{{version}}}",
        rf"\def\sfePdfTitle{{{plain(title)}}}",
        rf"\def\sfePdfAuthor{{{plain(author)}}}",
        rf"\def\sfePdfSubject{{{plain(subject)}}}",
        rf"\def\sfePdfKeywords{{{plain(keywords)}}}",
        rf"\def\sfeFooterLeft{{{tex_escape(footer_left)}}}",
        rf"\def\sfeFooterRight{{{footer_right}}}",
        r"\usepackage{sfe}",
        r"\begin{document}",
    ]
    if banner:
        head.append(cmd("sfeBanner", tex_escape(banner)))
    return "\n".join(head + [body, r"\end{document}", ""])
