"""Command line: `python -m sfe <command>` (run with PYTHONPATH=scripts; see the Makefile).

Exit codes: 0 success, 1 a gate failed (findings printed), 2 usage or environment error.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from . import __version__
from .registry import Repo, scaffold


def _default_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="sfe", description="Survival Field Encyclopedia build tooling (Gate A scaffold)")
    parser.add_argument("--root", type=Path, default=None, help="repository root (default: the checkout containing this script)")
    parser.add_argument("--version", action="version", version=f"sfe {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("scaffold", help="create missing zone directories, zone READMEs and header-only registers")

    validate = sub.add_parser("validate", help="run every content, register and asset gate")
    validate.add_argument("--specimen", action="store_true", help="validate the dummy specimen and its registers instead of content/")
    validate.add_argument("--strict", action="store_true", help="treat warnings as errors")

    proof = sub.add_parser("proof", help="build the labelled dummy specimen PDF")
    proof.add_argument("--profile", choices=("letter", "a4"), default="letter")
    proof.add_argument("--out-dir", type=Path, default=None, help="output directory (default: proofs/)")
    proof.add_argument("--no-previews", action="store_true", help="skip the colour and grayscale PNG previews")

    sub.add_parser("repro", help="build the specimen twice in different directories and compare SHA-256")
    sub.add_parser("release", help="build zone PDFs from PUBLISHED entries only (fails closed when there are none)")

    hash_entry = sub.add_parser("hash-entry", help="print the approval content hash of an entry file")
    hash_entry.add_argument("path", type=Path)
    return parser


def _print_findings(findings) -> tuple[int, int]:
    for finding in findings:
        print(finding)
    errors = sum(1 for f in findings if f.severity == "error")
    return errors, len(findings) - errors


def main(argv: list[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    root = (args.root or _default_root()).resolve()
    repo = Repo(root)

    if args.command == "scaffold":
        try:
            for action in scaffold(repo):
                print(action)
        except RuntimeError as exc:
            print(exc, file=sys.stderr)
            return 1
        print("scaffold: done")
        return 0

    if args.command == "validate":
        from .validate import validate_repo

        errors, warnings = _print_findings(validate_repo(root, specimen=args.specimen))
        mode = "specimen" if args.specimen else "content"
        print(f"validate[{mode}]: {errors} error(s), {warnings} warning(s)")
        return 1 if errors or (args.strict and warnings) else 0

    if args.command == "hash-entry":
        from .entries import EntryParseError, content_sha256, parse_entry

        try:
            fm, body = parse_entry(args.path.read_bytes())
        except (EntryParseError, OSError) as exc:
            print(f"hash-entry: {exc}", file=sys.stderr)
            return 2
        print(content_sha256(fm, body))
        return 0

    from . import pdfbuild  # deferred: needs pdflatex and poppler

    try:
        if args.command == "proof":
            result = pdfbuild.build_proof(repo, profile=args.profile, out_dir=args.out_dir, previews=not args.no_previews)
            errors, warnings = _print_findings(result.findings)
            print(f"proof[{args.profile}]: {'OK' if result.ok else 'FAILED'} ({errors} error(s), {warnings} warning(s))")
            if result.pdf:
                print(f"  pdf    {result.pdf}\n  sha256 {result.sha256}")
            return 0 if result.ok else 1
        if args.command == "repro":
            ok, detail = pdfbuild.check_reproducible(repo)
            print(detail)
            return 0 if ok else 1
        if args.command == "release":
            result = pdfbuild.build_release(repo)
            errors, warnings = _print_findings(result.findings)
            print(f"release: {'OK' if result.ok else 'REFUSED'} ({errors} error(s), {warnings} warning(s)); {len(result.pdfs)} PDF(s) written")
            for pdf in result.pdfs:
                print(f"  {pdf}")
            return 0 if result.ok else 1
    except pdfbuild.ToolchainError as exc:
        print(f"toolchain error: {exc}", file=sys.stderr)
        return 2
    return 2
