"""Content validation and approval gates (handoff section 10).

validate_repo() runs every gate and returns findings; errors fail closed.

Status ladder (each rung includes every rung below it):
    draft       well-formed shape; ids resolve where present (warning only)
    researched  sources and claims registered and cited; procedure steps traceable
    verified    claims and sources verified; technical review; steps complete; hazard,
                species, procedure and medical rules; no placeholder text
    approved    editorial review; ChatGPT approval bound to the exact content hash;
                safety audit for hazardous entries; image audits for cited images
    published   all cited assets reviewed with caption and alt text

Nothing here decides whether content is *true*. It only refuses to let content
advance without the recorded evidence that handoff section 10 demands.
"""
from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterator

from jsonschema import Draft202012Validator

from . import assets as assets_mod
from . import units as units_mod
from .common import Finding, err, sha256_file, warn
from .entries import Entry, EntryParseError, iter_entry_paths, load_entry
from .registry import (
    REGISTERS, SPECIMEN_REGISTERS, Repo, _format_error, load_hazards, load_register, load_zones,
)

RANK = {"draft": 0, "researched": 1, "verified": 2, "approved": 3, "published": 4}
PLACEHOLDER_RE = re.compile(
    r"\bDUMMY\b|\bTBD\b|\bTODO\b|\bPLACEHOLDER\b|\bUNVERIFIED\b|NEEDS_CHAT_RESEARCH"
    r"|example\.invalid|lorem ipsum|\{\{.*?\}\}",
    re.IGNORECASE,
)
DUMMY_RE = re.compile(r"\bDUMMY\b")
SPECIMEN_ENTRY = "layouts/specimen/specimen_entry.md"
PROSE_FIELDS = (
    "title", "what_it_is", "find_where", "find_when", "diagnostic_features", "lookalikes_or_confusions",
    "materials", "conditions_and_limits", "dangers", "materials_tools", "environmental_constraints",
    "inspection_acceptance_criteria", "failure_modes", "hazard_boundaries",
)


@dataclass
class Context:
    repo: Repo
    specimen: bool
    zones: list[dict[str, Any]]
    hazards: dict[str, dict[str, Any]]
    reg: dict[str, list[dict[str, Any]]]
    labels: dict[str, str]
    entries: list[Entry]
    sources: dict[str, dict[str, Any]] = field(default_factory=dict)
    claims: dict[str, dict[str, Any]] = field(default_factory=dict)
    assets: dict[str, dict[str, Any]] = field(default_factory=dict)


# ------------------------------------------------------------------ small helpers
def nonempty(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, str):
        return bool(value.strip())
    if isinstance(value, list):
        return any(nonempty(item) for item in value)
    return True


def walk_strings(value: Any, path: str = "") -> Iterator[tuple[str, str]]:
    if isinstance(value, str):
        yield path, value
    elif isinstance(value, dict):
        for key, item in value.items():
            yield from walk_strings(item, f"{path}.{key}" if path else str(key))
    elif isinstance(value, list):
        for index, item in enumerate(value):
            yield from walk_strings(item, f"{path}[{index}]")


def _latest(rows: list[dict[str, Any]], date_key: str) -> dict[str, Any]:
    return max(rows, key=lambda r: (r[date_key], r["_row"]))


# --------------------------------------------------------------------- entry points
def validate_repo(root: Path | str, *, specimen: bool = False) -> list[Finding]:
    ctx, findings = build_context(root, specimen=specimen)
    return sorted(set(findings + run_gates(ctx)))


def build_context(root: Path | str, *, specimen: bool = False) -> tuple[Context, list[Finding]]:
    """Load zones, hazards, registers and entries. Returns the context plus load-time findings."""
    repo = Repo(root)
    findings: list[Finding] = []
    zones, found = load_zones(repo)
    findings += found
    hazards, found = load_hazards(repo)
    findings += found

    reg: dict[str, list[dict[str, Any]]] = {}
    labels: dict[str, str] = {}
    for name, (rel, _schema, _key) in REGISTERS.items():
        if specimen and name not in SPECIMEN_REGISTERS:
            reg[name], labels[name] = [], f"(not used in specimen mode) {rel}"
            continue
        use = SPECIMEN_REGISTERS[name] if specimen else rel
        rows, found = load_register(repo, name, use)
        reg[name], labels[name] = rows, use
        findings += found

    entries, found = _load_specimen_entry(repo) if specimen else _discover_entries(repo, zones)
    findings += found

    ctx = Context(repo, specimen, zones, hazards, reg, labels, entries)
    ctx.sources = {r["source_id"]: r for r in reg["sources"]}
    ctx.claims = {r["claim_id"]: r for r in reg["claims"]}
    ctx.assets = {r["asset_id"]: r for r in reg["assets"]}
    return ctx, findings


def run_gates(ctx: Context) -> list[Finding]:
    """Run every gate over an already-loaded context."""
    findings = _check_register_rules(ctx)
    findings += assets_mod.check_assets(ctx.repo, ctx.reg["assets"], label=ctx.labels["assets"], specimen=ctx.specimen)
    validator = Draft202012Validator(ctx.repo.schema("entry.schema.json"))
    id_counts = Counter(e.entry_id for e in ctx.entries)
    for entry in ctx.entries:
        findings += _check_entry(ctx, entry, validator, id_counts)
    if ctx.specimen:
        findings += _check_specimen(ctx)
    else:
        findings += _check_zones(ctx)
        findings += _check_content_tree(ctx)
    return findings


def _discover_entries(repo: Repo, zones: list[dict[str, Any]]) -> tuple[list[Entry], list[Finding]]:
    entries: list[Entry] = []
    findings: list[Finding] = []
    for path in iter_entry_paths(repo.path("content"), [z["dir"] for z in zones]):
        try:
            entries.append(load_entry(path, repo.root))
        except EntryParseError as exc:
            findings.append(err("ENTRY_PARSE", path.relative_to(repo.root).as_posix(), str(exc)))
    return entries, findings


def _load_specimen_entry(repo: Repo) -> tuple[list[Entry], list[Finding]]:
    path = repo.path(SPECIMEN_ENTRY)
    if not path.is_file():
        return [], [err("SPECIMEN_MISSING", SPECIMEN_ENTRY, "specimen entry is missing")]
    try:
        return [load_entry(path, repo.root)], []
    except EntryParseError as exc:
        return [], [err("ENTRY_PARSE", SPECIMEN_ENTRY, str(exc))]


# ------------------------------------------------------------------ register rules
def _check_register_rules(ctx: Context) -> list[Finding]:
    found: list[Finding] = []
    labels = ctx.labels
    for name, key in (("sources", "source_id"), ("claims", "claim_id"), ("assets", "asset_id")):
        for row in ctx.reg[name]:
            where = f"{labels[name]}:row {row['_row']}"
            is_dummy = str(row[key]).startswith("DUMMY-")
            if ctx.specimen and not is_dummy:
                found.append(err("SPECIMEN_REGISTER_ID_NOT_DUMMY", where, f"{row[key]} must start with DUMMY- in specimen registers"))
            if not ctx.specimen and is_dummy:
                found.append(err("DUMMY_ID_IN_REAL_REGISTER", where, f"{row[key]}: dummy ids are never allowed in the real registers"))

    for row in ctx.reg["sources"]:
        where = f"{labels['sources']}:row {row['_row']}"
        if row["rights_status"] == "permitted":
            if row["provenance_class"] in ("third_party_mirror", "unknown") and not row.get("permission_reference"):
                found.append(err("RIGHTS_PERMITTED_WITHOUT_PROVENANCE", where, "a source on a third-party mirror or of unknown provenance cannot be 'permitted' without a permission_reference"))
            if row["access_usage_rights"].strip().upper() == "UNKNOWN":
                found.append(err("RIGHTS_PERMITTED_UNKNOWN_TERMS", where, "rights_status 'permitted' needs stated access/usage terms, not UNKNOWN"))
        origin = row["url_or_local_origin"]
        if origin.lower().startswith(("http://", "https://")):
            if not assets_mod.valid_http_url(origin):
                found.append(err("SOURCE_URL_INVALID", where, f"{origin!r} is not a valid http(s) URL"))
            elif not ctx.specimen and re.search(r"\.invalid(/|$)|//example\.", origin):
                found.append(err("SOURCE_URL_PLACEHOLDER", where, "placeholder URL in the real source register"))
        copy = row.get("local_copy_path")
        if copy:
            if not assets_mod.safe_relative_path(copy):
                found.append(err("SOURCE_LOCAL_COPY_UNSAFE", where, f"local_copy_path {copy!r} must be relative with no '..'"))
            elif not ctx.repo.path(copy).is_file():
                found.append(err("SOURCE_LOCAL_COPY_MISSING", where, f"{copy} does not exist"))
            elif not row.get("local_sha256"):
                found.append(err("SOURCE_LOCAL_COPY_UNHASHED", where, "a local copy needs local_sha256"))
            elif sha256_file(ctx.repo.path(copy)) != row["local_sha256"]:
                found.append(err("SOURCE_LOCAL_COPY_MISMATCH", where, "local copy does not match local_sha256"))

    for row in ctx.reg["claims"]:
        where = f"{labels['claims']}:row {row['_row']}"
        source = ctx.sources.get(row["source_id"])
        if source is None:
            found.append(err("CLAIM_SOURCE_UNKNOWN", where, f"source {row['source_id']} is not in the source register"))
            continue
        if source["intended_use"] == "benchmark_only":
            found.append(err("BENCHMARK_SOURCE_CITED", where, "benchmark-only sources may never back a claim (handoff section 5)"))
        if row["status"] == "verified" and source["verification_status"] != "verified":
            found.append(err("CLAIM_VERIFIED_ON_UNVERIFIED_SOURCE", where, "a verified claim needs a verified source"))
    return found


# ----------------------------------------------------------------------- one entry
def _check_entry(ctx: Context, entry: Entry, validator: Draft202012Validator, ids: Counter) -> list[Finding]:
    fm, where = entry.fm, entry.rel
    found = [err("ENTRY_SCHEMA", where, _format_error(e))
             for e in sorted(validator.iter_errors(fm), key=lambda e: list(e.absolute_path))]
    if found:
        return found  # later gates assume a well-formed shape
    eid, zone, rank = fm["id"], fm["zone"], RANK[fm["status"]]

    if ids[eid] > 1:
        found.append(err("ENTRY_ID_DUPLICATE", where, f"id {eid} is used by more than one entry"))
    if not ctx.specimen:
        zone_dir = next((z["dir"] for z in ctx.zones if z["id"] == zone), None)
        if entry.path.stem != eid:
            found.append(err("ENTRY_FILENAME_MISMATCH", where, f"file name must be {eid}.md"))
        if zone_dir is None or entry.path.parent.name != zone_dir:
            found.append(err("ENTRY_WRONG_ZONE_DIR", where, f"zone {zone} entries belong in content/{zone_dir}/"))
        if not eid.startswith(zone + "-"):
            found.append(err("ENTRY_ID_ZONE_MISMATCH", where, f"id {eid} must start with {zone}-"))
        if fm.get("specimen"):
            found.append(err("SPECIMEN_IN_CONTENT", where, "specimen entries may only live under layouts/specimen/"))
        for path, text in walk_strings({**fm, "body": entry.body}):
            if DUMMY_RE.search(text):
                found.append(err("DUMMY_MARKER_IN_REAL_CONTENT", where, f"dummy marker in {path}"))
                break

    for tag in fm["hazard_tags"]:
        if tag not in ctx.hazards:
            found.append(err("HAZARD_TAG_UNKNOWN", where, f"{tag} is not defined in schemas/hazard_topics.yaml"))
    if fm["approved_by_chatgpt"] and rank < RANK["approved"]:
        found.append(err("APPROVED_FLAG_BELOW_APPROVED", where, "approved_by_chatgpt may be true only at status approved or published"))
    if rank >= RANK["approved"] and not fm["approved_by_chatgpt"]:
        found.append(err("APPROVED_STATUS_WITHOUT_FLAG", where, "status approved/published requires approved_by_chatgpt: true"))

    found += _check_references(ctx, entry, strict=rank >= 1 or ctx.specimen)
    found += _check_units(ctx, entry, require_claims=rank >= 1)
    if rank >= RANK["researched"]:
        found += _gate_researched(ctx, entry)
    if rank >= RANK["verified"]:
        found += _gate_verified(ctx, entry)
    if rank >= RANK["approved"]:
        found += _gate_approved(ctx, entry)
    if rank >= RANK["published"]:
        found += _gate_published(ctx, entry)
    return found


def _claim_ids_of(fm: dict[str, Any]) -> set[str]:
    ids = set(fm["claim_ids"])
    for step in fm["procedure"]:
        ids.update(step["claim_ids"])
    ids.update(row["claim_id"] for row in fm.get("dimension_unit_table", []) if row["claim_id"])
    return ids


def _check_references(ctx: Context, entry: Entry, *, strict: bool) -> list[Finding]:
    """Ids that are present must resolve and have the right kind (warning for early drafts)."""
    make = err if strict else warn
    fm, where, found = entry.fm, entry.rel, []
    for sid in fm["source_ids"]:
        if sid not in ctx.sources:
            found.append(make("SOURCE_NOT_REGISTERED", where, f"{sid} is not in the source register"))
    for cid in sorted(_claim_ids_of(fm)):
        claim = ctx.claims.get(cid)
        if claim is None:
            found.append(make("CLAIM_NOT_REGISTERED", where, f"{cid} is not in the claim register"))
        elif claim["source_id"] not in fm["source_ids"]:
            found.append(make("CLAIM_SOURCE_NOT_CITED", where, f"claim {cid} rests on {claim['source_id']}, which this entry does not list in source_ids"))
    for field_name, kinds in (("photo_ids", ("photo",)), ("illustration_ids", ("illustration", "diagram"))):
        for aid in fm[field_name]:
            asset = ctx.assets.get(aid)
            if asset is None:
                found.append(make("ASSET_NOT_REGISTERED", where, f"{aid} is not in the asset manifest"))
            elif asset["asset_kind"] not in kinds:
                found.append(make("ASSET_KIND_MISMATCH", where, f"{aid} is a {asset['asset_kind']} but is listed in {field_name}"))
            elif asset["license_status"] == "rejected":
                found.append(err("ASSET_REJECTED_CITED", where, f"{aid} has a rejected license and may not be cited"))
    return found


def _check_units(ctx: Context, entry: Entry, *, require_claims: bool) -> list[Finding]:
    found: list[Finding] = []
    for index, row in enumerate(entry.fm.get("dimension_unit_table", []), start=1):
        where = f"{entry.rel} dimension_unit_table[{index}]"
        if not (row["us_customary"].strip() and row["metric"].strip()):
            if require_claims:
                found.append(err("UNIT_ROW_INCOMPLETE", where, "both US customary and metric values are required"))
            continue
        for problem in units_mod.check_pair(row["us_customary"], row["metric"]):
            found.append(err("UNIT_INCONSISTENT", where, problem))
        if require_claims and not row["claim_id"]:
            found.append(err("UNCITED_SPECIFICATION", where, "every specification needs a claim_id"))
    return found


def _gate_researched(ctx: Context, entry: Entry) -> list[Finding]:
    fm, where, found = entry.fm, entry.rel, []
    if not fm["source_ids"]:
        found.append(err("SOURCE_IDS_EMPTY", where, "researched entries must cite at least one source"))
    for sid in fm["source_ids"]:
        source = ctx.sources.get(sid)
        if source and source["intended_use"] == "benchmark_only":
            found.append(err("BENCHMARK_SOURCE_CITED", where, f"{sid} is benchmark-only and cannot be cited"))
    numbers = [step["step"] for step in fm["procedure"]]
    if numbers != list(range(1, len(numbers) + 1)):
        found.append(err("STEP_NUMBERING", where, "procedure steps must be numbered 1..n in order"))
    for step in fm["procedure"]:
        if not step["claim_ids"]:
            found.append(err("STEP_WITHOUT_CLAIM", where, f"step {step['step']} has no claim_ids (every actionable step must be traceable)"))
    return found


def _is_hazardous(fm: dict[str, Any]) -> bool:
    return bool(fm["hazard_tags"]) or fm["entry_type"] == "medical_guidance"


def _gate_verified(ctx: Context, entry: Entry) -> list[Finding]:
    fm, where, found = entry.fm, entry.rel, []
    for cid in sorted(_claim_ids_of(fm)):
        claim = ctx.claims.get(cid)
        if claim and claim["status"] != "verified":
            found.append(err("CLAIM_NOT_VERIFIED", where, f"claim {cid} is {claim['status']}; UNVERIFIED claims are excluded from publishable output"))
    for sid in fm["source_ids"]:
        source = ctx.sources.get(sid)
        if source and source["verification_status"] != "verified":
            found.append(err("SOURCE_NOT_VERIFIED", where, f"source {sid} is {source['verification_status']}"))
    if not nonempty(fm["technical_reviewer"]):
        found.append(err("TECHNICAL_REVIEWER_MISSING", where, "verified entries need a named technical_reviewer"))
    for step in fm["procedure"]:
        for key in ("action", "verify", "abort_if"):
            if not nonempty(step[key]):
                found.append(err("STEP_INCOMPLETE", where, f"step {step['step']} needs a non-empty {key} (step + verification + abort condition)"))
    if _is_hazardous(fm) and not nonempty(fm["dangers"]):
        found.append(err("DANGER_BOUNDARY_MISSING", where, "hazardous entries must state danger boundaries in 'dangers'"))
    if "HZ-HARVEST-LEGAL" in fm["hazard_tags"] and not (nonempty(fm["region"]) and nonempty(fm.get("as_of_date"))):
        found.append(err("LEGAL_REGION_DATE_MISSING", where, "legal/harvest entries need region and an as_of_date stamp"))
    for path, text in walk_strings({**fm, "body": entry.body}):
        if PLACEHOLDER_RE.search(text):
            found.append(err("PLACEHOLDER_IN_VERIFIED_CONTENT", where, f"placeholder or unverified marker in {path}"))
            break
    for aid in fm["photo_ids"] + fm["illustration_ids"]:
        asset = ctx.assets.get(aid)
        if asset and asset["license_status"] != "approved":
            found.append(err("ASSET_LICENSE_NOT_APPROVED", where, f"{aid} license_status is {asset['license_status']}"))
    entry_type = fm["entry_type"]
    if entry_type == "species_profile":
        found += _species_rules(ctx, entry)
    elif entry_type == "technical_procedure":
        for key in ("materials_tools", "inspection_acceptance_criteria", "failure_modes", "hazard_boundaries", "environmental_constraints"):
            if not nonempty(fm[key]):
                found.append(err("PROCEDURE_FIELD_EMPTY", where, f"technical procedures need a non-empty {key}"))
    elif entry_type == "medical_guidance":
        for key in ("audience_scope", "evidence_date", "emergency_evacuation_threshold", "local_emergency_service_guidance"):
            if not nonempty(fm[key]):
                found.append(err("MEDICAL_FIELD_EMPTY", where, f"medical guidance needs a non-empty {key}"))
        if not nonempty(fm["contraindications"]):
            found.append(err("MEDICAL_FIELD_EMPTY", where, "medical guidance needs contraindications"))
    return found


def _species_rules(ctx: Context, entry: Entry) -> list[Finding]:
    fm, where, found = entry.fm, entry.rel, []
    for key in ("scientific_name", "geographic_range", "phenology", "identification_uncertainty",
                "regulated_or_protected_status", "processing_restrictions", "positive_identification_warning"):
        if not nonempty(fm[key]):
            found.append(err("SPECIES_FIELD_EMPTY", where, f"species profiles need a non-empty {key}"))
    if not nonempty(fm["lookalikes_or_confusions"]):
        found.append(err("SPECIES_LOOKALIKES_MISSING", where, "species profiles need an explicit look-alike review"))
    diagnostic = [ctx.assets[a] for a in fm["photo_ids"] if a in ctx.assets and ctx.assets[a]["role"] == "verified_diagnostic"]
    views = {a["view"] for a in diagnostic if a.get("view")}
    if len(diagnostic) < 2 or len(views) < 2:
        found.append(err("SPECIES_PLATE_VIEWS", where, "an identification plate needs at least two complementary verified diagnostic views"))
    if "HZ-FORAGING-ID" in fm["hazard_tags"] and not nonempty(fm["expert_identification_criteria"]):
        found.append(err("SPECIES_EXPERT_CRITERIA_MISSING", where, "hard-to-identify groups need expert identification criteria; photo count never substitutes for expertise"))
    return found


def _gate_approved(ctx: Context, entry: Entry) -> list[Finding]:
    fm, where, found = entry.fm, entry.rel, []
    eid, revision, current = fm["id"], fm["revision"], entry.content_hash
    if not nonempty(fm["editorial_reviewer"]):
        found.append(err("EDITORIAL_REVIEWER_MISSING", where, "approved entries need a named editorial_reviewer"))

    rows = [r for r in ctx.reg["approvals"] if r["entry_id"] == eid and r["revision"] == revision]
    if not rows:
        found.append(err("APPROVAL_MISSING", where, f"no row in reviews/approvals.csv for {eid} revision {revision}"))
    else:
        last = _latest(rows, "decided_on")
        if last["decision"] != "approved":
            found.append(err("APPROVAL_NOT_CURRENT", where, f"latest approval decision is {last['decision']!r}"))
        elif last["content_sha256"] != current:
            found.append(err("APPROVAL_STALE", where, "entry content changed after approval; a new approval row is required"))
        if not any(r["decision"] == "approved" and r["approver_role"] == "chatgpt_editorial" and r["content_sha256"] == current for r in rows):
            found.append(err("APPROVAL_NOT_CHATGPT_EDITORIAL", where, "approved_by_chatgpt needs a current chatgpt_editorial approval row"))

    if _is_hazardous(fm):
        safety = [r for r in ctx.reg["safety_audit"] if r["entry_id"] == eid and r["revision"] == revision]
        passing = [r for r in safety if r["decision"] == "pass" and r["content_sha256"] == current]
        if not safety:
            found.append(err("SAFETY_AUDIT_MISSING", where, "hazardous entries need a row in reviews/safety-audit.csv"))
        elif not passing:
            found.append(err("SAFETY_AUDIT_NOT_PASSING_OR_STALE", where, "no passing safety audit matches the current content hash"))
        else:
            covered = {topic for r in passing for topic in r["topics_reviewed"]}
            for tag in fm["hazard_tags"]:
                if tag not in covered:
                    found.append(err("SAFETY_TOPIC_UNCOVERED", where, f"safety audit does not cover {tag}"))

    for aid in fm["photo_ids"] + fm["illustration_ids"]:
        asset = ctx.assets.get(aid)
        if not asset or not asset.get("sha256"):
            found.append(err("ASSET_NOT_PUBLISHABLE", where, f"{aid} has no catalogued file hash"))
            continue
        audits = [r for r in ctx.reg["image_audit"] if r["asset_id"] == aid]
        if not audits:
            found.append(err("IMAGE_AUDIT_MISSING", where, f"no image audit for {aid}"))
        else:
            last = _latest(audits, "reviewed_on")
            if last["decision"] != "pass":
                found.append(err("IMAGE_AUDIT_NOT_PASSING", where, f"latest image audit for {aid} is {last['decision']!r}"))
            elif last["asset_sha256"] != asset["sha256"]:
                found.append(err("IMAGE_AUDIT_STALE", where, f"image audit for {aid} does not match the current file hash"))
    return found


def _gate_published(ctx: Context, entry: Entry) -> list[Finding]:
    fm, where, found = entry.fm, entry.rel, []
    for aid in fm["photo_ids"] + fm["illustration_ids"]:
        asset = ctx.assets.get(aid)
        if not asset:
            continue
        if asset["review_status"] != "approved":
            found.append(err("ASSET_REVIEW_NOT_APPROVED", where, f"{aid} review_status is {asset['review_status']}"))
        if not nonempty(asset.get("caption")):
            found.append(err("ASSET_CAPTION_MISSING", where, f"{aid} has no caption"))
        if not nonempty(asset.get("alt_text")):
            found.append(err("ASSET_ALT_TEXT_MISSING", where, f"{aid} has no alt text"))
    return found


# --------------------------------------------------------------------- zones, tree
def _check_zones(ctx: Context) -> list[Finding]:
    found: list[Finding] = []
    for zone in ctx.zones:
        where = f"content/zones.yaml:{zone['id']}"
        members = [e for e in ctx.entries if e.fm.get("zone") == zone["id"] and isinstance(e.fm.get("status"), str)]
        ranked = [RANK.get(e.fm["status"], 0) for e in members]
        approved = sum(1 for r in ranked if r >= RANK["approved"])
        if zone["approved_cards"] != approved:
            found.append(err("ZONE_APPROVED_COUNT", where, f"approved_cards is {zone['approved_cards']} but {approved} entries are approved or published"))
        if zone["status"] == "complete":
            if not members:
                found.append(err("ZONE_COMPLETE_WITHOUT_ENTRIES", where, "a zone cannot be complete without entries"))
            elif any(r < RANK["published"] for r in ranked):
                found.append(err("ZONE_COMPLETE_WITH_UNPUBLISHED", where, "a complete zone must have every entry published"))
            if any(r["zone_id"] == zone["id"] and r["status"] != "published" for r in ctx.reg["coverage"]):
                found.append(err("ZONE_COMPLETE_COVERAGE_OPEN", where, "coverage-matrix still has unpublished topics for this zone"))
        elif zone["status"] == "not_started" and members:
            found.append(warn("ZONE_STATUS_STALE", where, "zone has entries but is still marked not_started"))
    return found


def _check_content_tree(ctx: Context) -> list[Finding]:
    found: list[Finding] = []
    content = ctx.repo.path("content")
    zone_dirs = {z["dir"] for z in ctx.zones}
    if not content.is_dir():
        return [err("CONTENT_MISSING", "content", "content directory is missing")]
    for child in sorted(content.iterdir()):
        rel = child.relative_to(ctx.repo.root).as_posix()
        if child.is_dir() and child.name not in zone_dirs:
            found.append(warn("CONTENT_UNEXPECTED_PATH", rel, "directory is not a registered zone"))
        elif child.is_file() and child.name != "zones.yaml":
            found.append(warn("CONTENT_UNEXPECTED_PATH", rel, "unexpected file at content/ top level"))
    for zone in ctx.zones:
        directory = content / zone["dir"]
        if not directory.is_dir():
            found.append(err("ZONE_DIR_MISSING", f"content/{zone['dir']}", "zone directory is missing"))
            continue
        for child in sorted(directory.iterdir()):
            if child.name in ("README.md", ".gitkeep") or (child.is_file() and child.suffix == ".md"):
                continue
            found.append(warn("CONTENT_UNEXPECTED_PATH", child.relative_to(ctx.repo.root).as_posix(), "only README.md and entry .md files belong in a zone directory"))
    return found


# ------------------------------------------------------------------------ specimen
def _check_specimen(ctx: Context) -> list[Finding]:
    """The dummy specimen must be impossible to mistake for real content."""
    found: list[Finding] = []
    if len(ctx.entries) != 1 or ctx.entries[0].fm.get("specimen") is not True:
        return [err("SPECIMEN_ENTRY_INVALID", SPECIMEN_ENTRY, "exactly one entry with specimen: true is required")]
    entry = ctx.entries[0]
    fm, where = entry.fm, entry.rel
    for key in PROSE_FIELDS:
        value = fm.get(key)
        items = [value] if isinstance(value, str) else (value or [])
        for item in items:
            if isinstance(item, str) and item.strip() and not DUMMY_RE.search(item):
                found.append(err("SPECIMEN_TEXT_NOT_MARKED", where, f"{key}: every specimen string must contain the DUMMY marker"))
    for step in fm.get("procedure", []):
        for key in ("action", "verify", "abort_if"):
            if not DUMMY_RE.search(step.get(key, "")):
                found.append(err("SPECIMEN_TEXT_NOT_MARKED", where, f"procedure step {step.get('step')} {key} must contain the DUMMY marker"))
    if nonempty(fm.get("technical_reviewer")) or nonempty(fm.get("editorial_reviewer")):
        found.append(err("SPECIMEN_HAS_REVIEWER", where, "the specimen must not name reviewers (no invented approvals)"))
    for row in ctx.reg["sources"]:
        if row["rights_status"] != "unreviewed" or row["verification_status"] != "unverified":
            found.append(err("SPECIMEN_REGISTER_STATUS", f"{ctx.labels['sources']}:row {row['_row']}", "specimen sources must stay unreviewed/unverified"))
    for row in ctx.reg["claims"]:
        if row["status"] != "UNVERIFIED":
            found.append(err("SPECIMEN_REGISTER_STATUS", f"{ctx.labels['claims']}:row {row['_row']}", "specimen claims must stay UNVERIFIED"))
    return found
