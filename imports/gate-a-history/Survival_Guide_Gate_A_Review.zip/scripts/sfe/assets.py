"""Image provenance and licensing checks (handoff sections 4 and 10).

These checks verify the *metadata and file integrity* of the asset manifest. They
cannot judge whether a license is legally sufficient or whether a photograph shows
the stated species; that stays a human review recorded in reviews/image-audit.csv.
Nothing here downloads or fetches anything.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from .common import Finding, err, sha256_file, warn
from .registry import Repo

REQUIRED_LABEL = "ILLUSTRATION — NOT FOR SPECIES IDENTIFICATION"
# Handoff section 4: "do not assume all images are public domain". These bare values
# state no license basis, so they are rejected as a license.
AMBIGUOUS_LICENSES = frozenset({
    "free", "public domain", "public-domain", "pd", "ok", "okay", "unknown", "n/a", "na",
    "none", "tbd", "unspecified", "open", "royalty free", "royalty-free", "found online",
})
APPROVED_DIR = {"photo": "assets/original_photos/", "illustration": "assets/diagrams/", "diagram": "assets/diagrams/"}
QUARANTINE_DIR = "assets/rejected_unverified/"
ID_PREFIX = {"photo": "PHO-", "illustration": "ILL-", "diagram": "ILL-"}
GENERATED = frozenset({"vector_drawing", "rendered", "ai_generated"})
# Hosts the handoff lists as typical sources; anything else is a prompt to verify, not a failure.
RECOMMENDED_HOST_SUFFIXES = (".gov", ".edu", "commons.wikimedia.org", "dnr.state.mn.us")
SUPPORTED_EXTENSIONS = frozenset({".jpg", ".jpeg", ".png", ".tif", ".tiff", ".pdf"})


def valid_http_url(url: str) -> bool:
    parts = urlparse(url)
    return parts.scheme in ("http", "https") and bool(parts.netloc) and not any(c.isspace() for c in url)


def safe_relative_path(path: str) -> bool:
    candidate = Path(path)
    return bool(candidate.parts) and not candidate.is_absolute() and ".." not in candidate.parts


def _bare(row: dict[str, Any], key: str) -> str:
    return (row.get(key) or "").strip()


def check_assets(repo: Repo, rows: list[dict[str, Any]], *, label: str, specimen: bool) -> list[Finding]:
    findings: list[Finding] = []
    manifest_paths: set[str] = set()
    for row in rows:
        where = f"{label}:row {row['_row']}"
        aid, kind = row["asset_id"], row["asset_kind"]
        approved = row["license_status"] == "approved"
        path = _bare(row, "local_path")

        if not aid.removeprefix("DUMMY-").startswith(ID_PREFIX[kind]):
            findings.append(err("ID_KIND_MISMATCH", where, f"{aid} does not match asset_kind {kind!r} (expected prefix {ID_PREFIX[kind]})"))

        # ---- paths, placement, file integrity
        if path:
            manifest_paths.add(path)
            root_dir = "layouts/specimen/" if specimen else "assets/"
            if not safe_relative_path(path) or not path.startswith(root_dir):
                findings.append(err("ASSET_PATH_UNSAFE", where, f"local_path {path!r} must be relative and under {root_dir}"))
            else:
                if approved and not path.startswith(APPROVED_DIR[kind]):
                    findings.append(err("ASSET_WRONG_DIRECTORY", where, f"approved {kind} must live under {APPROVED_DIR[kind]}"))
                if not approved and not path.startswith(QUARANTINE_DIR):
                    findings.append(err("ASSET_NOT_QUARANTINED", where, f"license_status {row['license_status']!r} items must live under {QUARANTINE_DIR}"))
                if Path(path).suffix.lower() not in SUPPORTED_EXTENSIONS:
                    findings.append(warn("ASSET_EXTENSION_UNSUPPORTED", where, f"{Path(path).suffix!r} is not a supported image type"))
                file_path = repo.path(path)
                if file_path.is_file():
                    actual = sha256_file(file_path)
                    if row.get("sha256") and actual != row["sha256"]:
                        findings.append(err("ASSET_HASH_MISMATCH", where, "file content does not match manifest sha256"))
                elif approved:
                    findings.append(err("ASSET_FILE_MISSING", where, f"approved asset file {path} does not exist"))
        elif approved:
            findings.append(err("ASSET_FILE_MISSING", where, "approved asset has no local_path"))

        # ---- licensing and provenance
        if approved:
            if _bare(row, "license").lower() in AMBIGUOUS_LICENSES:
                findings.append(err("LICENSE_AMBIGUOUS", where, f"license {row['license']!r} states no basis; name the specific license or permission (no image is assumed public domain)"))
            if not (_bare(row, "provenance_url") or _bare(row, "permission_reference")):
                findings.append(err("ASSET_PROVENANCE_INCOMPLETE", where, "need provenance_url or permission_reference"))
            if not (_bare(row, "credited_photographer") or _bare(row, "organization")):
                findings.append(err("ASSET_PROVENANCE_INCOMPLETE", where, "need credited_photographer or organization"))
            if row["review_status"] != "approved":
                findings.append(err("ASSET_REVIEW_NOT_APPROVED", where, "license approved but review_status is not approved"))
        url = _bare(row, "provenance_url")
        if url:
            host = (urlparse(url).hostname or "").lower()
            if not valid_http_url(url):
                findings.append(err("PROVENANCE_URL_INVALID", where, f"{url!r} is not a valid http(s) URL"))
            elif not specimen and (host.endswith(".invalid") or host.startswith("example.") or host == "example.com"):
                findings.append(err("PROVENANCE_URL_PLACEHOLDER", where, f"placeholder host {host!r} in real manifest"))
            elif not any(host.endswith(s) or host == s.lstrip(".") for s in RECOMMENDED_HOST_SUFFIXES):
                findings.append(warn("PROVENANCE_HOST_UNRECOGNIZED", where, f"host {host!r} is not one of the handoff's usual sources; verify the rights individually"))
        if row["review_status"] == "approved":
            if not _bare(row, "caption"):
                findings.append(err("ASSET_CAPTION_MISSING", where, "reviewed asset needs a caption"))
            if not _bare(row, "alt_text"):
                findings.append(err("ASSET_ALT_TEXT_MISSING", where, "reviewed asset needs alt text"))

        # ---- generated vs real imagery, identification evidence
        method, role = row["generation_method"], row["role"]
        subject = _bare(row, "subject_common_name") or _bare(row, "subject_scientific_or_material_name")
        if method == "ai_generated":
            if kind == "photo":
                findings.append(err("AI_ASSET_NOT_ILLUSTRATION", where, "an AI-generated image may only be an illustration, never a photo"))
            if role == "verified_diagnostic":
                findings.append(err("AI_ASSET_AS_EVIDENCE", where, "AI-generated imagery can never be identification evidence"))
        if kind == "photo" and method in GENERATED and not specimen:
            findings.append(err("PHOTO_KIND_GENERATED", where, f"asset_kind photo requires camera_photo or scan, not {method}"))
        if role == "verified_diagnostic":
            if kind != "photo" or method not in ("camera_photo", "scan"):
                findings.append(err("DIAGNOSTIC_NOT_REAL_PHOTO", where, "verified_diagnostic requires a real photograph (camera_photo or scan)"))
            if not subject:
                findings.append(err("DIAGNOSTIC_SUBJECT_MISSING", where, "diagnostic photo needs a common or scientific/material subject name"))
            if not row.get("view"):
                findings.append(err("DIAGNOSTIC_VIEW_MISSING", where, "diagnostic photo needs a view (whole, key_feature, habitat, look_alike, other)"))
        if method in GENERATED and kind in ("illustration", "diagram") and subject and _bare(row, "overlay_label") != REQUIRED_LABEL:
            findings.append(err("ILLUSTRATION_LABEL_MISSING", where, f"generated/schematic image of a subject must carry overlay_label {REQUIRED_LABEL!r}"))
        if specimen and kind == "photo" and not (role == "decorative_only" and not approved and not path):
            findings.append(err("SPECIMEN_PHOTO_SLOT_INVALID", where, "specimen photo rows are slots only: decorative_only, license pending, no file"))

    if not specimen:
        for rel_dir in sorted(set(APPROVED_DIR.values())):
            directory = repo.path(rel_dir)
            if directory.is_dir():
                for file_path in sorted(directory.rglob("*")):
                    rel = file_path.relative_to(repo.root).as_posix()
                    if file_path.is_file() and file_path.name != ".gitkeep" and rel not in manifest_paths:
                        findings.append(err("ORPHAN_ASSET_FILE", rel, "file is not listed in assets/manifest.csv; catalogue it or quarantine it"))
    return findings
