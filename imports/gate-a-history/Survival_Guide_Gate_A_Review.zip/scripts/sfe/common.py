"""Shared helpers: findings, hashing, strict YAML and strict CSV.

Strictness is deliberate: the gates fail closed, so ambiguous input (duplicate
YAML keys, yes/no booleans, BOMs, CR characters, ragged CSV rows) is an error,
not something to guess about.
"""
from __future__ import annotations

import csv
import hashlib
import io
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
HEX64_RE = re.compile(r"^[0-9a-f]{64}$")


@dataclass(frozen=True, order=True)
class Finding:
    """One validation result. Errors fail a gate; warnings are advisory (--strict promotes them)."""

    severity: str
    code: str
    where: str
    message: str

    def __str__(self) -> str:
        return f"{self.severity.upper():7s} {self.code:38s} {self.where}: {self.message}"


def err(code: str, where: str, message: str) -> Finding:
    return Finding("error", code, where, message)


def warn(code: str, where: str, message: str) -> Finding:
    return Finding("warning", code, where, message)


def errors_of(findings: list[Finding]) -> list[Finding]:
    return [f for f in findings if f.severity == "error"]


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


# --------------------------------------------------------------------------- YAML
class StrictLoader(yaml.SafeLoader):
    """SafeLoader that keeps ISO dates as strings, accepts only true/false as
    booleans (no yes/no/on/off), and rejects duplicate mapping keys."""


_DROPPED_TAGS = {"tag:yaml.org,2002:timestamp", "tag:yaml.org,2002:bool"}
StrictLoader.yaml_implicit_resolvers = {
    first: [(tag, rx) for tag, rx in resolvers if tag not in _DROPPED_TAGS]
    for first, resolvers in yaml.SafeLoader.yaml_implicit_resolvers.items()
}
StrictLoader.add_implicit_resolver(
    "tag:yaml.org,2002:bool",
    re.compile(r"^(?:true|false|True|False|TRUE|FALSE)$"),
    list("tTfF"),
)


def _construct_mapping_no_dupes(loader: StrictLoader, node: yaml.MappingNode, deep: bool = False):
    seen: set[Any] = set()
    for key_node, _value_node in node.value:
        key = loader.construct_object(key_node, deep=True)
        if key in seen:
            raise yaml.constructor.ConstructorError(
                "while constructing a mapping", node.start_mark,
                f"found duplicate key {key!r}", key_node.start_mark,
            )
        seen.add(key)
    return yaml.SafeLoader.construct_mapping(loader, node, deep)


StrictLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, _construct_mapping_no_dupes)


def load_yaml(text: str) -> Any:
    # StrictLoader subclasses SafeLoader, so no arbitrary object construction is possible.
    return yaml.load(text, Loader=StrictLoader)  # noqa: S506


# ---------------------------------------------------------------------------- CSV
class CsvError(ValueError):
    """Raised for structurally invalid CSV (encoding, line endings, ragged rows)."""


def read_csv(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    raw = path.read_bytes()
    if raw.startswith(b"\xef\xbb\xbf"):
        raise CsvError("UTF-8 BOM is not allowed")
    if b"\r" in raw:
        raise CsvError("carriage returns found; use LF line endings")
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise CsvError(f"not valid UTF-8: {exc}") from exc
    if not text.strip():
        raise CsvError("empty file: a header row is required")
    records = list(csv.reader(io.StringIO(text, newline="")))
    header = records[0]
    rows: list[dict[str, str]] = []
    for number, record in enumerate(records[1:], start=2):
        if record == []:
            raise CsvError(f"record {number}: blank line")
        if len(record) != len(header):
            raise CsvError(f"record {number}: {len(record)} fields but header has {len(header)}")
        rows.append(dict(zip(header, record)))
    return header, rows


def header_line(columns: list[str]) -> str:
    return ",".join(columns) + "\n"
