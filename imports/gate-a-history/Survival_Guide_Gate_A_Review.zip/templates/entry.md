---
# GENERAL ENTRY TEMPLATE (handoff section 3). Copy to content/<zone dir>/<ENTRY_ID>.md and fill in.
# Field names only: this template holds no survival content. Text arrives from ChatGPT-approved packs.
entry_type: general
id: ""                # zone + topic words + 3-digit sequence, e.g. Z08-CHERT-001
zone: ""              # Z01..Z16; must match the id prefix and the directory
title: ""
status: draft         # draft | researched | verified | approved | published (gated by scripts/sfe/validate.py)
region: []
season: []
what_it_is: ""
find_where: ""
find_when: ""
diagnostic_features: []
lookalikes_or_confusions: []
materials: []
procedure: []         # each item: {step: 1, action: "", verify: "", abort_if: "", claim_ids: []}
conditions_and_limits: []
dangers: []
source_ids: []        # SRC-0001 ... from research/sources.csv
claim_ids: []         # CLM-0001 ... from research/claims.csv
photo_ids: []         # PHO-0001 ... real photographs only, from assets/manifest.csv
illustration_ids: []  # ILL-0001 ... original schematics/diagrams, from assets/manifest.csv
hazard_tags: []       # HZ-... ids from schemas/hazard_topics.yaml
technical_reviewer: null
editorial_reviewer: null
approved_by_chatgpt: false   # true only at status approved/published, with a matching row in reviews/approvals.csv
revision: 1
as_of_date: ""        # date stamp for region/legal statements (required for HZ-HARVEST-LEGAL at verified+)
---
<!-- Body text arrives only from ChatGPT-approved packs. The build tooling never writes survival content. -->
