---
# SPECIES PROFILE TEMPLATE (handoff section 3, "species profiles"). Field names only; no content.
# No field-use identification may rest on a single photo or on AI alone. Plates need at least two
# complementary verified diagnostic views plus explicit uncertainty and look-alike review (handoff section 10).
# NOTE: the PDF layout for this entry type is not implemented yet, so release builds refuse it (fail closed).
entry_type: species_profile
id: ""
zone: ""
title: ""
status: draft
region: []
season: []
what_it_is: ""
find_where: ""
find_when: ""
diagnostic_features: []
lookalikes_or_confusions: []
materials: []
procedure: []
conditions_and_limits: []
dangers: []
source_ids: []
claim_ids: []
photo_ids: []         # need >= 2 verified_diagnostic photos with different views (whole, key_feature, habitat, look_alike)
illustration_ids: []  # illustrations never count as identification evidence
hazard_tags: []       # e.g. HZ-FORAGING-ID for mushrooms, plants and their poisonous look-alikes
technical_reviewer: null
editorial_reviewer: null
approved_by_chatgpt: false
revision: 1
as_of_date: ""
scientific_name: ""
taxonomic_authority: null
geographic_range: ""
phenology: ""
identification_uncertainty: ""
regulated_or_protected_status: ""
processing_restrictions: ""
positive_identification_warning: ""
expert_identification_criteria: []   # required for hard-to-identify groups (HZ-FORAGING-ID)
---
<!-- Body text arrives only from ChatGPT-approved packs. -->
