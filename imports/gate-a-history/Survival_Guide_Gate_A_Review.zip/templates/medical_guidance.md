---
# MEDICAL GUIDANCE TEMPLATE (handoff section 3, "medical guidance"). Field names only. Do not invent medical procedures.
# Entries of this type always need a passing reviews/safety-audit.csv row before approval, whether or not they carry hazard tags.
# NOTE: the PDF layout for this entry type is not implemented yet, so release builds refuse it (fail closed).
entry_type: medical_guidance
id: ""
zone: ""
title: ""
status: draft
region: []
season: []
what_it_is: ""
find_where: ""
find_when: ""
diagnostic_features: []
lookalikes_or_confusions: []
materials: []
procedure: []
conditions_and_limits: []
dangers: []
source_ids: []
claim_ids: []
photo_ids: []
illustration_ids: []
hazard_tags: []
technical_reviewer: null
editorial_reviewer: null
approved_by_chatgpt: false
revision: 1
as_of_date: ""
audience_scope: ""
evidence_date: ""            # YYYY-MM-DD of the evidence reviewed
emergency_evacuation_threshold: ""
contraindications: []
local_emergency_service_guidance: ""
---
<!-- Body text arrives only from ChatGPT-approved packs. -->
