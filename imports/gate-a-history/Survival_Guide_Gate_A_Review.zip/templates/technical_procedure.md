---
# TECHNICAL / ENGINEERING PROCEDURE TEMPLATE (handoff section 3, "engineering procedures"). Field names only.
# Every physical procedure needs, per step: the action, a verification check and an error/abort condition (handoff section 10).
entry_type: technical_procedure
id: ""
zone: ""
title: ""
status: draft
region: []
season: []
what_it_is: ""
find_where: ""
find_when: ""
diagnostic_features: []
lookalikes_or_confusions: []
materials: []
procedure: []         # each item: {step: 1, action: "", verify: "", abort_if: "", claim_ids: []}
conditions_and_limits: []
dangers: []
source_ids: []
claim_ids: []
photo_ids: []
illustration_ids: []
hazard_tags: []
technical_reviewer: null
editorial_reviewer: null
approved_by_chatgpt: false
revision: 1
as_of_date: ""
materials_tools: []
dimension_unit_table: []   # each item: {quantity: "", us_customary: "4 in", metric: "101.6 mm", claim_id: ""}; pairs must round-trip
environmental_constraints: []
inspection_acceptance_criteria: []
failure_modes: []
hazard_boundaries: []
---
<!-- Body text arrives only from ChatGPT-approved packs. -->
