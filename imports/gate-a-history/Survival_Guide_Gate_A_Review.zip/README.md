# Survival Field Encyclopedia

An original, source-traceable, region-aware, offline-first field encyclopedia (Minnesota / Upper Midwest first), produced as
16 zone PDFs plus one combined indexed master. **This repository is at Gate A: production scaffolding only.**

| | |
|---|---|
| Content written | **None.** No zone has an entry; no zone is complete. |
| Research, photos, approvals recorded | **None.** All registers are header-only. |
| What exists | Zone structure, schemas, validation and approval gates, image-provenance checks, a reproducible PDF pipeline, one labelled dummy specimen PDF, tests |
| Where the facts come from | `handoff/` (supplied by the owner, preserved byte-for-byte) |
| Status of Gate A | Evidence submitted in `RUN-001.md`; awaiting review. Nothing here claims it has passed. |

ChatGPT owns research, claims, wording and approval. The build tooling owns structure, validation, asset cataloguing and PDF
production. It never writes, edits or invents survival content (`GOVERNANCE.md`).

## Run it

```bash
make check      # integrity + all gates + tests + specimen proof + reproducibility proof
make test       # 449 tests (about 25 s)
make proof      # rebuild proofs/SPECIMEN_LAYOUT_PROOF.pdf
make release    # must REFUSE at Gate A: nothing is published
```

Prerequisites: Python 3.13 with `requirements.txt`; `pdflatex` (TeX Live 2023: latex-base, -recommended, -extra,
fonts-recommended, pictures, tex-gyre); poppler-utils; make. Details and decisions: `BUILD_PLAN.md`.

## Layout

```
handoff/                 supplied documents (never edited; hashes in PRESERVED_FILES.sha256)
content/                 zones.yaml + Z01_fundamentals/ ... Z16_field_atlas/ (README only, no entries)
templates/               entry, species profile, technical procedure, medical guidance (field names only)
schemas/                 JSON Schemas for entries, registers and ledgers; hazard_topics.yaml
research/                sources.csv, claims.csv, coverage-matrix.csv (header-only), unresolved-research.md
assets/                  manifest.csv (header-only), original_photos/, diagrams/, rejected_unverified/
reviews/                 approvals.csv, image-audit.csv, safety-audit.csv (header-only)
layouts/                 sfe.sty (the card layout), build.yaml, specimen/ (labelled dummy inputs)
scripts/sfe/             validation, gates, provenance checks, PDF pipeline, CLI
tests/                   449 tests, built on throwaway fixture repositories
proofs/                  SPECIMEN_LAYOUT_PROOF.pdf, its build manifest, colour and grayscale previews
dist/                    release output (empty; fail-closed)
```

## Documents

`PROJECT_AUDIT.md` (what was found, reconciliation, no-overwrite plan) · `BUILD_PLAN.md` (toolchain, commands, decisions for review)
· `RUN-001.md` (this run's record and Gate A evidence matrix) · `GOVERNANCE.md` (rules and gates) · `RUN-LOG.md` · `CHANGELOG.md`
· `BASELINE_AUDIT_20261116.md` (earlier audit, preserved unchanged).
