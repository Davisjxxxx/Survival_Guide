"""The command line: exit codes and the fail-closed release command."""
from __future__ import annotations

import os
import subprocess
import sys

import pytest

from factories import REAL, build_world, entry_dict, entry_hash, make_repo, write_entry
from sfe.cli import main


def cli(capsys, *args):
    code = main(list(args))
    captured = capsys.readouterr()
    return code, captured.out + captured.err


def test_validate_passes_on_the_real_repository(capsys):
    code, out = cli(capsys, "--root", str(REAL), "validate")
    assert code == 0 and "validate[content]: 0 error(s), 0 warning(s)" in out


def test_validate_specimen_passes(capsys):
    code, out = cli(capsys, "--root", str(REAL), "validate", "--specimen")
    assert code == 0 and "validate[specimen]: 0 error(s)" in out


def test_validate_fails_closed_on_a_broken_repository(tmp_path, capsys):
    repo = make_repo(tmp_path)
    write_entry(repo, entry_dict(status="verified"))  # cites sources and claims that were never registered
    code, out = cli(capsys, "--root", str(repo.root), "validate")
    assert code == 1 and "ERROR" in out and "SOURCE_NOT_REGISTERED" in out


def test_strict_promotes_warnings_to_failures(tmp_path, capsys):
    repo = make_repo(tmp_path)
    repo.path("content/Z99_extra").mkdir()
    assert cli(capsys, "--root", str(repo.root), "validate")[0] == 0
    code, out = cli(capsys, "--root", str(repo.root), "validate", "--strict")
    assert code == 1 and "CONTENT_UNEXPECTED_PATH" in out


def test_hash_entry_prints_the_approval_hash(tmp_path, capsys):
    repo = make_repo(tmp_path)
    path = write_entry(repo, entry_dict())
    code, out = cli(capsys, "hash-entry", str(path))
    assert code == 0 and out.strip() == entry_hash(path)


def test_hash_entry_rejects_garbage(tmp_path, capsys):
    bad = tmp_path / "nope.md"
    bad.write_text("not an entry", encoding="utf-8")
    assert cli(capsys, "hash-entry", str(bad))[0] == 2
    assert cli(capsys, "hash-entry", str(tmp_path / "missing.md"))[0] == 2


def test_scaffold_is_idempotent(tmp_path, capsys):
    repo = make_repo(tmp_path)
    code, out = cli(capsys, "--root", str(repo.root), "scaffold")
    assert code == 0 and out.strip() == "scaffold: done"


def test_scaffold_refuses_when_the_zone_registry_is_broken(tmp_path, capsys):
    repo = make_repo(tmp_path)
    repo.path("content/zones.yaml").write_text("schema_version: 1\nzones: []\n", encoding="utf-8")
    assert cli(capsys, "--root", str(repo.root), "scaffold")[0] == 1


def test_release_refuses_at_gate_a_and_writes_nothing(capsys):
    before = sorted(p.name for p in (REAL / "dist/zones").iterdir())
    code, out = cli(capsys, "--root", str(REAL), "release")
    assert code == 1 and "NO_PUBLISHED_ENTRIES" in out and "REFUSED" in out
    assert sorted(p.name for p in (REAL / "dist/zones").iterdir()) == before == [".gitkeep"]


def test_module_entry_point_runs():
    env = {**os.environ, "PYTHONPATH": str(REAL / "scripts")}
    proc = subprocess.run([sys.executable, "-m", "sfe", "--version"], capture_output=True, text=True, env=env, cwd=REAL, check=False)
    assert proc.returncode == 0 and proc.stdout.strip() == "sfe 0.1.0"


def test_unknown_command_is_a_usage_error():
    with pytest.raises(SystemExit) as raised:
        main(["no-such-command"])
    assert raised.value.code == 2
