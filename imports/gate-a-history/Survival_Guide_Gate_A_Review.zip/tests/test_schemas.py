"""Schemas, templates, strict parsing and the approval content hash."""
from __future__ import annotations

import json
from pathlib import Path

import pytest
from jsonschema import Draft202012Validator

from factories import REAL, entry_dict, medical_dict, species_dict
from sfe.common import CsvError, load_yaml, read_csv
from sfe.entries import canonical_body, content_sha256, parse_entry

SCHEMAS = sorted((REAL / "schemas").glob("*.schema.json"))


@pytest.mark.parametrize("path", SCHEMAS, ids=lambda p: p.name)
def test_schema_is_valid_draft_2020_12(path):
    schema = json.loads(path.read_text(encoding="utf-8"))
    Draft202012Validator.check_schema(schema)
    assert schema["$schema"].endswith("2020-12/schema")


def test_schema_ids_are_unique():
    ids = [json.loads(p.read_text(encoding="utf-8"))["$id"] for p in SCHEMAS]
    assert len(ids) == len(set(ids)) == 9


@pytest.mark.parametrize("path", SCHEMAS, ids=lambda p: p.name)
def test_schemas_reject_unknown_fields(path):
    schema = json.loads(path.read_text(encoding="utf-8"))
    if path.name == "zone.schema.json":
        assert schema["additionalProperties"] is False
        assert schema["properties"]["zones"]["items"]["additionalProperties"] is False
    else:
        assert schema["additionalProperties"] is False, "a typo in a field name must be an error, not silently ignored"


def test_entry_schema_has_every_handoff_section_3_field():
    props = set(json.loads((REAL / "schemas/entry.schema.json").read_text(encoding="utf-8"))["properties"])
    handoff = {"id", "zone", "title", "status", "region", "season", "what_it_is", "find_where", "find_when",
               "diagnostic_features", "lookalikes_or_confusions", "materials", "procedure", "conditions_and_limits", "dangers",
               "source_ids", "photo_ids", "illustration_ids", "technical_reviewer", "editorial_reviewer",
               "approved_by_chatgpt", "revision"}
    assert handoff <= props


def test_status_vocabulary_is_exactly_the_handoff_ladder():
    schema = json.loads((REAL / "schemas/entry.schema.json").read_text(encoding="utf-8"))
    assert schema["properties"]["status"]["enum"] == ["draft", "researched", "verified", "approved", "published"]


def test_handoff_example_id_is_valid():
    validator = Draft202012Validator(json.loads((REAL / "schemas/entry.schema.json").read_text(encoding="utf-8")))
    ok = entry_dict(id="Z08-CHERT-001", zone="Z08")
    assert list(validator.iter_errors(ok)) == []


# ------------------------------------------------------------------------ templates
TEMPLATES = {"entry.md": "general", "species_profile.md": "species_profile", "technical_procedure.md": "technical_procedure",
             "medical_guidance.md": "medical_guidance"}


def _required_for(schema, entry_type):
    required = set(schema["required"])
    for clause in schema["allOf"]:
        const = clause["if"].get("properties", {}).get("entry_type", {}).get("const")
        if const == entry_type:
            required |= set(clause["then"]["required"])
    return required


@pytest.mark.parametrize("name,entry_type", TEMPLATES.items())
def test_templates_carry_every_required_field_and_no_unknown_ones(name, entry_type):
    schema = json.loads((REAL / "schemas/entry.schema.json").read_text(encoding="utf-8"))
    fm, body = parse_entry((REAL / "templates" / name).read_bytes())
    assert fm["entry_type"] == entry_type
    assert _required_for(schema, entry_type) <= set(fm)
    assert set(fm) <= set(schema["properties"])
    assert fm["status"] == "draft" and fm["approved_by_chatgpt"] is False
    assert fm["technical_reviewer"] is None and fm["editorial_reviewer"] is None


@pytest.mark.parametrize("name", TEMPLATES)
def test_templates_hold_no_content(name):
    fm, body = parse_entry((REAL / "templates" / name).read_bytes())
    for key, value in fm.items():
        if key in ("entry_type", "status", "revision", "approved_by_chatgpt", "technical_reviewer", "editorial_reviewer"):
            continue
        assert value in ("", [], None), f"template field {key} must be empty"
    assert "never writes survival content" in body or "Body text arrives only" in body


# ---------------------------------------------------------------------- strict YAML
def test_yaml_dates_stay_strings():
    assert load_yaml("when: 2026-01-15\n") == {"when": "2026-01-15"}


@pytest.mark.parametrize("word", ["yes", "no", "on", "off", "y", "n", "Yes", "NO"])
def test_yaml_loose_booleans_stay_strings(word):
    assert load_yaml(f"x: {word}\n") == {"x": word}


@pytest.mark.parametrize("word,value", [("true", True), ("false", False), ("True", True), ("FALSE", False)])
def test_yaml_real_booleans(word, value):
    assert load_yaml(f"x: {word}\n") == {"x": value}


def test_yaml_duplicate_keys_are_rejected():
    with pytest.raises(Exception, match="duplicate key"):
        load_yaml("a: 1\na: 2\n")


def test_yaml_cannot_construct_python_objects():
    with pytest.raises(Exception):
        load_yaml("x: !!python/object/apply:os.system ['true']\n")


# ---------------------------------------------------------------------------- CSV
def test_csv_reader_rules(tmp_path):
    path = tmp_path / "a.csv"
    path.write_text("a,b\n1,2\n", encoding="utf-8")
    assert read_csv(path) == (["a", "b"], [{"a": "1", "b": "2"}])
    for payload, fragment in [(b"", "empty"), (b"\xef\xbb\xbfa,b\n", "BOM"), (b"a,b\r\n1,2\r\n", "carriage"),
                              (b"a,b\n1\n", "fields"), (b"a,b\n\n1,2\n", "blank")]:
        path.write_bytes(payload)
        with pytest.raises(CsvError, match=fragment):
            read_csv(path)


def test_csv_quoted_commas_and_newlines_round_trip(tmp_path):
    path = tmp_path / "q.csv"
    path.write_text('a,b\n"x, y","line1\nline2"\n', encoding="utf-8")
    assert read_csv(path)[1] == [{"a": "x, y", "b": "line1\nline2"}]


# ------------------------------------------------------------------ content hash
def _hash(fm, body="Body.\n"):
    return content_sha256(fm, body)


def test_hash_ignores_workflow_fields():
    base = entry_dict()
    moved = {**base, "status": "published", "approved_by_chatgpt": True, "technical_reviewer": "A", "editorial_reviewer": "B", "revision": 7}
    assert _hash(base) == _hash(moved)


def test_hash_changes_with_any_content_field():
    base = entry_dict()
    for key, value in (("title", "Changed"), ("what_it_is", "Changed"), ("dangers", ["Changed"]), ("source_ids", ["SRC-0002"]),
                       ("hazard_tags", ["HZ-WATER-POTABILITY"]), ("dimension_unit_table", [])):
        assert _hash({**base, key: value}) != _hash(base), key


def test_hash_covers_the_body_but_not_formatting_noise():
    fm = entry_dict()
    assert _hash(fm, "Body.\n") != _hash(fm, "Body changed.\n")
    assert _hash(fm, "Body.\n") == _hash(fm, "\n\nBody.   \n\n\n")
    assert canonical_body("a  \r\nb\n\n") == "a\nb"


def test_hash_is_independent_of_key_order():
    base = entry_dict()
    shuffled = dict(reversed(list(base.items())))
    assert _hash(base) == _hash(shuffled)


@pytest.mark.parametrize("factory", [entry_dict, species_dict, medical_dict])
def test_hash_is_64_hex(factory):
    value = _hash(factory())
    assert len(value) == 64 and set(value) <= set("0123456789abcdef")
