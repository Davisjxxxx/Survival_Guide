"""Species identification plates (handoff sections 3 and 10): photographs alone never establish identification."""
from __future__ import annotations

import pytest

from factories import add_asset, append_row, build_world, codes, safety_row, species_dict
from sfe.validate import validate_repo


def run(repo):
    return validate_repo(repo.root)


def world(repo, status="verified", views=("whole", "key_feature"), **over):
    photos = []
    for n, view in enumerate(views, start=1):
        add_asset(repo, n, view=view)
        photos.append(f"PHO-{n:04d}")
    return build_world(repo, status, fm_factory=species_dict, photo_ids=photos, **over)


def test_two_complementary_diagnostic_views_pass(repo):
    world(repo)
    assert codes(run(repo)) == set(), [str(f) for f in run(repo)]


def test_one_photo_is_not_a_plate(repo):
    world(repo, views=("whole",))
    assert "SPECIES_PLATE_VIEWS" in codes(run(repo))


def test_no_photos_is_not_a_plate(repo):
    world(repo, views=())
    assert "SPECIES_PLATE_VIEWS" in codes(run(repo))


def test_two_photos_of_the_same_view_are_not_complementary(repo):
    world(repo, views=("whole", "whole"))
    assert "SPECIES_PLATE_VIEWS" in codes(run(repo))


def test_many_photos_never_substitute_for_views(repo):
    world(repo, views=("habitat", "habitat", "habitat", "habitat"))
    assert "SPECIES_PLATE_VIEWS" in codes(run(repo))


def test_supporting_photos_do_not_count_as_diagnostic(repo):
    add_asset(repo, 1, view="whole")
    add_asset(repo, 2, view="key_feature", role="supporting_habitat")
    build_world(repo, "verified", fm_factory=species_dict, photo_ids=["PHO-0001", "PHO-0002"])
    assert "SPECIES_PLATE_VIEWS" in codes(run(repo))


def test_illustrations_never_count_as_identification_evidence(repo):
    add_asset(repo, 1, view="whole")
    add_asset(repo, 1, kind="illustration", audited=False)
    build_world(repo, "verified", fm_factory=species_dict, photo_ids=["PHO-0001"], illustration_ids=["ILL-0001"])
    assert "SPECIES_PLATE_VIEWS" in codes(run(repo))


@pytest.mark.parametrize("field", ["scientific_name", "geographic_range", "phenology", "identification_uncertainty",
                                   "regulated_or_protected_status", "processing_restrictions", "positive_identification_warning"])
def test_species_fields_are_required_to_verify(repo, field):
    world(repo, **{field: ""})
    assert "SPECIES_FIELD_EMPTY" in codes(run(repo))


def test_lookalike_review_is_required(repo):
    world(repo, lookalikes_or_confusions=[])
    assert "SPECIES_LOOKALIKES_MISSING" in codes(run(repo))


def test_hard_to_identify_groups_need_expert_criteria(repo):
    world(repo, expert_identification_criteria=[])
    assert "SPECIES_EXPERT_CRITERIA_MISSING" in codes(run(repo))


def test_cited_photo_must_have_an_approved_license(repo):
    add_asset(repo, 1, view="whole", license_status="pending", local_path="assets/rejected_unverified/PHO-0001.png",
              license=None, allowed_derivatives=None, acquired_on=None, reviewer=None, reviewed_on=None, review_status="unreviewed")
    add_asset(repo, 2, view="key_feature")
    build_world(repo, "verified", fm_factory=species_dict, photo_ids=["PHO-0001", "PHO-0002"])
    assert "ASSET_LICENSE_NOT_APPROVED" in codes(run(repo))


def test_rejected_license_can_never_be_cited(repo):
    add_asset(repo, 1, view="whole", license_status="rejected", local_path="assets/rejected_unverified/PHO-0001.png",
              license=None, allowed_derivatives=None, acquired_on=None, reviewer=None, reviewed_on=None, review_status="rejected")
    build_world(repo, "researched", fm_factory=species_dict, photo_ids=["PHO-0001"])
    assert "ASSET_REJECTED_CITED" in codes(run(repo))


def test_approved_species_entry_needs_image_and_safety_audits(repo):
    path = world(repo, status="approved")
    found = codes(run(repo))
    assert "SAFETY_AUDIT_MISSING" in found
    append_row(repo, "safety_audit", safety_row(path, ["HZ-FORAGING-ID"]))
    assert codes(run(repo)) == set()


def test_swapped_image_file_is_detected(repo):
    """The audit and manifest are bound to the file's hash, so replacing the file behind them must fail the gate."""
    from factories import make_png
    world(repo, status="approved")
    make_png(repo.path("assets/original_photos/PHO-0001.png"), color=(10, 20, 30))
    assert "ASSET_HASH_MISMATCH" in codes(run(repo))


def test_stale_image_audit_is_detected(repo):
    """If the manifest hash is re-recorded for a new file, the old audit no longer matches and must not count."""
    from factories import edit_rows, make_png
    from sfe.common import sha256_file
    world(repo, status="approved")
    make_png(repo.path("assets/original_photos/PHO-0001.png"), color=(10, 20, 30))
    new_hash = sha256_file(repo.path("assets/original_photos/PHO-0001.png"))
    edit_rows(repo, "assets", lambda rows: rows[0].update(sha256=new_hash))
    assert "IMAGE_AUDIT_STALE" in codes(run(repo))


def test_missing_image_audit_blocks_approval(repo):
    add_asset(repo, 1, view="whole", audited=False)
    add_asset(repo, 2, view="key_feature")
    build_world(repo, "approved", fm_factory=species_dict, photo_ids=["PHO-0001", "PHO-0002"])
    assert "IMAGE_AUDIT_MISSING" in codes(run(repo))


def test_failed_image_audit_blocks_approval(repo):
    add_asset(repo, 1, view="whole", audited=False)
    add_asset(repo, 2, view="key_feature")
    from factories import read_rows
    row = read_rows(repo, "assets")[0]
    append_row(repo, "image_audit", {"audit_id": "IMG-0099", "asset_id": "PHO-0001", "asset_sha256": row["sha256"],
                                     "provenance_checked": True, "license_checked": True, "identification_checked": False,
                                     "caption_alt_checked": True, "decision": "fail", "reviewer": "Fixture", "reviewer_role": "technical_reviewer",
                                     "reviewed_on": "2026-01-15"})
    build_world(repo, "approved", fm_factory=species_dict, photo_ids=["PHO-0001", "PHO-0002"])
    assert "IMAGE_AUDIT_NOT_PASSING" in codes(run(repo))
