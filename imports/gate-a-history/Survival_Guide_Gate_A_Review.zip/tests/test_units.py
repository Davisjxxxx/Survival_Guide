"""US customary <-> metric round-trip consistency (handoff section 7)."""
from __future__ import annotations

from decimal import Decimal

import pytest

from sfe.units import UnitError, check_pair, parse_quantity


@pytest.mark.parametrize("us,metric", [
    ("4 in", "101.6 mm"), ("4 in", "102 mm"), ("2 lb", "907 g"), ("50 °F", "10 °C"), ("32 °F", "0 °C"),
    ("-40 °F", "-40 °C"), ("98.6 °F", "37 °C"), ("1 gal", "3.79 L"), ("1 mi", "1.61 km"), ("1 ft", "30.5 cm"),
    ("1 qt", "946 mL"), ("14.7 psi", "101.4 kPa"), ("1 fl oz", "29.6 mL"), ("1 oz", "28 g"),
])
def test_consistent_pairs_round_trip(us, metric):
    assert check_pair(us, metric) == []


@pytest.mark.parametrize("us,metric", [
    ("4 in", "100 mm"), ("3.9 in", "100 mm"), ("4.00 in", "102 mm"), ("10 psi", "10 kPa"), ("5 °F", "5 °C"),
    ("1 gal", "3 L"), ("2 lb", "2 kg"),
])
def test_inconsistent_pairs_are_flagged(us, metric):
    assert check_pair(us, metric), f"{us} / {metric} should not round-trip"


def test_round_trip_is_checked_in_both_directions():
    problems = check_pair("4 in", "100 mm")
    assert any("converts to 102 mm" in p for p in problems)  # US -> metric direction fails
    problems = check_pair("3.9 in", "100 mm")
    assert any("converts to 99 mm" in p for p in problems)   # and this one fails the other way round


@pytest.mark.parametrize("us,metric,fragment", [
    ("4 in", "5 kg", "dimension mismatch"), ("4 mm", "4 in", "not a US customary unit"), ("4 in", "4 ft", "not a metric unit"),
    ("4 furlong", "800 m", "unknown unit"), ("four in", "100 mm", "cannot parse"), ("", "100 mm", "cannot parse"),
])
def test_unit_errors(us, metric, fragment):
    assert any(fragment in p for p in check_pair(us, metric))


def test_parse_quantity_reads_displayed_precision():
    assert parse_quantity("4 in") == (Decimal("4"), 0, "in")
    assert parse_quantity("101.60 mm") == (Decimal("101.60"), 2, "mm")
    assert parse_quantity("  -40  °F ") == (Decimal("-40"), 0, "°f")
    assert parse_quantity("1 fl oz")[2] == "fl oz"
    with pytest.raises(UnitError):
        parse_quantity("12")


def test_arithmetic_is_exact_not_floating_point():
    # 0.1 in = 2.54 mm exactly; floating point would sit on a rounding knife-edge here.
    assert check_pair("0.1 in", "2.54 mm") == []
    assert check_pair("0.5 in", "12.7 mm") == []
