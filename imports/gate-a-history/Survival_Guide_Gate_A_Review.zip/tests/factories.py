"""Fixture factories. Every test builds a throwaway repository under tmp_path; nothing touches the real tree.

All fixture text is deliberately neutral ("Fixture ...") so it carries no survival meaning and cannot be
mistaken for content. Fixture rows live only in temporary directories, never in the real registers.
"""
from __future__ import annotations

import csv
import shutil
from pathlib import Path
from typing import Any, Callable

import yaml
from PIL import Image

from sfe.common import sha256_file
from sfe.entries import content_sha256, parse_entry
from sfe.registry import REGISTERS, Repo, load_zones, scaffold

REAL = Path(__file__).resolve().parents[1]
DATE = "2026-01-15"
LADDER = ["draft", "researched", "verified", "approved", "published"]


# ----------------------------------------------------------------------- repo
def make_repo(tmp_path: Path) -> Repo:
    """A minimal repository: real schemas, layouts and zone registry, scaffolded empty."""
    for rel in ("schemas", "layouts"):
        shutil.copytree(REAL / rel, tmp_path / rel)
    (tmp_path / "content").mkdir()
    shutil.copyfile(REAL / "content/zones.yaml", tmp_path / "content/zones.yaml")
    repo = Repo(tmp_path)
    scaffold(repo)
    return repo


def zone_dir(repo: Repo, zone_id: str) -> str:
    zones, _ = load_zones(repo)
    return next(z["dir"] for z in zones if z["id"] == zone_id)


# ------------------------------------------------------------------------ CSV
def _cell(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, list):
        return "|".join(str(v) for v in value)
    return str(value)


def read_rows(repo: Repo, name: str) -> list[dict[str, str]]:
    with repo.path(REGISTERS[name][0]).open(encoding="utf-8", newline="") as fh:
        return list(csv.DictReader(fh))


def write_rows(repo: Repo, name: str, rows: list[dict[str, Any]]) -> None:
    cols = repo.columns(name)
    with repo.path(REGISTERS[name][0]).open("w", encoding="utf-8", newline="") as fh:
        writer = csv.writer(fh, lineterminator="\n")
        writer.writerow(cols)
        for row in rows:
            writer.writerow([_cell(row.get(c)) for c in cols])


def append_row(repo: Repo, name: str, row: dict[str, Any]) -> None:
    write_rows(repo, name, read_rows(repo, name) + [row])


def edit_rows(repo: Repo, name: str, fn: Callable[[list[dict[str, Any]]], None]) -> None:
    rows = read_rows(repo, name)
    fn(rows)
    write_rows(repo, name, rows)


# --------------------------------------------------------------------- rows
def source_row(**o: Any) -> dict[str, Any]:
    row = {
        "source_id": "SRC-0001", "document_title": "Fixture source", "issuing_body_author": "Fixture Agency",
        "edition_date": "2020", "url_or_local_origin": "https://fixture-agency.gov/doc", "source_type": "government",
        "access_usage_rights": "Fixture terms", "revision_date": "2021-01-01", "reliability_notes": "Fixture notes",
        "sections_pages_relevant": "p. 1", "intended_use": "claim_source", "provenance_class": "primary_publisher",
        "rights_status": "permitted", "verification_status": "verified", "verified_by": "Fixture Reviewer", "verified_on": DATE,
    }
    row.update(o)
    return row


def claim_row(**o: Any) -> dict[str, Any]:
    row = {
        "claim_id": "CLM-0001", "claim_text": "Fixture claim text.", "claim_type": "specification", "risk_level": "low",
        "source_id": "SRC-0001", "source_locator": "p. 1", "evidence_date": DATE, "status": "verified",
        "verified_by": "Fixture Reviewer", "verified_on": DATE,
    }
    row.update(o)
    return row


def entry_dict(**o: Any) -> dict[str, Any]:
    step = lambda n: {"step": n, "action": f"Fixture action {n}.", "verify": f"Fixture verify {n}.",  # noqa: E731
                      "abort_if": f"Fixture abort {n}.", "claim_ids": ["CLM-0001"]}
    fm: dict[str, Any] = {
        "entry_type": "technical_procedure", "id": "Z09-FIXTURE-001", "zone": "Z09", "title": "Fixture entry one",
        "status": "draft", "region": ["fixture_region"], "season": ["year_round"],
        "what_it_is": "Fixture what text.", "find_where": "Fixture where text.", "find_when": "Fixture when text.",
        "diagnostic_features": ["Fixture feature"], "lookalikes_or_confusions": ["Fixture lookalike"],
        "materials": ["Fixture material"], "procedure": [step(1), step(2)],
        "conditions_and_limits": ["Fixture limit"], "dangers": ["Fixture danger boundary"],
        "source_ids": ["SRC-0001"], "claim_ids": ["CLM-0001"], "photo_ids": [], "illustration_ids": [], "hazard_tags": [],
        "technical_reviewer": None, "editorial_reviewer": None, "approved_by_chatgpt": False, "revision": 1,
        "materials_tools": ["Fixture tool"],
        "dimension_unit_table": [{"quantity": "Fixture length", "us_customary": "4 in", "metric": "101.6 mm", "claim_id": "CLM-0001"}],
        "environmental_constraints": ["Fixture constraint"], "inspection_acceptance_criteria": ["Fixture criterion"],
        "failure_modes": ["Fixture failure mode"], "hazard_boundaries": ["Fixture hazard boundary"],
    }
    fm.update(o)
    return fm


def species_dict(**o: Any) -> dict[str, Any]:
    fm = entry_dict(entry_type="species_profile", id="Z05-FIXTURE-001", zone="Z05", procedure=[], claim_ids=["CLM-0001"],
                    hazard_tags=["HZ-FORAGING-ID"])
    for key in ("materials_tools", "dimension_unit_table", "environmental_constraints", "inspection_acceptance_criteria",
                "failure_modes", "hazard_boundaries"):
        del fm[key]
    fm.update({
        "scientific_name": "Fixture speciesus", "taxonomic_authority": None, "geographic_range": "Fixture range",
        "phenology": "Fixture phenology", "identification_uncertainty": "Fixture uncertainty",
        "regulated_or_protected_status": "Fixture status", "processing_restrictions": "Fixture restrictions",
        "positive_identification_warning": "Fixture warning", "expert_identification_criteria": ["Fixture expert criterion"],
    })
    fm.update(o)
    return fm


def write_entry(repo: Repo, fm: dict[str, Any], body: str = "Fixture body text.\n") -> Path:
    path = repo.path(f"content/{zone_dir(repo, fm['zone'])}/{fm['id']}.md")
    path.write_text("---\n" + yaml.safe_dump(fm, sort_keys=False, allow_unicode=True) + "---\n" + body, encoding="utf-8", newline="\n")
    return path


def entry_hash(path: Path) -> str:
    fm, body = parse_entry(path.read_bytes())
    return content_sha256(fm, body)


def approval_row(path: Path, **o: Any) -> dict[str, Any]:
    fm, _ = parse_entry(path.read_bytes())
    row = {"approval_id": "APR-0001", "entry_id": fm["id"], "revision": fm["revision"], "content_sha256": entry_hash(path),
           "decision": "approved", "approver": "Fixture ChatGPT Editorial", "approver_role": "chatgpt_editorial", "decided_on": DATE}
    row.update(o)
    return row


def safety_row(path: Path, topics: list[str], **o: Any) -> dict[str, Any]:
    fm, _ = parse_entry(path.read_bytes())
    row = {"audit_id": "SAF-0001", "entry_id": fm["id"], "revision": fm["revision"], "content_sha256": entry_hash(path),
           "topics_reviewed": topics, "decision": "pass", "reviewer": "Fixture Safety Reviewer",
           "reviewer_role": "technical_reviewer", "reviewed_on": DATE}
    row.update(o)
    return row


# --------------------------------------------------------------------- assets
def make_png(path: Path, size: tuple[int, int] = (40, 30), color: tuple[int, int, int] = (200, 200, 200)) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    Image.new("RGB", size, color).save(path, format="PNG")


def asset_row(n: int = 1, *, kind: str = "photo", **o: Any) -> dict[str, Any]:
    prefix, folder = ("PHO", "original_photos") if kind == "photo" else ("ILL", "diagrams")
    row = {
        "asset_id": f"{prefix}-{n:04d}", "asset_kind": kind, "local_path": f"assets/{folder}/{prefix}-{n:04d}.png",
        "subject_common_name": "Fixture subject", "generation_method": "camera_photo" if kind == "photo" else "vector_drawing",
        "role": "verified_diagnostic" if kind == "photo" else "schematic_illustration",
        "view": "whole" if kind == "photo" else None, "provenance_url": "https://fixture-agency.gov/photo",
        "organization": "Fixture Agency", "credited_photographer": "Fixture Photographer", "license": "Fixture-License-1.0",
        "license_status": "approved", "permission_reference": None, "allowed_derivatives": "resize and crop",
        "acquired_on": DATE, "reviewer": "Fixture Image Reviewer", "review_status": "approved", "reviewed_on": DATE,
        "caption": f"Fixture caption {n}.", "alt_text": f"Fixture alt text {n}.",
        "overlay_label": "ILLUSTRATION — NOT FOR SPECIES IDENTIFICATION" if kind != "photo" else None,
    }
    row.update(o)
    return row


def add_asset(repo: Repo, n: int = 1, *, kind: str = "photo", audited: bool = True, write_file: bool = True, **o: Any) -> dict[str, Any]:
    """Create the file, hash it, append the manifest row and (optionally) a passing image audit."""
    row = asset_row(n, kind=kind, **o)
    if write_file and row.get("local_path"):
        make_png(repo.path(row["local_path"]), color=(180 + n, 180, 180))
        row.setdefault("sha256", None)
        if not o.get("sha256"):
            row["sha256"] = sha256_file(repo.path(row["local_path"]))
    append_row(repo, "assets", row)
    if audited and row.get("sha256"):
        append_row(repo, "image_audit", {
            "audit_id": f"IMG-{len(read_rows(repo, 'image_audit')) + 1:04d}", "asset_id": row["asset_id"], "asset_sha256": row["sha256"], "provenance_checked": True,
            "license_checked": True, "identification_checked": True, "caption_alt_checked": True, "decision": "pass",
            "reviewer": "Fixture Image Reviewer", "reviewer_role": "technical_reviewer", "reviewed_on": DATE})
    return row


# ---------------------------------------------------------------------- worlds
def build_world(repo: Repo, status: str = "published", *, fm_factory: Callable[..., dict[str, Any]] = entry_dict, **over: Any) -> Path:
    """Register everything an entry needs to pass every gate up to `status`; returns the entry path."""
    rank = LADDER.index(status)
    fm = fm_factory(status=status, **over)
    if rank >= 2:
        fm["technical_reviewer"] = "Fixture Technical Reviewer"
    if rank >= 3:
        fm["editorial_reviewer"] = "Fixture Editorial Reviewer"
        fm["approved_by_chatgpt"] = True
    verified = rank >= 2
    append_row(repo, "sources", source_row(verification_status="verified" if verified else "unverified",
                                           verified_by="Fixture Reviewer" if verified else None, verified_on=DATE if verified else None))
    append_row(repo, "claims", claim_row(status="verified" if verified else "UNVERIFIED",
                                         verified_by="Fixture Reviewer" if verified else None,
                                         verified_on=DATE if verified else None, evidence_date=DATE if verified else None))
    path = write_entry(repo, fm)
    if rank >= 3:
        append_row(repo, "approvals", approval_row(path))
    set_zone(repo, fm["zone"], status="in_drafting", approved_cards=1 if rank >= 3 else 0)
    return path


def codes(findings: Any, severity: str = "error") -> set[str]:
    return {f.code for f in findings if f.severity == severity}


# ------------------------------------------------------------------ more helpers
def medical_dict(**o: Any) -> dict[str, Any]:
    fm = entry_dict(entry_type="medical_guidance", id="Z10-FIXTURE-001", zone="Z10")
    for key in ("materials_tools", "dimension_unit_table", "environmental_constraints", "inspection_acceptance_criteria",
                "failure_modes", "hazard_boundaries"):
        del fm[key]
    fm.update({"audience_scope": "Fixture audience", "evidence_date": DATE, "emergency_evacuation_threshold": "Fixture threshold",
               "contraindications": ["Fixture contraindication"], "local_emergency_service_guidance": "Fixture guidance"})
    fm.update(o)
    return fm


def set_zone(repo: Repo, zone_id: str, **fields: Any) -> None:
    """Edit one zone in the temporary repo's content/zones.yaml."""
    path = repo.path("content/zones.yaml")
    data = yaml.safe_load(path.read_text(encoding="utf-8"))
    for zone in data["zones"]:
        if zone["id"] == zone_id:
            zone.update(fields)
    path.write_text(yaml.safe_dump(data, sort_keys=False, allow_unicode=True), encoding="utf-8", newline="\n")


def rewrite_entry(path: Path, fn: Callable[[dict[str, Any]], None]) -> None:
    """Apply `fn` to an entry's front matter and write it back, keeping the body."""
    fm, body = parse_entry(path.read_bytes())
    fn(fm)
    path.write_text("---\n" + yaml.safe_dump(fm, sort_keys=False, allow_unicode=True) + "---\n" + body, encoding="utf-8", newline="\n")
