"""Register structure and source/claim rules (handoff section 5)."""
from __future__ import annotations

import pytest

from factories import (
    DATE, append_row, build_world, claim_row, codes, edit_rows, read_rows, source_row, write_rows,
)
from sfe.registry import REGISTERS, load_register
from sfe.validate import validate_repo


def run(repo):
    return validate_repo(repo.root)


def test_every_register_header_equals_its_schema_property_order(real_repo):
    for name, (rel, schema_file, _key) in REGISTERS.items():
        header = real_repo.path(rel).read_text(encoding="utf-8").splitlines()[0]
        assert header == ",".join(real_repo.schema(schema_file)["properties"]), rel


def test_mandatory_source_fields_are_exactly_handoff_section_5(real_repo):
    schema = real_repo.schema("source.schema.json")
    mandatory = ["source_id", "document_title", "issuing_body_author", "edition_date", "url_or_local_origin",
                 "source_type", "access_usage_rights", "revision_date", "reliability_notes", "sections_pages_relevant"]
    assert list(schema["properties"])[:10] == mandatory
    assert set(mandatory) <= set(schema["required"])


def test_photo_manifest_has_every_handoff_section_4_field(real_repo):
    columns = set(real_repo.columns("assets"))
    needed = {"asset_id", "local_path", "subject_common_name", "subject_scientific_or_material_name", "provenance_url",
              "organization", "credited_photographer", "license", "permission_reference", "allowed_derivatives", "acquired_on",
              "location_region", "date_observed", "role", "reviewer", "review_status", "caption", "alt_text"}
    assert needed <= columns


@pytest.mark.parametrize("name", list(REGISTERS))
def test_missing_register_fails_closed(repo, name):
    repo.path(REGISTERS[name][0]).unlink()
    assert "REGISTER_MISSING" in codes(run(repo))


@pytest.mark.parametrize("name", list(REGISTERS))
def test_header_mismatch_fails_closed(repo, name):
    path = repo.path(REGISTERS[name][0])
    path.write_text(path.read_text(encoding="utf-8").replace(",", ";", 1), encoding="utf-8")
    assert "HEADER_MISMATCH" in codes(run(repo))


@pytest.mark.parametrize("payload,fragment", [
    (b"\xef\xbb\xbf", "BOM"), (b"\r", "carriage"), (b"\xff", "UTF-8"),
])
def test_csv_encoding_problems(repo, payload, fragment):
    path = repo.path("research/sources.csv")
    original = path.read_bytes()
    path.write_bytes(payload + original if payload != b"\r" else original.replace(b"\n", b"\r\n"))
    findings = [f for f in run(repo) if f.code == "CSV_INVALID"]
    assert findings and fragment in findings[0].message


def test_ragged_and_blank_rows(repo):
    path = repo.path("research/claims.csv")
    path.write_text(path.read_text(encoding="utf-8") + "CLM-0001,only,three\n", encoding="utf-8")
    assert "CSV_INVALID" in codes(run(repo))
    path.write_text(path.read_text(encoding="utf-8").replace("CLM-0001,only,three\n", "\n"), encoding="utf-8")
    assert "CSV_INVALID" in codes(run(repo))


def test_duplicate_ids(repo):
    append_row(repo, "sources", source_row())
    append_row(repo, "sources", source_row())
    assert "DUPLICATE_ID" in codes(run(repo))


def test_enum_violations(repo):
    append_row(repo, "sources", source_row(rights_status="probably fine"))
    assert "ROW_SCHEMA" in codes(run(repo))


def test_verified_claim_needs_a_verifier(repo):
    append_row(repo, "sources", source_row())
    append_row(repo, "claims", claim_row(verified_by=None))
    assert "ROW_SCHEMA" in codes(run(repo))


def test_verified_source_needs_a_verifier(repo):
    append_row(repo, "sources", source_row(verified_by=None))
    assert "ROW_SCHEMA" in codes(run(repo))


def test_claim_needs_a_source_locator(repo):
    append_row(repo, "sources", source_row())
    append_row(repo, "claims", claim_row(source_locator=""))
    assert "ROW_SCHEMA" in codes(run(repo))


def test_mandatory_source_fields_cannot_be_blank(repo):
    append_row(repo, "sources", source_row(reliability_notes=""))
    assert "ROW_SCHEMA" in codes(run(repo))


def test_benchmark_only_sources_cannot_back_a_claim(repo):
    append_row(repo, "sources", source_row(intended_use="benchmark_only"))
    append_row(repo, "claims", claim_row())
    assert "BENCHMARK_SOURCE_CITED" in codes(run(repo))


def test_claim_source_must_exist(repo):
    append_row(repo, "claims", claim_row(source_id="SRC-0042"))
    assert "CLAIM_SOURCE_UNKNOWN" in codes(run(repo))


def test_verified_claim_needs_a_verified_source(repo):
    append_row(repo, "sources", source_row(verification_status="unverified", verified_by=None, verified_on=None))
    append_row(repo, "claims", claim_row())
    assert "CLAIM_VERIFIED_ON_UNVERIFIED_SOURCE" in codes(run(repo))


@pytest.mark.parametrize("provenance", ["third_party_mirror", "unknown"])
def test_permitted_needs_provenance_beyond_a_mirror(repo, provenance):
    append_row(repo, "sources", source_row(provenance_class=provenance))
    assert "RIGHTS_PERMITTED_WITHOUT_PROVENANCE" in codes(run(repo))


def test_permission_reference_unlocks_a_mirrored_source(repo):
    append_row(repo, "sources", source_row(provenance_class="third_party_mirror", permission_reference="Publisher email 2026-01-10"))
    assert "RIGHTS_PERMITTED_WITHOUT_PROVENANCE" not in codes(run(repo))


def test_permitted_needs_stated_usage_terms(repo):
    append_row(repo, "sources", source_row(access_usage_rights="UNKNOWN"))
    assert "RIGHTS_PERMITTED_UNKNOWN_TERMS" in codes(run(repo))


def test_unknown_is_acceptable_for_unreviewed_rights(repo):
    append_row(repo, "sources", source_row(access_usage_rights="UNKNOWN", rights_status="unreviewed", verification_status="unverified",
                                           verified_by=None, verified_on=None))
    assert codes(run(repo)) == set()


def test_source_url_must_be_valid(repo):
    append_row(repo, "sources", source_row(url_or_local_origin="https://bad host/x"))
    assert "SOURCE_URL_INVALID" in codes(run(repo))


@pytest.mark.parametrize("url", ["https://example.invalid/x", "https://example.org/x"])
def test_placeholder_source_urls_are_rejected_in_real_register(repo, url):
    append_row(repo, "sources", source_row(url_or_local_origin=url))
    assert "SOURCE_URL_PLACEHOLDER" in codes(run(repo))


def test_local_copy_checks(repo):
    from sfe.common import sha256_bytes
    (repo.path("research") / "copy.txt").write_text("fixture copy", encoding="utf-8")
    good = sha256_bytes(b"fixture copy")
    append_row(repo, "sources", source_row(local_copy_path="research/copy.txt", local_sha256=good))
    assert codes(run(repo)) == set()
    edit_rows(repo, "sources", lambda rows: rows[0].update(local_sha256="0" * 64))
    assert "SOURCE_LOCAL_COPY_MISMATCH" in codes(run(repo))
    edit_rows(repo, "sources", lambda rows: rows[0].update(local_sha256=""))
    assert "SOURCE_LOCAL_COPY_UNHASHED" in codes(run(repo))
    edit_rows(repo, "sources", lambda rows: rows[0].update(local_copy_path="research/absent.txt", local_sha256=good))
    assert "SOURCE_LOCAL_COPY_MISSING" in codes(run(repo))
    edit_rows(repo, "sources", lambda rows: rows[0].update(local_copy_path="../escape.txt"))
    assert "SOURCE_LOCAL_COPY_UNSAFE" in codes(run(repo))


def test_dummy_ids_are_rejected_in_real_registers(repo):
    append_row(repo, "sources", source_row(source_id="DUMMY-SRC-0001"))
    assert "DUMMY_ID_IN_REAL_REGISTER" in codes(run(repo))


def test_list_cells_use_pipe_separator(repo):
    append_row(repo, "claims", claim_row(entry_ids=["Z09-A-001", "Z09-B-002"]))
    rows, _ = load_register(repo, "claims")
    assert rows[0]["entry_ids"] == ["Z09-A-001", "Z09-B-002"]


def test_empty_cells_become_null_for_optional_fields(repo):
    append_row(repo, "sources", source_row(permission_reference=None))
    rows, _ = load_register(repo, "sources")
    assert rows[0]["permission_reference"] is None and rows[0]["document_title"] == "Fixture source"
