# Governance

Source of authority: `handoff/SURVIVAL_FIELD_ENCYCLOPEDIA_ASTRA_CLI_HANDOFF.md` (the handoff) and
`handoff/Survival_Field_Encyclopedia_Master_Sprint_Plan_v1.md` (the plan). Where this file restates them it cites the section.
Where it adds an engineering rule it says so. Rules marked **[gate]** are enforced by code and tested; the rest are procedure.

## Roles (handoff section 0)

| Role | Owns | Never |
|---|---|---|
| ChatGPT (GPT-6 High / Extra High) | Research, claims, source evaluation, wording, species and photo decisions, content approval, final safety sign-off | |
| Build tooling and its operator | Structure, schemas, validation, build automation, asset cataloguing, provenance checks, PDF production, tests, Git records | Invent claims, write safety-critical advice, rewrite approved text, treat an unreviewed AI identification as authoritative |
| Qualified specialists | Positive identification of high-risk fungi and plants, medical, trade and food-preservation review | Be replaced by an AI |
| Owner | Priorities, every gate decision, real-world tests, any publication, merge to `main`, any remote or deployment | |

The ChatGPT research is the editorial source of truth. The build is an implementation artifact, not a scientific authority.

## Non-negotiable rules (handoff sections 0, 4, 5, 6)

1. Never invent survival claims or fill a gap with plausible text. Missing research becomes a `NEEDS_CHAT_RESEARCH` card in `research/unresolved-research.md`.
2. Never substitute a plausible diagram for a verified one. Original diagrams come only from approved briefs. **[gate]** AI-generated images are never photographs and never identification evidence; generated or schematic images of a subject carry `ILLUSTRATION — NOT FOR SPECIES IDENTIFICATION`.
3. Never silently rewrite approved text. **[gate]** An approval is bound to one revision and one content hash; any later change makes it stale and the entry fails closed.
4. Never copy copyrighted text, figures or distinctive structure from commercial guides. Comparator titles are benchmarks only. **[gate]** `benchmark_only` sources can never back a claim.
5. Never treat a PDF as authorised because a third-party site offers it. **[gate]** A mirrored or unknown-provenance source cannot be `permitted` without a recorded permission.
6. Never assume an image is public domain. **[gate]** A bare "free" or "public domain" is rejected as a license; each image needs a specific license or permission, a credit, a recorded human review and a file hash.
7. Photographs alone never establish edibility or identity. **[gate]** A species plate needs at least two complementary verified diagnostic views, an explicit uncertainty statement and a look-alike review; hard-to-identify groups need expert criteria.

## The status ladder **[gate]**

Each status includes every one below it. Nothing advances without the recorded evidence.

| Status | Needs |
|---|---|
| `draft` | Well-formed shape. Ids that are present should resolve (warning only). |
| `researched` | At least one registered source; every procedure step carries claim ids that resolve; every claim rests on a source the entry lists. |
| `verified` | All claims and sources `verified`; named technical reviewer; every step has an action, a verification check and an abort condition; hazardous entries state danger boundaries; type-specific fields (species, procedure, medical) present; unit pairs round-trip; no placeholder text; cited images have an approved license. |
| `approved` | Named editorial reviewer; `approved_by_chatgpt: true`; a current `chatgpt_editorial` row in `reviews/approvals.csv` bound to the exact content hash; a passing `reviews/safety-audit.csv` row for hazardous or medical entries; a passing `reviews/image-audit.csv` row for every cited image. |
| `published` | Every cited image reviewed, captioned and with alt text. Release builds include **only** `published` entries and refuse to build when there are none. |

Zones: `complete` is allowed only when the zone has entries, every one is `published` and no coverage row for it is open.
`approved_cards` must equal the number of approved or published entries.

## Hazard topics **[gate]**

`schemas/hazard_topics.yaml` encodes the six physical fact checks of handoff section 6 (ignition sparks, water potability,
combustion and carbon monoxide, mushroom/plant identification, harvest legality, canning and preservation). An entry tagged with
any of them, and every `medical_guidance` entry, cannot be approved or published without a passing, non-stale safety audit that
covers each tag. Each topic lists what the reviewer must confirm; that list is a review checklist, not publishable text.

## Change control

- Approved text changes only through a new `revision`, a new approval and a shown diff (handoff section 12).
- Research arrives as ChatGPT-approved packs (files or pasted text). Register sources and claims first, then entries, then run `make check`.
- Reviews and approvals are attestations supplied by the reviewer. The tooling never creates a reviewer's name, a review row or an approval.

## Git and release authority

- Work happens on feature branches. `main` does not exist yet and must not be created or committed to without the owner's explicit authorization.
- No remote, push, deployment, upload or release without the owner's explicit authorization.
- `handoff/` and `BASELINE_AUDIT_20261116.md` are preserved byte-for-byte; `PRESERVED_FILES.sha256` and `tests/test_preservation.py` enforce it.
- Do not initialise or change any other project.
