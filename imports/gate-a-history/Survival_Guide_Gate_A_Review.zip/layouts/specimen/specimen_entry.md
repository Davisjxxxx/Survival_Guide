---
# LABELLED DUMMY SPECIMEN: exists only to exercise the layout, schema and gates.
# Every string carries the DUMMY marker; nothing here has field meaning, a real
# source, a real photograph or any approval. scripts/sfe/validate.py (--specimen)
# refuses this file if any prose string lacks the marker or any reviewer is named.
specimen: true
entry_type: technical_procedure
id: DUMMY-ZXX-SPECIMEN-001
zone: ZXX
title: "[DUMMY] SPECIMEN LAYOUT ENTRY"
status: draft
region: ["[DUMMY] region"]
season: ["[DUMMY] season"]
what_it_is: "[DUMMY] Stand-in text for the WHAT field. It has no field meaning."
find_where: "[DUMMY] Stand-in text for the WHERE field."
find_when: "[DUMMY] Stand-in text for the WHEN field."
diagnostic_features:
  - "[DUMMY] identification feature A (stand-in)"
  - "[DUMMY] identification feature B (stand-in)"
lookalikes_or_confusions:
  - "[DUMMY] look-alike A (stand-in)"
materials:
  - "[DUMMY] material one (stand-in)"
  - "[DUMMY] material two (stand-in)"
procedure:
  - step: 1
    action: "[DUMMY] Action one (stand-in, no operational meaning)."
    verify: "[DUMMY] Check one (stand-in)."
    abort_if: "[DUMMY] Abort condition one (stand-in)."
    claim_ids: [DUMMY-CLM-0000]
  - step: 2
    action: "[DUMMY] Action two (stand-in, no operational meaning)."
    verify: "[DUMMY] Check two (stand-in)."
    abort_if: "[DUMMY] Abort condition two (stand-in)."
    claim_ids: [DUMMY-CLM-0000]
  - step: 3
    action: "[DUMMY] Action three (stand-in, no operational meaning)."
    verify: "[DUMMY] Check three (stand-in)."
    abort_if: "[DUMMY] Abort condition three (stand-in)."
    claim_ids: [DUMMY-CLM-0000]
conditions_and_limits:
  - "[DUMMY] Regional or legal limitation (stand-in)."
dangers:
  - "[DUMMY] Danger boundary (stand-in)."
source_ids: [DUMMY-SRC-0000]
claim_ids: [DUMMY-CLM-0000]
photo_ids: [DUMMY-PHO-0000]
illustration_ids: [DUMMY-ILL-0000]
hazard_tags: []
technical_reviewer: null
editorial_reviewer: null
approved_by_chatgpt: false
revision: 1
materials_tools:
  - "[DUMMY] tool one (stand-in)"
dimension_unit_table:
  - {quantity: "[DUMMY] length A", us_customary: "4 in", metric: "101.6 mm", claim_id: DUMMY-CLM-0000}
  - {quantity: "[DUMMY] mass B", us_customary: "2 lb", metric: "907 g", claim_id: DUMMY-CLM-0000}
  - {quantity: "[DUMMY] temperature C", us_customary: "50 °F", metric: "10 °C", claim_id: DUMMY-CLM-0000}
environmental_constraints:
  - "[DUMMY] environmental constraint (stand-in)"
inspection_acceptance_criteria:
  - "[DUMMY] acceptance criterion (stand-in)"
failure_modes:
  - "[DUMMY] failure mode (stand-in)"
hazard_boundaries:
  - "[DUMMY] hazard boundary (stand-in)"
---
[DUMMY] Body text is intentionally empty of content. Long-form body rendering is a later sprint.
