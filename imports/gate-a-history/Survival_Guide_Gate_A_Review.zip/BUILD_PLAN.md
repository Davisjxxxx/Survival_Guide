# Build plan

Scope: the production engineering for the Survival Field Encyclopedia (handoff section 11, item 2). It records the toolchain decisions, the
dependencies, the build and test commands, the architecture, and what the Gate A reviewer must decide. It says nothing about content.

## 1. Toolchain decisions

| # | Decision | Choice | Evidence and alternatives |
|---|---|---|---|
| T1 | Typesetting engine | **pdfLaTeX**, TeX Live 2023 (Debian) | A spike built the same page twice in different directories, with different file times and time zones: byte-identical. **LuaLaTeX was tried first and failed**: `module 'luaotfload-main' not found` (the `texlive-luatex` package is not installed). Chrome headless writes a creation date and ID that cannot be fixed. `reportlab`, `weasyprint`, `typst`, `pandoc` and `qpdf` are not installed. Nothing was installed from the network. |
| T2 | Fonts | **TeX Gyre Heros** (text) and **TeX Gyre Cursor** (identifiers), Type 1, from the TeX tree | All fonts are embedded in the PDF (checked). Their file hashes are recorded in every build manifest, so font drift is visible. |
| T3 | Reproducibility | `SOURCE_DATE_EPOCH` fixed in `layouts/build.yaml` (`1794787200`), `FORCE_SOURCE_DATE=1`, `TZ=UTC`, fixed job name, no wall clock anywhere | `make repro` builds twice in unrelated directories and compares SHA-256 and manifests. The epoch is a pipeline setting changed deliberately per release. |
| T4 | Hardening | `--no-shell-escape`, `openin_any=p`, `openout_any=p`, every field passed through a strict escaper | Tests prove a hostile string is printed literally and executes nothing, shell escape is off, and TeX cannot read `/etc/passwd`. A test pins the flags themselves. |
| T5 | PDF QA | **poppler only** (`pdfinfo`, `pdffonts`, `pdftotext -bbox`, `pdftohtml -xml`, `pdftoppm`), run as separate processes | One apt package. PyMuPDF is installed but is AGPL and was not made a dependency. |
| T6 | Structural objects | Written uncompressed (`\pdfobjcompresslevel=0`) | Language, links and viewer preferences can then be audited with plain tools. Streams stay compressed. Cost: a slightly larger file. |
| T7 | Entry format | YAML front matter plus Markdown body, strict loader | Strict: duplicate keys are errors, only `true`/`false` are booleans, dates stay strings. |
| T8 | Registers | CSV (UTF-8, LF, no BOM), column order = schema property order | One source of truth for shape and header. Lists use `\|`. |
| T9 | Gates | Python 3.13, JSON Schema 2020-12 for shape, Python for cross-references and the ladder | Fail closed everywhere: an unparseable file, an unknown id or a stale approval is an error. |

Honest consequences of T1: text is Latin only (T1 encoding with UTF-8 input: fine for English and accented Latin names, no OpenType
features), and **PDFs are untagged** (`Tagged: no`): TeX Live 2023 has no kernel-level tagging. See decision D1.

## 2. Dependencies

Nothing was installed for this project. All of it was already present.

| Kind | Item | Version tested |
|---|---|---|
| System | pdfTeX (`texlive-latex-base`, `-recommended`, `-extra`, `-fonts-recommended`, `-pictures`, `tex-gyre`) | 3.141592653-2.6-1.40.25 (TeX Live 2023/Debian) |
| System | poppler-utils | 26.01.0 |
| System | git, make | 2.43.0, GNU make |
| Python 3.13.0 | PyYAML, jsonschema, Pillow | 6.0.2, 4.19.1, 11.2.1 |
| Python (tests only) | openpyxl, pytest | 3.1.5, 8.2.2 |

## 3. Commands

| Command | Does |
|---|---|
| `make check` | integrity, content gates, specimen gates, all tests, proof build, reproducibility proof |
| `make verify-preserved` | `sha256sum -c` on `PRESERVED_FILES.sha256` and `handoff/SHA256SUMS.txt` |
| `make validate` / `make validate-specimen` | every gate on `content/` and the registers / on the labelled specimen |
| `make test` | the full test suite (`pytest -m gate_a_snapshot` runs only the Gate A baseline guards) |
| `make proof` | rebuild `proofs/SPECIMEN_LAYOUT_PROOF.pdf`, its manifest and previews |
| `make repro` | prove byte-reproducibility |
| `make release` | zone PDFs from `published` entries only. **It must refuse at Gate A.** |
| `python -m sfe scaffold` | create missing zone directories, generated READMEs and header-only registers; never overwrites hand edits |
| `python -m sfe hash-entry FILE` | print the content hash an approval row must carry |
| `python -m sfe proof --profile a4` | A4 variant (tested; not committed) |

All commands run with `PYTHONPATH=scripts` (the Makefile sets it).

## 4. Architecture

```
content/*.md + research/*.csv + assets/manifest.csv + reviews/*.csv + schemas/ + content/zones.yaml
          │
          ▼  validate (scripts/sfe/validate.py, assets.py, units.py)        any error stops here
 status ladder · cross-references · approvals bound to content hash · safety audits · image audits · provenance
          │
          ▼  texgen.py: strict escape + layouts/sfe.sty                      unsupported entry types refuse to render
 main.tex  ──►  pdflatex (fixed epoch, no shell escape) until aux/out are stable
          │
          ▼  log gate: overflow, undefined reference, dead link target, missing glyph, font substitution = errors
          ▼  qa.py: pages, size, title, date, language, fonts embedded, required text, standard section order,
          │         margins, bookmarks, link + destination, colour and grayscale renders
          ▼  manifest (input hashes, toolchain, font hashes, output hash)  ──►  proofs/  or  dist/zones/
```

The specimen uses its own registers under `layouts/specimen/` (all ids `DUMMY-…`) so the real registers stay untouched. `release` reads only the
real tree and writes nothing unless every gate passes and at least one entry is `published`.

## 5. Repository layout against handoff section 8

The workspace root `/home/jd/Survival_Guide` plays the role of `survival-field-encyclopedia/`. Everything in the handoff layout exists.
Additions: `schemas/` (machine-readable contracts), `templates/medical_guidance.md` (handoff section 3 gives medical entries their own fields),
`layouts/specimen/`, `PRESERVED_FILES.sha256`, `PROJECT_AUDIT.md`, `BUILD_PLAN.md`, `RUN-001.md`, `GOVERNANCE.md`, `Makefile`, `scripts/sfe/`.

## 6. Schema fields added beyond handoff section 3 (for review)

`entry_type` (selects the species, procedure or medical field sets the handoff describes) · `claim_ids` and per-step `claim_ids` (traceability, section 5) ·
per-step `abort_if` (the "error/abort condition", section 10) · `hazard_tags` (section 6 gates) · `as_of_date` (region/legal date stamps) ·
`dimension_unit_table` rows with `claim_id` (US and metric, section 7) · `expert_identification_criteria` ("additional expert criteria", section 10) ·
`specimen` (marks the dummy). Register columns beyond the mandatory ones are listed in each schema's description.

## 7. Tests

449 tests, about 25 seconds, all on throwaway repositories with neutral "Fixture" text, so no test puts survival content on disk.

| Suite | Proves |
|---|---|
| `test_validation_gates`, `test_hazard_gates`, `test_species_gates` | every rung of the ladder, every handoff-section-6 topic, the species-plate rules, stale approvals and audits |
| `test_assets`, `test_registers` | provenance, licensing, quarantine, AI-image and label rules; source and claim rules; CSV strictness |
| `test_zones`, `test_handoff_consistency`, `test_schemas`, `test_units` | structure matches the supplied documents; schema, template and hash behaviour; round-trip units |
| `test_texgen`, `test_layout_contrast`, `test_pdf_pipeline` | escaping, the optional-argument traps, the log gate, QA gates that can fail, reproducibility, release path with real images, hardening, contrast ratios |
| `test_preservation`, `test_gate_a_snapshot`, `test_cli` | supplied files unchanged; no content, research, photo or approval exists; fail-closed `release` |

Sensitivity was checked by sabotaging eight safeguards one at a time in scratch copies (approval staleness, AI-as-evidence, backslash escaping,
safety-audit requirement, claim verification, release fail-closed, shell escape enabled, shell-escape flag dropped); the suite failed each time.

## 8. Known limitations (stated plainly)

1. **The gates check evidence and consistency, never truth.** A verified claim is only as good as its reviewer.
2. **Approvals are attestations in a CSV ledger.** There is no cryptographic signing; integrity relies on Git history and the owner's review.
3. **Image rights are checked as metadata only.** Whether a license is legally sufficient, or a photograph shows the stated species, stays a human review.
4. **No network access was used or implemented.** Online link checking and source retrieval are not built.
5. **Real photographs are untested.** Image embedding was tested with synthetic PNGs; real JPEG and colour-profile handling is unproven.
6. **Layouts exist only for `general` and `technical_procedure`.** Species and medical entries refuse to render (fail closed) until their layouts exist.
7. **Not built yet:** body-text rendering, multi-page flow polish, table of contents, glossary, indexes, cross-references, combined PDF, phone profile, EPUB/HTML, tagged PDF.
8. **Reproducibility holds per toolchain.** Another TeX Live or poppler version may differ; manifests record versions, and the byte-comparison test skips (with the reason) when the toolchain differs.

## 9. Decisions requested at Gate A

| # | Decision | Recommendation |
|---|---|---|
| D1 | **Accessibility and engine.** PDFs are untagged. Accept for proofs, or approve a spike for tagged output (TeX Live 2025+ kernel tagging, or Typst/WeasyPrint)? Needs an install, so it needs the owner's authorization. | Accept for Gate A; run the spike before S13, with the accessibility gate (tracker `GH`) as the deadline. |
| D2 | Schema additions in §6. | Approve. |
| D3 | **Unit policy:** US and metric values must round-trip in both directions at their displayed precision (`4 in / 100 mm` fails; `4 in / 102 mm` passes). | Approve; relax only by explicit rule. |
| D4 | Directory names for Z02–Z15 (the handoff names only Z01 and Z16). | Approve, or supply names. |
| D5 | **Gate naming:** pick one vocabulary from the three in `PROJECT_AUDIT.md` §3. | Adopt the plan's A0…H2 and update the handoff and tracker. |
| D6 | Which coverage list is authoritative: handoff §2 or the tracker's "Required subtopics". | Handoff §2, with the tracker as a planning aid. |
| D7 | Per-zone "placeholder entries": the gates forbid dummy markers in `content/`. Still wanted? | No; the specimen and templates suffice. |
| D8 | Merge: `gate-a/scaffold` has no `main` to merge into. Creating `main` needs the owner's authorization. | Owner decides after review. |
| D9 | Hazard topics: the six of section 6 plus "every medical entry". Any others to gate? | Approve; ChatGPT may extend the list. |

## 10. Proposed engineering next steps (proposals, not commitments; no content)

- **S02:** a pack-ingest command that validates a ChatGPT pack into the registers; authority-source checks for the water and preservation topics.
- **S03:** body-text rendering, multi-page cards, phone profile; a 12-card pilot layout review.
- **S04:** diagram pipeline from approved specifications only.
- **S06:** species and plate layout, rights-audit report, photo ingest with ICC handling.
- **S13:** table of contents, glossary, indexes, cross-references, combined PDF, coverage report that names incomplete subjects.
- **S15:** print and mobile profiles, accessibility, attribution ledger, release package.
